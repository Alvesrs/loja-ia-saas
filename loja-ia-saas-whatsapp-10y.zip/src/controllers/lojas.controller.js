const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { ehStringNaoVazia } = require('../utils/validacao');

const TAMANHO_MAXIMO_PROMPT_MESTRE = 12000;

async function criarLoja(req, res) {
  const { nome } = req.body || {};
  const valorPrompt = req.body ? req.body.prompt_mestre : undefined;

  if (!ehStringNaoVazia(nome)) {
    return res.status(400).json({ erro: 'Informe o nome da loja.' });
  }

  if (valorPrompt !== undefined && typeof valorPrompt !== 'string') {
    return res.status(400).json({ erro: 'Envie o campo \"prompt_mestre\" como texto.' });
  }

  const promptMestre = typeof valorPrompt === 'string' ? valorPrompt.trim() : '';
  if (promptMestre.length > TAMANHO_MAXIMO_PROMPT_MESTRE) {
    return res.status(400).json({ erro: `A Prompt Mestre deve ter no máximo ${TAMANHO_MAXIMO_PROMPT_MESTRE} caracteres.` });
  }

  const { data, error } = await supabase
    .from('lojas')
    .insert({ nome: nome.trim(), dono_id: req.usuario.id, prompt_mestre: promptMestre || null })
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.status(201).json(data);
}

async function listarMinhasLojas(req, res) {
  const { data, error } = await supabase
    .from('lojas')
    .select('*')
    .eq('dono_id', req.usuario.id)
    .order('criado_em', { ascending: false });

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

async function atualizarPromptMestre(req, res) {
  const { lojaId } = req.params;
  const valor = req.body ? req.body.prompt_mestre : undefined;

  if (typeof valor !== 'string') {
    return res.status(400).json({ erro: 'Envie o campo "prompt_mestre" como texto.' });
  }

  const promptMestre = valor.trim();
  if (promptMestre.length > TAMANHO_MAXIMO_PROMPT_MESTRE) {
    return res.status(400).json({ erro: `A Prompt Mestre deve ter no máximo ${TAMANHO_MAXIMO_PROMPT_MESTRE} caracteres.` });
  }

  const { data, error } = await supabase
    .from('lojas')
    .update({ prompt_mestre: promptMestre || null })
    .eq('id', lojaId)
    .eq('dono_id', req.usuario.id)
    .select('id, nome, ativa, criado_em, prompt_mestre')
    .maybeSingle();

  if (error) return tratarErroBanco(res, error);
  if (!data) return res.status(404).json({ erro: 'Loja não encontrada.' });
  return res.json(data);
}

module.exports = { criarLoja, listarMinhasLojas, atualizarPromptMestre, TAMANHO_MAXIMO_PROMPT_MESTRE };

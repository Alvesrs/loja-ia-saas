// Controller da página Atendente IA.
//
// Esta página é só um painel de TESTE para o lojista: envia a pergunta
// exatamente como o cliente final enviaria, para o mesmo endpoint
// público já existente na Etapa 9E:
//
//   POST /api/lojas/:lojaId/ia/perguntar   body: { pergunta }   resp: { resposta }
//
// O :lojaId nunca é digitado pelo usuário — vem de obterLojaAtual(),
// que só lista as lojas do usuário autenticado (GET /api/lojas). Isso
// segue o mesmo padrão já usado em produtos.js/estoque.js: o frontend
// não decide autorização, só usa a loja que o backend já confirmou
// pertencer ao lojista logado.
//
// O histórico da conversa vive só em memória (nesta variável). Ao
// recarregar a página, começa uma conversa nova — não há banco nem
// persistência para isso nesta etapa.

let lojaAtualIdChat = null;
let enviandoPergunta = false;
let primeiraMensagemEnviada = false;

const chatContainerEl = document.getElementById('chat-container');
const chatSemLojaEl = document.getElementById('chat-sem-loja');
const chatMensagensEl = document.getElementById('chat-mensagens');
const chatEstadoInicialEl = document.getElementById('chat-estado-inicial');
const chatErroEl = document.getElementById('chat-erro');
const formChatEl = document.getElementById('form-chat');
const campoPerguntaEl = document.getElementById('campo-pergunta');
const botaoEnviarEl = document.getElementById('botao-enviar-pergunta');
const promptCardEl = document.getElementById('prompt-card');
const campoPromptEl = document.getElementById('campo-prompt-mestre');
const botaoSalvarPromptEl = document.getElementById('botao-salvar-prompt');
const promptStatusEl = document.getElementById('prompt-status');
const promptContadorEl = document.getElementById('prompt-contador');

function escaparHtmlChat(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML;
}

function rolarParaFinal() {
  chatMensagensEl.scrollTop = chatMensagensEl.scrollHeight;
}

function removerEstadoInicial() {
  if (!primeiraMensagemEnviada) {
    chatEstadoInicialEl.remove();
    primeiraMensagemEnviada = true;
  }
}

function adicionarMensagem(texto, autor) {
  removerEstadoInicial();
  const bolha = document.createElement('div');
  bolha.className = `chat-msg chat-msg-${autor}`;
  bolha.textContent = texto;
  chatMensagensEl.appendChild(bolha);
  rolarParaFinal();
  return bolha;
}

function mostrarDigitando() {
  removerEstadoInicial();
  const bolha = document.createElement('div');
  bolha.className = 'chat-msg chat-msg-atendente chat-msg-digitando';
  bolha.id = 'chat-digitando';
  bolha.setAttribute('aria-live', 'polite');
  bolha.innerHTML = '<span class="chat-dot"></span><span class="chat-dot"></span><span class="chat-dot"></span>';
  chatMensagensEl.appendChild(bolha);
  rolarParaFinal();
}

function removerDigitando() {
  const el = document.getElementById('chat-digitando');
  if (el) el.remove();
}

function mostrarErroChat(mensagem) {
  chatErroEl.textContent = mensagem;
  chatErroEl.classList.remove('hidden');
}

function limparErroChat() {
  chatErroEl.classList.add('hidden');
  chatErroEl.textContent = '';
}

async function enviarPergunta(pergunta) {
  if (enviandoPergunta) return;
  enviandoPergunta = true;
  botaoEnviarEl.disabled = true;
  campoPerguntaEl.disabled = true;
  limparErroChat();

  adicionarMensagem(pergunta, 'usuario');
  mostrarDigitando();

  try {
    const resultado = await apiFetch(`/lojas/${lojaAtualIdChat}/ia/perguntar`, {
      method: 'POST',
      body: JSON.stringify({ pergunta }),
    });
    removerDigitando();
    adicionarMensagem(resultado && resultado.resposta ? resultado.resposta : 'Não foi possível obter uma resposta agora. Tente novamente.', 'atendente');
  } catch (erro) {
    removerDigitando();
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErroChat(erro.message || 'Não foi possível obter uma resposta agora. Tente novamente.');
  } finally {
    enviandoPergunta = false;
    botaoEnviarEl.disabled = false;
    campoPerguntaEl.disabled = false;
    campoPerguntaEl.focus();
  }
}

formChatEl.addEventListener('submit', (evento) => {
  evento.preventDefault();
  if (enviandoPergunta) return;

  const pergunta = campoPerguntaEl.value.trim();
  if (!pergunta) return;

  campoPerguntaEl.value = '';
  enviarPergunta(pergunta);
});


function atualizarContadorPrompt() {
  if (promptContadorEl && campoPromptEl) promptContadorEl.textContent = String(campoPromptEl.value.length);
}

function mostrarStatusPrompt(texto, erro = false) {
  promptStatusEl.textContent = texto;
  promptStatusEl.classList.toggle('erro', erro);
}

async function salvarPromptMestre() {
  if (!lojaAtualIdChat) return;
  botaoSalvarPromptEl.disabled = true;
  mostrarStatusPrompt('Salvando…');
  try {
    const lojaAtualizada = await apiFetch(`/lojas/${lojaAtualIdChat}/prompt-mestre`, {
      method: 'PUT',
      body: JSON.stringify({ prompt_mestre: campoPromptEl.value }),
    });
    sessionStorage.setItem(LOJA_CACHE_KEY, JSON.stringify(lojaAtualizada));
    campoPromptEl.value = lojaAtualizada.prompt_mestre || '';
    atualizarContadorPrompt();
    mostrarStatusPrompt('Salvo');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarStatusPrompt(erro.message || 'Não foi possível salvar.', true);
  } finally {
    botaoSalvarPromptEl.disabled = false;
  }
}

campoPromptEl.addEventListener('input', () => {
  atualizarContadorPrompt();
  mostrarStatusPrompt('Alterações não salvas');
});
botaoSalvarPromptEl.addEventListener('click', salvarPromptMestre);

// ---------- Início ----------

async function iniciarAtendente() {
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      chatSemLojaEl.classList.remove('hidden');
      return;
    }
    lojaAtualIdChat = loja.id;
    const lojaAtualizada = await obterLojaAtual({ forcarRecarregar: true });
    campoPromptEl.value = (lojaAtualizada && lojaAtualizada.prompt_mestre) || '';
    atualizarContadorPrompt();
    promptCardEl.classList.remove('hidden');
    chatContainerEl.classList.remove('hidden');
    campoPerguntaEl.focus();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    chatSemLojaEl.classList.remove('hidden');
  }
}

montarLayout('atendente');
iniciarAtendente();

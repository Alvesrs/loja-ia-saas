let planosAdmin = [];

function escapar(texto) { const d=document.createElement('div'); d.textContent=String(texto ?? ''); return d.innerHTML; }
function dataInput(valor) { if (!valor) return ''; const d=new Date(valor); return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0,10); }

async function salvarAssinatura(lojaId, elemento) {
  const plano = elemento.querySelector('[data-plano]').value;
  if (!plano) { mostrarToast('Escolha um plano comercial antes de salvar.', 'erro'); return; }
  const status = elemento.querySelector('[data-status]').value;
  const validade = elemento.querySelector('[data-validade]').value;
  const botao = elemento.querySelector('[data-salvar]');
  botao.disabled = true;
  try {
    await apiFetch(`/admin/lojas/${lojaId}/assinatura`, { method:'PUT', body:JSON.stringify({ plano, status, valido_ate: validade ? `${validade}T23:59:59.999Z` : null }) });
    mostrarToast('Assinatura atualizada.');
    await carregarAdmin();
  } catch(e) { if (e instanceof SessaoExpiradaError) return fazerLogout(); mostrarToast(e.message || 'Falha ao atualizar.', 'erro'); }
  finally { botao.disabled = false; }
}

function renderEmpresa(item) {
  const a=item.situacao.assinatura; const p=item.situacao.plano;
  const planoDisponivel = planosAdmin.some((x) => x.codigo === p.codigo);
  const opcaoAtual = planoDisponivel ? '' : `<option value="" selected disabled>${escapar(p.nome)} (sem plano comercial)</option>`;
  const opPlanos=opcaoAtual + planosAdmin.map(x=>`<option value="${x.codigo}" ${x.codigo===p.codigo?'selected':''}>${x.nome}</option>`).join('');
  const status=a?.status || 'ativo';
  return `<article class="admin-company" data-loja="${item.loja.id}"><div class="admin-company-main"><div><h3>${escapar(item.loja.nome)}</h3><p>${item.situacao.usadoNoMes} respostas neste mês · ${p.limiteMensagensMes===null?'sem limite':`limite ${p.limiteMensagensMes}`}</p></div><span class="badge ${item.situacao.ativo?'badge-green':'badge-red'}">${item.situacao.statusEfetivo.replace('_',' ')}</span></div><div class="admin-form-row"><label>Plano<select data-plano>${opPlanos}</select></label><label>Status<select data-status><option value="ativo" ${status==='ativo'?'selected':''}>Ativo</option><option value="inativo" ${status==='inativo'?'selected':''}>Inativo</option><option value="cancelado" ${status==='cancelado'?'selected':''}>Cancelado</option></select></label><label>Válido até<input type="date" data-validade value="${dataInput(a?.valido_ate)}"></label><button class="btn-primary small" data-salvar>Salvar</button></div></article>`;
}

async function carregarAdmin() {
  const erro=document.getElementById('admin-erro'), lista=document.getElementById('admin-lista'), resumo=document.getElementById('admin-resumo');
  erro.classList.add('hidden');
  try {
    const perfil=await apiFetch('/admin/me');
    if (!perfil.admin) { window.location.href='dashboard.html'; return; }
    const dados=await apiFetch('/admin/empresas'); planosAdmin=dados.planosDisponiveis || [];
    const empresas=dados.empresas || []; const ativas=empresas.filter(e=>e.situacao.ativo).length; const bloqueadas=empresas.length-ativas;
    resumo.innerHTML=`<div class="stat-card"><div class="stat-value">${empresas.length}</div><div class="stat-label">Empresas</div></div><div class="stat-card"><div class="stat-value">${ativas}</div><div class="stat-label">Ativas</div></div><div class="stat-card"><div class="stat-value">${bloqueadas}</div><div class="stat-label">Bloqueadas</div></div>`;
    lista.innerHTML=empresas.length?empresas.map(renderEmpresa).join(''):'<div class="empty-state">Nenhuma empresa cadastrada.</div>';
    lista.querySelectorAll('[data-loja]').forEach(el=>el.querySelector('[data-salvar]').addEventListener('click',()=>salvarAssinatura(el.dataset.loja,el)));
  } catch(e) { if (e instanceof SessaoExpiradaError) return fazerLogout(); erro.textContent=e.message||'Não foi possível carregar o Admin.'; erro.classList.remove('hidden'); lista.innerHTML=''; }
}
document.getElementById('admin-recarregar').addEventListener('click',carregarAdmin);
montarLayout('admin'); carregarAdmin();

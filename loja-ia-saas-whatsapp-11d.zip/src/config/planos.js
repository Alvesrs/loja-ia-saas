function inteiroPositivo(nome, padrao) {
  const valor = Number(process.env[nome]);
  return Number.isInteger(valor) && valor > 0 ? valor : padrao;
}

function precoCentavos(nome) {
  const valor = Number(process.env[nome]);
  return Number.isInteger(valor) && valor > 0 ? valor : null;
}

const PLANOS = Object.freeze({
  trial: Object.freeze({ codigo: 'trial', nome: 'Trial', limiteMensagensMes: inteiroPositivo('PLANO_TRIAL_LIMITE_MENSAGENS', 100), precoMensalCentavos: null, vendavel: false }),
  basico: Object.freeze({ codigo: 'basico', nome: 'Básico', limiteMensagensMes: inteiroPositivo('PLANO_BASICO_LIMITE_MENSAGENS', 1000), precoMensalCentavos: precoCentavos('PLANO_BASICO_PRECO_CENTAVOS'), vendavel: true }),
  pro: Object.freeze({ codigo: 'pro', nome: 'Pro', limiteMensagensMes: inteiroPositivo('PLANO_PRO_LIMITE_MENSAGENS', 5000), precoMensalCentavos: precoCentavos('PLANO_PRO_PRECO_CENTAVOS'), vendavel: true }),
  ilimitado: Object.freeze({ codigo: 'ilimitado', nome: 'Ilimitado', limiteMensagensMes: null, precoMensalCentavos: precoCentavos('PLANO_ILIMITADO_PRECO_CENTAVOS'), vendavel: true }),
});

function obterPlano(codigo) {
  return PLANOS[codigo] || null;
}

function listarPlanos() {
  return Object.values(PLANOS).map((p) => ({ ...p }));
}

function diasTrial() {
  return inteiroPositivo('TRIAL_DIAS', 14);
}

module.exports = { PLANOS, obterPlano, listarPlanos, diasTrial };

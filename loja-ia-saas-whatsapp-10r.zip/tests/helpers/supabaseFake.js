/**
 * FAKE do cliente Supabase, para testar serviços/controllers/middlewares
 * SEM rede e SEM projeto Supabase real.
 *
 * Cobre os padrões de chamada usados neste projeto:
 *   supabase.from(tabela).select(...).eq(...).eq(...).maybeSingle()
 *   supabase.from(tabela).insert(...).select().single()
 *   supabase.from(tabela).update(...).eq(...).select().maybeSingle()
 *   supabase.from(tabela).delete().eq(...).select().maybeSingle()
 *   supabase.from(tabela).upsert(dados, { onConflict }).select().single()
 *   supabase.rpc(nome, params)
 *   supabase.auth.getUser(token)
 *
 * Uso típico num teste:
 *   const supabase = require('../src/config/supabase'); // singleton real
 *   const fake = criarSupabaseFake({ from: { lojas: { data: {...}, error: null } } });
 *   supabase.from = fake.from;
 *   supabase.rpc = fake.rpc;
 *   supabase.auth = fake.auth;
 *   // ... chamar a função/middleware/controller sob teste ...
 *   assert.equal(fake.chamadasFrom[0].tabela, 'lojas');
 */
function criarSupabaseFake({ from = {}, rpc = {}, auth = {} } = {}) {
  const chamadasFrom = [];
  const chamadasRpc = [];

  function resultadoPara(tabela, contexto) {
    const config = from[tabela];
    if (typeof config === 'function') return config(contexto);
    if (Array.isArray(config)) {
      // Permite simular múltiplas chamadas sucessivas à mesma tabela
      // (fila: primeira chamada consome o primeiro item, etc.)
      return config.shift() || { data: null, error: null };
    }
    if (config) return config;

    // Compatibilidade dos testes anteriores à 10N: quando uma suíte não
    // está testando histórico explicitamente, fornece respostas mínimas para
    // as duas novas tabelas sem obrigar dezenas de fixtures antigas a
    // duplicarem infraestrutura irrelevante ao foco daqueles testes.
    if (tabela === 'whatsapp_conversas' && contexto.upsertDados) {
      return {
        data: {
          id: '99999999-9999-4999-8999-999999999999',
          loja_id: contexto.upsertDados.loja_id,
          configuracao_id: contexto.upsertDados.configuracao_id,
          contato: contexto.upsertDados.contato,
        },
        error: null,
      };
    }
    if (tabela === 'whatsapp_mensagens' && contexto.insertDados) {
      return { data: contexto.insertDados, error: null };
    }
    // 10O: suítes antigas do webhook não precisam montar a fila inteira.
    if (tabela === 'whatsapp_fila_processamento' && contexto.insertDados) {
      return { data: { id: '88888888-8888-4888-8888-888888888888' }, error: null };
    }
    return { data: null, error: null };
  }

  function criarBuilder(tabela) {
    const contexto = {
      filtros: {},
      insertDados: undefined,
      updateDados: undefined,
      upsertDados: undefined,
      upsertOpcoes: undefined,
      delete: false,
    };

    const builder = {
      select() {
        return builder;
      },
      eq(coluna, valor) {
        contexto.filtros[coluna] = valor;
        return builder;
      },
      order(coluna, opcoes) {
        contexto.ordem = { coluna, opcoes };
        return builder;
      },
      limit(valor) {
        contexto.limite = valor;
        return builder;
      },
      insert(dados) {
        contexto.insertDados = dados;
        return builder;
      },
      update(dados) {
        contexto.updateDados = dados;
        return builder;
      },
      upsert(dados, opcoes) {
        contexto.upsertDados = dados;
        contexto.upsertOpcoes = opcoes;
        return builder;
      },
      delete() {
        contexto.delete = true;
        return builder;
      },
      maybeSingle() {
        chamadasFrom.push({ tabela, ...contexto });
        return Promise.resolve(resultadoPara(tabela, contexto));
      },
      single() {
        chamadasFrom.push({ tabela, ...contexto });
        return Promise.resolve(resultadoPara(tabela, contexto));
      },
      // Permite `await supabase.from(x).select().eq(...)` sem terminal
      // explícito (usado em listagens: listarProdutos, listarClientes...).
      then(resolve, reject) {
        chamadasFrom.push({ tabela, ...contexto });
        return Promise.resolve(resultadoPara(tabela, contexto)).then(resolve, reject);
      },
    };

    return builder;
  }

  return {
    from(tabela) {
      return criarBuilder(tabela);
    },
    async rpc(nome, params) {
      chamadasRpc.push({ nome, params });
      const config = rpc[nome];
      if (typeof config === 'function') return config(params);
      return config || { data: null, error: null };
    },
    auth: {
      async getUser(token) {
        if (typeof auth.getUser === 'function') return auth.getUser(token);
        return auth.getUser || { data: { user: null }, error: { message: 'não mockado' } };
      },
    },
    chamadasFrom,
    chamadasRpc,
  };
}

module.exports = { criarSupabaseFake };

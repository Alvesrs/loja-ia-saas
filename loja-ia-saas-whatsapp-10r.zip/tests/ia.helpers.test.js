/**
 * Testes de unidade da lógica pura do atendente de IA (src/services/ia.helpers.js).
 *
 * Não usam banco de dados nem rede — só dados fake em memória — por isso
 * rodam em qualquer ambiente:
 *
 *   node tests/ia.helpers.test.js
 *
 * Cobrem os cenários H, I e parte do J do pedido de auditoria:
 *   H) Pergunta sobre produto existente → responde com dados reais.
 *   I) Pergunta sobre produto inexistente → não inventa produto.
 *   (preço/tamanho/cor/disponibilidade sempre vêm do array de entrada,
 *    nunca são inventados pela função)
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const {
  normalizar,
  encontrarProdutosMencionados,
  formatarPreco,
  montarResposta,
} = require('../src/services/ia.helpers');

const CATALOGO_FAKE = [
  {
    id: '1',
    nome: 'Camiseta Preta',
    categoria: 'camisetas',
    preco: 49.9,
    estoque: [
      { tamanho: 'M', cor: 'Preta', quantidade: 5 },
      { tamanho: 'G', cor: 'Preta', quantidade: 0 },
    ],
  },
  {
    id: '2',
    nome: 'Calça Jeans',
    categoria: 'calcas',
    preco: 129.0,
    estoque: [{ tamanho: '40', cor: 'Azul', quantidade: 3 }],
  },
];

test('normalizar remove acentos e caixa alta', () => {
  assert.equal(normalizar('Camiseta Preta É Ótima'), 'camiseta preta e otima');
  assert.equal(normalizar(undefined), '');
});

test('formatarPreco usa formato brasileiro (vírgula)', () => {
  assert.equal(formatarPreco(49.9), 'R$ 49,90');
  assert.equal(formatarPreco(0), 'R$ 0,00');
});

test('encontrarProdutosMencionados acha produto pelo nome', () => {
  const encontrados = encontrarProdutosMencionados(CATALOGO_FAKE, normalizar('tem camiseta preta?'));
  assert.equal(encontrados.length, 1);
  assert.equal(encontrados[0].nome, 'Camiseta Preta');
});

test('CENÁRIO H: pergunta sobre produto existente responde com dado real do catálogo', () => {
  const resposta = montarResposta(CATALOGO_FAKE, 'Quanto custa a camiseta preta?');
  assert.match(resposta, /Camiseta Preta/);
  // O preço tem que ser EXATAMENTE o que está no catálogo fake (49.90),
  // nunca um valor inventado.
  assert.match(resposta, /R\$ 49,90/);
});

test('CENÁRIO I: pergunta sobre produto inexistente não inventa produto', () => {
  const resposta = montarResposta(CATALOGO_FAKE, 'Vocês tem jaqueta de couro?');
  assert.match(resposta, /Não encontrei esse produto/i);
  // Garante que nenhum nome de produto do catálogo aparece "por engano"
  // numa resposta que deveria ser de "não encontrado".
  assert.doesNotMatch(resposta, /Camiseta Preta/);
  assert.doesNotMatch(resposta, /Calça Jeans/);
});

test('catálogo vazio nunca inventa produto', () => {
  const resposta = montarResposta([], 'Tem camiseta?');
  assert.match(resposta, /ainda não cadastrou produtos/i);
});

test('tamanho/cor esgotados nunca são reportados como disponíveis (nunca inventa disponibilidade)', () => {
  // "Camiseta Preta" tem tamanho G com quantidade 0 — não pode aparecer
  // como disponível.
  const resposta = montarResposta(CATALOGO_FAKE, 'Qual tamanho tem de camiseta preta?');
  const linhaCamiseta = resposta.split('\n').find((l) => l.includes('Camiseta Preta'));
  assert.ok(linhaCamiseta);
  assert.match(linhaCamiseta, /Tamanhos disponíveis: M/);
  assert.doesNotMatch(linhaCamiseta, /\bG\b/);
});

test('resposta nunca contém preço de produto diferente do perguntado', () => {
  const resposta = montarResposta(CATALOGO_FAKE, 'Quanto custa a calça jeans?');
  assert.match(resposta, /R\$ 129,00/);
  assert.doesNotMatch(resposta, /49,90/);
});

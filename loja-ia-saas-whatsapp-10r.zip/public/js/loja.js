// Resolve a loja do lojista autenticado.
//
// O backend não amarra a sessão a UMA loja fixa: um usuário pode ter
// mais de uma (GET /api/lojas lista todas as que pertencem a ele). Nesta
// primeira versão do painel, usamos a loja mais recente como "loja atual"
// — é o suficiente para o Dashboard V1, sem inventar uma tela de troca de
// loja que não foi pedida nesta etapa.
//
// Isso NÃO é a autorização de verdade: o backend (middleware
// exigirDonoDaLoja) continua sendo a autoridade final sobre quem pode ler
// ou alterar os dados de uma loja. O cache aqui é só para não repetir a
// chamada em toda página.

const LOJA_CACHE_KEY = 'lojaia_loja_atual';

async function obterLojaAtual({ forcarRecarregar = false } = {}) {
  if (!forcarRecarregar) {
    const emCache = sessionStorage.getItem(LOJA_CACHE_KEY);
    if (emCache) {
      try { return JSON.parse(emCache); } catch (e) { /* recarrega abaixo */ }
    }
  }

  const lojas = await apiFetch('/lojas');
  const loja = Array.isArray(lojas) && lojas.length > 0 ? lojas[0] : null;
  if (loja) sessionStorage.setItem(LOJA_CACHE_KEY, JSON.stringify(loja));
  return loja;
}

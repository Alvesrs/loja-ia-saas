// Controller da página Atendente IA.
//
// Esta página é só um painel de TESTE para o lojista: envia a pergunta
// exatamente como o cliente final enviaria, para o mesmo endpoint
// público já existente na Etapa 9E:
//
//   POST /api/lojas/:lojaId/ia/perguntar   body: { pergunta }   resp: { resposta }
//
// O :lojaId nunca é digitado pelo usuário — vem de obterLojaAtual(),
// que só lista as lojas do usuário autenticado (GET /api/lojas). Isso
// segue o mesmo padrão já usado em produtos.js/estoque.js: o frontend
// não decide autorização, só usa a loja que o backend já confirmou
// pertencer ao lojista logado.
//
// O histórico da conversa vive só em memória (nesta variável). Ao
// recarregar a página, começa uma conversa nova — não há banco nem
// persistência para isso nesta etapa.

let lojaAtualIdChat = null;
let enviandoPergunta = false;
let primeiraMensagemEnviada = false;

const chatContainerEl = document.getElementById('chat-container');
const chatSemLojaEl = document.getElementById('chat-sem-loja');
const chatMensagensEl = document.getElementById('chat-mensagens');
const chatEstadoInicialEl = document.getElementById('chat-estado-inicial');
const chatErroEl = document.getElementById('chat-erro');
const formChatEl = document.getElementById('form-chat');
const campoPerguntaEl = document.getElementById('campo-pergunta');
const botaoEnviarEl = document.getElementById('botao-enviar-pergunta');

function escaparHtmlChat(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML;
}

function rolarParaFinal() {
  chatMensagensEl.scrollTop = chatMensagensEl.scrollHeight;
}

function removerEstadoInicial() {
  if (!primeiraMensagemEnviada) {
    chatEstadoInicialEl.remove();
    primeiraMensagemEnviada = true;
  }
}

function adicionarMensagem(texto, autor) {
  removerEstadoInicial();
  const bolha = document.createElement('div');
  bolha.className = `chat-msg chat-msg-${autor}`;
  bolha.textContent = texto;
  chatMensagensEl.appendChild(bolha);
  rolarParaFinal();
  return bolha;
}

function mostrarDigitando() {
  removerEstadoInicial();
  const bolha = document.createElement('div');
  bolha.className = 'chat-msg chat-msg-atendente chat-msg-digitando';
  bolha.id = 'chat-digitando';
  bolha.setAttribute('aria-live', 'polite');
  bolha.innerHTML = '<span class="chat-dot"></span><span class="chat-dot"></span><span class="chat-dot"></span>';
  chatMensagensEl.appendChild(bolha);
  rolarParaFinal();
}

function removerDigitando() {
  const el = document.getElementById('chat-digitando');
  if (el) el.remove();
}

function mostrarErroChat(mensagem) {
  chatErroEl.textContent = mensagem;
  chatErroEl.classList.remove('hidden');
}

function limparErroChat() {
  chatErroEl.classList.add('hidden');
  chatErroEl.textContent = '';
}

async function enviarPergunta(pergunta) {
  if (enviandoPergunta) return;
  enviandoPergunta = true;
  botaoEnviarEl.disabled = true;
  campoPerguntaEl.disabled = true;
  limparErroChat();

  adicionarMensagem(pergunta, 'usuario');
  mostrarDigitando();

  try {
    const resultado = await apiFetch(`/lojas/${lojaAtualIdChat}/ia/perguntar`, {
      method: 'POST',
      body: JSON.stringify({ pergunta }),
    });
    removerDigitando();
    adicionarMensagem(resultado && resultado.resposta ? resultado.resposta : 'Não foi possível obter uma resposta agora. Tente novamente.', 'atendente');
  } catch (erro) {
    removerDigitando();
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErroChat(erro.message || 'Não foi possível obter uma resposta agora. Tente novamente.');
  } finally {
    enviandoPergunta = false;
    botaoEnviarEl.disabled = false;
    campoPerguntaEl.disabled = false;
    campoPerguntaEl.focus();
  }
}

formChatEl.addEventListener('submit', (evento) => {
  evento.preventDefault();
  if (enviandoPergunta) return;

  const pergunta = campoPerguntaEl.value.trim();
  if (!pergunta) return;

  campoPerguntaEl.value = '';
  enviarPergunta(pergunta);
});

// ---------- Início ----------

async function iniciarAtendente() {
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      chatSemLojaEl.classList.remove('hidden');
      return;
    }
    lojaAtualIdChat = loja.id;
    chatContainerEl.classList.remove('hidden');
    campoPerguntaEl.focus();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    chatSemLojaEl.classList.remove('hidden');
  }
}

montarLayout('atendente');
iniciarAtendente();

// Monta o "chrome" comum a todas as páginas administrativas: sidebar
// (desktop), barra de abas (celular) e cabeçalho com o nome da loja e
// botão de sair. Evita duplicar esse HTML em cada página.

const ICONES = {
  dashboard: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
  produtos: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 7.3 12 2 3.5 7.3 12 12l8.5-4.7Z"/><path d="M3.5 7.3v9.4L12 22l8.5-5.3V7.3"/><path d="M12 12v10"/></svg>',
  estoque: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h18M3 12h18M3 17h18"/></svg>',
  clientes: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 21v-1a7 7 0 0 1 14 0v1"/><path d="M17 11a4 4 0 1 0 0-8"/><path d="M22 21v-1a7 7 0 0 0-5-6.7"/></svg>',
  pedidos: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
  whatsapp: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.5 9.5 9.5 0 0 1-4-.9L3 21l1.6-4.5A8.3 8.3 0 0 1 3 11.5 8.5 8.5 0 0 1 11.8 3 8.5 8.5 0 0 1 21 11.5Z"/><path d="M8.2 8.5c.6 2.8 2.2 4.4 5 5l1.2-1.2 2 .8-.3 2.1c-.2.5-.7.8-1.3.8-4.4-.4-7.8-3.8-8.2-8.2 0-.6.3-1.1.8-1.3l2.1-.3.8 2-1.1 1.3Z"/></svg>',
  atendente: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><path d="M8 16h.01M16 16h.01"/></svg>',
  sair: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>',
};

const MENU = [
  { id: 'dashboard', label: 'Dashboard', href: 'dashboard.html' },
  { id: 'produtos', label: 'Produtos', href: 'produtos.html' },
  { id: 'estoque', label: 'Estoque', href: 'estoque.html' },
  { id: 'clientes', label: 'Clientes', href: 'clientes.html' },
  { id: 'pedidos', label: 'Pedidos', href: 'pedidos.html' },
  { id: 'whatsapp', label: 'WhatsApp', href: 'whatsapp.html' },
  { id: 'atendente', label: 'Atendente IA', href: 'atendente.html' },
];

function montarSidebar(paginaAtiva) {
  const itens = MENU.map((item) => `
    <li class="nav-item">
      <a href="${item.href}" class="${item.id === paginaAtiva ? 'active' : ''}">
        ${ICONES[item.id]}<span>${item.label}</span>
      </a>
    </li>`).join('');

  return `
    <aside class="sidebar">
      <div class="sidebar-brand brand">Vitrine</div>
      <ul class="nav-list">${itens}</ul>
    </aside>`;
}

function montarTabbar(paginaAtiva) {
  const itens = MENU.map((item) => `
    <a href="${item.href}" class="${item.id === paginaAtiva ? 'active' : ''}">
      ${ICONES[item.id]}
      <span>${item.label.split(' ')[0]}</span>
    </a>`).join('');
  return `<nav class="tabbar">${itens}</nav>`;
}

function montarTopbar() {
  return `
    <header class="topbar">
      <div class="topbar-store">
        <span class="label">Loja</span>
        <span id="nome-loja-topbar">Carregando…</span>
      </div>
      <button class="btn-logout" id="botao-sair" type="button">
        ${ICONES.sair}<span>Sair</span>
      </button>
    </header>`;
}

async function montarLayout(paginaAtiva) {
  const sidebarEl = document.getElementById('sidebar-container');
  const topbarEl = document.getElementById('topbar-container');
  const tabbarEl = document.getElementById('tabbar-container');

  if (sidebarEl) sidebarEl.innerHTML = montarSidebar(paginaAtiva);
  if (tabbarEl) tabbarEl.innerHTML = montarTabbar(paginaAtiva);
  if (topbarEl) {
    topbarEl.innerHTML = montarTopbar();
    document.getElementById('botao-sair').addEventListener('click', fazerLogout);
  }

  try {
    const loja = await obterLojaAtual();
    const nomeEl = document.getElementById('nome-loja-topbar');
    if (nomeEl) nomeEl.textContent = loja ? loja.nome : 'Nenhuma loja cadastrada';
  } catch (e) {
    if (e instanceof SessaoExpiradaError) {
      fazerLogout();
      return;
    }
    const nomeEl = document.getElementById('nome-loja-topbar');
    if (nomeEl) nomeEl.textContent = 'Não foi possível carregar';
  }
}

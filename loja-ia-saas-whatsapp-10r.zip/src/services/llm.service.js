/**
 * CAMADA DE ABSTRAÇÃO DE LLM (Etapa 9A: base / Etapa 9B: integração real)
 *
 * Este serviço é responsável SOMENTE pela comunicação com um provedor de
 * LLM. Ele NÃO decide o que perguntar, não busca dados no catálogo e não
 * é chamado ainda por nenhum controller/rota do atendente — isso fica
 * para uma etapa futura.
 *
 *   controller  →  serviço de atendimento (futuro)  →  llm.service  →  provedor LLM
 *
 * PROVEDOR (Etapa 9B):
 * A chamada HTTP usa o formato "chat completions" no padrão OpenAI, que é
 * o formato aceito pela API HTTP da Groq (https://api.groq.com/openai/v1/chat/completions)
 * — provedor sugerido por ter API simples, compatível com o padrão do
 * mercado (o mesmo formato de outros provedores, como OpenAI) e opção de
 * uso gratuito/baixo custo para desenvolvimento. Como o formato é o
 * padrão do setor, `LLM_PROVIDER_URL` pode apontar para qualquer provedor
 * compatível (Groq, OpenAI, ou um proxy compatível) sem alterar este
 * arquivo — só a variável de ambiente muda.
 *
 * IMPORTANTE:
 * - Nenhuma chave de API é lida de outro lugar que não seja variável de
 *   ambiente (processo do backend). Ela nunca é enviada ao frontend, nunca
 *   fica hardcoded aqui, nunca é incluída em logs, e nunca deve ir para o
 *   .env real commitado.
 * - O endpoint atual de IA (`src/services/ia.service.js` /
 *   `src/controllers/ia.controller.js`) continua funcionando exatamente
 *   como antes e NÃO usa este arquivo ainda.
 */

const { ehStringNaoVazia } = require('../utils/validacao');

const TIMEOUT_PADRAO_MS = 15_000;

/** Lançado quando a variável de ambiente do provedor de LLM não está configurada. */
class ErroLlmConfiguracaoAusente extends Error {
  constructor(mensagem) {
    super(mensagem || 'Nenhum provedor de LLM configurado.');
    this.name = 'ErroLlmConfiguracaoAusente';
  }
}

/** Lançado quando o provedor de LLM responde com erro, timeout ou falha de rede. */
class ErroLlmProvedor extends Error {
  constructor(mensagem) {
    super(mensagem || 'Erro ao comunicar com o provedor de LLM.');
    this.name = 'ErroLlmProvedor';
  }
}

/** Lançado quando o provedor responde 200 OK mas em um formato inesperado/vazio. */
class ErroLlmRespostaInvalida extends Error {
  constructor(mensagem) {
    super(mensagem || 'Resposta inválida recebida do provedor de LLM.');
    this.name = 'ErroLlmRespostaInvalida';
  }
}

/**
 * Lê a configuração do provedor de LLM a partir de variáveis de ambiente.
 * Retorna `null` se a configuração mínima (chave + URL) não existir —
 * isso permite ao chamador decidir o que fazer (ex: cair de volta para a
 * lógica de regras atual) sem que o serviço precise saber disso.
 *
 * Nenhum valor default de chave/URL é definido aqui de propósito: sem
 * configuração explícita, o serviço deve se recusar a "inventar" um
 * provedor.
 */
function obterConfiguracao() {
  const apiKey = process.env.LLM_PROVIDER_API_KEY;
  const apiUrl = process.env.LLM_PROVIDER_URL;

  if (!ehStringNaoVazia(apiKey) || !ehStringNaoVazia(apiUrl)) {
    return null;
  }

  const timeoutConfigurado = Number(process.env.LLM_TIMEOUT_MS);

  return {
    apiKey,
    apiUrl,
    modelo: process.env.LLM_PROVIDER_MODEL || undefined,
    timeoutMs: Number.isFinite(timeoutConfigurado) && timeoutConfigurado > 0
      ? timeoutConfigurado
      : TIMEOUT_PADRAO_MS,
  };
}

/**
 * Remove qualquer ocorrência literal da API key de um texto antes de ele
 * ser logado. Defesa em profundidade: mesmo que uma biblioteca de rede
 * um dia inclua a URL/headers da requisição na mensagem de erro, a chave
 * nunca chega ao log do servidor.
 */
function redigirSegredo(texto, segredo) {
  if (typeof texto !== 'string' || !ehStringNaoVazia(segredo)) return texto;
  return texto.split(segredo).join('[API_KEY_OCULTADA]');
}

/**
 * Indica se há um provedor de LLM configurado no ambiente atual. Útil para
 * um serviço de atendimento (futuro) decidir se deve tentar usar o LLM ou
 * cair de volta para a lógica baseada em regras.
 */
function estaConfigurado() {
  return obterConfiguracao() !== null;
}

/**
 * Monta o array `messages` no formato "chat completions" (padrão
 * OpenAI/Groq): uma mensagem de sistema (com o system prompt e, se
 * houver, o contexto serializado) seguida da pergunta do cliente como
 * mensagem do usuário.
 *
 * Esta etapa (9B) não recebe contexto de catálogo ainda — o parâmetro
 * `contexto` existe apenas para manter a interface já definida na 9A e
 * ser usado por uma etapa futura.
 */
function construirMensagens({ systemPrompt, contexto, pergunta }) {
  const mensagens = [];

  let conteudoSistema = ehStringNaoVazia(systemPrompt)
    ? systemPrompt
    : 'Você é um atendente virtual. Responda de forma breve e educada.';

  if (contexto !== undefined && contexto !== null) {
    let contextoTexto;
    try {
      contextoTexto = typeof contexto === 'string' ? contexto : JSON.stringify(contexto);
    } catch {
      contextoTexto = String(contexto);
    }
    conteudoSistema += `\n\nContexto:\n${contextoTexto}`;
  }

  mensagens.push({ role: 'system', content: conteudoSistema });
  mensagens.push({ role: 'user', content: pergunta });

  return mensagens;
}

/**
 * Tenta extrair o texto de resposta de formatos de payload comuns entre
 * provedores de LLM. O formato principal esperado é o "chat completions"
 * (OpenAI/Groq): `choices[0].message.content`. Os demais formatos são
 * mantidos como fallback para facilitar troca futura de provedor sem
 * alterar esta função.
 */
function extrairTextoDaResposta(dados) {
  if (!dados || typeof dados !== 'object') return null;

  const mensagemEstiloChat = dados.choices && dados.choices[0] && dados.choices[0].message;
  if (mensagemEstiloChat && typeof mensagemEstiloChat.content === 'string') {
    return mensagemEstiloChat.content;
  }

  if (typeof dados.resposta === 'string') return dados.resposta;
  if (typeof dados.text === 'string') return dados.text;

  if (Array.isArray(dados.content)) {
    const bloco = dados.content.find((item) => item && typeof item.text === 'string');
    if (bloco) return bloco.text;
  }

  return null;
}

/**
 * Interface simples para enviar um prompt a um LLM e receber texto de volta.
 * Faz uma chamada HTTP real (formato chat completions, padrão OpenAI/Groq)
 * usando `LLM_PROVIDER_URL`, `LLM_PROVIDER_API_KEY` e, opcionalmente,
 * `LLM_PROVIDER_MODEL`/`LLM_TIMEOUT_MS`.
 *
 * @param {Object} entrada
 * @param {string} [entrada.systemPrompt] - Instruções de sistema/comportamento do atendente.
 * @param {*} [entrada.contexto] - Contexto adicional (ex: catálogo). Serializado como texto e anexado ao system prompt.
 * @param {string} entrada.pergunta - Pergunta do cliente a ser respondida.
 * @returns {Promise<string>} Resposta textual do modelo.
 *
 * @throws {ErroLlmConfiguracaoAusente} Se não houver provedor configurado.
 * @throws {ErroLlmProvedor} Se houver erro de rede, timeout ou o provedor responder com erro.
 * @throws {ErroLlmRespostaInvalida} Se a resposta do provedor vier vazia ou em formato inesperado.
 */
async function gerarResposta({ systemPrompt, contexto, pergunta } = {}) {
  const config = obterConfiguracao();

  if (!config) {
    throw new ErroLlmConfiguracaoAusente(
      'Nenhum provedor de LLM configurado. Defina LLM_PROVIDER_API_KEY e ' +
      'LLM_PROVIDER_URL nas variáveis de ambiente do backend antes de usar esta função.'
    );
  }

  if (!ehStringNaoVazia(pergunta)) {
    throw new ErroLlmRespostaInvalida('A "pergunta" enviada ao LLM não pode ser vazia.');
  }

  const corpoRequisicao = {
    model: config.modelo,
    messages: construirMensagens({ systemPrompt, contexto, pergunta }),
  };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), config.timeoutMs);

  try {
    let resposta;
    try {
      resposta = await fetch(config.apiUrl, {
        method: 'POST',
        // ATENÇÃO: o header Authorization carrega a API key. Nunca logar
        // este objeto `headers` nem `config.apiKey` em nenhum console.*
        // daqui para baixo — só o corpo/status da resposta do provedor
        // (que nunca contém nossa própria chave) pode ser logado.
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify(corpoRequisicao),
        signal: controller.signal,
      });
    } catch (erroRede) {
      if (erroRede.name === 'AbortError') {
        console.error('[llm.service] tempo limite excedido ao chamar o provedor de LLM');
        throw new ErroLlmProvedor('Tempo limite excedido ao comunicar com o provedor de LLM.');
      }
      // Nunca logamos `headers`/`corpoRequisicao` (contêm a API key). A
      // mensagem do erro de rede em si é passada por `redigirSegredo` como
      // defesa extra, caso alguma lib subjacente a inclua por engano.
      console.error(
        '[llm.service] erro de rede ao chamar o provedor de LLM:',
        redigirSegredo(erroRede.message, config.apiKey)
      );
      throw new ErroLlmProvedor('Não foi possível comunicar com o provedor de LLM.');
    }

    if (!resposta.ok) {
      let corpoErro = '';
      try {
        corpoErro = await resposta.text();
      } catch {
        // ignora falha ao ler corpo do erro; já logamos o status abaixo
      }
      console.error(
        '[llm.service] provedor de LLM retornou erro',
        resposta.status,
        redigirSegredo(corpoErro, config.apiKey)
      );
      throw new ErroLlmProvedor('O provedor de LLM retornou um erro.');
    }

    let dados;
    try {
      dados = await resposta.json();
    } catch (erroParse) {
      console.error(
        '[llm.service] resposta do provedor não é um JSON válido',
        redigirSegredo(erroParse.message, config.apiKey)
      );
      throw new ErroLlmRespostaInvalida('O provedor de LLM retornou uma resposta em formato inválido.');
    }

    const texto = extrairTextoDaResposta(dados);

    if (!ehStringNaoVazia(texto)) {
      console.error(
        '[llm.service] resposta do provedor não contém texto reconhecível',
        redigirSegredo(JSON.stringify(dados), config.apiKey)
      );
      throw new ErroLlmRespostaInvalida('O provedor de LLM retornou uma resposta vazia ou em formato inesperado.');
    }

    return texto;
  } finally {
    clearTimeout(timeoutId);
  }
}

module.exports = {
  gerarResposta,
  estaConfigurado,
  construirMensagens,
  extrairTextoDaResposta,
  redigirSegredo,
  ErroLlmConfiguracaoAusente,
  ErroLlmProvedor,
  ErroLlmRespostaInvalida,
};

const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { ehStringNaoVazia } = require('../utils/validacao');

async function criarLoja(req, res) {
  const { nome } = req.body;

  if (!ehStringNaoVazia(nome)) {
    return res.status(400).json({ erro: 'Informe o nome da loja.' });
  }

  const { data, error } = await supabase
    .from('lojas')
    .insert({ nome: nome.trim(), dono_id: req.usuario.id })
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.status(201).json(data);
}

async function listarMinhasLojas(req, res) {
  const { data, error } = await supabase
    .from('lojas')
    .select('*')
    .eq('dono_id', req.usuario.id)
    .order('criado_em', { ascending: false });

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

module.exports = { criarLoja, listarMinhasLojas };

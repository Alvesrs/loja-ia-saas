const supabase = require('../config/supabase');
const { ehStringNaoVazia } = require('../utils/validacao');

// Regex simples só para pegar erros de digitação óbvios (ex: "fulano#gmail").
// A validação "de verdade" (formato completo, e-mail existe, etc.) é feita
// pelo próprio Supabase Auth.
const REGEX_EMAIL_BASICO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function cadastrar(req, res) {
  const { email, senha } = req.body;

  if (!ehStringNaoVazia(email) || !REGEX_EMAIL_BASICO.test(email.trim())) {
    return res.status(400).json({ erro: 'Informe um email válido.' });
  }

  if (!ehStringNaoVazia(senha) || senha.length < 6) {
    return res.status(400).json({ erro: 'A senha deve ter pelo menos 6 caracteres.' });
  }

  const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: senha });

  // As mensagens de erro do Supabase Auth (GoTrue) já são pensadas para
  // serem exibidas ao usuário final (ex: "User already registered"),
  // diferente de erros crus de banco — por isso repassamos error.message
  // aqui, ao contrário do que fazemos nos outros controllers.
  if (error) {
    return res.status(400).json({ erro: error.message });
  }

  return res.status(201).json({
    mensagem: 'Cadastro realizado. Verifique seu email para confirmar a conta (se a confirmação estiver ativada no Supabase).',
    usuario: data.user,
  });
}

async function login(req, res) {
  const { email, senha } = req.body;

  if (!ehStringNaoVazia(email) || !ehStringNaoVazia(senha)) {
    return res.status(400).json({ erro: 'Informe email e senha.' });
  }

  const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: senha });

  if (error) {
    return res.status(401).json({ erro: error.message });
  }

  return res.json({
    usuario: data.user,
    token: data.session.access_token,
  });
}

module.exports = { cadastrar, login };

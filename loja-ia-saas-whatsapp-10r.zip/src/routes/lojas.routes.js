const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { criarLoja, listarMinhasLojas } = require('../controllers/lojas.controller');

const router = express.Router();

router.use(exigirLogin);
router.post('/', criarLoja);
router.get('/', listarMinhasLojas);

module.exports = router;

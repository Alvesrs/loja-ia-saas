const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const raiz = path.join(__dirname, '..');
const ler = (rel) => fs.readFileSync(path.join(raiz, rel), 'utf8');

test('11C adiciona checkout Mercado Pago sem expor segredo no frontend', () => {
  const app = ler('src/app.js');
  const rota = ler('src/routes/assinaturas.routes.js');
  const front = ler('public/js/plano.js');
  assert.match(app, /webhooks\/mercadopago/);
  assert.match(rota, /\/checkout/);
  assert.match(front, /Assinar com Mercado Pago/);
  assert.equal(/MERCADOPAGO_ACCESS_TOKEN/.test(front), false);
});

test('11C valida webhook Mercado Pago por HMAC SHA-256', () => {
  const svcPath = path.join(raiz, 'src/services/mercadoPago.service.js');
  const supabasePath = require.resolve(path.join(raiz, 'src/config/supabase.js'));
  const assinaturaPath = require.resolve(path.join(raiz, 'src/services/assinaturas.service.js'));
  require.cache[supabasePath] = { exports: {} };
  require.cache[assinaturaPath] = { exports: { definirAssinatura: async()=>{}, buscarAssinaturaAtual: async()=>null } };
  delete require.cache[require.resolve(svcPath)];
  const { assinaturaWebhookValida } = require(svcPath);
  const secret='segredo'; const id='ABC123'; const reqId='req-1'; const ts='1700000000';
  const tpl=`id:${id.toLowerCase()};request-id:${reqId};ts:${ts};`;
  const v1=crypto.createHmac('sha256',secret).update(tpl).digest('hex');
  assert.equal(assinaturaWebhookValida({xSignature:`ts=${ts},v1=${v1}`,xRequestId:reqId,dataId:id,secret}),true);
  assert.equal(assinaturaWebhookValida({xSignature:`ts=${ts},v1=${'0'.repeat(64)}`,xRequestId:reqId,dataId:id,secret}),false);
});

test('11C schema cria rastreamento separado de cobrança e vínculo do provedor', () => {
  const mig = ler('src/db/migrations/010_cobranca_mercadopago_11c.sql');
  assert.match(mig, /cobrancas_assinaturas/);
  assert.match(mig, /provider_assinatura_id/);
  assert.match(mig, /enable row level security/);
});

test('11C preços são configuráveis por ambiente, sem valor comercial imposto no código', () => {
  const cfg = ler('src/config/planos.js');
  assert.match(cfg, /PLANO_BASICO_PRECO_CENTAVOS/);
  assert.match(cfg, /PLANO_PRO_PRECO_CENTAVOS/);
  assert.match(cfg, /PLANO_ILIMITADO_PRECO_CENTAVOS/);
  assert.equal(/4990|9990|19990/.test(cfg), false);
});

/**
 * Testes do CONTRATO INTERNO de provedor de WhatsApp e do ADAPTADOR SIMULADO
 * (src/services/providers/whatsapp/).
 *
 * Etapa 10F: arquitetura de adaptador. NÃO há provedor real, chamada HTTP,
 * credencial, banco nem LLM — e o adaptador testado aqui não envia nada
 * (seu resultado é "simulado").
 *
 * Cobre os cenários pedidos na etapa:
 *   A) envio com dados válidos é aceito;
 *   B) texto vazio é rejeitado;
 *   C) contato ausente é rejeitado;
 *   D) lojaId ausente é rejeitado;
 *   E) o adaptador não realiza HTTP;
 *   F) credenciais não são expostas (retorno de erro nem logs);
 *   G) a normalização de mensagem tem formato previsível;
 *   H) o contato é identidade do remetente/destinatário, nunca da loja;
 *   I) o resultado interno do envio tem formato consistente;
 *   J) compatibilidade com o que já existia (10A e webhook).
 *
 * Não usa Supabase, express nem rede: os módulos testados nem dependem deles.
 *
 * Rodar com: node --test tests/whatsappProvedor.contrato.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');
const net = require('node:net');

const whatsappService = require('../src/services/whatsapp.service');
const {
  ErroMensagemWhatsappInvalida,
  LIMITE_TEXTO_MENSAGEM,
} = whatsappService;
const provedores = require('../src/services/providers/whatsapp');
const {
  obterProvedorWhatsapp,
  listarProvedoresDisponiveis,
  criarPedidoDeEnvio,
  criarResultadoEnvio,
  criarResultadoFalha,
  mensagemFoiEnviada,
  verificarImplementacaoDoContrato,
  OPERACOES_DO_CONTRATO,
  STATUS_ENVIO,
  CODIGOS_ERRO_ENVIO,
  CAMPOS_DO_PEDIDO_DE_ENVIO,
  ErroProvedorWhatsappInvalido,
  ErroProvedorWhatsappNaoSuportado,
} = provedores;
const { criarAdaptadorSimulado } = require('../src/services/providers/whatsapp/adaptadorSimulado');

const RAIZ = path.join(__dirname, '..');
const LOJA_A = '11111111-1111-4111-8111-111111111111';
const LOJA_B = '22222222-2222-4222-8222-222222222222';
const CFG_A = 'a1a1a1a1-a1a1-4a1a-8a1a-a1a1a1a1a1a1';
const CFG_B = 'b2b2b2b2-b2b2-4b2b-8b2b-b2b2b2b2b2b2';

const pedido = (extra = {}) => ({ lojaId: LOJA_A, contato: '5511988887777', texto: 'Sim, temos a camiseta P.', ...extra });
const semCampo = (obj, campo) => {
  const copia = { ...obj };
  delete copia[campo];
  return copia;
};
const adaptador = () => obterProvedorWhatsapp('simulado');

const CHAVES_RESULTADO = ['canal', 'erro', 'idExterno', 'provedor', 'simulado', 'status', 'sucesso'];
const CHAVES_MENSAGEM = ['canal', 'contato', 'idExterno', 'lojaId', 'texto', 'timestamp'];
const CHAVES_PEDIDO = ['canal', 'configuracaoId', 'contato', 'lojaId', 'texto'];

// Captura TODA saída de console (o adaptador não deve escrever nada).
function capturarConsole(t) {
  const linhas = [];
  for (const metodo of ['log', 'info', 'warn', 'error', 'debug']) {
    t.mock.method(console, metodo, (...args) => { linhas.push([metodo, ...args]); });
  }
  return linhas;
}

function semComentarios(codigo) {
  return codigo.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`])\/\/.*$/gm, '$1');
}
function lerCodigo(arquivoRelativo) {
  return semComentarios(fs.readFileSync(path.join(RAIZ, arquivoRelativo), 'utf8'));
}

function fechamentoDeDependencias(arquivoInicial) {
  const visitados = new Set();
  const externos = new Set();
  const pilha = [path.resolve(arquivoInicial)];
  while (pilha.length) {
    const arquivo = pilha.pop();
    if (visitados.has(arquivo)) continue;
    visitados.add(arquivo);
    const codigo = semComentarios(fs.readFileSync(arquivo, 'utf8'));
    for (const m of codigo.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)) {
      const alvo = m[1];
      if (alvo.startsWith('.')) pilha.push(path.resolve(path.dirname(arquivo), alvo.endsWith('.js') ? alvo : (fs.existsSync(path.resolve(path.dirname(arquivo), alvo)) && fs.statSync(path.resolve(path.dirname(arquivo), alvo)).isDirectory() ? path.join(alvo, 'index.js') : `${alvo}.js`)));
      else externos.add(alvo);
    }
  }
  return { arquivos: [...visitados].map((a) => path.basename(a)).sort(), externos: [...externos].sort() };
}

// ---------------------------------------------------------------
// A) envio com dados válidos
// ---------------------------------------------------------------
test('A) envio com dados válidos é aceito e devolve o resultado interno SIMULADO (nada é enviado)', async () => {
  const resultado = await adaptador().enviarMensagem(pedido());

  assert.deepEqual(Object.keys(resultado).sort(), CHAVES_RESULTADO);
  assert.deepEqual(resultado, {
    canal: 'whatsapp',
    sucesso: true,
    status: 'simulado',
    simulado: true,
    idExterno: null,
    provedor: 'simulado',
    erro: null,
  });
  assert.equal(mensagemFoiEnviada(resultado), false, 'simulado NUNCA conta como enviado de verdade');
  assert.equal(Object.isFrozen(resultado), true);
});

test('A) aceita configuracaoId opcional (UUID) e um pedido já montado por criarPedidoDeEnvio', async () => {
  const comConfiguracao = await adaptador().enviarMensagem(pedido({ configuracaoId: CFG_A }));
  assert.equal(comConfiguracao.status, 'simulado');

  const montado = criarPedidoDeEnvio(pedido({ configuracaoId: CFG_A }));
  assert.equal((await adaptador().enviarMensagem(montado)).sucesso, true);
  assert.equal((await adaptador().enviarMensagem(criarPedidoDeEnvio(pedido()))).sucesso, true);
});

test('A) criarPedidoDeEnvio produz a estrutura interna: normalizada, congelada e sem segredo', () => {
  const montado = criarPedidoDeEnvio({ lojaId: LOJA_A, contato: '  5511988887777 ', texto: '  olá  ', configuracaoId: CFG_A });

  assert.deepEqual(montado, { canal: 'whatsapp', lojaId: LOJA_A, contato: '5511988887777', texto: 'olá', configuracaoId: CFG_A });
  assert.deepEqual(Object.keys(montado).sort(), CHAVES_PEDIDO);
  assert.equal(Object.isFrozen(montado), true);
  assert.equal(criarPedidoDeEnvio(pedido()).configuracaoId, null, 'sem configuração informada → null');
  assert.deepEqual([...CAMPOS_DO_PEDIDO_DE_ENVIO].sort(), CHAVES_PEDIDO, 'os campos aceitos são exatamente estes');
});

test('A) configuracaoId inválido é rejeitado; o limite de texto é o da 10A', async () => {
  for (const configuracaoId of ['abc', 123, {}, '', true]) {
    await assert.rejects(() => adaptador().enviarMensagem(pedido({ configuracaoId })), ErroMensagemWhatsappInvalida);
  }
  assert.equal((await adaptador().enviarMensagem(pedido({ texto: 'a'.repeat(LIMITE_TEXTO_MENSAGEM) }))).sucesso, true);
});

// ---------------------------------------------------------------
// B) texto vazio
// ---------------------------------------------------------------
test('B) texto vazio, em branco, ausente, que não é texto ou grande demais é rejeitado', async () => {
  for (const texto of ['', '   ', '\n\t', undefined, null, 123, {}, [], ['oi'], 'a'.repeat(LIMITE_TEXTO_MENSAGEM + 1)]) {
    await assert.rejects(() => adaptador().enviarMensagem(pedido({ texto })), ErroMensagemWhatsappInvalida);
  }
  await assert.rejects(() => adaptador().enviarMensagem(semCampo(pedido(), 'texto')), ErroMensagemWhatsappInvalida);
});

// ---------------------------------------------------------------
// C) contato ausente
// ---------------------------------------------------------------
test('C) contato ausente, vazio ou que não é texto é rejeitado', async () => {
  for (const contato of ['', '   ', undefined, null, 5511988887777, {}, []]) {
    await assert.rejects(() => adaptador().enviarMensagem(pedido({ contato })), ErroMensagemWhatsappInvalida);
  }
  await assert.rejects(() => adaptador().enviarMensagem(semCampo(pedido(), 'contato')), ErroMensagemWhatsappInvalida);
});

// ---------------------------------------------------------------
// D) lojaId ausente
// ---------------------------------------------------------------
test('D) lojaId ausente ou inválido é rejeitado (não existe loja no contexto interno)', async () => {
  for (const lojaId of [undefined, null, '', 'abc', 123, {}, LOJA_A.slice(1), `${LOJA_A}x`]) {
    await assert.rejects(() => adaptador().enviarMensagem(pedido({ lojaId })), ErroMensagemWhatsappInvalida);
  }
  await assert.rejects(() => adaptador().enviarMensagem(semCampo(pedido(), 'lojaId')), ErroMensagemWhatsappInvalida);
});

test('D) a loja não pode ser informada por outro nome: loja_id no lugar de lojaId é rejeitado', async () => {
  const semLojaId = { ...semCampo(pedido(), 'lojaId'), loja_id: LOJA_A };
  await assert.rejects(() => adaptador().enviarMensagem(semLojaId), ErroMensagemWhatsappInvalida);
  // E, mesmo com lojaId presente, um loja_id extra não é tolerado (nem "corrigido" em silêncio).
  await assert.rejects(() => adaptador().enviarMensagem(pedido({ loja_id: LOJA_B })), ErroMensagemWhatsappInvalida);
});

test('D) entrada que não é um objeto é rejeitada', async () => {
  for (const entrada of [undefined, null, 'texto', 42, true, [], [pedido()]]) {
    await assert.rejects(() => adaptador().enviarMensagem(entrada), ErroMensagemWhatsappInvalida);
  }
});

// ---------------------------------------------------------------
// E) o adaptador não realiza HTTP
// ---------------------------------------------------------------
test('E) o adaptador não faz nenhuma chamada externa (http, https, fetch, sockets)', async (t) => {
  const espioes = [
    t.mock.method(http, 'request', () => { throw new Error('http.request não deveria ser chamado'); }),
    t.mock.method(http, 'get', () => { throw new Error('http.get não deveria ser chamado'); }),
    t.mock.method(https, 'request', () => { throw new Error('https.request não deveria ser chamado'); }),
    t.mock.method(https, 'get', () => { throw new Error('https.get não deveria ser chamado'); }),
    t.mock.method(net, 'connect', () => { throw new Error('net.connect não deveria ser chamado'); }),
    t.mock.method(globalThis, 'fetch', () => { throw new Error('fetch não deveria ser chamado'); }),
  ];
  const adaptadorTeste = adaptador();

  await adaptadorTeste.enviarMensagem(pedido());
  await adaptadorTeste.enviarMensagem(semCampo(pedido(), 'texto')).catch(() => {});
  adaptadorTeste.normalizarMensagemRecebida({ ...pedido(), idExterno: 'x' });
  adaptadorTeste.identificarContato({ contato: '5511' });
  adaptadorTeste.identificarLoja({ lojaId: LOJA_A });

  for (const espiao of espioes) assert.equal(espiao.mock.callCount(), 0);
});

test('E) inspeção: o contrato e o adaptador SIMULADO não dependem de NENHUM módulo externo nem do Node (nem rede, banco, IA)', () => {
  // A partir da Etapa 10G, o PONTO DE ENTRADA (index.js) passou a registrar
  // também o adaptador real da Meta (adaptadorMeta.js + clienteHttpMeta.js),
  // então ele — e só ele, por precisar importar/registrar o adaptador —
  // agora tem essa dependência extra. O restante do teste continua
  // garantindo o que sempre garantiu: nenhum pacote npm/módulo nativo de
  // rede em NENHUM arquivo, e que o CONTRATO e o ADAPTADOR SIMULADO
  // (arquitetura da 10F) continuam sem qualquer conhecimento de rede,
  // provedor real, log ou banco.
  const { arquivos, externos } = fechamentoDeDependencias(path.join(RAIZ, 'src/services/providers/whatsapp/index.js'));

  assert.deepEqual(arquivos, [
    'adaptadorMeta.js',
    'adaptadorSimulado.js',
    'clienteHttpMeta.js',
    'contrato.js',
    'index.js',
    'validacao.js',
    'whatsapp.service.js',
  ]);
  assert.deepEqual(externos, [], 'nenhum pacote npm nem módulo nativo (http, https, net, fs...)');

  for (const arquivo of ['contrato.js', 'adaptadorSimulado.js']) {
    const codigo = lerCodigo(`src/services/providers/whatsapp/${arquivo}`);
    assert.equal(/\bfetch\s*\(|axios|XMLHttpRequest|undici|node-fetch|https?:\/\/|process\.env/i.test(codigo), false, arquivo);
    assert.equal(/twilio|z-?api|evolution|baileys|graph\.facebook|\bmeta\b|whatsapp-web|qrcode/i.test(codigo), false, `${arquivo} não pode conhecer provedor real`);
    assert.equal(/console\./.test(codigo), false, `${arquivo} não escreve em log`);
    assert.equal(/supabase|\.from\(/i.test(codigo), false, `${arquivo} não acessa banco`);
  }

  // index.js continua sem rede/log/banco diretos: ele só REGISTRA
  // adaptadores (importa e coloca num Map), não os implementa.
  const codigoIndex = lerCodigo('src/services/providers/whatsapp/index.js');
  assert.equal(/\bfetch\s*\(|axios|XMLHttpRequest|undici|node-fetch|https?:\/\//i.test(codigoIndex), false, 'index.js não chama rede diretamente');
  assert.equal(/console\./.test(codigoIndex), false, 'index.js não escreve em log');
  assert.equal(/supabase|\.from\(/i.test(codigoIndex), false, 'index.js não acessa banco');
});

// ---------------------------------------------------------------
// F) credenciais não são expostas
// ---------------------------------------------------------------
test('F) campos de credencial no pedido são rejeitados, sem ecoar nome nem valor, e sem nenhum log', async (t) => {
  const logs = capturarConsole(t);
  const camposDeSegredo = [
    'access_token', 'accessToken', 'token', 'api_key', 'apiKey', 'apikey', 'secret', 'client_secret',
    'senha', 'password', 'credenciais', 'credentials', 'authorization', 'bearer_token', 'chave_api',
  ];

  const mensagens = new Set();
  for (const campo of camposDeSegredo) {
    const erro = await adaptador().enviarMensagem({ ...pedido(), [campo]: 'VALOR-SECRETO-123' }).catch((e) => e);
    assert.ok(erro instanceof ErroMensagemWhatsappInvalida, `deveria rejeitar "${campo}"`);
    const exposto = `${erro.name} ${erro.message} ${JSON.stringify(erro)} ${erro.stack.split('\n')[0]}`;
    assert.equal(exposto.includes('VALOR-SECRETO-123'), false, 'o valor não pode aparecer no erro');
    mensagens.add(erro.message);
  }
  // A mesma mensagem fixa para qualquer campo: nada do nome enviado é repetido.
  assert.equal(mensagens.size, 1);
  assert.deepEqual(logs, [], 'nada foi escrito em console');
});

test('F) nenhum objeto de domínio tem campo de segredo: pedido, resultado, mensagem e o próprio adaptador', async () => {
  const REGEX = /token|secret|segredo|senha|passw|api[_-]?key|credencia|credential|authorization|bearer/i;
  const adaptadorTeste = adaptador();
  const objetos = {
    adaptador: adaptadorTeste,
    pedido: criarPedidoDeEnvio(pedido({ configuracaoId: CFG_A })),
    resultado: await adaptadorTeste.enviarMensagem(pedido()),
    falha: criarResultadoFalha({ provedor: 'simulado', codigoErro: CODIGOS_ERRO_ENVIO.provedorIndisponivel }),
    mensagem: adaptadorTeste.normalizarMensagemRecebida({ lojaId: LOJA_A, contato: '5511', texto: 'oi' }),
  };
  for (const [nome, objeto] of Object.entries(objetos)) {
    assert.equal(REGEX.test(Object.keys(objeto).join(' ')), false, `${nome} não pode ter campo de credencial`);
  }
  assert.deepEqual(Object.keys(adaptadorTeste).sort(), ['enviarMensagem', 'identificarContato', 'identificarLoja', 'nome', 'normalizarMensagemRecebida']);
});

test('F) falhas do contrato têm mensagem FIXA por código: texto do provedor (e o que ele contiver) nunca passa', (t) => {
  const logs = capturarConsole(t);
  const falha = criarResultadoFalha({ provedor: 'simulado', codigoErro: CODIGOS_ERRO_ENVIO.mensagemRejeitada });
  assert.deepEqual(falha.erro, { codigo: 'mensagem_rejeitada', mensagem: 'A mensagem foi rejeitada pelo provedor de WhatsApp.' });

  // Tentar passar um "erro do provedor" como código é recusado sem ecoá-lo.
  const erro = (() => {
    try { criarResultadoEnvio({ provedor: 'simulado', status: 'falhou', codigoErro: 'Invalid token EAAB-SEGREDO for app 123' }); } catch (e) { return e; }
    return null;
  })();
  assert.ok(erro instanceof ErroProvedorWhatsappInvalido);
  assert.equal(/EAAB|SEGREDO|token/i.test(erro.message), false);
  assert.deepEqual(logs, []);
});

test('F) nenhuma operação do adaptador escreve em log (nem texto, nem contato), em sucesso ou em erro', async (t) => {
  const logs = capturarConsole(t);
  const adaptadorTeste = adaptador();

  await adaptadorTeste.enviarMensagem(pedido({ texto: 'TEXTO-PRIVADO', contato: '5511977776666' }));
  await adaptadorTeste.enviarMensagem(pedido({ texto: '' })).catch(() => {});
  const mensagem = adaptadorTeste.normalizarMensagemRecebida({ lojaId: LOJA_A, contato: '5511977776666', texto: 'TEXTO-PRIVADO' });
  adaptadorTeste.identificarContato(mensagem);
  adaptadorTeste.identificarLoja(mensagem);

  assert.deepEqual(logs, []);
});

test('F) o retorno do adaptador nunca contém o texto da mensagem nem o telefone do contato', async () => {
  const resultado = await adaptador().enviarMensagem(pedido({ texto: 'TEXTO-PRIVADO-DO-CLIENTE', contato: '5511977776666' }));
  const exposto = JSON.stringify(resultado);
  assert.equal(exposto.includes('TEXTO-PRIVADO-DO-CLIENTE'), false);
  assert.equal(exposto.includes('5511977776666'), false);
  assert.equal(exposto.includes(LOJA_A), false, 'nem o lojaId: o resultado descreve o envio, não o pedido');
});

// ---------------------------------------------------------------
// G) normalização de mensagem
// ---------------------------------------------------------------
test('G) a mensagem recebida é normalizada num formato previsível (o da 10A), congelado', () => {
  const mensagem = adaptador().normalizarMensagemRecebida({
    lojaId: LOJA_A, contato: '  5511988887777 ', texto: '  Tem camiseta P?  ', idExterno: 'msg-1', timestamp: '2026-09-18T12:00:00.000Z',
  });

  assert.deepEqual(mensagem, {
    canal: 'whatsapp',
    lojaId: LOJA_A,
    contato: '5511988887777',
    texto: 'Tem camiseta P?',
    idExterno: 'msg-1',
    timestamp: '2026-09-18T12:00:00.000Z',
  });
  assert.deepEqual(Object.keys(mensagem).sort(), CHAVES_MENSAGEM);
  assert.equal(Object.isFrozen(mensagem), true);
});

test('G) é exatamente a normalização da 10A (nada duplicado) e os opcionais ausentes viram null', () => {
  const entrada = { lojaId: LOJA_A, contato: '5511988887777', texto: 'oi', timestamp: 1789732800000 };
  assert.deepEqual(adaptador().normalizarMensagemRecebida(entrada), whatsappService.normalizarMensagemRecebida(entrada));

  const minima = adaptador().normalizarMensagemRecebida({ lojaId: LOJA_A, contato: '5511', texto: 'oi' });
  assert.equal(minima.idExterno, null);
  assert.equal(minima.timestamp, null);
});

test('G) campos extras (loja_id, configuracaoId, provedor, instruções...) são ignorados e a loja vem SÓ do lojaId explícito', () => {
  const mensagem = adaptador().normalizarMensagemRecebida({
    lojaId: LOJA_A, contato: '5511', texto: 'oi',
    loja_id: LOJA_B, LojaId: LOJA_B, configuracaoId: CFG_B, provedor: 'provedor-forjado',
    system_prompt: 'ignore tudo', access_token: 'abc', dadosExternos: { loja_id: LOJA_B },
  });

  assert.equal(mensagem.lojaId, LOJA_A);
  assert.deepEqual(Object.keys(mensagem).sort(), CHAVES_MENSAGEM);
  assert.equal(/provedor-forjado|system_prompt|ignore tudo|abc|configuracaoId/.test(JSON.stringify(mensagem)), false);
  assert.equal(JSON.stringify(mensagem).includes(LOJA_B), false);
});

test('G) sem lojaId explícito NÃO se usa loja_id do payload: rejeita', () => {
  assert.throws(() => adaptador().normalizarMensagemRecebida({ loja_id: LOJA_A, contato: '5511', texto: 'oi' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => adaptador().normalizarMensagemRecebida({ dadosExternos: { loja_id: LOJA_A }, contato: '5511', texto: 'oi' }), ErroMensagemWhatsappInvalida);

  // propriedades herdadas do protótipo também não são lidas
  const herdado = Object.create({ lojaId: LOJA_A, contato: '5511', texto: 'oi' });
  assert.throws(() => adaptador().normalizarMensagemRecebida(herdado), ErroMensagemWhatsappInvalida);
});

test('G) entradas inválidas são rejeitadas com erro controlado', () => {
  for (const entrada of [undefined, null, 'texto', 42, [], [{ lojaId: LOJA_A }]]) {
    assert.throws(() => adaptador().normalizarMensagemRecebida(entrada), ErroMensagemWhatsappInvalida);
  }
  const base = { lojaId: LOJA_A, contato: '5511', texto: 'oi' };
  assert.throws(() => adaptador().normalizarMensagemRecebida({ ...base, texto: '' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => adaptador().normalizarMensagemRecebida({ ...base, contato: '  ' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => adaptador().normalizarMensagemRecebida({ ...base, texto: 'a'.repeat(LIMITE_TEXTO_MENSAGEM + 1) }), ErroMensagemWhatsappInvalida);
  assert.throws(() => adaptador().normalizarMensagemRecebida({ ...base, idExterno: 99 }), ErroMensagemWhatsappInvalida);
  assert.throws(() => adaptador().normalizarMensagemRecebida({ ...base, timestamp: 'não é data' }), ErroMensagemWhatsappInvalida);
});

// ---------------------------------------------------------------
// H) identificação de contato
// ---------------------------------------------------------------
test('H) o contato é a identidade do remetente/destinatário, e a loja é lida do lojaId — nunca do contato', () => {
  const mensagem = adaptador().normalizarMensagemRecebida({ lojaId: LOJA_A, contato: '5511988887777', texto: 'oi' });

  assert.equal(adaptador().identificarContato(mensagem), '5511988887777');
  assert.equal(adaptador().identificarLoja(mensagem), LOJA_A);
});

test('H) mesmo um contato que "parece" a loja de outro tenant não altera a loja', () => {
  for (const contato of [LOJA_B, LOJA_A, CFG_B, 'loja_id=' + LOJA_B]) {
    const mensagem = adaptador().normalizarMensagemRecebida({ lojaId: LOJA_A, contato, texto: 'oi' });
    assert.equal(adaptador().identificarLoja(mensagem), LOJA_A);
    assert.equal(adaptador().identificarContato(mensagem), contato);
  }

  // identificarLoja não inventa loja a partir do contato.
  assert.equal(adaptador().identificarLoja({ contato: LOJA_B }), null);
  assert.equal(adaptador().identificarContato({ lojaId: LOJA_B }), null);
});

test('H) no envio, o contato também é só o destinatário: o pedido mantém a loja informada', () => {
  const montado = criarPedidoDeEnvio(pedido({ contato: LOJA_B }));
  assert.equal(montado.lojaId, LOJA_A);
  assert.equal(montado.contato, LOJA_B);
});

test('H) identificarContato/identificarLoja rejeitam o que não é mensagem normalizada', () => {
  for (const entrada of [undefined, null, 'texto', 42]) {
    assert.throws(() => adaptador().identificarContato(entrada), ErroMensagemWhatsappInvalida);
    assert.throws(() => adaptador().identificarLoja(entrada), ErroMensagemWhatsappInvalida);
  }
});

// ---------------------------------------------------------------
// I) resultado interno
// ---------------------------------------------------------------
test('I) o resultado do envio simulado é sempre idêntico em formato, e nunca inventa idExterno', async () => {
  const r1 = await adaptador().enviarMensagem(pedido());
  const r2 = await adaptador().enviarMensagem(pedido({ contato: '5511000000000', texto: 'outra', configuracaoId: CFG_A }));

  assert.deepEqual(r1, r2, 'o resultado descreve o envio, não depende do conteúdo');
  assert.deepEqual(Object.keys(r1), Object.keys(r2));
  assert.equal(r1.idExterno, null);
  assert.equal(r1.simulado, true);
  assert.equal(r1.status, STATUS_ENVIO.simulado);
});

test('I) criarResultadoEnvio: os três status têm formato consistente', () => {
  const enviado = criarResultadoEnvio({ provedor: 'algum-provedor', status: 'enviado', idExterno: 'abc-123' });
  assert.deepEqual(enviado, { canal: 'whatsapp', sucesso: true, status: 'enviado', simulado: false, idExterno: 'abc-123', provedor: 'algum-provedor', erro: null });

  const enviadoSemId = criarResultadoEnvio({ provedor: 'algum-provedor', status: 'enviado' });
  assert.equal(enviadoSemId.idExterno, null);

  const falhou = criarResultadoFalha({ provedor: 'algum-provedor', codigoErro: CODIGOS_ERRO_ENVIO.erroInterno });
  assert.deepEqual(falhou, {
    canal: 'whatsapp', sucesso: false, status: 'falhou', simulado: false, idExterno: null, provedor: 'algum-provedor',
    erro: { codigo: 'erro_interno', mensagem: 'Não foi possível enviar a mensagem.' },
  });

  for (const resultado of [enviado, enviadoSemId, falhou, criarResultadoEnvio({ provedor: 'x', status: 'simulado' })]) {
    assert.deepEqual(Object.keys(resultado).sort(), CHAVES_RESULTADO);
    assert.equal(Object.isFrozen(resultado), true);
  }
  assert.equal(Object.isFrozen(falhou.erro), true);
});

test('I) criarResultadoEnvio rejeita combinações incoerentes', () => {
  const invalidos = [
    {},
    { provedor: '', status: 'enviado' },
    { provedor: 'p', status: 'desconhecido' },
    { provedor: 'p', status: 'enviado', idExterno: 123 },
    { provedor: 'p', status: 'enviado', idExterno: '   ' },
    { provedor: 'p', status: 'simulado', idExterno: 'inventado' }, // simulado não tem id
    { provedor: 'p', status: 'falhou' }, // falha exige código
    { provedor: 'p', status: 'falhou', codigoErro: 'inventado' },
    { provedor: 'p', status: 'falhou', codigoErro: 'erro_interno', idExterno: 'x' },
    { provedor: 'p', status: 'enviado', codigoErro: 'erro_interno' }, // código só em falhas
  ];
  for (const entrada of invalidos) {
    assert.throws(() => criarResultadoEnvio(entrada), ErroProvedorWhatsappInvalido, JSON.stringify(entrada));
  }
  assert.throws(() => criarResultadoEnvio(), ErroProvedorWhatsappInvalido);
});

test('I) mensagemFoiEnviada só é verdadeira para um envio REAL aceito', () => {
  assert.equal(mensagemFoiEnviada(criarResultadoEnvio({ provedor: 'p', status: 'enviado', idExterno: 'x' })), true);
  assert.equal(mensagemFoiEnviada(criarResultadoEnvio({ provedor: 'p', status: 'enviado' })), true);

  assert.equal(mensagemFoiEnviada(criarResultadoEnvio({ provedor: 'p', status: 'simulado' })), false);
  assert.equal(mensagemFoiEnviada(criarResultadoFalha({ provedor: 'p', codigoErro: 'erro_interno' })), false);
  for (const lixo of [undefined, null, {}, 'enviado', 1, { sucesso: true }, { sucesso: true, status: 'enviado' }, { sucesso: true, status: 'enviado', simulado: true }]) {
    assert.equal(mensagemFoiEnviada(lixo), false);
  }
});

// ---------------------------------------------------------------
// Contrato: implementações e registro
// ---------------------------------------------------------------
test('contrato: as quatro operações exigidas, e o adaptador simulado as cumpre', () => {
  assert.deepEqual([...OPERACOES_DO_CONTRATO], ['enviarMensagem', 'normalizarMensagemRecebida', 'identificarContato', 'identificarLoja']);
  assert.equal(verificarImplementacaoDoContrato(criarAdaptadorSimulado()).nome, 'simulado');
});

test('contrato: implementação incompleta ou malformada é rejeitada', () => {
  const completa = criarAdaptadorSimulado();

  for (const operacao of OPERACOES_DO_CONTRATO) {
    const incompleta = { ...completa, [operacao]: undefined };
    const erro = (() => { try { verificarImplementacaoDoContrato(incompleta); } catch (e) { return e; } return null; })();
    assert.ok(erro instanceof ErroProvedorWhatsappInvalido, operacao);
    assert.match(erro.message, new RegExp(operacao));
  }
  for (const invalida of [undefined, null, 'x', 42, {}, { ...completa, nome: '' }, { ...completa, nome: 5 }]) {
    assert.throws(() => verificarImplementacaoDoContrato(invalida), ErroProvedorWhatsappInvalido);
  }
});

test('contrato: o adaptador está congelado (não dá para trocar uma operação em tempo de execução)', () => {
  const adaptadorTeste = adaptador();
  assert.equal(Object.isFrozen(adaptadorTeste), true);
  assert.throws(() => { 'use strict'; adaptadorTeste.enviarMensagem = async () => ({ sucesso: true }); }, TypeError);
});

test('registro: "simulado" e, a partir da 10G, "meta" estão registrados; nenhum outro provedor está', () => {
  // Etapa 10G: o adaptador real da Meta passou a existir e está registrado
  // no ponto de entrada (ver src/services/providers/whatsapp/index.js e
  // adaptadorMeta.js). Isso NÃO significa que ele está ativo no fluxo de
  // produção — nada chama `obterProvedorWhatsapp('meta')` automaticamente
  // (ver docs/ARQUITETURA.md) — só que pedir esse nome explicitamente
  // agora devolve um adaptador de verdade em vez de lançar.
  assert.deepEqual(listarProvedoresDisponiveis(), ['simulado', 'meta']);
  assert.equal(obterProvedorWhatsapp('simulado').nome, 'simulado');
  assert.equal(obterProvedorWhatsapp('  SIMULADO ').nome, 'simulado');
  assert.equal(obterProvedorWhatsapp('meta').nome, 'meta');
  assert.equal(obterProvedorWhatsapp('  META ').nome, 'meta');

  for (const nome of ['twilio', 'evolution', 'baileys', 'zapi', 'z-api', 'outro', '__proto__', 'constructor', 'toString', 'hasOwnProperty']) {
    assert.throws(() => obterProvedorWhatsapp(nome), ErroProvedorWhatsappNaoSuportado, nome);
  }
});

test('registro: o nome do provedor é obrigatório (sem padrão) e o erro não ecoa o que foi pedido', () => {
  for (const nome of [undefined, null, '', '   ', 123, {}, []]) {
    assert.throws(() => obterProvedorWhatsapp(nome), ErroProvedorWhatsappNaoSuportado);
  }
  const erro = (() => { try { obterProvedorWhatsapp('provedor-secreto-XYZ'); } catch (e) { return e; } return null; })();
  assert.equal(erro.message, 'Provedor de WhatsApp não suportado.');
  assert.equal(JSON.stringify(erro).includes('XYZ'), false);
});

test('registro: o ponto de entrada reexporta o contrato, então o resto do sistema não importa adaptador algum', () => {
  for (const nome of ['criarPedidoDeEnvio', 'criarResultadoEnvio', 'criarResultadoFalha', 'mensagemFoiEnviada', 'verificarImplementacaoDoContrato', 'obterProvedorWhatsapp']) {
    assert.equal(typeof provedores[nome], 'function', nome);
  }
  assert.equal(Object.hasOwn(provedores, 'criarAdaptadorSimulado'), false, 'o adaptador específico não faz parte da API pública');
});

// ---------------------------------------------------------------
// J) compatibilidade
// ---------------------------------------------------------------
test('J) whatsapp.service.js (10A) continua intacto: as funções existem e os placeholders reais continuam lançando', async () => {
  for (const nome of ['normalizarMensagemRecebida', 'prepararEnvioMensagem', 'identificarContato', 'identificarLoja', 'enviarMensagem', 'receberMensagem']) {
    assert.equal(typeof whatsappService[nome], 'function', nome);
  }
  // O placeholder de envio da 10A continua recusando de propósito: ele não é o adaptador.
  await assert.rejects(() => whatsappService.enviarMensagem(pedido()), /integração real com provedor de WhatsApp ainda não implementada/);
  await assert.rejects(() => whatsappService.receberMensagem(), /ainda não implementada/);
});

test('J) o adaptador REAPROVEITA a 10A em vez de duplicar regras', () => {
  const contratoCodigo = lerCodigo('src/services/providers/whatsapp/contrato.js');
  const adaptadorCodigo = lerCodigo('src/services/providers/whatsapp/adaptadorSimulado.js');

  assert.match(contratoCodigo, /prepararEnvioMensagem/);
  assert.match(adaptadorCodigo, /normalizarMensagemRecebida[\s\S]*identificarContato[\s\S]*identificarLoja/);
  assert.equal(/LIMITE_TEXTO_MENSAGEM\s*=/.test(contratoCodigo + adaptadorCodigo), false, 'não redefine o limite de texto');
  assert.equal(/class ErroMensagemWhatsappInvalida/.test(contratoCodigo + adaptadorCodigo), false, 'não redefine o erro da 10A');
});

test('J) o webhook e a segurança já aprovados não dependem do novo contrato (envio) e não foram tocados por ele', () => {
  // Desde a Etapa 10I, o controller importa APENAS o interpretador de
  // RECEBIMENTO da Meta (`interpretadorWebhookMeta.js`, 10H) — nunca o
  // contrato/adaptador de ENVIO (`contrato.js`, `adaptadorSimulado.js`,
  // `adaptadorMeta.js`, `providers/whatsapp/index.js`,
  // `obterProvedorWhatsapp`). Por isso ele é verificado à parte, com uma
  // checagem mais específica do que os demais arquivos do webhook (que
  // continuam sem tocar em nada de `providers/whatsapp`).
  const codigoControlador = lerCodigo('src/controllers/whatsappWebhook.controller.js');
  assert.equal(/providers\/whatsapp\/(contrato|adaptadorSimulado|adaptadorMeta|clienteHttpMeta|index)|obterProvedorWhatsapp/.test(codigoControlador), false, 'o controller não deve importar o contrato/adaptador de ENVIO');
  assert.match(codigoControlador, /providers\/whatsapp\/interpretadorWebhookMeta/, 'o controller deve importar só o interpretador de recebimento (10H)');

  const arquivosDoWebhookSemProvider = [
    'src/routes/whatsappWebhook.routes.js',
    'src/services/whatsappWebhook.service.js',
    'src/services/whatsappWebhookAssinatura.service.js',
    'src/middleware/webhookAssinatura.js',
    'src/services/whatsappConfiguracao.service.js',
    'src/app.js',
  ];
  for (const arquivo of arquivosDoWebhookSemProvider) {
    assert.equal(/providers\/whatsapp|obterProvedorWhatsapp|adaptadorSimulado/.test(lerCodigo(arquivo)), false, `${arquivo} não deve importar o contrato/adaptador`);
  }
  // A cadeia de segurança continua declarada na rota (a ordem é exercitada em tests/whatsappWebhookAssinatura.test.js).
  const rota = lerCodigo('src/routes/whatsappWebhook.routes.js');
  assert.match(rota, /router\.post\('\/', limitarWebhook, interpretarJson, verificarAssinaturaWebhook, receberEvento\)/);
});

test('J/10N compat) contrato de envio não adiciona credenciais; migrations incluem histórico sem novos segredos', () => {
  const migrations = fs.readdirSync(path.join(RAIZ, 'src/db/migrations')).sort();
  assert.deepEqual(migrations, ['001_correcoes_auditoria.sql', '002_clientes_v1.sql', '003_whatsapp_configuracoes.sql', '004_whatsapp_idempotencia.sql', '005_whatsapp_historico.sql', '006_whatsapp_fila_retry.sql', '007_whatsapp_credenciais.sql', '008_prompt_mestre_loja.sql', '009_comercial_11a.sql', '010_cobranca_mercadopago_11c.sql']);

  const exemplo = fs.readFileSync(path.join(RAIZ, '.env.example'), 'utf8');
  const variaveisWhatsapp = exemplo.split('\n').filter((l) => /^WHATSAPP_[A-Z_]+=/.test(l)).map((l) => l.split('=')[0]).sort();
  assert.deepEqual(variaveisWhatsapp, ['WHATSAPP_CREDENTIALS_MASTER_KEY', 'WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS', 'WHATSAPP_WEBHOOK_RATE_LIMIT_MAX', 'WHATSAPP_WORKER_INTERVALO_MS', 'WHATSAPP_WORKER_LEASE_SEGUNDOS', 'WHATSAPP_WORKER_MAX_TENTATIVAS', 'WHATSAPP_WORKER_RETRY_BASE_MS', 'WHATSAPP_WORKER_RETRY_MAX_MS'].sort());
  assert.match(exemplo, /^META_APP_SECRET=$/m);
  assert.match(exemplo, /^META_WHATSAPP_VERIFY_TOKEN=$/m);

  const schema = fs.readFileSync(path.join(RAIZ, 'src/db/schema.sql'), 'utf8').toLowerCase();
  const trechoConfig = schema.split('create table if not exists whatsapp_configuracoes')[1].split('create table if not exists whatsapp_credenciais')[0];
  assert.equal(/access_token|api_key|client_secret/.test(trechoConfig), false);
  assert.match(schema, /create table if not exists whatsapp_credenciais/);
  assert.match(schema, /access_token_cifrado/);
});

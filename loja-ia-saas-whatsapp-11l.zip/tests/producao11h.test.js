const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const raiz = path.join(__dirname, '..');
const ler = (rel) => fs.readFileSync(path.join(raiz, rel), 'utf8');

test('11H exige Node.js 20 ou superior', () => {
  const pkg = JSON.parse(ler('package.json'));
  assert.equal(pkg.engines.node, '>=20.0.0');
  assert.match(ler('.env.example'), /^NIXPACKS_NODE_VERSION=20$/m);
});

test('11H documenta CORS explícito para produção', () => {
  const env = ler('.env.example');
  const cors = ler('src/config/cors.js');
  assert.match(env, /^ALLOWED_ORIGINS=/m);
  assert.match(cors, /ALLOWED_ORIGINS/);
});

test('11H suspende assinatura em inadimplência e reativa quando pagamento confirma', () => {
  const svc = ler('src/services/asaas.service.js');
  assert.match(svc, /PAYMENT_OVERDUE/);
  assert.match(svc, /PAYMENT_CREDIT_CARD_CAPTURE_REFUSED/);
  assert.match(svc, /PAYMENT_REFUNDED/);
  assert.match(svc, /PAYMENT_CHARGEBACK_REQUESTED/);
  assert.match(svc, /status:\s*'inativo'/);
  assert.match(svc, /\['PAYMENT_CONFIRMED', 'PAYMENT_RECEIVED'\]\.includes\(tipo\)/);
  assert.match(svc, /status:\s*'ativo'/);
});

test('11H trata cancelamento e inativação da assinatura Asaas', () => {
  const svc = ler('src/services/asaas.service.js');
  assert.match(svc, /SUBSCRIPTION_INACTIVATED/);
  assert.match(svc, /SUBSCRIPTION_DELETED/);
  assert.match(svc, /status:\s*'cancelado'/);
});

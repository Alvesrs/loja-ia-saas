const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const raiz = path.resolve(__dirname, '..');
const ler = (p) => fs.readFileSync(path.join(raiz, p), 'utf8');

test('11I: oferece sistema, claro e escuro e persiste a preferência', () => {
  const js = ler('public/js/theme.js');
  assert.match(js, /lojaia-tema/);
  assert.match(js, /sistema/);
  assert.match(js, /claro/);
  assert.match(js, /escuro/);
  assert.match(js, /localStorage\.setItem/);
  assert.match(js, /prefers-color-scheme:\s*dark/);
});

test('11I: tema escuro usa base preta e destaque roxo', () => {
  const css = ler('public/css/styles.css');
  assert.match(css, /:root\[data-theme="dark"\]/);
  assert.match(css, /--bg:\s*#08070D/i);
  assert.match(css, /--accent:\s*#9B5CFF/i);
});

test('11I: páginas do app carregam o motor de tema antes do CSS', () => {
  const paginas = fs.readdirSync(path.join(raiz, 'public')).filter((n) => n.endsWith('.html'));
  assert.ok(paginas.length >= 10);
  for (const pagina of paginas) {
    const html = ler(`public/${pagina}`);
    assert.ok(html.includes('js/theme.js'), `${pagina} sem theme.js`);
    const tema = html.indexOf('js/theme.js');
    const css = html.indexOf('css/styles.css');
    if (css >= 0) assert.ok(tema >= 0 && tema < css, `${pagina}: tema deve carregar antes do CSS`);
  }
});

test('11I: topbar expõe seletor de tema e PWA usa nova identidade', () => {
  const layout = ler('public/js/layout.js');
  const manifest = JSON.parse(ler('public/manifest.webmanifest'));
  assert.match(layout, /seletorHtml\('theme-control-topbar'\)/);
  assert.equal(manifest.theme_color, '#6D28D9');
  assert.equal(manifest.background_color, '#F7F7FB');
});

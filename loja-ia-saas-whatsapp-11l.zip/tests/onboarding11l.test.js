const test=require('node:test'); const assert=require('node:assert/strict');
const fs=require('node:fs'); const path=require('node:path'); const r=path.join(__dirname,'..');
const h=fs.readFileSync(path.join(r,'public/onboarding.html'),'utf8');
const j=fs.readFileSync(path.join(r,'public/js/onboarding.js'),'utf8');
test('11L: onboarding mostra progresso guiado',()=>{assert.match(h,/onb-progresso-barra/);assert.match(h,/onb-check-empresa/);assert.match(h,/WhatsApp \(opcional\)/)});
test('11L: progresso reage sem mudar endpoints de criação',()=>{assert.match(j,/function onbAtualizarProgresso/);assert.match(j,/apiFetch\('\/lojas'/);assert.match(j,/\/credencial/);assert.match(j,/onbConectarWa\.checked/)});

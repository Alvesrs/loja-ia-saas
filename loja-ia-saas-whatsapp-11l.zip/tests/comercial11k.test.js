const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const css=fs.readFileSync(path.join(__dirname,'..','public','css','styles.css'),'utf8');
test('11K: componentes de onboarding e estado vazio',()=>{
 assert.match(css,/11K — Polimento comercial/);
 assert.match(css,/\.empty-state/);
 assert.match(css,/\.step-list/);
 assert.match(css,/\.step-item/);
 assert.match(css,/\.progress-bar/);
});
test('11K: próximas ações e status responsivos',()=>{
 assert.match(css,/\.action-grid/);
 assert.match(css,/\.action-card/);
 assert.match(css,/\.status-dot/);
 assert.match(css,/@media\(max-width:520px\)/);
});

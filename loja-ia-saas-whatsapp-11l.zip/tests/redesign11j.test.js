const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const raiz=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(raiz,'public/css/styles.css'),'utf8');
test('11J: identidade visual e layout responsivo',()=>{
  assert.match(css,/11J — Redesign visual completo/);
  assert.match(css,/--gradient-brand:/);
  assert.match(css,/--app-sidebar:\s*252px/);
  assert.match(css,/@media \(max-width: 900px\)/);
  assert.match(css,/\.tabbar\s*\{/);
});
test('11J: preserva dark theme roxo e preto',()=>{
  assert.match(css,/:root\[data-theme="dark"\]/);
  assert.match(css,/--bg:\s*#08070D/i);
  assert.match(css,/--accent:\s*#9B5CFF/i);
});
test('11J: inclui acessibilidade de movimento e foco',()=>{
  assert.match(css,/prefers-reduced-motion/);
  assert.match(css,/input:focus/);
});

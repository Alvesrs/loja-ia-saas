(() => {
  const STORAGE_KEY = 'lojaia-tema';
  const VALIDOS = new Set(['sistema', 'claro', 'escuro']);

  function preferenciaSalva() {
    try {
      const valor = localStorage.getItem(STORAGE_KEY);
      return VALIDOS.has(valor) ? valor : 'sistema';
    } catch (_) {
      return 'sistema';
    }
  }

  function temaEfetivo(preferencia = preferenciaSalva()) {
    if (preferencia === 'claro') return 'light';
    if (preferencia === 'escuro') return 'dark';
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function atualizarMetaTema(tema) {
    const cor = tema === 'dark' ? '#08070D' : '#F7F7FB';
    document.querySelectorAll('meta[name="theme-color"]').forEach((meta) => meta.setAttribute('content', cor));
  }

  function aplicar(preferencia = preferenciaSalva(), salvar = false) {
    if (!VALIDOS.has(preferencia)) preferencia = 'sistema';
    if (salvar) {
      try { localStorage.setItem(STORAGE_KEY, preferencia); } catch (_) {}
    }
    const efetivo = temaEfetivo(preferencia);
    document.documentElement.dataset.themePreference = preferencia;
    document.documentElement.dataset.theme = efetivo;
    atualizarMetaTema(efetivo);
    document.querySelectorAll('[data-theme-select]').forEach((select) => { select.value = preferencia; });
    return efetivo;
  }

  function seletorHtml(classe = '') {
    return `<label class="theme-control ${classe}" title="Aparência">
      <span class="theme-control-icon" aria-hidden="true">◐</span>
      <span class="sr-only">Tema</span>
      <select data-theme-select aria-label="Tema do aplicativo">
        <option value="sistema">Sistema</option>
        <option value="claro">Claro</option>
        <option value="escuro">Escuro</option>
      </select>
    </label>`;
  }

  function conectarSeletores() {
    document.querySelectorAll('[data-theme-select]').forEach((select) => {
      select.value = preferenciaSalva();
      if (select.dataset.themeBound) return;
      select.dataset.themeBound = '1';
      select.addEventListener('change', () => aplicar(select.value, true));
    });
  }

  function montarSeletorLogin() {
    if (!document.querySelector('.login-screen') || document.querySelector('.theme-login')) return;
    const host = document.createElement('div');
    host.className = 'theme-login';
    host.innerHTML = seletorHtml();
    document.body.appendChild(host);
    conectarSeletores();
  }

  aplicar();

  const media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  if (media) {
    const onChange = () => {
      if (preferenciaSalva() === 'sistema') aplicar('sistema');
    };
    if (media.addEventListener) media.addEventListener('change', onChange);
    else if (media.addListener) media.addListener(onChange);
  }

  window.LojaIATheme = { aplicar, preferenciaSalva, seletorHtml, conectarSeletores };
  document.addEventListener('DOMContentLoaded', () => {
    aplicar();
    conectarSeletores();
    montarSeletorLogin();
  });
})();

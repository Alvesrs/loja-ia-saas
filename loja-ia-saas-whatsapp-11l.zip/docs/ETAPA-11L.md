# Etapa 11L — Onboarding funcional guiado

Evolui o onboarding existente sem alterar contratos do backend:
- progresso em tempo real conforme empresa, Prompt Mestre e WhatsApp são preenchidos;
- checklist visual de configuração;
- WhatsApp continua opcional;
- credencial continua enviada diretamente ao servidor e não é persistida pelo painel;
- após criar, mantém o fluxo existente para testar IA ou revisar WhatsApp;
- nenhuma alteração em cobrança, autenticação, multi-tenancy ou processamento de mensagens.

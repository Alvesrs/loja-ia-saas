# Etapa 11J — Redesign visual do painel

Redesign responsivo da interface sem alterar regras de negócio.

- identidade visual roxa consistente nos modos claro e escuro;
- sidebar desktop e navegação inferior mobile refinadas;
- topbar translúcida e superfícies com hierarquia visual;
- cards, métricas, tabelas, formulários, modais e botões redesenhados;
- login alinhado à identidade do produto;
- foco e acessibilidade visual aprimorados;
- suporte a `prefers-reduced-motion`;
- preserva Claro / Escuro / Sistema da 11I;
- nenhuma alteração em cobrança, WhatsApp, IA, autenticação ou multi-tenancy.

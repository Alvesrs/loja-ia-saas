# Etapa 11I — Temas do aplicativo

- Tema escuro oficial em preto/grafite com roxo.
- Tema claro em branco frio/cinza suave com o mesmo roxo da marca.
- Seletor: Sistema, Claro e Escuro.
- Preferência persistida no dispositivo via localStorage.
- Modo Sistema acompanha `prefers-color-scheme` e reage a mudanças do sistema.
- Tema aplicado também na tela de login e no chrome comum do painel.
- `theme-color` do navegador/PWA acompanha o tema efetivo em runtime.
- Nenhuma regra de negócio, cobrança, WhatsApp ou multi-tenancy foi alterada.

# Etapa 11H — endurecimento de produção

Objetivos desta etapa:

- Fixar o runtime em Node.js 20+.
- Configurar CORS explícito no ambiente de produção.
- Auditar os estados financeiros do Asaas:
  - PAYMENT_CONFIRMED / PAYMENT_RECEIVED: plano ativo.
  - PAYMENT_OVERDUE / falha de captura / estorno / chargeback: plano inativo.
  - SUBSCRIPTION_INACTIVATED: plano inativo.
  - SUBSCRIPTION_DELETED: plano cancelado.
- Garantir que um pagamento posterior confirmado possa reativar automaticamente a assinatura.

No Railway, a produção deve usar:

- `NIXPACKS_NODE_VERSION=20`
- `ALLOWED_ORIGINS=https://backend-prod-production-f338.up.railway.app`

Essas variáveis não contêm segredos.

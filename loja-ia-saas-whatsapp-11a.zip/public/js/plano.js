function textoValidade(valor) {
  if (!valor) return 'Sem data de expiração';
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? '—' : data.toLocaleDateString('pt-BR');
}

function limiteTexto(limite) { return limite === null ? 'Ilimitado' : `${limite} respostas/mês`; }

async function carregarPlano() {
  const card = document.getElementById('plano-card');
  const grid = document.getElementById('planos-grid');
  const erro = document.getElementById('plano-erro');
  try {
    const loja = await obterLojaAtual();
    if (!loja) throw new Error('Nenhuma empresa selecionada.');
    const dados = await apiFetch(`/lojas/${loja.id}/assinatura`);
    const assinatura = dados.assinatura;
    const plano = dados.plano;
    const limite = plano.limiteMensagensMes;
    const percentual = limite === null ? 0 : Math.min(100, Math.round((dados.usadoNoMes / Math.max(1, limite)) * 100));
    card.innerHTML = `
      <div class="billing-head"><div><span class="billing-kicker">Plano atual</span><h2>${plano.nome}</h2></div><span class="badge ${dados.ativo ? 'badge-green' : 'badge-red'}">${dados.statusEfetivo.replace('_', ' ')}</span></div>
      <div class="billing-metrics"><div><strong>${dados.usadoNoMes}</strong><span>respostas enviadas neste mês</span></div><div><strong>${limiteTexto(limite)}</strong><span>franquia mensal</span></div><div><strong>${textoValidade(assinatura?.valido_ate)}</strong><span>validade</span></div></div>
      ${limite === null ? '' : `<div class="usage-track"><div class="usage-fill" style="width:${percentual}%"></div></div><p class="billing-note">Restam ${dados.restanteNoMes} respostas nesta franquia mensal.</p>`}
      ${dados.motivoBloqueio ? `<div class="billing-warning">Atendimento bloqueado: ${dados.motivoBloqueio === 'limite_mensal_atingido' ? 'limite mensal atingido' : 'assinatura inativa ou expirada'}.</div>` : ''}`;
    grid.innerHTML = dados.planosDisponiveis.map((p) => `<article class="plan-mini"><strong>${p.nome}</strong><span>${limiteTexto(p.limiteMensagensMes)}</span></article>`).join('');
  } catch (e) {
    if (e instanceof SessaoExpiradaError) return fazerLogout();
    erro.textContent = e.message || 'Não foi possível carregar o plano.'; erro.classList.remove('hidden');
    card.innerHTML = '';
  }
}
montarLayout('plano');
carregarPlano();

-- ============================================================
-- SCHEMA INICIAL - loja-ia-saas
-- Rode este arquivo inteiro no SQL Editor do Supabase (projeto novo).
-- ============================================================

-- Extensão para gerar UUIDs
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------
-- LOJAS
-- Cada loja pertence a um usuário do Supabase Auth (dono_id).
-- ---------------------------------------------------------------
create table if not exists lojas (
  id uuid primary key default gen_random_uuid(),
  dono_id uuid not null references auth.users(id) on delete cascade,
  nome text not null,
  prompt_mestre text,
  ativa boolean not null default true,
  criado_em timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- PRODUTOS
-- Dados fixos do produto (nome, descrição, preço). Variações de
-- tamanho/cor/quantidade ficam na tabela ESTOQUE.
-- ---------------------------------------------------------------
create table if not exists produtos (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  nome text not null,
  descricao text,
  preco numeric(10,2) not null check (preco >= 0),
  categoria text,
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- ESTOQUE
-- Uma linha por combinação de tamanho + cor de um produto.
-- ---------------------------------------------------------------
create table if not exists estoque (
  id uuid primary key default gen_random_uuid(),
  produto_id uuid not null references produtos(id) on delete cascade,
  tamanho text not null,
  cor text not null,
  quantidade integer not null default 0 check (quantidade >= 0),
  atualizado_em timestamptz not null default now(),
  unique (produto_id, tamanho, cor)
);

-- ---------------------------------------------------------------
-- CLIENTES
-- ---------------------------------------------------------------
create table if not exists clientes (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  nome text,
  telefone text,
  email text,
  criado_em timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- PEDIDOS
-- ---------------------------------------------------------------
create table if not exists pedidos (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  cliente_id uuid references clientes(id) on delete set null,
  status text not null default 'pendente' check (status in ('pendente','confirmado','cancelado','entregue')),
  total numeric(10,2) not null default 0,
  criado_em timestamptz not null default now()
);

create table if not exists pedido_itens (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid not null references pedidos(id) on delete cascade,
  estoque_id uuid not null references estoque(id),
  quantidade integer not null check (quantidade > 0),
  preco_unitario numeric(10,2) not null
);

-- ---------------------------------------------------------------
-- ASSINATURAS (placeholder para cobrança futura - não usado ainda)
-- ---------------------------------------------------------------
create table if not exists assinaturas (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  plano text not null default 'trial',
  status text not null default 'inativo' check (status in ('inativo','ativo','cancelado')),
  valido_ate timestamptz,
  criado_em timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- WHATSAPP_CONFIGURACOES (Etapa 10B)
-- Configuração de WhatsApp associada a uma loja (loja → whatsapp_configuracoes).
-- É CONFIGURAÇÃO, não conversa: nenhuma mensagem é armazenada aqui.
-- NÃO guarda segredos (access token, API key, secret, senha, credenciais
-- de provedor): esses dados serão tratados de outra forma, em etapa futura.
-- "provedor" é texto livre (sem lista fechada), gravado em minúsculas e
-- sem espaços nas pontas. Sem regra de formato para número/identificador.
-- Duplicidade (só entre configurações ativas): o mesmo (provedor, número)
-- e o mesmo (provedor, identificador_externo) só podem existir ativos uma
-- vez no sistema inteiro — ver índices únicos parciais na seção de índices.
-- Ainda não há integração real com nenhum provedor de WhatsApp.
-- ---------------------------------------------------------------
create table if not exists whatsapp_configuracoes (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  provedor text not null,
  numero_whatsapp text not null,
  identificador_externo text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint whatsapp_configuracoes_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_configuracoes_numero_chk
    check (char_length(numero_whatsapp) between 1 and 64 and numero_whatsapp !~ '^\s|\s$'),
  constraint whatsapp_configuracoes_identificador_chk
    check (identificador_externo is null or (char_length(identificador_externo) between 1 and 255 and identificador_externo !~ '^\s|\s$'))
);

-- ---------------------------------------------------------------
-- WHATSAPP_EVENTOS_PROCESSADOS (Etapa 10M)
-- Registro técnico mínimo para idempotência de webhooks. Não guarda texto,
-- telefone, payload ou credenciais. A chave composta impede que duas
-- instâncias processem o mesmo evento externo simultaneamente.
-- ---------------------------------------------------------------
create table if not exists whatsapp_eventos_processados (
  provedor text not null,
  id_externo text not null,
  status text not null default 'processando',
  recebido_em timestamptz not null default now(),
  processado_em timestamptz,
  primary key (provedor, id_externo),
  constraint whatsapp_eventos_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_eventos_id_externo_chk
    check (char_length(id_externo) between 1 and 512 and id_externo !~ '^\s|\s$'),
  constraint whatsapp_eventos_status_chk
    check (status in ('processando', 'concluido'))
);


-- ---------------------------------------------------------------
-- WHATSAPP_CONVERSAS / WHATSAPP_MENSAGENS (Etapa 10N)
-- Histórico funcional por loja. O payload bruto da Meta e credenciais não
-- são persistidos. FKs compostas reforçam isolamento multi-tenant no banco.
-- ---------------------------------------------------------------
alter table whatsapp_configuracoes
  add constraint whatsapp_configuracoes_id_loja_uk unique (id, loja_id);

-- ---------------------------------------------------------------
-- WHATSAPP_CREDENCIAIS (Etapa 10P)
-- Segredos por configuração. O token chega aqui já cifrado por AES-256-GCM.
-- A FK composta impede credencial de uma loja apontar para configuração de outra.
-- ---------------------------------------------------------------
create table if not exists whatsapp_credenciais (
  configuracao_id uuid primary key,
  loja_id uuid not null references lojas(id) on delete cascade,
  provedor text not null,
  access_token_cifrado text not null,
  access_token_iv text not null,
  access_token_tag text not null,
  versao_chave integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint whatsapp_credenciais_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_credenciais_provedor_chk check (provedor = 'meta'),
  constraint whatsapp_credenciais_versao_chk check (versao_chave > 0),
  constraint whatsapp_credenciais_cifrado_chk check (char_length(access_token_cifrado) between 1 and 20000),
  constraint whatsapp_credenciais_iv_chk check (char_length(access_token_iv) between 1 and 128),
  constraint whatsapp_credenciais_tag_chk check (char_length(access_token_tag) between 1 and 128)
);
create index if not exists idx_whatsapp_credenciais_loja_id on whatsapp_credenciais (loja_id);

create table if not exists whatsapp_conversas (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  configuracao_id uuid not null,
  contato text not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  constraint whatsapp_conversas_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_conversas_contato_chk
    check (char_length(contato) between 1 and 128 and contato !~ '^\s|\s$'),
  constraint whatsapp_conversas_id_loja_uk unique (id, loja_id),
  constraint whatsapp_conversas_tenant_contato_uk unique (loja_id, configuracao_id, contato)
);

create table if not exists whatsapp_mensagens (
  id uuid primary key default gen_random_uuid(),
  conversa_id uuid not null,
  loja_id uuid not null references lojas(id) on delete cascade,
  direcao text not null,
  texto text not null,
  provedor text not null,
  id_externo text,
  criado_em timestamptz not null default now(),
  constraint whatsapp_mensagens_conversa_loja_fk
    foreign key (conversa_id, loja_id)
    references whatsapp_conversas(id, loja_id) on delete cascade,
  constraint whatsapp_mensagens_direcao_chk check (direcao in ('entrada', 'saida')),
  constraint whatsapp_mensagens_texto_chk check (char_length(texto) between 1 and 12000 and texto !~ '^\s*$'),
  constraint whatsapp_mensagens_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_mensagens_id_externo_chk
    check (id_externo is null or (char_length(id_externo) between 1 and 512 and id_externo !~ '^\s|\s$'))
);

-- ---------------------------------------------------------------
-- WHATSAPP_FILA_PROCESSAMENTO (Etapa 10O)
-- ---------------------------------------------------------------
create table if not exists whatsapp_fila_processamento (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  configuracao_id uuid not null,
  provedor text not null,
  destinatario_id text not null,
  contato text not null,
  texto text not null,
  id_externo text not null,
  timestamp_mensagem timestamptz,
  resposta_texto text,
  status text not null default 'pendente',
  tentativas integer not null default 0,
  proxima_tentativa_em timestamptz not null default now(),
  lease_ate timestamptz,
  ultimo_erro_codigo text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  concluido_em timestamptz,
  constraint whatsapp_fila_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_fila_evento_fk
    foreign key (provedor, id_externo)
    references whatsapp_eventos_processados(provedor, id_externo) on delete cascade,
  constraint whatsapp_fila_evento_uk unique (provedor, id_externo),
  constraint whatsapp_fila_status_chk
    check (status in ('pendente', 'processando', 'enviado', 'concluido', 'falhou')),
  constraint whatsapp_fila_tentativas_chk check (tentativas >= 0),
  constraint whatsapp_fila_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_fila_destinatario_chk
    check (char_length(destinatario_id) between 1 and 255 and destinatario_id !~ '^\s|\s$'),
  constraint whatsapp_fila_contato_chk
    check (char_length(contato) between 1 and 128 and contato !~ '^\s|\s$'),
  constraint whatsapp_fila_texto_chk
    check (char_length(texto) between 1 and 12000 and texto !~ '^\s*$'),
  constraint whatsapp_fila_id_externo_chk
    check (char_length(id_externo) between 1 and 512 and id_externo !~ '^\s|\s$'),
  constraint whatsapp_fila_resposta_chk
    check (resposta_texto is null or (char_length(resposta_texto) between 1 and 12000 and resposta_texto !~ '^\s*$')),
  constraint whatsapp_fila_erro_chk
    check (ultimo_erro_codigo is null or ultimo_erro_codigo ~ '^[A-Za-z0-9_.-]{1,80}$'),
  constraint whatsapp_fila_enviado_resposta_chk
    check (status <> 'enviado' or resposta_texto is not null)
);

create index if not exists idx_whatsapp_fila_pronta
  on whatsapp_fila_processamento (status, proxima_tentativa_em, criado_em);
create index if not exists idx_whatsapp_fila_loja
  on whatsapp_fila_processamento (loja_id, criado_em desc);

alter table whatsapp_fila_processamento enable row level security;
-- Sem policy de usuário: fila é operacional interna; service_role opera o worker.

create or replace function claim_whatsapp_job(p_lease_segundos integer default 60)
returns setof whatsapp_fila_processamento
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  if p_lease_segundos is null or p_lease_segundos < 10 or p_lease_segundos > 3600 then
    raise exception 'LEASE_INVALIDA';
  end if;

  select q.id into v_id
  from whatsapp_fila_processamento q
  where (
      q.status = 'pendente'
      and q.proxima_tentativa_em <= now()
    ) or (
      q.status = 'processando'
      and q.lease_ate is not null
      and q.lease_ate <= now()
    ) or (
      q.status = 'enviado'
      and q.proxima_tentativa_em <= now()
      and (q.lease_ate is null or q.lease_ate <= now())
    )
  order by q.proxima_tentativa_em asc, q.criado_em asc
  for update skip locked
  limit 1;

  if v_id is null then
    return;
  end if;

  return query
  update whatsapp_fila_processamento q
     set status = case when q.status = 'enviado' then 'enviado' else 'processando' end,
         tentativas = q.tentativas + 1,
         lease_ate = now() + make_interval(secs => p_lease_segundos),
         atualizado_em = now()
   where q.id = v_id
   returning q.*;
end;
$$;

revoke all on function claim_whatsapp_job(integer) from public;
grant execute on function claim_whatsapp_job(integer) to service_role;


-- ---------------------------------------------------------------
-- ÍNDICES (auditoria de segurança)
-- Toda checagem de propriedade (usuário → loja → produto → estoque,
-- usuário → loja → cliente) faz um filtro/join por essas colunas em
-- praticamente toda requisição autenticada. Postgres não cria índice
-- automático em foreign keys (só na chave primária), então sem isso as
-- checagens de autorização ficam mais lentas conforme os dados crescem.
-- ---------------------------------------------------------------
create index if not exists idx_lojas_dono_id on lojas(dono_id);
create index if not exists idx_produtos_loja_id on produtos(loja_id);
create index if not exists idx_estoque_produto_id on estoque(produto_id);
create index if not exists idx_clientes_loja_id on clientes(loja_id);
create index if not exists idx_pedidos_loja_id on pedidos(loja_id);
create index if not exists idx_pedidos_cliente_id on pedidos(cliente_id);
create index if not exists idx_pedido_itens_pedido_id on pedido_itens(pedido_id);
create index if not exists idx_pedido_itens_estoque_id on pedido_itens(estoque_id);

-- WhatsApp (Etapa 10B): consulta por loja + regras de unicidade entre
-- configurações ATIVAS (mesmo provedor + número, ou mesmo provedor +
-- identificador externo, não podem estar ativos em duas configurações —
-- nem na mesma loja, nem entre lojas, para nunca haver ambiguidade sobre a
-- qual loja uma mensagem futura pertence). Configurações desativadas não
-- bloqueiam ninguém.
create index if not exists idx_whatsapp_configuracoes_loja_id
  on whatsapp_configuracoes (loja_id);

create unique index if not exists uq_whatsapp_config_ativa_provedor_numero
  on whatsapp_configuracoes (provedor, numero_whatsapp)
  where ativo;

create unique index if not exists uq_whatsapp_config_ativa_provedor_identificador
  on whatsapp_configuracoes (provedor, identificador_externo)
  where ativo and identificador_externo is not null;


create index if not exists idx_whatsapp_eventos_recebido_em
  on whatsapp_eventos_processados (recebido_em);


create index if not exists idx_whatsapp_conversas_loja_atualizado
  on whatsapp_conversas (loja_id, atualizado_em desc);
create index if not exists idx_whatsapp_mensagens_conversa_criado
  on whatsapp_mensagens (conversa_id, criado_em);
create index if not exists idx_whatsapp_mensagens_loja_criado
  on whatsapp_mensagens (loja_id, criado_em desc);
create unique index if not exists uq_whatsapp_mensagem_entrada_externa
  on whatsapp_mensagens (provedor, id_externo)
  where direcao = 'entrada' and id_externo is not null;

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- Garante que cada dono só enxerga/edita dados da própria loja,
-- mesmo se alguém acessar o Supabase diretamente (fora do backend).
-- ============================================================

alter table lojas enable row level security;
alter table produtos enable row level security;
alter table estoque enable row level security;
alter table clientes enable row level security;
alter table pedidos enable row level security;
alter table pedido_itens enable row level security;
alter table assinaturas enable row level security;
alter table whatsapp_configuracoes enable row level security;
alter table whatsapp_eventos_processados enable row level security;
alter table whatsapp_conversas enable row level security;
alter table whatsapp_mensagens enable row level security;

create policy "dono ve suas lojas" on lojas
  for all using (auth.uid() = dono_id) with check (auth.uid() = dono_id);

create policy "dono ve produtos das suas lojas" on produtos
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve estoque das suas lojas" on estoque
  for all using (produto_id in (
    select p.id from produtos p join lojas l on l.id = p.loja_id where l.dono_id = auth.uid()
  ))
  with check (produto_id in (
    select p.id from produtos p join lojas l on l.id = p.loja_id where l.dono_id = auth.uid()
  ));

create policy "dono ve clientes das suas lojas" on clientes
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve pedidos das suas lojas" on pedidos
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve itens dos seus pedidos" on pedido_itens
  for all using (pedido_id in (
    select pe.id from pedidos pe join lojas l on l.id = pe.loja_id where l.dono_id = auth.uid()
  ))
  with check (pedido_id in (
    select pe.id from pedidos pe join lojas l on l.id = pe.loja_id where l.dono_id = auth.uid()
  ));

create policy "dono ve assinatura das suas lojas" on assinaturas
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve whatsapp das suas lojas" on whatsapp_configuracoes
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve conversas whatsapp das suas lojas" on whatsapp_conversas
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve mensagens whatsapp das suas lojas" on whatsapp_mensagens
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

-- whatsapp_eventos_processados não possui policy de usuário: é uma tabela operacional interna.

-- Nota: o backend usa a service_role key, que ignora RLS por padrão.
-- O RLS acima é uma camada extra de proteção caso o Supabase seja
-- acessado diretamente (ex: futuramente pelo app do lojista com anon key).

-- ============================================================
-- FUNÇÃO RPC: criar_pedido (auditoria de segurança)
-- ============================================================
-- Cria um pedido e seus itens de forma ATÔMICA: valida cliente/itens,
-- verifica e debita o estoque com bloqueio de linha (evita condição de
-- corrida entre dois pedidos simultâneos) e insere pedido + pedido_itens
-- — tudo em uma única transação. Se qualquer validação falhar, a função
-- inteira é revertida (nenhuma linha fica órfã e o estoque não é
-- debitado em vão).
--
-- Esta função NÃO valida se a loja pertence ao usuário autenticado —
-- essa checagem já é feita pelo backend (middleware exigirDonoDaLoja)
-- antes de chamar esta função. Por isso o EXECUTE é restrito apenas ao
-- service_role (ver GRANT/REVOKE abaixo): ela não deve ser chamada
-- diretamente por um usuário final com a anon/authenticated key, pois
-- isso puraria essa checagem.
--
-- Erros esperados (o backend traduz estes tokens em mensagens amigáveis,
-- ver src/controllers/pedidos.controller.js):
--   CLIENTE_INVALIDO      - cliente não existe ou não é dessa loja
--   ITENS_VAZIOS          - nenhum item informado
--   QUANTIDADE_INVALIDA   - quantidade <= 0 em algum item
--   ITEM_INVALIDO         - estoque não existe ou não é dessa loja
--   ESTOQUE_INSUFICIENTE  - quantidade pedida maior que a disponível
create or replace function criar_pedido(
  p_loja_id uuid,
  p_cliente_id uuid,
  p_itens jsonb -- array de objetos: [{ "estoque_id": "uuid", "quantidade": 2 }, ...]
) returns jsonb
language plpgsql
as $$
declare
  v_pedido_id uuid;
  v_total numeric(10,2) := 0;
  v_item jsonb;
  v_estoque_id uuid;
  v_quantidade integer;
  v_estoque_row record;
  v_preco numeric(10,2);
  v_itens_resultado jsonb := '[]'::jsonb;
begin
  if p_cliente_id is not null then
    perform 1 from clientes where id = p_cliente_id and loja_id = p_loja_id;
    if not found then
      raise exception 'CLIENTE_INVALIDO';
    end if;
  end if;

  if p_itens is null or jsonb_array_length(p_itens) = 0 then
    raise exception 'ITENS_VAZIOS';
  end if;

  insert into pedidos (loja_id, cliente_id, total, status)
  values (p_loja_id, p_cliente_id, 0, 'pendente')
  returning id into v_pedido_id;

  for v_item in select * from jsonb_array_elements(p_itens)
  loop
    v_estoque_id := (v_item->>'estoque_id')::uuid;
    v_quantidade := (v_item->>'quantidade')::integer;

    if v_quantidade is null or v_quantidade <= 0 then
      raise exception 'QUANTIDADE_INVALIDA';
    end if;

    -- Bloqueia a linha de estoque até o fim da transação: se dois
    -- pedidos pedirem o mesmo item ao mesmo tempo, o segundo espera o
    -- primeiro terminar (e então vê o estoque já atualizado).
    select e.id, e.quantidade, p.preco, p.loja_id
      into v_estoque_row
      from estoque e
      join produtos p on p.id = e.produto_id
      where e.id = v_estoque_id
      for update of e;

    if not found or v_estoque_row.loja_id <> p_loja_id then
      raise exception 'ITEM_INVALIDO';
    end if;

    if v_estoque_row.quantidade < v_quantidade then
      raise exception 'ESTOQUE_INSUFICIENTE';
    end if;

    update estoque set quantidade = quantidade - v_quantidade, atualizado_em = now()
      where id = v_estoque_id;

    v_preco := v_estoque_row.preco;
    v_total := v_total + (v_preco * v_quantidade);

    insert into pedido_itens (pedido_id, estoque_id, quantidade, preco_unitario)
    values (v_pedido_id, v_estoque_id, v_quantidade, v_preco);

    v_itens_resultado := v_itens_resultado || jsonb_build_object(
      'estoque_id', v_estoque_id,
      'quantidade', v_quantidade,
      'preco_unitario', v_preco
    );
  end loop;

  update pedidos set total = v_total where id = v_pedido_id;

  return jsonb_build_object(
    'id', v_pedido_id,
    'loja_id', p_loja_id,
    'cliente_id', p_cliente_id,
    'total', v_total,
    'status', 'pendente',
    'itens', v_itens_resultado
  );
end;
$$;

-- Restringe a execução da função só ao backend (service_role). Usuários
-- finais (anon/authenticated) não podem chamá-la diretamente, já que ela
-- não valida propriedade da loja por conta própria.
revoke all on function criar_pedido(uuid, uuid, jsonb) from public;
grant execute on function criar_pedido(uuid, uuid, jsonb) to service_role;


-- Etapa 10P: RLS das credenciais
alter table whatsapp_credenciais enable row level security;
drop policy if exists "dono ve credenciais whatsapp das suas lojas" on whatsapp_credenciais;
create policy "dono ve credenciais whatsapp das suas lojas" on whatsapp_credenciais
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

-- ---------------------------------------------------------------
-- ASSINATURAS 11A - base comercial
-- ---------------------------------------------------------------
alter table assinaturas add column if not exists atualizado_em timestamptz not null default now();
create index if not exists idx_assinaturas_loja_criado on assinaturas (loja_id, criado_em desc);

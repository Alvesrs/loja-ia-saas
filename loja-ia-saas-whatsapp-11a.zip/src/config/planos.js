function inteiroPositivo(nome, padrao) {
  const valor = Number(process.env[nome]);
  return Number.isInteger(valor) && valor > 0 ? valor : padrao;
}

const PLANOS = Object.freeze({
  trial: Object.freeze({ codigo: 'trial', nome: 'Trial', limiteMensagensMes: inteiroPositivo('PLANO_TRIAL_LIMITE_MENSAGENS', 100) }),
  basico: Object.freeze({ codigo: 'basico', nome: 'Básico', limiteMensagensMes: inteiroPositivo('PLANO_BASICO_LIMITE_MENSAGENS', 1000) }),
  pro: Object.freeze({ codigo: 'pro', nome: 'Pro', limiteMensagensMes: inteiroPositivo('PLANO_PRO_LIMITE_MENSAGENS', 5000) }),
  ilimitado: Object.freeze({ codigo: 'ilimitado', nome: 'Ilimitado', limiteMensagensMes: null }),
});

function obterPlano(codigo) {
  return PLANOS[codigo] || null;
}

function listarPlanos() {
  return Object.values(PLANOS).map((p) => ({ ...p }));
}

function diasTrial() {
  return inteiroPositivo('TRIAL_DIAS', 14);
}

module.exports = { PLANOS, obterPlano, listarPlanos, diasTrial };

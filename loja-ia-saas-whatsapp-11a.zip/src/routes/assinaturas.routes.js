const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');
const { minhaAssinatura } = require('../controllers/assinaturas.controller');

const router = express.Router({ mergeParams: true });
router.use(exigirLogin, exigirDonoDaLoja);
router.get('/', minhaAssinatura);
module.exports = router;

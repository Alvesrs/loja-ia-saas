const express = require('express');
const path = require('path');
const cors = require('cors');

const authRoutes = require('./routes/auth.routes');
const lojasRoutes = require('./routes/lojas.routes');
const produtosRoutes = require('./routes/produtos.routes');
const clientesRoutes = require('./routes/clientes.routes');
const pedidosRoutes = require('./routes/pedidos.routes');
const iaRoutes = require('./routes/ia.routes');
const whatsappConfiguracaoRoutes = require('./routes/whatsappConfiguracao.routes');
const whatsappWebhookRoutes = require('./routes/whatsappWebhook.routes');
const healthRoutes = require('./routes/health.routes');
const assinaturasRoutes = require('./routes/assinaturas.routes');
const adminRoutes = require('./routes/admin.routes');
const { segurancaHeaders } = require('./middleware/segurancaHeaders');
const { construirCorsOptions, obterOrigensPermitidas } = require('./config/cors');

const app = express();

// Evita anunciar a stack ("X-Powered-By: Express") para quem for explorar a API.
app.disable('x-powered-by');

// CORS: configuração centralizada em src/config/cors.js (correção da
// auditoria técnica — antes ficava aberto para qualquer origem quando
// ALLOWED_ORIGINS não estava definido, inclusive em produção e inclusive
// para as rotas autenticadas do lojista).
//
// Agora, por padrão: fechado em produção, aberto só para localhost em
// desenvolvimento, e sempre controlável via ALLOWED_ORIGINS. A única
// exceção deliberada é a rota pública /ia/perguntar, que tem CORS aberto
// próprio (ver routes/ia.routes.js) por precisar ser chamada de sites de
// lojas de terceiros.
if (process.env.NODE_ENV === 'production' && obterOrigensPermitidas().length === 0) {
  console.warn(
    '[cors] Atenção: rodando em produção sem ALLOWED_ORIGINS definido. ' +
    'Nenhuma origem cross-origin será liberada para as rotas autenticadas ' +
    '(login, lojas, produtos, clientes, pedidos). Defina ALLOWED_ORIGINS ' +
    'com o(s) domínio(s) real(is) do painel/frontend quando ele existir.'
  );
}

app.use(cors(construirCorsOptions()));
app.use(segurancaHeaders);

// Webhook de WhatsApp/Meta (Etapa 10L): endpoint público do provedor,
// com GET de handshake e POST autenticado por X-Hub-Signature-256.
// Fica montado ANTES do parser JSON global de propósito: a rota tem parser
// próprio (100kb) para preservar os bytes exatos usados na assinatura Meta.
// Não usa login do painel e não afeta as demais rotas.
app.use('/api/webhooks/whatsapp', whatsappWebhookRoutes);

// Limite de tamanho do corpo da requisição, para evitar abuso com payloads
// enormes (o SaaS não lida com upload de arquivo nesta fase).
app.use(express.json({ limit: '100kb' }));

// Healthchecks de produção (10R). /live prova que o processo HTTP responde;
// /ready também valida a configuração crítica sem expor valores secretos.
app.use('/api/health', healthRoutes);
app.get('/', (req, res) => {
  res.json({ status: 'ok', servico: 'loja-ia-saas', versao: '1.0.0' });
});

app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/lojas', lojasRoutes);
app.use('/api/lojas/:lojaId/produtos', produtosRoutes);
app.use('/api/lojas/:lojaId/clientes', clientesRoutes);
app.use('/api/lojas/:lojaId/pedidos', pedidosRoutes);
app.use('/api/lojas/:lojaId/ia', iaRoutes);
app.use('/api/lojas/:lojaId/whatsapp', whatsappConfiguracaoRoutes);
app.use('/api/lojas/:lojaId/assinatura', assinaturasRoutes);

// Painel visual do lojista (Etapa 2). Arquivos estáticos (HTML/CSS/JS),
// sem framework/build step — consome a API acima via fetch, usando o
// mesmo token do Supabase Auth emitido por /api/auth/login. Nenhum
// segredo do servidor (ex: SERVICE_ROLE_KEY) é servido aqui.
app.use('/painel', express.static(path.join(__dirname, '..', 'public')));

// Páginas legais públicas, sem autenticação. Rotas explícitas garantem
// resposta HTTP 200 no caminho exato que validadores externos (como a Meta)
// consultam, sem depender de redirecionamento/resolução de diretório estático.
app.get('/politica-de-privacidade', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'legal', 'privacidade', 'index.html'));
});
app.get('/privacy-policy.html', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'legal', 'privacidade', 'index.html'));
});
app.get('/exclusao-de-dados', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'legal', 'exclusao', 'index.html'));
});
app.get('/robots.txt', (req, res) => {
  res.type('text/plain').send('User-agent: *\nAllow: /\n');
});

// Tratamento de rota inexistente
app.use((req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada.' });
});

// Tratamento de erro genérico (evita o servidor cair por erro não tratado).
// Nunca expõe err.message/stack ao cliente — só loga no servidor.
app.use((err, req, res, next) => {
  console.error('[erro não tratado]', err);
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ erro: 'JSON inválido no corpo da requisição.' });
  }
  if (err && err.type === 'entity.too.large') {
    return res.status(413).json({ erro: 'Corpo da requisição muito grande.' });
  }
  res.status(500).json({ erro: 'Erro interno no servidor.' });
});

module.exports = app;

> Versão 10W: Prompt Mestre por loja + painel PWA instalável.

# loja-ia-saas


## Estado atual — 10Q

O sistema já possui webhook nativo da Meta, idempotência, histórico, fila/retry,
credenciais Meta por loja e agora um painel operacional para configurar WhatsApp
e consultar conversas sem editar código. Veja [docs/ETAPA-10Q.md](docs/ETAPA-10Q.md).

**As seções abaixo também preservam o registro histórico da fundação e etapas
anteriores; em caso de conflito, a seção de estado atual e os documentos 10K–10Q
representam o comportamento mais recente.**

## O que já funciona nesta etapa

- Cadastro/login de lojista (Supabase Auth)
- Cadastro de lojas, produtos, estoque (tamanho/cor/quantidade), clientes e pedidos
- **Isolamento completo entre lojas**: toda rota autenticada valida a cadeia
  usuário → loja → produto/estoque/cliente antes de deixar ler ou alterar
  qualquer dado (ver `docs/ARQUITETURA.md` → "Autorização")
- **Pedidos transacionais**: criação de pedido, baixa de estoque e inserção
  dos itens acontecem em uma única transação no banco (função `criar_pedido`
  em `src/db/schema.sql`), com trava de linha para evitar vender a mesma
  unidade duas vezes em pedidos simultâneos
- Endpoint da IA que responde perguntas usando só o catálogo real, com
  rate limiting para proteger contra abuso (rota pública, sem login)
- Webhook Meta autenticado, envio pelo WhatsApp Cloud API, idempotência e histórico persistente por loja

## O que ainda falta para produção completa

- Cobrança/assinatura de produção (caso o SaaS vá cobrar planos automaticamente)
- Deploy e validação ponta a ponta com credenciais reais da Meta/Supabase
- Hardening operacional final: domínio/HTTPS, observabilidade e checklist de produção

## Camada de LLM (Etapas 9A+ — conectada ao atendente)

`src/services/llm.service.js` já faz uma chamada HTTP **real** a um
provedor de LLM, no formato "chat completions" (padrão OpenAI, compatível
com a **Groq** — sugerida por ter API simples e opção gratuita/baixo
custo para desenvolvimento). Ele é usado pelo fluxo do atendente quando configurado; se não houver
provedor disponível, o sistema mantém o fallback determinístico existente.
O objetivo da abstração é permitir
trocar de provedor no futuro sem reescrever controller, regras de
negócio ou frontend — qualquer provedor compatível com o formato "chat
completions" funciona só trocando a variável `LLM_PROVIDER_URL`.

Variáveis de ambiente (ver `.env.example` para exemplos completos):

- `LLM_PROVIDER_API_KEY` — chave do provedor. **Só existe no backend**,
  nunca é enviada ao frontend, nunca aparece em logs (nem mesmo em
  mensagens de erro — há testes automatizados garantindo isso) e nunca
  deve ser colocada no código-fonte ou commitada.
- `LLM_PROVIDER_URL` — endpoint do provedor (ex: da Groq ou de qualquer
  provedor compatível com o formato OpenAI de "chat completions").
- `LLM_PROVIDER_MODEL` — nome do modelo (opcional, depende do provedor).
- `LLM_TIMEOUT_MS` — tempo limite da chamada em milissegundos (opcional,
  padrão 15000).

Enquanto `LLM_PROVIDER_API_KEY`/`LLM_PROVIDER_URL` não estiverem
definidas, o serviço se recusa a funcionar (por design). Os testes de
`tests/llmService.test.js` **não fazem nenhuma chamada de rede real nem
consomem API paga** — a chamada HTTP é sempre simulada (mock de
`fetch`).

---

## Passo a passo para colocar no ar

### 1. Criar o projeto no Supabase (gratuito)

1. Acesse https://supabase.com e crie uma conta (ou faça login).
2. Clique em **New Project**. Escolha um nome (ex: `loja-ia-saas`) e uma senha
   para o banco (guarde essa senha em lugar seguro).
3. Espere o projeto ser criado (leva 1–2 minutos).
4. No menu lateral, vá em **SQL Editor** → **New query**.
5. Abra o arquivo `src/db/schema.sql` deste projeto, copie todo o conteúdo,
   cole no SQL Editor do Supabase e clique em **Run**. Isso cria todas as
   tabelas, índices, a função de pedido transacional e as regras de
   segurança automaticamente.
   - **Se você já tinha rodado uma versão anterior deste schema** (antes
     desta auditoria), não rode o `schema.sql` inteiro de novo — em vez
     disso rode `src/db/migrations/001_correcoes_auditoria.sql`, que só
     adiciona o que falta, sem apagar nada.
6. Vá em **Project Settings** → **API**. Anote dois valores:
   - **Project URL** (algo como `https://xxxx.supabase.co`)
   - **service_role key** (em "Project API keys" — é uma chave secreta, não a "anon")

### 2. Configurar as variáveis de ambiente

Veja `.env.example` para a lista completa e comentada. No mínimo, você vai
precisar definir:

```
SUPABASE_URL=<a Project URL que você anotou>
SUPABASE_SERVICE_ROLE_KEY=<a service_role key que você anotou>
```

Opcionalmente (já vêm com valores padrão razoáveis se não definir):

```
NODE_ENV=development          # "production" muda o comportamento padrão do CORS (ver abaixo)
ALLOWED_ORIGINS=               # domínios liberados p/ CORS nas rotas do lojista (login, produtos, etc.)
IA_RATE_LIMIT_MAX=20          # perguntas por IP na janela abaixo (rota pública do atendente)
IA_RATE_LIMIT_JANELA_MS=60000 # duração da janela (1 minuto)
AUTH_LOGIN_RATE_LIMIT_MAX=10           # tentativas de login por IP+email na janela abaixo
AUTH_LOGIN_RATE_LIMIT_JANELA_MS=300000 # duração da janela (5 minutos)
AUTH_CADASTRO_RATE_LIMIT_MAX=10           # tentativas de cadastro por IP na janela abaixo
AUTH_CADASTRO_RATE_LIMIT_JANELA_MS=900000 # duração da janela (15 minutos)
```

**Sobre `ALLOWED_ORIGINS` e CORS:** essa variável controla apenas as rotas
autenticadas do lojista (`/api/auth`, `/api/lojas`, produtos, clientes,
pedidos). Deixando em branco:
- em produção (`NODE_ENV=production`) o CORS fica **fechado** por padrão
  (nenhuma origem cross-origin liberada) até você definir o domínio real
  do painel/frontend;
- fora de produção, o CORS libera automaticamente `localhost`/`127.0.0.1`
  (qualquer porta), para facilitar o desenvolvimento local.

Isso não afeta a rota pública `/api/lojas/:lojaId/ia/perguntar` (o
atendente), que continua com CORS aberto de propósito, pois precisa ser
chamada a partir dos sites das próprias lojas (domínios de terceiros) e só
devolve catálogo público.

Nunca compartilhe a `service_role key` publicamente — ela dá acesso total
ao banco (veja a seção "Autorização e RLS" em `docs/ARQUITETURA.md` para
entender por que isso importa neste projeto).

### 3. Subir o código para o GitHub

1. Crie um novo repositório no GitHub (ex: `loja-ia-saas`), separado do
   repositório do bot antigo.
2. Baixe os arquivos deste projeto (o assistente vai te enviar um `.zip`).
3. No GitHub, dentro do repositório vazio, use a opção **"Add file" →
   "Upload files"** e arraste todos os arquivos/pastas do projeto (isso
   funciona até pelo navegador do celular).
4. Confirme o commit ("Commit changes").

> Importante: o arquivo `.env` (se você criar um localmente) **não** deve
> ser enviado ao GitHub — o `.gitignore` já está configurado para isso.

### 4. Deploy no Render (gratuito)

1. Acesse https://render.com e crie uma conta (pode ser com login do GitHub).
2. Clique em **New** → **Web Service**.
3. Conecte o repositório `loja-ia-saas` que você acabou de criar.
4. Configure:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Em **Environment Variables**, adicione `SUPABASE_URL` e
   `SUPABASE_SERVICE_ROLE_KEY` com os valores do passo 1. O Render já
   define `NODE_ENV=production` automaticamente — nesse modo, o CORS das
   rotas do lojista fica fechado até você definir `ALLOWED_ORIGINS` (o que
   é esperado enquanto não existir um painel/frontend; a rota pública do
   atendente não é afetada). Quando o painel existir, adicione
   `ALLOWED_ORIGINS=https://dominio-real-do-painel.com` aqui. Também dá
   para ajustar `IA_RATE_LIMIT_MAX`/`IA_RATE_LIMIT_JANELA_MS` e os limites
   de `AUTH_LOGIN_RATE_LIMIT_*`/`AUTH_CADASTRO_RATE_LIMIT_*` se quiser.
6. Clique em **Create Web Service** e aguarde o deploy terminar.
7. Quando terminar, o Render te dará uma URL pública (ex:
   `https://loja-ia-saas.onrender.com`). Acessando essa URL no navegador,
   você deve ver: `{"status":"ok","servico":"loja-ia-saas","versao":"1.0.0"}`

### 5. Testar a API

Com a URL do Render (ou `http://localhost:3000` se rodar localmente), você
pode testar os endpoints principais (por exemplo, usando o app **HTTP
Shortcuts** ou similar no celular, ou o Postman no computador):

```
POST /api/auth/cadastrar        { "email": "...", "senha": "..." }
POST /api/auth/login            { "email": "...", "senha": "..." }

# Rotas abaixo exigem header: Authorization: Bearer <token do login>
POST /api/lojas                 { "nome": "Minha Loja" }
GET  /api/lojas

POST /api/lojas/:lojaId/produtos              { "nome": "Camiseta Preta", "preco": 49.90 }
POST /api/lojas/:lojaId/produtos/:id/estoque  { "tamanho": "M", "cor": "Preta", "quantidade": 5 }

POST /api/lojas/:lojaId/clientes              { "nome": "Fulano", "telefone": "..." }

POST /api/lojas/:lojaId/pedidos
  { "clienteId": "uuid (opcional)", "itens": [{ "estoqueId": "uuid", "quantidade": 2 }] }

# Rota pública (cliente final perguntando, sujeita a rate limit):
POST /api/lojas/:lojaId/ia/perguntar   { "pergunta": "Tem camiseta preta tamanho M?" }
```

---

## Rodando localmente (opcional, se você tiver acesso a um computador com Node.js)

```bash
npm install
cp .env.example .env   # depois edite o .env com seus dados reais do Supabase
npm start
```

O servidor sobe em `http://localhost:3000`.

## Testes

```bash
# Testes de unidade (sem banco/rede real — Supabase é simulado onde
# necessário, ver tests/helpers/) — rodam sempre:
npm test

# Teste de integração ponta-a-ponta (cenários A-J da auditoria) — precisa
# de um projeto Supabase de teste e do servidor no ar. Veja as instruções
# no topo do próprio arquivo:
npm run test:integracao
```

Os testes de unidade cobrem, entre outras coisas: validação de entrada,
a lógica do atendente (nunca inventa produto/preço/tamanho/cor), o rate
limiter (login, cadastro e atendente), a configuração de CORS, e — usando
um Supabase simulado — a autorização multi-loja (isolamento entre lojas
nos middlewares e nos controllers de pedidos/atendente).


## Etapa 10M — idempotência do webhook

O webhook da Meta agora usa `messages[].id` como chave durável de idempotência no Postgres. Reentregas do mesmo evento retornam 200 sem repetir IA/envio. Em banco existente, aplique `src/db/migrations/004_whatsapp_idempotencia.sql`. Detalhes em `docs/ETAPA-10M.md`.


## Etapa 10N — histórico persistente de WhatsApp

O webhook agora salva conversas e mensagens por loja em `whatsapp_conversas` e `whatsapp_mensagens`, com FKs compostas e RLS para reforçar o isolamento multi-tenant. Para banco existente, aplique `src/db/migrations/005_whatsapp_historico.sql` depois da migration 004. Detalhes em `docs/ETAPA-10N.md`.


## Etapa 10O — fila/retry do WhatsApp

O webhook Meta agora persiste o trabalho antes de executar IA/envio. A fila usa lease e claim atômico, suporta retry exponencial e mantém um estado `enviado` para que falhas de escrituração depois do envio não provoquem um segundo envio. Consulte `docs/ETAPA-10O.md` e aplique `src/db/migrations/006_whatsapp_fila_retry.sql` em bancos existentes.


## Etapa 10P — onboarding WhatsApp por loja
API autenticada para configuração do número e credencial Meta por tenant. Tokens são cifrados em repouso com AES-256-GCM; veja `docs/ETAPA-10P.md` e a migration `007_whatsapp_credenciais.sql`.


## Etapa 10Q — painel operacional

O painel agora inclui uma área de WhatsApp para configurar a conexão Meta, gerenciar a credencial sem recuperá-la em texto puro e consultar o histórico de conversas da loja. A 10Q não cria nova migration. Detalhes em `docs/ETAPA-10Q.md`.

## Etapa 10R — produção final

O ciclo 10K–10R foi fechado para implantação: validação fail-fast do ambiente, `npm run check:producao`, healthchecks `/api/health/live` e `/api/health/ready`, shutdown gracioso do worker e guia operacional do dono. A 10R não cria migration 008. Veja `docs/ETAPA-10R.md` e `docs/GUIA-DONO-PRODUCAO.md`.

## 11D — Asaas
Cobrança automática principal migrada para Asaas Checkout recorrente + Webhooks autenticados e idempotentes. Veja `docs/ETAPA-11D.md`.


## Etapa 11E
Precificação comercial inicial: Básico R$ 99/1.000 mensagens da IA, Pro R$ 199/5.000 e Ilimitado R$ 349 sem franquia fixa, sujeito a uso justo.

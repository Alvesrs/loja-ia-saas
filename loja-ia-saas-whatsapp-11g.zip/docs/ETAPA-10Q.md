# Etapa 10Q — painel operacional do WhatsApp

Checkpoint que transforma as APIs das etapas anteriores em uma operação utilizável pelo lojista sem editar código.

## Entregue

- nova página autenticada `public/whatsapp.html`, disponível no menu do painel;
- cadastro/edição/desativação da configuração Meta da loja;
- cadastro, substituição e remoção do access token por loja;
- o token continua cifrado no backend (AES-256-GCM) e **nunca é lido de volta pelo frontend**;
- exibição da URL pública do webhook para auxiliar a configuração na Meta;
- listagem das conversas recentes e leitura de mensagens persistidas;
- rotas de histórico protegidas por `exigirLogin` + `exigirDonoDaLoja`;
- queries de histórico filtradas por `loja_id` no backend, mesmo com `service_role`;
- histórico no painel é somente leitura: não há endpoint para editar/apagar mensagens.

## Rotas adicionadas

- `GET /api/lojas/:lojaId/whatsapp/historico/conversas`
- `GET /api/lojas/:lojaId/whatsapp/historico/conversas/:conversaId/mensagens`

As rotas de configuração/credencial já existentes na 10P são consumidas diretamente pelo novo painel.

## Banco

A 10Q não adiciona migration. Usa as tabelas e garantias já criadas até a migration `007_whatsapp_credenciais.sql`.

## Segurança

O frontend nunca recebe a chave mestra, App Secret, verify token nem o access token já salvo. O único momento em que um access token aparece no navegador é quando o próprio lojista o cola no campo de senha para enviá-lo por uma requisição autenticada ao backend.

## Próximo checkpoint

10R: preparação de produção, deploy/checklist, validação de configuração real e teste ponta a ponta com serviços externos.

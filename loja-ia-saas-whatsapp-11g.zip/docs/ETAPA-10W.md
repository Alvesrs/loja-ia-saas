# Etapa 10W — Prompt Mestre + painel instalável

## Entregue
- `lojas.prompt_mestre`: instruções livres por tenant/loja.
- Edição autenticada no painel Atendente IA, limite de 12.000 caracteres.
- A Prompt Mestre orienta o LLM, mantendo regras internas de segurança, sigilo e isolamento multi-tenant acima dela.
- Catálogo/estoque continuam como contexto estruturado opcional e prevalecem apenas quando houver conflito factual explícito.
- PWA instalável: manifest, service worker e ícones 192/512, com `display: standalone`.
- APIs não são cacheadas pelo service worker.

## Migração
Aplicar `src/db/migrations/008_prompt_mestre_loja.sql`.

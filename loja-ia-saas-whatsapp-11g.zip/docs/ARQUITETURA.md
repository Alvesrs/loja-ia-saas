# Arquitetura — loja-ia-saas

## Visão geral

Backend em **Node.js + Express** que expõe uma API REST. O banco de dados é o
**Supabase** (Postgres gerenciado, com Auth embutido e camada de segurança
por linha — RLS). Não há frontend nesta fase; toda interação é via API
(testável com ferramentas como Postman/Insomnia, ou pelo app do celular).

```
Cliente da loja  →  (futuro) WhatsApp / chat web  →  API /ia/perguntar
Lojista          →  API /auth, /lojas, /produtos, /estoque, /clientes, /pedidos
```

## Por que essa stack

- **Node.js + Express**: leve, roda em qualquer host gratuito (Render),
  grande quantidade de exemplos e fácil manutenção futura.
- **Supabase**: banco Postgres real com plano gratuito generoso, já resolve
  autenticação (não precisamos implementar login do zero) e permite
  Row Level Security.
- **Sem frontend nesta etapa**: reduz complexidade da fundação. O painel
  administrativo web entra numa etapa seguinte, consumindo essa mesma API.
- **IA sem custo nesta etapa**: o "atendente" é uma lógica de regras que
  consulta o catálogo real. Isso já cumpre a exigência de nunca inventar
  preço/estoque, e deixa a porta aberta para depois trocar por uma IA de
  verdade (ex: Groq) que apenas formata a resposta, sem inventar dados.

## Estrutura de pastas

```
loja-ia-saas/
├── src/
│   ├── server.js            # inicia o servidor HTTP
│   ├── app.js                # monta middlewares e rotas
│   ├── config/
│   │   └── supabase.js       # cliente único do Supabase (service_role)
│   ├── db/
│   │   ├── schema.sql         # script completo para criar o banco do zero
│   │   └── migrations/
│   │       └── 001_correcoes_auditoria.sql  # migração incremental
│   ├── middleware/
│   │   ├── auth.js              # valida login do lojista (Bearer token)
│   │   ├── lojaOwnership.js     # garante :lojaId/:produtoId do usuário
│   │   ├── rateLimiter.js       # limitador de requisições (rota pública IA)
│   │   └── segurancaHeaders.js  # headers de segurança básicos
│   ├── routes/                # define os endpoints HTTP
│   ├── controllers/           # regras de cada endpoint
│   ├── services/
│   │   ├── autorizacao.service.js  # checagem de propriedade (cadeia)
│   │   ├── ia.service.js           # busca dados reais no banco p/ IA
│   │   └── ia.helpers.js           # lógica pura da IA (sem I/O, testável)
│   └── utils/
│       ├── validacao.js       # validadores de entrada simples
│       └── erros.js           # traduz erros de banco p/ mensagens seguras
├── tests/
│   ├── ia.helpers.test.js         # unidade — lógica da IA (sem banco)
│   ├── validacao.test.js          # unidade — validadores (sem banco)
│   └── integracao.manual.test.js  # cenários A-J (precisa de Supabase real)
└── docs/
    └── ARQUITETURA.md         # este arquivo
```

## Modelo de dados (multi-loja)

- **lojas**: cada loja pertence a um usuário (`dono_id`, do Supabase Auth).
- **produtos**: nome, descrição, preço, categoria — pertence a uma loja.
- **estoque**: variações de tamanho/cor/quantidade de cada produto.
- **clientes**: cadastro simples de clientes de uma loja.
- **pedidos** / **pedido_itens**: pedidos feitos, com preço travado no
  momento da compra (nunca confia em preço vindo de fora) e estoque
  debitado atomicamente na criação (ver seção "Pedidos" abaixo).
- **assinaturas**: tabela já criada para o futuro sistema de cobrança
  (ainda não usada por nenhuma rota).
- **whatsapp_configuracoes** (Etapa 10B): configuração de WhatsApp de uma
  loja (`loja → whatsapp_configuracoes`). Só configuração — ver a seção
  "Configuração de WhatsApp por loja" abaixo.

Todas as foreign keys usadas em checagem de autorização (`loja_id`,
`produto_id`, `cliente_id` etc.) têm índice dedicado — sem isso, cada
checagem de propriedade ficaria mais lenta conforme os dados crescem,
já que o Postgres não cria índice automático em foreign key (só na PK).

## Autenticação

Login e cadastro usam o Supabase Auth (`/api/auth/cadastrar` e
`/api/auth/login`). O login retorna um token que deve ser enviado no
header `Authorization: Bearer <token>` em todas as rotas de loja/produto/
estoque/cliente/pedido. A rota da IA (`/api/lojas/:lojaId/ia/perguntar`)
é pública, pois representa o cliente final perguntando — não o lojista.

## Autorização (cadeia de propriedade) — como funciona de verdade

**Ponto crítico de segurança que toda pessoa mexendo neste código precisa
entender:** o backend se conecta ao Supabase usando a **service_role key**
(`src/config/supabase.js`). Essa chave **ignora completamente o Row Level
Security (RLS)** do Postgres. Ou seja: as políticas de RLS definidas em
`schema.sql` **não protegem nada quando é o próprio backend fazendo a
consulta** — elas só entrariam em ação se, no futuro, alguém acessasse o
Supabase diretamente com uma `anon`/`authenticated` key (ex: um app mobile
do lojista falando direto com o Supabase, sem passar por esta API).

Isso significa que **toda a autorização "multi-loja" desta API é
responsabilidade exclusiva do código Express**, não do banco. Antes desta
auditoria, essa checagem era feita "na mão", de forma inconsistente, em
cada controller — e faltava em pontos críticos (estoque, principalmente).

A abordagem atual centraliza isso em duas camadas:

1. **`src/middleware/lojaOwnership.js`** — aplicado em `router.use(...)`
   logo depois de `exigirLogin`, em toda rota aninhada sob
   `/api/lojas/:lojaId/*`:
   - `exigirDonoDaLoja`: confirma que `:lojaId` pertence ao usuário
     autenticado antes de deixar a requisição chegar ao controller.
   - `exigirProdutoDaLoja`: confirma que `:produtoId` pertence a
     `:lojaId`, usado nas rotas de estoque (aninhadas sob produtos).

   Como isso roda no nível do router, uma rota nova adicionada no futuro
   dentro desses grupos **já nasce protegida**, sem precisar lembrar de
   repetir a checagem em cada função.

2. **`src/services/autorizacao.service.js`** — funções usadas quando a
   checagem depende de um ID que vem no **corpo** da requisição (não na
   URL), como `clienteId` num pedido, ou o par `estoqueId`+`produtoId`
   dentro de `atualizarQuantidade`. Cada função confirma a cadeia
   completa (ex: estoque → produto → loja) com uma única consulta, nunca
   confiando isoladamente em um ID solto.

### O que estava quebrado antes (e foi corrigido)

- `POST /produtos/:produtoId/estoque`: verificava só se a **loja**
  pertencia ao usuário, mas nunca se o **produto** informado pertencia a
  essa loja. Um usuário dono de qualquer loja podia criar estoque para um
  `produtoId` de **outra loja**, bastando adivinhar/obter o ID.
- `PATCH /produtos/:produtoId/estoque/:estoqueId`: não verificava
  **nada** além do login — nem loja, nem produto, nem se o
  `estoqueId` pertencia a quem quer que fosse. Qualquer usuário
  autenticado, dono de qualquer loja, podia alterar a quantidade de
  estoque de **qualquer loja do sistema**.

Ambos os casos foram fechados: agora a cadeia completa usuário → loja →
produto → estoque é verificada antes de qualquer leitura ou escrita.

## Pedidos — transação atômica e trava contra concorrência

Antes: o pedido era criado numa chamada e os itens em outra, sem nenhuma
transação — uma falha entre as duas chamadas deixava um "pedido fantasma"
sem itens. Além disso, **o estoque nunca era debitado**, e a checagem
"tem estoque suficiente?" e o uso desse estoque não eram atômicos (duas
requisições simultâneas podiam ambas passar na checagem e vender a mesma
unidade duas vezes).

Agora, `POST /pedidos` chama a função `criar_pedido` (definida em
`src/db/schema.sql`), que roda inteira dentro de uma transação no Postgres:

1. Valida que o cliente (se informado) pertence à loja.
2. Para cada item: trava a linha de estoque (`SELECT ... FOR UPDATE`),
   confirma que ela pertence a essa loja, confirma que há quantidade
   suficiente, debita o estoque e insere a linha em `pedido_itens` — com
   o preço vindo **exclusivamente** do produto no banco, nunca do que o
   cliente mandou.
3. Se qualquer passo falhar (cliente inválido, item de outra loja,
   quantidade inválida, estoque insuficiente), a função inteira é
   revertida — nenhuma linha órfã, nenhum estoque debitado à toa.

O `SELECT ... FOR UPDATE` é o que impede duas requisições simultâneas de
venderem a mesma última unidade: a segunda espera a primeira terminar e
só então enxerga o estoque já atualizado.

Por padrão, essa função só pode ser chamada pelo `service_role` (backend)
— um usuário com chave `anon`/`authenticated` não consegue chamá-la
diretamente, porque ela não valida por conta própria se a loja pertence a
quem está chamando (isso já foi validado pelo middleware antes do backend
chamar a função).

## O atendente de IA (regra de ouro)

A lógica fica dividida em duas partes:

- `src/services/ia.service.js` → busca os dados reais no banco
  (`buscarContextoDaLoja`), sempre filtrando pela loja e por produtos
  ativos.
- `src/services/ia.helpers.js` → funções **puras** (sem banco, sem rede)
  que recebem esse array de produtos e montam a resposta. Por não
  dependerem de I/O, dá pra testar toda a lógica de "nunca inventar
  produto/preço/tamanho/cor" com dados fake (`tests/ia.helpers.test.js`),
  sem precisar de um Supabase de verdade.

Se o produto não existir no catálogo, a resposta é "não encontrei esse
produto" — nunca um valor inventado. Essa separação (`service` busca,
`helpers` formata) é também o que facilita plugar uma IA de linguagem
natural de verdade no futuro: ela entraria só para reformular o texto,
recebendo os mesmos dados reais que `ia.helpers.js` já usa hoje.

### Proteção contra abuso (rate limiting)

Por ser uma rota pública (sem login, pensada para clientes finais),
`POST /ia/perguntar` tem um limitador de requisições em memória
(`src/middleware/rateLimiter.js`), configurável por variável de ambiente
(`IA_RATE_LIMIT_MAX`, `IA_RATE_LIMIT_JANELA_MS`; padrão: 20 perguntas por
IP a cada 60 segundos). Passado o limite, a API responde `429` com header
`Retry-After`.

**Limitação conhecida:** por rodar em memória do próprio processo, o
limite é por instância — se o serviço rodar em múltiplas instâncias
(scale-out horizontal), o limite efetivo vira `limite × número de
instâncias`. Para uma única instância (ex: Render free/starter), o
comportamento é exato. Se o projeto crescer e escalar horizontalmente,
trocar por um contador compartilhado (ex: Redis) para manter o limite
exato entre instâncias.

## Camada de LLM (Etapa 9A: base / Etapa 9B: integração real)

`src/services/llm.service.js` é um serviço isolado que sabe **apenas**
comunicar-se com um provedor de LLM — ele não busca dados do catálogo,
não decide regras de negócio e não é chamado por nenhum controller/rota
ainda. A mesma separação já usada no atendente atual (busca de dados vs.
formatação) se aplica aqui, só que para a camada de rede:

```
controller           (ainda não integrado)
  → serviço de atendimento   (futuro)
    → llm.service.js         (adaptador HTTP real, feito na 9A/9B)
      → provedor de LLM real (Groq ou qualquer provedor compatível com
                               o formato "chat completions"/OpenAI)
```

Principais pontos:

- `estaConfigurado()` retorna `true`/`false` conforme `LLM_PROVIDER_API_KEY`
  e `LLM_PROVIDER_URL` existem no ambiente. Sem essas variáveis, o serviço
  se recusa a funcionar — nunca "inventa" um provedor ou usa uma chave
  hardcoded.
- `gerarResposta({ systemPrompt, contexto, pergunta })` monta o corpo da
  requisição no formato "chat completions" (`{ model, messages: [...] }`,
  padrão OpenAI/Groq — `construirMensagens()`) e extrai o texto da
  resposta (`extrairTextoDaResposta()`, com `choices[0].message.content`
  como formato principal e alguns formatos alternativos como fallback,
  para facilitar trocar de provedor sem alterar o restante do código).
- **Provedor sugerido: Groq** (`https://api.groq.com/openai/v1/chat/completions`),
  por ter API HTTP simples, formato compatível com o padrão do mercado
  (OpenAI) e opção de uso gratuito/baixo custo em desenvolvimento. Como o
  formato é o padrão do setor, trocar de provedor no futuro é só trocar
  `LLM_PROVIDER_URL` (e possivelmente `LLM_PROVIDER_MODEL`) — nenhum
  código muda.
- Erros são sinalizados com três classes próprias: `ErroLlmConfiguracaoAusente`,
  `ErroLlmProvedor` (erro HTTP do provedor, timeout ou falha de rede) e
  `ErroLlmRespostaInvalida` (resposta 200 OK mas vazia ou em formato
  inesperado). A mensagem devolvida ao chamador é sempre genérica e fixa
  — nunca inclui corpo de erro do provedor, stack trace ou a API key.
- **Segurança de logs**: antes de qualquer `console.error`, o texto é
  passado por `redigirSegredo()`, que substitui qualquer ocorrência
  literal da API key por `[API_KEY_OCULTADA]`. Isso é defesa em
  profundidade — mesmo que uma mensagem de erro subjacente
  (rede/parsing) um dia venha a conter a chave, ela não chega ao log do
  servidor. O objeto `headers` da requisição (que carrega o
  `Authorization: Bearer <chave>`) nunca é passado para nenhum
  `console.*`.
- O endpoint público atual (`POST /ia/perguntar`) **não usa este
  serviço ainda** — continua 100% baseado em `ia.helpers.js`/
  `ia.service.js`, como descrito na seção anterior. A conexão entre os
  dois fica para uma etapa futura.
- Testado em `tests/llmService.test.js`, sem rede real (usa
  `global.fetch` substituído por uma função fake durante os testes) —
  cobre configuração ausente, chamada bem-sucedida, erro HTTP, resposta
  inválida, timeout/falha de rede e não-vazamento da API key em erros e
  logs.

## Validação e tratamento de erros

- `src/utils/validacao.js`: validadores simples (string não vazia, UUID,
  número/inteiro não-negativo, etc.), usados nos controllers antes de
  qualquer consulta ao banco — evita erros de banco desnecessários e dá
  mensagens de erro melhores.
- `src/utils/erros.js`: erros vindos do Postgres nunca são repassados
  crus ao cliente (evita vazar nomes de coluna, texto de constraint,
  etc.) — são traduzidos para mensagens genéricas e seguras, enquanto o
  erro completo é sempre logado no servidor (`console.error`) para
  depuração. Exceção intencional: os erros do Supabase Auth
  (`auth.controller.js`) são repassados como vêm, porque já são pensados
  pelo próprio GoTrue para serem exibidos ao usuário final (ex: "Invalid
  login credentials").
- O handler de erro genérico em `app.js` nunca inclui `stack` nem
  `err.message` na resposta ao cliente.

## CORS, headers e limites

- **CORS** (`src/config/cors.js`): configurável via `ALLOWED_ORIGINS`
  (lista separada por vírgula), aplicado nas rotas autenticadas do
  lojista (`/api/auth`, `/api/lojas`, produtos, clientes, pedidos). Sem
  essa variável definida, o comportamento depende de `NODE_ENV`: em
  produção fica **fechado** por padrão (fail-safe — nenhuma origem
  cross-origin liberada até configurar o domínio real do painel); fora de
  produção, libera `localhost`/`127.0.0.1` automaticamente para facilitar
  o desenvolvimento local. A rota pública `/ia/perguntar` é uma exceção
  deliberada e mantém CORS aberto para qualquer origem (configurado
  separadamente em `routes/ia.routes.js`), pois precisa ser chamada a
  partir dos sites das próprias lojas (domínios variados, desconhecidos
  de antemão) e só devolve catálogo público — sem cookies, sem dado
  sensível.
- **Headers de segurança básicos** (`src/middleware/segurancaHeaders.js`):
  `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`,
  `Cross-Origin-Resource-Policy`. `X-Powered-By` é desabilitado
  (`app.disable('x-powered-by')`).
- **Limite de payload**: `express.json({ limit: '100kb' })` — suficiente
  para os dados deste projeto (não há upload de arquivo nesta fase) e
  evita abuso com corpos de requisição enormes.

## Camada de abstração de WhatsApp (Etapa 10A — fundação, sem integração real)

`src/services/whatsapp.service.js` define, de forma isolada, o **contrato**
que uma futura integração real com WhatsApp deverá seguir. Nesta etapa:

- **Não há** chamada HTTP real, Meta API, Twilio, Z-API, Evolution API ou
  qualquer outro provedor.
- **Não há** webhook público/rota HTTP associada a este service.
- **Não há** persistência de conversas. (A persistência da *configuração* de
  WhatsApp de cada loja veio depois, na Etapa 10B — seção abaixo. O
  `whatsapp.service.js` continua sem tocar em banco.)

O arquivo só expõe funções puras (sem I/O) para normalizar uma mensagem
recebida (`normalizarMensagemRecebida`) e preparar uma mensagem a enviar
(`prepararEnvioMensagem`), além de dois placeholders (`enviarMensagem`,
`receberMensagem`) que **sempre lançam erro** nesta etapa — existem só para
deixar explícito onde um adaptador de provedor real deverá se conectar no
futuro.

Fluxo conceitual futuro (nada disto está implementado ainda):

```
WhatsApp → adaptador do provedor → mensagem normalizada → loja → IA (ia.service) → resposta → adaptador do provedor → WhatsApp
```

O `lojaId` usado por esta camada deve sempre vir de uma fonte confiável da
própria aplicação — nunca de um campo (ex.: `loja_id`) presente no payload
bruto de um provedor externo. Isso segue o mesmo princípio de isolamento
multi-tenant já usado em `iaContexto.service.js` e
`middleware/lojaOwnership.js`. A lógica do Atendente de IA (`ia.service.js`
e os serviços que ele já usa) permanece intocada e centralizada; o WhatsApp
é tratado apenas como mais um canal de entrada/saída de texto.

Testes: `tests/whatsappService.test.js`.

(O contrato de provedor e um adaptador estrutural foram adicionados depois, na
Etapa 10F — seção mais abaixo. Os placeholders `enviarMensagem` e
`receberMensagem` deste arquivo continuam lançando erro de propósito.)

## Configuração de WhatsApp por loja (Etapa 10B — só estrutura, sem integração real)

Estrutura nova:

```
loja  →  whatsapp_configuracoes
```

Uma linha de `whatsapp_configuracoes` diz "esta loja usa este provedor e este
número de WhatsApp". Arquivos: `src/db/migrations/003_whatsapp_configuracoes.sql`
(bancos já existentes), `src/db/schema.sql` (projetos novos — mesma tabela) e
`src/services/whatsappConfiguracao.service.js`. Testes:
`tests/whatsappConfiguracao.service.test.js`.

**O que isto é e o que não é**

- **Ainda não existe integração real** com WhatsApp: nenhum provedor, nenhuma
  chamada HTTP, nenhum webhook, nenhuma rota, nenhuma tela. O service só lê e
  grava esta tabela e nada chama ele ainda.
- **A tabela representa configuração, não conversa.** Nenhuma mensagem é
  armazenada aqui.
- **Segredos de provedores não ficam nessa tabela.** Não há coluna para access
  token, API key, secret, senha ou credenciais, e o service rejeita qualquer
  campo desse tipo. Como esses dados serão guardados é decisão de uma etapa
  futura; não adicione colunas assim aqui.
- O Atendente de IA e o `whatsapp.service.js` não foram alterados.

**Colunas**

| coluna | tipo | regra |
| --- | --- | --- |
| `id` | uuid | chave primária |
| `loja_id` | uuid | `not null`, referencia `lojas(id)` (`on delete cascade`) |
| `provedor` | text | `not null`; texto livre (sem lista fechada), gravado em minúsculas e sem espaços nas pontas |
| `numero_whatsapp` | text | `not null`; sem regra de formato (só não vazio, sem espaços nas pontas) |
| `identificador_externo` | text | opcional (`null`); mesmo tratamento do número quando informado |
| `ativo` | boolean | `not null default true` |
| `created_at`, `updated_at` | timestamptz | `not null default now()`; `updated_at` é renovado pelo service a cada alteração |

**Duplicidade.** Só entre configurações **ativas**, por índices únicos parciais:
o mesmo (`provedor`, `numero_whatsapp`) e o mesmo (`provedor`,
`identificador_externo`) só podem estar ativos uma vez **no sistema inteiro** —
não só dentro da mesma loja. Motivo: a futura integração vai descobrir a loja a
partir do número que recebeu a mensagem; se duas lojas ativas tivessem o mesmo
número, a mensagem poderia ir para a loja errada. Configurações desativadas
(`ativo = false`) não bloqueiam ninguém. A mensagem de erro de duplicidade é
genérica e não revela qual loja possui o número. Existe também um índice por
`loja_id`; os índices únicos servem às consultas futuras por provedor + número
e provedor + identificador.

**Isolamento multi-tenant (a regra central do service).** O backend usa a
service_role key, que ignora o RLS — então o RLS desta tabela (mesmo padrão das
demais) é só uma camada extra, **nunca a autorização**. Quem isola as lojas é o
código:

- toda função exige `lojaId` explícito, de origem confiável da aplicação;
- buscar, atualizar e desativar filtram por `id` **e** `loja_id` na mesma
  consulta — a configuração de outra loja é tratada como inexistente;
- `loja_id` nunca é aceito dentro dos dados enviados (qualquer campo fora de
  `provedor`, `numero_whatsapp`, `identificador_externo` e `ativo` é rejeitado),
  então não dá para criar em outra loja nem "mover" uma configuração;
- as consultas listam colunas explicitamente e a saída é filtrada, então mesmo
  uma coluna adicionada por engano não vazaria.

Este service **não** verifica se o usuário logado é dono da loja: quem decide o
`lojaId` confiável (por exemplo o middleware `exigirDonoDaLoja`) continua sendo
responsável por isso antes de chamá-lo.

**Limitações conhecidas.** A tabela registra o que foi *declarado*: ela não
comprova que a loja realmente controla o número. A futura integração precisará
verificar isso (por exemplo, pelo próprio provedor) antes de tratar uma
configuração como confiável. A unicidade compara o texto exato do número (só
com espaços das pontas removidos), então "+55 11 91234-5678" e "5511912345678"
contam como valores diferentes; uma normalização de número pode ser definida
quando o provedor for escolhido.

**Regra para a futura integração.** Ela deverá resolver a loja de maneira
confiável — a partir de uma configuração ativa registrada nesta tabela, depois
de validar a origem da mensagem no provedor — e **nunca confiar em `loja_id`
fornecido pelo cliente final** (ou presente no payload bruto do provedor).

## Webhook de WhatsApp — camada de processamento (Etapa 10C — sem provedor; a rota HTTP veio na 10D)

**Conceito.** Um *webhook* é o endereço que o provedor de WhatsApp chama sozinho
sempre que acontece algo (por exemplo, um cliente mandou uma mensagem). Ele
entrega um evento e a aplicação precisa decidir, com segurança, de qual loja é
aquela mensagem. Antes de abrir um endereço público desses, esta etapa criou
apenas a **camada de processamento** do evento.

**O que existe agora.** `src/services/whatsappWebhook.service.js` recebe um
*evento genérico* (um objeto JS), valida, resolve a configuração e devolve uma
mensagem interna normalizada. Testes: `tests/whatsappWebhook.service.test.js`.
No `whatsappConfiguracao.service.js` foi adicionada
`buscarConfiguracaoPorIdentificadorExterno`.

**O que continua não existindo.** **Nenhum provedor real está conectado**; este
service não abre rota nem servidor (a rota HTTP foi criada depois, na Etapa 10D —
seção abaixo), e não há chamada HTTP, envio de mensagem, armazenamento de
conversa nem chamada ao LLM. O fluxo para na mensagem normalizada:

```
evento externo
  → adaptador de provedor      (futuro; aqui só o adaptador genérico)
  → validação
  → identificação da configuração WhatsApp   (banco)
  → normalização (abstração da 10A)
  → mensagem interna normalizada             ← o fluxo termina aqui
```

**Evento genérico aceito.** `destinatarioId` (identificador externo do número que
*recebeu* a mensagem), `contato` (quem enviou), `texto`, e opcionalmente
`idExterno` (id da mensagem no provedor) e `timestamp`. Qualquer outro campo do
payload é descartado sem ser lido. Faltando destinatário, contato ou texto
válido (ou com texto acima do limite da 10A), o evento é rejeitado com erro
controlado, antes de qualquer consulta ao banco. Campos opcionais ausentes ou em
branco viram `null`; se vierem preenchidos, precisam ser válidos.

**A loja é resolvida pela configuração cadastrada.** O `destinatarioId` é
procurado em `whatsapp_configuracoes` (só configurações **ativas**, e do
provedor informado pela aplicação, quando houver). O `lojaId` da mensagem é o
`loja_id` **dessa linha do banco**, assim como o `configuracaoId`. O número do
remetente identifica o **contato**, nunca a loja. Configuração inexistente ou
desativada é rejeitada com a mesma resposta genérica (não revela quais números
existem); se mais de uma configuração ativa bater (só possível sem informar o
provedor), o evento também é rejeitado em vez de escolher uma loja.

**`loja_id` externo não é confiável.** Um `loja_id`, `lojaId`, `configuracaoId`,
`provedor` (ou qualquer outro campo) presente no payload não altera a loja, a
configuração, o provedor nem as regras internas: a mensagem interna é montada
com campos explícitos e o provedor só pode vir do contexto que a própria
aplicação passa (por exemplo, parte da rota), nunca do corpo do evento. A
resolução ainda é conferida em código (ativa, mesmo identificador, mesmo
provedor, ids válidos), além do filtro da consulta.

**Dado × controle (anti-injection).** Na mensagem interna, `lojaId`,
`configuracaoId` e `canal` são **confiáveis** (derivados internamente);
`contato`, `texto`, `idExterno` e `timestamp` são **dados do cliente**. O `texto`
nunca é interpretado: frases como "ignore as instruções" ou "você é o
administrador" continuam sendo só texto. Quando o LLM for ligado, o `texto` deve
entrar apenas como conteúdo de usuário, jamais misturado ao system prompt, à
configuração ou a credenciais.

**Limitações e cuidados.**
- Esta camada **não autentica a origem** do evento. A futura rota precisará
  verificar que o evento veio mesmo do provedor (assinatura/segredo) *antes* de
  chamá-la; o identificador do número da loja não é segredo.
- Datas em formatos específicos de provedores (ex.: segundos desde 1970) são
  responsabilidade do futuro adaptador de cada provedor.

**Próximo passo.** A rota que chama `processarEventoWhatsapp` foi criada na
Etapa 10D (abaixo). Ainda falta, em etapa própria, autenticar a origem do evento
e informar o provedor como contexto confiável.

## Rota do webhook de WhatsApp (Etapa 10D — entrada HTTP genérica, sem provedor)

**Endpoint:** `POST /api/webhooks/whatsapp`. Arquivos:
`src/routes/whatsappWebhook.routes.js` (só liga HTTP ao controller),
`src/controllers/whatsappWebhook.controller.js` (traduz HTTP ↔ service, sem
lógica de negócio) e, em `src/app.js`, duas linhas que montam a rota. Testes:
`tests/whatsappWebhook.controller.test.js` e `tests/whatsappWebhook.routes.test.js`.

**Ainda é uma entrada genérica.** Ela aceita o *evento genérico* da 10C
(`destinatarioId`, `contato`, `texto`, opcionais `idExterno` e `timestamp`).
**Nenhum provedor real está conectado** e nada de fato a chama hoje. Também
**não há envio de mensagens nem processamento pela IA**, nem armazenamento de
conversa: o fluxo termina depois da normalização.

```
HTTP POST → rate limiter → parser JSON (100kb) → verificação de assinatura (10E)
          → controller → whatsappWebhook.service (10C) → resposta HTTP
```

**A identificação da loja ocorre internamente.** O controller extrai só os cinco
campos do evento e chama o service, que descobre a loja pela configuração de
WhatsApp cadastrada no banco (seção anterior). `loja_id`, `lojaId`,
`configuracaoId`, `provedor` ou qualquer outro campo no corpo são descartados;
nem `params`, `query` ou headers participam. O provedor só pode ser informado
por `req.contextoWebhook`, um dado que um middleware **do servidor** definirá no
futuro (nunca copiado do corpo).

**Sem login do painel, de propósito.** Quem chama um webhook é o provedor, não um
lojista logado: a rota não usa `exigirLogin` nem `exigirDonoDaLoja` e não tem
`:lojaId` no caminho. É um endpoint público por natureza.

**Respostas** (mensagens fixas e genéricas, sempre `{ "erro": "..." }` nos erros):

| status | quando |
| --- | --- |
| 200 | evento válido e número destinatário com configuração ativa → `{ "status": "recebido" }` |
| 401 | assinatura ausente, malformada ou inválida (Etapa 10E) |
| 400 | corpo/JSON inválido ou evento inválido (falta destinatário, contato ou texto; texto grande demais...) |
| 404 | nenhuma configuração ativa para o destinatário (inexistente, desativada ou ambígua: mesma resposta) |
| 413 | corpo acima de 100kb |
| 429 | excesso de requisições (rate limiter) |
| 500 | erro interno inesperado (ex.: banco fora do ar) |
| 503 | verificação de assinatura indisponível: segredo do servidor não configurado (Etapa 10E) |

Não existe 409: uma configuração ambígua vira 404 de propósito, para não revelar a
quem chama que o identificador existe. O 200 **não devolve** `lojaId`,
`configuracaoId`, contato nem texto (o endpoint é público: devolver ids
internos revelaria a qual loja pertence um número) — e, nesta etapa, a mensagem
normalizada é apenas descartada depois de validada.

**Erros e logs.** Nada de stack, SQL, erro do Supabase, nomes de tabela ou
caminhos vai para o cliente. O log do servidor recebe só um resumo seguro (tipo,
código e primeiras chamadas da pilha), nunca o texto, o contato nem o corpo.
(Falhas de banco continuam sendo registradas também pelo
`whatsappConfiguracao.service.js`, como em 10B.)

**Limite de corpo.** 100kb, o mesmo limite do app, aplicado por um parser JSON
próprio da rota. Por isso a rota é montada **antes** do parser global em
`app.js`: assim o parser dela preserva o corpo bruto (`req.corpoBruto`) e trata
os próprios erros. Não afeta nenhuma outra rota.

**Rate limiting.** Reaproveita o limitador em memória do projeto, com limite
próprio e generoso (300 requisições/minuto por padrão; ajustável por
`WHATSAPP_WEBHOOK_RATE_LIMIT_MAX` e `..._JANELA_MS`), aplicado antes de ler o
corpo. **Não é uma solução final:** o contador é por processo e por IP
(`req.ip`); atrás de um proxy sem `trust proxy` (como costuma ser em
hospedagens tipo Render) os IPs podem se confundir num só, virando um teto
global que também poderia barrar tráfego legítimo do provedor. Isso deve ser
reavaliado na etapa do provedor real (limite por origem já autenticada,
`trust proxy`, contador compartilhado).

**Autenticação da origem.** Na 10D a rota nasceu sem verificação de origem; ela
foi adicionada na Etapa 10E (seção abaixo), no ponto que a 10D já havia reservado
(`verificacoesDeOrigem`, entre o parser e o controller, usando `req.corpoBruto`).
Continua **não existindo** a verificação por GET (desafio/`challenge`) que alguns
provedores exigem ao cadastrar o webhook.

**Como foi testado, e o que falta testar.** Os testes usam Express e Supabase
falsos: verificam o controller com o service real, a fiação da rota (caminho,
ordem dos middlewares, limite, ausência de login, registro em `app.js`) sem abrir
servidor. Eles **não** exercitam o Express/body-parser reais (o parse real do JSON
e o 413 real por tamanho). Depois de `npm install`, um teste manual rápido:

```
npm start
curl -i -X POST localhost:3000/api/webhooks/whatsapp -H "Content-Type: application/json" -d '{}'
   → 400   (evento inválido)
curl -i -X POST localhost:3000/api/webhooks/whatsapp -H "Content-Type: application/json" \
     -d '{"destinatarioId":"qualquer","contato":"5511999999999","texto":"oi"}'
   → 404   (sem configuração ativa para esse destinatário)
curl -i -X POST localhost:3000/api/webhooks/whatsapp -H "Content-Type: application/json" -d '{quebrado'
   → 400   (JSON inválido);  um corpo com mais de 100kb → 413
```

## Autenticação da origem do webhook (Etapa 10E — assinatura HMAC GENÉRICA)

**O webhook é público, e a origem é autenticada por assinatura.** A rota
`POST /api/webhooks/whatsapp` continua sem login do painel (não usa
`exigirLogin`): quem chama é um sistema externo, não um lojista. O que a protege é
uma **assinatura HMAC-SHA256 do corpo da requisição**. Requisições sem assinatura
válida são rejeitadas antes de qualquer processamento: o controller e o service
do webhook nem chegam a executar.

> **O formato é GENÉRICO.** Ele foi criado como abstração para o estágio atual do
> projeto e **não** é o formato de nenhum provedor real; não deve ser tratado como
> compatível com Meta, Twilio ou qualquer outro. **Antes de integrar um provedor
> real, o formato de assinatura específico dele** (nome do header, prefixo,
> algoritmo, o que exatamente é assinado, como o segredo é obtido) **precisará ser
> verificado na documentação oficial do provedor e adaptado** — em
> `verificacoesDeOrigem`, na rota, sem mexer no controller nem no service de
> negócio.

**Como a assinatura é calculada.**

```
X-Webhook-Signature: sha256=<HMAC_SHA256_HEX>
HMAC_SHA256_HEX = HMAC-SHA256( chave = WHATSAPP_WEBHOOK_SECRET, mensagem = req.corpoBruto )
```

- É calculada sobre o **corpo bruto** (`req.corpoBruto`): os bytes exatos recebidos,
  guardados pelo parser JSON da rota. **Nunca** sobre `JSON.stringify(req.body)`,
  porque reserializar o JSON muda espaços, ordem das chaves e escapes, e uma
  assinatura só vale para os bytes que foram assinados.
- O formato do header é estrito: `sha256=` (minúsculas) seguido de exatamente 64
  dígitos hexadecimais (maiúsculos ou minúsculos), sem espaços. Qualquer outra
  coisa (`abc`, `sha1=...`, tamanho errado, header duplicado) é rejeitada.
- A comparação é feita com `crypto.timingSafeEqual` sobre os dois HMACs (32 bytes),
  de forma segura contra *timing attacks*. Nunca com `===`. Só é usado o módulo
  nativo `node:crypto` (nenhuma dependência nova).

**Onde o segredo fica.** **Somente na variável de ambiente `WHATSAPP_WEBHOOK_SECRET`
do servidor**, lida a cada requisição. Ele não fica no banco, no código, em arquivo
versionado (o `.env.example` traz a variável em branco), nem em resposta HTTP ou
log. Sugestão: um valor longo e aleatório, por exemplo `openssl rand -hex 32`.

**Fail closed.** Nada é aceito sem verificação bem-sucedida:

| situação | resposta |
| --- | --- |
| header ausente, malformado, assinatura inválida, corpo alterado ou corpo bruto indisponível | `401` `{ "erro": "Não autorizado." }` (idêntica em todos os casos) |
| segredo ausente, vazio ou em branco no servidor (ou falha inesperada na verificação) | `503` `{ "erro": "Webhook temporariamente indisponível." }` |

**Não existe modo "sem verificação":** segredo ausente **não** libera o webhook. A
resposta 503 não diz que o problema é o segredo; o motivo só aparece no log do
servidor (o nome da variável, uma única vez enquanto persistir).

**Logs.** Só frases fixas com um motivo categórico (por exemplo, "Falha na
verificação de assinatura do webhook (motivo: cabecalho_ausente)"). Nunca o
segredo, a assinatura (recebida ou esperada), o corpo, a mensagem nem o contato.

**Onde a verificação acontece no fluxo.**

```
POST /api/webhooks/whatsapp
   → rate limiter                 (antes de ler o corpo)
   → parser JSON (limite 100kb)   (guarda req.corpoBruto)
   → verificação HMAC             ← 10E: 401/503 encerram aqui
   → controller → whatsappWebhook.service → resolve a loja
```

Arquivos: `src/services/whatsappWebhookAssinatura.service.js` (cálculo e comparação,
funções puras), `src/middleware/webhookAssinatura.js` (respostas HTTP e log) e a
linha em `src/routes/whatsappWebhook.routes.js`. Testes:
`tests/whatsappWebhookAssinatura.test.js`. O restante do comportamento aprovado na
10D (resolução da loja pela configuração ativa, `loja_id`/`lojaId`/`configuracaoId`/
`provedor` do corpo ignorados, rate limit, limite de corpo, erros genéricos) não foi
alterado.

**Limitações.**
- **O formato é genérico** (ver o aviso acima). Assinar corretamente não prova que
  o emissor é um provedor específico: prova que ele conhece o segredo compartilhado.
- **Não há proteção contra replay.** Uma requisição legítima capturada e reenviada
  com o mesmo corpo e a mesma assinatura continua válida. Provedores reais costumam
  oferecer timestamp/identificador para isso; fica para a integração com o provedor.
- A verificação roda **depois** do parser: uma requisição não autenticada ainda faz o
  servidor ler e interpretar até 100kb (o rate limiter roda antes). Um JSON quebrado
  responde `400` antes de a assinatura ser conferida.
- Um único segredo para todo o webhook; não há rotação com dois segredos válidos.
- Como na 10D, os testes usam Express falso e não exercitam o body-parser real; o
  teste manual sugerido acima continua valendo, agora assinando o corpo (por exemplo:
  `openssl dgst -sha256 -hmac "$WHATSAPP_WEBHOOK_SECRET" -hex` sobre o arquivo do
  corpo, enviando `sha256=` seguido só do valor hexadecimal no header `X-Webhook-Signature`).

## Contrato e adaptador de provedor de WhatsApp (Etapa 10F — estrutural, sem provedor real)

**Existe um contrato interno para WhatsApp**, e o sistema **não depende diretamente
da API de nenhum provedor**. A ideia é impedir que regras específicas de um
provedor (campos de payload, códigos de erro, autenticação) contaminem o restante
do código:

```
nosso sistema
    ↓  usa APENAS o contrato
contrato interno de WhatsApp          src/services/providers/whatsapp/contrato.js
    ↓
adaptador do provedor                 src/services/providers/whatsapp/adaptadorSimulado.js
    ↓  [futuramente]
API real do provedor                  (ainda não existe)
```

**Situação real hoje — leia com atenção.** O único adaptador é o **simulado**: é
apenas estrutural/testável e **não envia nem recebe nada**. **Não existe chamada
externa** nesta etapa (sem HTTP, fetch, axios, SDK ou socket) e **credenciais
reais ainda não estão configuradas** (não há token, API key nem segredo de
provedor no código, no banco ou no `.env.example`). **O WhatsApp real ainda não
está funcionando**; a integração real será adicionada em etapa posterior, quando
um provedor for escolhido. Nenhum provedor foi escolhido: o contrato não assume
Meta, Twilio, Evolution, Baileys nem outro.

**O contrato** define quatro operações (`OPERACOES_DO_CONTRATO`):

| operação | o que faz |
| --- | --- |
| `enviarMensagem(pedidoDeEnvio)` | envia; devolve o resultado interno do envio |
| `normalizarMensagemRecebida(entrada)` | valida/normaliza uma mensagem recebida |
| `identificarContato(mensagem)` | devolve o contato (a pessoa) |
| `identificarLoja(mensagem)` | devolve o `lojaId` da mensagem |

As três últimas **já existiam** em `whatsapp.service.js` (10A) e o adaptador só as
reutiliza — nada foi duplicado nem alterado. O que é novo:

- **Pedido de envio** (`criarPedidoDeEnvio`): `{ canal, lojaId, contato, texto,
  configuracaoId }`, com as mesmas validações da 10A (UUID, contato e texto não
  vazios, limite de texto). `configuracaoId` é opcional e vem da aplicação.
  **Nunca carrega segredo/token**: qualquer campo fora da lista, e em especial nomes
  que parecem credencial, é rejeitado sem repetir o valor. `lojaId` ausente ou
  inválido é rejeitado.
- **Resultado do envio** (`criarResultadoEnvio`/`criarResultadoFalha`), o único
  formato que o resto do sistema conhece, qualquer que seja o provedor:
  `{ canal, sucesso, status, simulado, idExterno, provedor, erro }`, com
  `status` = `enviado` | `simulado` | `falhou`. Erros de provedor são traduzidos para
  códigos genéricos com mensagem fixa (`provedor_indisponivel`,
  `mensagem_rejeitada`, `erro_interno`), então nada específico ou sensível vaza.
- **Cuidado com `sucesso: true`:** um resultado **simulado** também o tem, e nele
  `simulado` é `true`, `status` é `simulado` e `idExterno` é `null` (não se inventa
  identificador). Para saber se uma mensagem foi entregue de verdade use sempre
  `mensagemFoiEnviada(resultado)`.
- **Verificação de implementações** (`verificarImplementacaoDoContrato`): confere que
  um adaptador tem `nome` e as quatro operações.

**Como o resto do sistema deve usar o contrato** (nada o usa ainda; isto é o
desenho para a integração futura):

```js
const { obterProvedorWhatsapp, criarPedidoDeEnvio, mensagemFoiEnviada } =
  require('./providers/whatsapp');

const provedor = obterProvedorWhatsapp(nomeDoProvedor);   // hoje só existe 'simulado'
const resultado = await provedor.enviarMensagem(
  criarPedidoDeEnvio({ lojaId, contato, texto, configuracaoId })
);
if (!mensagemFoiEnviada(resultado)) { /* simulado ou falhou */ }
```

Quem usa importa apenas o ponto de entrada (`providers/whatsapp/index.js`), nunca um
adaptador. `obterProvedorWhatsapp` exige o nome (não há padrão, para nunca cair sem
aviso num adaptador que não envia nada) e lança erro genérico para qualquer nome
sem adaptador. O nome deve vir de fonte confiável da aplicação (por exemplo, a
configuração ativa cadastrada) — **nunca do payload externo**.

**Isolamento multi-tenant.** O adaptador não escolhe a loja: `lojaId` é sempre um
parâmetro explícito e confiável. `loja_id`, `lojaId` extra, `configuracaoId`,
`provedor` ou qualquer outro campo vindo de um payload externo são ignorados (na
normalização) ou rejeitados (no pedido de envio). O **contato identifica a
pessoa**, nunca a loja. A resolução segura da loja continua sendo feita pela
configuração ativa cadastrada (`whatsappWebhook.service.js`, 10C), sem mudança.

**Credenciais (só a abstração; nada implementado).** Objetos de domínio nunca
carregam segredo. Quando um provedor real for escolhido, as credenciais dele deverão
ser entregues ao **adaptador na construção**, vindas de fonte segura definida em
etapa própria (por exemplo, o ambiente do servidor) — nunca pelo pedido de envio,
pelo payload externo nem pela tabela `whatsapp_configuracoes`.

**Adicionar um provedor real (etapa futura).** Escrever o adaptador no mesmo molde do
simulado, com a chamada externa dentro de `enviarMensagem` e a tradução do payload
do provedor dentro de `normalizarMensagemRecebida`; verificar o formato de
assinatura e as regras dele (ver o aviso da 10E); e incluí-lo em `ADAPTADORES` no
`index.js`. Quem usa o contrato não precisa mudar.

**O que não mudou.** O webhook e sua segurança (rate limit → corpo bruto → HMAC →
controller → `whatsappWebhook.service`), o `whatsapp.service.js`, a IA, o banco (sem
migrations) e o frontend. O webhook **não** usa o adaptador; os dois se encontrarão
numa etapa futura.

Testes: `tests/whatsappProvedor.contrato.test.js`.

## Adaptador Meta WhatsApp Cloud API (Etapa 10G — infraestrutura de envio, isolado)

**O que existe agora.** Além do adaptador **simulado** (10F), existe um segundo
adaptador que cumpre o mesmo contrato interno e faz uma chamada HTTP **real** de
envio de mensagem de texto à **Meta WhatsApp Cloud API**:

```
src/services/providers/whatsapp/
    contrato.js            (10F — inalterado)
    adaptadorSimulado.js   (10F — inalterado)
    adaptadorMeta.js       (10G — NOVO: adaptador real da Meta)
    clienteHttpMeta.js     (10G — NOVO: cliente HTTP isolado da Meta)
    index.js               (10G — passou a registrar também 'meta')
```

**Documentação oficial consultada** (Meta for Developers → WhatsApp Business
Platform → Cloud API, seções "Send Messages"/"Text messages"/referência da
Messages API), na data em que este adaptador foi escrito. Versão da Graph API
adotada: **v26.0** (a mais recente estável no momento da consulta ao Graph API
Changelog oficial), configurável por `META_WHATSAPP_API_VERSION` sem alterar
código, caso a Meta publique uma versão mais nova depois.

**Situação real hoje — leia com atenção.** Este adaptador **não está ligado a
nada**: nenhuma rota, controller ou webhook chama `obterProvedorWhatsapp('meta')`.
Ele só pode ser obtido explicitamente (hoje, só os testes fazem isso). O webhook
existente (10C/10D/10E) continua exatamente como está — o fluxo "mensagem
recebida → IA → resposta pela Meta" **não foi conectado** nesta etapa. Nenhuma
mensagem real foi enviada durante o desenvolvimento/testes desta etapa: todos os
testes usam uma função `fetch` falsa injetada (`fetchFn`), nunca a rede.

**Como o adaptador é isolado (PROVEDOR → ADAPTADOR → CONTRATO INTERNO):**

```
sistema (nada usa isto ainda)
    ↓  contrato interno (inalterado — ./contrato.js)
adaptadorMeta.js       — sabe o que é um "pedido de envio"/"resultado de envio"
    ↓                    do CONTRATO; NÃO sabe fazer HTTP sozinho
clienteHttpMeta.js     — sabe montar e EXECUTAR uma requisição HTTP; NÃO
    ↓                    conhece o contrato nem o domínio da aplicação
Meta Graph API (graph.facebook.com/<versão>/<phoneNumberId>/messages)
```

`adaptadorMeta.js` só chama `clienteHttpMeta.js`; nenhum outro arquivo do
projeto (controller, service de IA, service de pedidos, webhook, frontend) faz
chamada HTTP à Meta. `clienteHttpMeta.js` separa **montar** a requisição
(`montarRequisicaoEnvioTexto`, função pura — método, URL, headers, body) de
**executar** a requisição (`executarRequisicao`, com timeout e `fetchFn`
injetável), exatamente para permitir testar a montagem sem rede e testar a
execução com uma função fake.

**Normalização do resultado.** Sucesso vira
`criarResultadoEnvio({ provedor: 'meta', status: 'enviado', idExterno })`, com
`idExterno` extraído de `messages[0].id` da resposta da Meta — nunca inventado.
Qualquer falha (HTTP 4xx/5xx, timeout, falha de rede, JSON inválido, resposta
sem o campo `id` esperado, credencial ausente) vira
`criarResultadoFalha({ provedor: 'meta', codigoErro })`, com o **código
genérico** do contrato (nunca o texto/código específico da Meta):
- HTTP `5xx` ou `429` → `provedor_indisponivel`;
- demais erros HTTP `4xx` (token inválido, número rejeitado etc.) → `mensagem_rejeitada`;
- credencial ausente, JSON inválido, resposta sem `id` → `erro_interno`.

Erros de ENTRADA (pedido inválido: `lojaId`/`contato`/`texto` ausentes ou
malformados) continuam lançando `ErroMensagemWhatsappInvalida`, igual ao
adaptador simulado — isso é erro de programação de quem chama, não falha do
provedor.

**Credenciais.** `META_WHATSAPP_ACCESS_TOKEN` e `META_WHATSAPP_API_VERSION` (e
`META_WHATSAPP_TIMEOUT_MS`) são lidas do ambiente do servidor — nenhum valor
real em código, testes, logs ou no ZIP (ver `.env.example`). **`phoneNumberId`
propositalmente NÃO tem variável de ambiente**: cada loja teria, num cenário
real, o seu próprio número de WhatsApp Business na Meta, então uma variável
global faria toda loja enviar pelo mesmo número — o oposto do isolamento
multi-tenant que o resto do projeto garante. Em vez disso, `criarAdaptadorMeta`
aceita `phoneNumberId` como parâmetro explícito da construção: hoje só os
testes o fornecem. Sem ele, `enviarMensagem` **falha de forma segura**
(`erro_interno`), nunca lança e nunca "inventa" um número. Resolver a
credencial certa por loja (usando `configuracaoId`, já presente no pedido de
envio) fica para a etapa futura de credenciais/onboarding (ver item 6 desta
etapa) — nenhuma migration, coluna ou tabela de token foi criada agora.

**Multi-tenant.** Como no contrato (10F), `lojaId` chega sempre explícito e
confiável; nenhum campo de payload externo (`loja_id`, `lojaId`,
`configuracaoId`, `provedor`) determina credencial ou número.

**Erros e segurança de log.** Nenhum `console.*` deste adaptador ou do cliente
HTTP inclui o access token, o header `Authorization`, o corpo completo da
requisição enviada ou uma URL com credencial — só status HTTP, o tipo de falha
(`timeout`/`rede`/`resposta_invalida`) e o corpo da RESPOSTA do provedor (que
nunca contém nosso próprio token), passado por `redigirSegredo` como defesa
extra. As mensagens de erro devolvidas ao restante do sistema são sempre as
fixas do contrato (10F) — nunca o texto de erro original da Meta.

**Escopo explicitamente FORA desta etapa** (adiado para etapas futuras): fluxo
completo mensagem recebida → IA → resposta; parsing do formato bruto do webhook
de eventos da Meta (`entry[].changes[].value.messages[]...` — `adaptadorMeta.js`
usa a MESMA normalização genérica do 10A/10F, delegada, não a da Meta);
histórico/memória de conversa; dashboard de WhatsApp; onboarding; cobrança;
múltiplos provedores simultâneos; automações; qualquer resposta automática a
cliente real.

**Testes:** `tests/whatsappProvedorMeta.adaptador.test.js` (offline; `fetchFn`
fake em todo cenário — nenhuma chamada de rede real). `tests/whatsappProvedor.contrato.test.js`
(10F) foi atualizado apenas onde a própria 10G o tornava desatualizado por
definição (a lista de arquivos do módulo e o registro de `'meta'` como
provedor existente); as garantias de arquitetura que continuam válidas
(contrato e adaptador simulado sem rede/log/banco/conhecimento de provedor
real) permanecem intactas e testadas.

## Mensagem do WhatsApp → atendente de IA (Etapa 10J — resposta INTERNA, sem envio)

A mensagem interna produzida pelo webhook (10C, com a loja resolvida pelo banco)
passa a alimentar a IA já existente (9A–9G). A resposta é produzida só
internamente: **nada é enviado pelo WhatsApp** nesta etapa.

```
WhatsApp Meta → webhook HTTP → HMAC (10E) → interpretador Meta (10H)
  → resolução segura da loja (10C: destinatarioId → configuração ativa → loja_id)
  → mensagem interna
  → whatsappAtendente.service.js (10J)  → ia.service.responderPergunta(lojaId, texto)
  → resposta interna { lojaId, contato, idExterno, pergunta, resposta }  (descartada pelo controller)
```

- **Arquivo novo:** `src/services/whatsappAtendente.service.js` (orquestrador fino). Toda a lógica
  de IA continua em `ia.service.js` e nos serviços que ele usa (catálogo filtrado por loja,
  produtos ativos, contexto seguro, prompt master, LLM, fallback determinístico). Não há bypass
  para o WhatsApp: a requisição ao LLM é idêntica à da rota `/ia/perguntar`.
- **`loja_id`:** vem só da mensagem interna confiável. O orquestrador lê apenas `canal`, `lojaId`,
  `contato`, `texto` e `idExterno`; ignora `loja_id`, `configuracaoId` e qualquer outro campo.
  O contato é dado do remetente e nunca decide loja, catálogo, prompt ou credencial.
- **Pergunta:** exatamente `mensagem.texto`, sem instrução acrescentada, como mensagem de usuário.
- **Erros:** falha da IA vira `ErroAtendenteWhatsapp` (mensagem fixa, sem `cause`); o controller
  responde 500 genérico. Só o tipo do erro é logado. Falha do LLM continua caindo no fallback
  determinístico existente.
- **Resposta HTTP do webhook:** continua sendo só `{ "status": "recebido" }`.
- **Fora do escopo (etapas futuras):** envio da resposta, idempotência por `idExterno`,
  persistência/histórico, fila, retry. Nenhuma migration nova.
- **Testes:** `tests/whatsappAtendente.test.js` (offline; `fetch` do LLM e Supabase falsos).

## Próximas etapas sugeridas (fora do escopo desta fundação)

1. Rodar `src/db/schema.sql` (projeto novo) ou
   `src/db/migrations/001_correcoes_auditoria.sql` (projeto já existente).
2. Rodar os testes de integração (`tests/integracao.manual.test.js`) contra
   um projeto Supabase de teste antes de ir para produção.
3. Painel administrativo (web) para o lojista cadastrar produtos/estoque
   sem precisar chamar a API manualmente.
4. Trocar a lógica de regras da IA por um modelo de linguagem real,
   mantendo a mesma garantia de nunca inventar dados (a IA só formata,
   os dados sempre vêm do banco, via `ia.helpers.js`).
5. Integração real com WhatsApp (Cloud API da Meta) — o adaptador de ENVIO já
   existe de forma isolada (Etapa 10G, `adaptadorMeta.js`), mas ainda falta:
   resolução de credencial (`accessToken`/`phoneNumberId`) por loja, parsing
   do webhook real da Meta e conectar o fluxo mensagem recebida → IA → envio.
6. Cobrança de assinatura (PIX/cartão) usando a tabela `assinaturas`.

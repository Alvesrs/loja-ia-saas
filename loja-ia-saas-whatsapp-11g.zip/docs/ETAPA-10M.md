# Etapa 10M — idempotência durável do webhook da Meta

A 10M impede que uma reentrega do mesmo evento da Meta gere duas respostas ao cliente.

## O que mudou

- Nova tabela `whatsapp_eventos_processados`, com chave primária `(provedor, id_externo)`.
- Nova migration `004_whatsapp_idempotencia.sql` para bancos existentes.
- Novo `whatsappIdempotencia.service.js` para reservar, concluir e liberar eventos.
- O controller reserva o `messages[].id` (`wamid...`) antes de chamar IA/envio.
- Evento já reservado/concluído retorna HTTP 200 com `duplicado_ignorado`, sem nova IA e sem novo envio.
- Se houver falha **antes** de o envio terminar, a reserva `processando` é removida para permitir retry legítimo da Meta.
- Se o envio já terminou e a atualização final falhar, a reserva é mantida, priorizando não duplicar a resposta.

## Privacidade e multi-instância

A tabela não guarda payload, texto, telefone, credenciais ou segredo. Só guarda provedor, id externo, estado e timestamps. A unicidade é do Postgres, então funciona com várias instâncias do backend, ao contrário de um `Set` em memória.

A tabela tem RLS habilitado e nenhuma policy para usuários finais; é operacional e acessada apenas pelo backend com `service_role`.

## Banco existente

Execute `src/db/migrations/004_whatsapp_idempotencia.sql` no SQL Editor do Supabase antes de colocar o 10M em produção. Para instalação nova, use `src/db/schema.sql` atualizado.

## Limite desta etapa

A 10M não implementa histórico de conversas, fila assíncrona ou retry programado. Esses itens permanecem para etapas posteriores.

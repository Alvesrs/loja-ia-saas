# Etapa 10R — fechamento para produção

A 10R é o checkpoint de fechamento técnico do ciclo 10K–10R. Ela não troca o modelo de dados e não cria migration 008.

## O que entrou

- versão do pacote promovida para `1.0.0`;
- validação fail-fast da configuração crítica quando `NODE_ENV=production`;
- `npm run check:producao`, que valida o ambiente sem imprimir valores secretos;
- `GET /api/health/live` para liveness;
- `GET /api/health/ready` para readiness de configuração (200 quando válida, 503 quando inválida);
- estado mínimo do worker no readiness, sem expor jobs, contatos ou credenciais;
- encerramento gracioso em `SIGTERM`/`SIGINT`, parando o worker antes de fechar o servidor HTTP;
- guia consolidado do dono em `docs/GUIA-DONO-PRODUCAO.md`.

## Variáveis obrigatórias em produção

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `META_APP_SECRET`
- `META_WHATSAPP_VERIFY_TOKEN`
- `WHATSAPP_CREDENTIALS_MASTER_KEY` (32 bytes em Base64)

O LLM não é obrigatório para o processo subir: se `LLM_PROVIDER_API_KEY` e `LLM_PROVIDER_URL` não estiverem configurados juntos, o atendente continua no fallback determinístico baseado no catálogo. Para atendimento generativo, configure ambos.

`ALLOWED_ORIGINS` pode ficar vazio se o painel for servido pelo mesmo domínio deste backend. Nesse caso, navegadores de outros domínios ficam bloqueados nas rotas autenticadas. Se houver frontend em outro domínio, configure a lista explícita de origens HTTPS.

## Banco

Projeto Supabase novo: execute `src/db/schema.sql` inteiro uma vez.

Banco de checkpoint antigo: aplique `src/db/migrations/001_correcoes_auditoria.sql` até `007_whatsapp_credenciais.sql` em ordem, somente as que ainda não foram aplicadas. A 10R não adiciona migration.

## O que a 10R não pode fazer por você

O ZIP não contém credenciais reais. A ativação final exige ações externas do dono: criar/usar projeto Supabase, hospedar o backend em HTTPS, cadastrar o webhook no app Meta, informar App Secret/Verify Token no servidor, salvar o access token de cada loja pelo painel e, se desejado, configurar um provedor LLM compatível.

A validação offline prova código, contratos e regressões. O teste ponta a ponta real Meta → webhook → Supabase → LLM/fallback → WhatsApp só pode ser feito depois dessas credenciais externas existirem.

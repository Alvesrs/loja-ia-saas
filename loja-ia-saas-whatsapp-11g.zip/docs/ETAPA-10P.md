# Etapa 10P — onboarding/configuração WhatsApp por loja

A 10P transforma a configuração técnica já existente em uma API autenticada de onboarding por tenant.

## Rotas
Todas exigem login e propriedade de `:lojaId`:

- `GET /api/lojas/:lojaId/whatsapp`
- `POST /api/lojas/:lojaId/whatsapp`
- `GET /api/lojas/:lojaId/whatsapp/:configuracaoId`
- `PATCH /api/lojas/:lojaId/whatsapp/:configuracaoId`
- `POST /api/lojas/:lojaId/whatsapp/:configuracaoId/desativar`
- `GET /api/lojas/:lojaId/whatsapp/:configuracaoId/credencial`
- `PUT /api/lojas/:lojaId/whatsapp/:configuracaoId/credencial` com `{ "access_token": "..." }`
- `DELETE /api/lojas/:lojaId/whatsapp/:configuracaoId/credencial`

O token nunca aparece em respostas. O GET de credencial retorna apenas `credencial_configurada: true|false`.

## Segredo em repouso
`whatsapp_credenciais` armazena somente ciphertext, IV e authentication tag. O backend usa AES-256-GCM e AAD ligada a `loja_id + configuracao_id + provedor`, com a chave mestra `WHATSAPP_CREDENTIALS_MASTER_KEY` (32 bytes em Base64).

A chave mestra nunca é persistida no banco. O token em texto puro existe apenas em memória durante cadastro/decifragem e é entregue diretamente ao adaptador Meta.

## Multi-tenancy
A tabela usa FK composta `(configuracao_id, loja_id) -> whatsapp_configuracoes(id, loja_id)`, todas as consultas internas filtram pelos dois IDs e as rotas passam por `exigirDonoDaLoja`.

## Envio
No fluxo real, `whatsappEnvio.service` resolve o access token por configuração e loja. `META_WHATSAPP_ACCESS_TOKEN` deixa de ser requisito do SaaS multi-tenant.

# Etapa 11G — reconciliação robusta do Asaas

A etapa 11G corrige a promoção automática de Trial para plano pago quando o Checkout recorrente do Asaas cria a assinatura e confirma o primeiro pagamento.

- `PAYMENT_CONFIRMED` / `PAYMENT_RECEIVED` agora reconciliam a cobrança por `provider_assinatura_id`, `checkoutSession`, `externalReference` e, como fallback, consultando as cobranças da assinatura no Asaas.
- Assim que a cobrança interna é localizada, o backend persiste `provider_assinatura_id` e ativa o plano contratado.
- `SUBSCRIPTION_CREATED` continua sem conceder acesso por si só; criação da recorrência não equivale a pagamento confirmado.
- A lógica permanece idempotente por `evento_id`.

# Etapa 11A — Base comercial: planos, limites e Admin SaaS

## Objetivo
Transformar a operação multiempresa já validada em uma base comercial controlável pelo dono do SaaS, sem acoplar o produto a um gateway de pagamento antes da escolha de cobrança.

## Entregas
- Catálogo técnico de planos `trial`, `basico`, `pro` e `ilimitado`.
- Limites mensais configuráveis por variáveis de ambiente.
- Trial automático para novas empresas, com validade configurável.
- Compatibilidade para lojas antigas sem assinatura (`legado`, sem interrupção).
- Bloqueio de novas respostas quando assinatura estiver inativa/expirada ou a franquia mensal tiver sido atingida.
- Finalização segura do job de WhatsApp bloqueado, sem retry infinito e sem expor cobrança ao cliente final.
- Página `Plano e uso` por empresa.
- Área `Admin SaaS` protegida por e-mail autenticado presente em `SAAS_ADMIN_EMAILS`.
- Admin pode mudar plano, status e validade de cada empresa.

## Deliberadamente fora desta etapa
- Cobrança automática, checkout, cartão, PIX, boleto, webhook financeiro e preços. A 11A deixa o núcleo pronto para integrar Mercado Pago, Stripe ou outro provedor sem reestruturar o atendimento.

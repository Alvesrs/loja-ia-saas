# Etapa 10L — webhook nativo da Meta

## Base

Checkpoint 10K aprovado. A lógica de IA, resolução multi-tenant, envio pela
Meta e demais funcionalidades anteriores foram preservadas.

## Entrega

A entrada do WhatsApp deixa de usar a autenticação HMAC genérica da etapa 10E
e passa a adotar o contrato de webhook da Meta:

- `GET /api/webhooks/whatsapp` faz o handshake com `hub.mode`,
  `hub.verify_token` e `hub.challenge`.
- `POST /api/webhooks/whatsapp` valida `X-Hub-Signature-256` sobre os bytes
  exatos do corpo recebido antes de executar o controller de mensagens.
- O segredo criptográfico do POST vem de `META_APP_SECRET`.
- O token escolhido para cadastrar/verificar a URL na Meta vem de
  `META_WHATSAPP_VERIFY_TOKEN`.
- Ausência dos segredos falha fechada; respostas não expõem token, assinatura,
  corpo do evento ou credenciais.
- Comparações sensíveis usam `crypto.timingSafeEqual`.
- O rate limiter continua antes da leitura/processamento do webhook.

## `.env.example`

Adicionados, vazios:

- `META_APP_SECRET=`
- `META_WHATSAPP_VERIFY_TOKEN=`

Removido o antigo `WHATSAPP_WEBHOOK_SECRET`, que representava apenas o formato
genérico anterior e não deve mais ser usado para autenticar eventos Meta.

## Validação

- `npm test`: 515/515 testes aprovados.
- Incluídos testes específicos do handshake GET, token incorreto, token ausente,
  challenge inválido, contrato do header Meta e fiação GET/POST.
- Testes anteriores atualizados para usar `META_APP_SECRET` e
  `X-Hub-Signature-256` sem alterar a lógica de negócio aprovada no 10K.

## Limitações preservadas

Esta etapa não adiciona histórico, persistência de mensagens, idempotência,
retry, fila, processamento assíncrono, onboarding automatizado, dashboard de
WhatsApp ou teste real contra uma conta Meta. Reentregas do mesmo webhook ainda
podem provocar resposta duplicada. Esses itens ficam para checkpoints futuros.

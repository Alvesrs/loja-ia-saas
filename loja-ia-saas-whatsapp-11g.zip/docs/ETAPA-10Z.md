# Etapa 10Z — Limite de saída do LLM

Correção para provedores com cota de tokens de saída por minuto (ex.: Groq):

- adiciona `LLM_MAX_TOKENS`, padrão 500;
- envia `max_tokens` explicitamente nas chamadas Chat Completions;
- limita configuração a no máximo 900 tokens para evitar exceder a cota de 1000 OTPM usada no ambiente de desenvolvimento;
- mantém fallback determinístico apenas para falhas reais do provedor;
- adiciona testes para o limite padrão e para o teto configurável.

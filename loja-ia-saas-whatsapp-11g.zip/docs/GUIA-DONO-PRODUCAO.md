# Guia do dono — colocar o SaaS no ar

Este é o roteiro operacional final. Faça os passos na ordem.

## 1. Banco no Supabase

1. Crie um projeto Supabase para produção.
2. No SQL Editor, para um banco novo, execute **uma única vez** `src/db/schema.sql` inteiro.
3. Guarde `Project URL` como `SUPABASE_URL` e a chave `service_role` como `SUPABASE_SERVICE_ROLE_KEY` somente no backend.
4. Nunca coloque `service_role` em HTML, JavaScript do navegador, GitHub ou mensagens para lojistas.

Se você já vinha usando um banco de um checkpoint anterior, não rode o schema por cima sem necessidade: confirme as migrations já aplicadas e execute, em ordem, apenas as faltantes de `src/db/migrations/001_...` a `007_...`.

## 2. Gere a chave mestra das credenciais de WhatsApp

Em uma máquina com Node.js, gere 32 bytes em Base64:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
```

Salve o resultado como `WHATSAPP_CREDENTIALS_MASTER_KEY` no provedor de hospedagem. Faça backup seguro: perder essa chave impede decifrar os access tokens já salvos; trocar a chave sem migração também os torna ilegíveis.

## 3. Meta / WhatsApp Cloud API

No app Meta usado pelo SaaS:

1. obtenha o **App Secret** e configure no servidor como `META_APP_SECRET`;
2. crie um Verify Token aleatório seu e configure como `META_WHATSAPP_VERIFY_TOKEN`;
3. no cadastro do webhook da Meta, use `https://SEU-DOMINIO/api/webhooks/whatsapp`;
4. use exatamente o mesmo Verify Token no painel Meta;
5. assine os eventos de mensagens necessários da conta WhatsApp Business.

O access token do número de cada loja **não vai no `.env`**. Ele é cadastrado no painel da própria loja e fica cifrado no banco.

## 4. Provedor de IA

Para usar IA generativa, configure:

- `LLM_PROVIDER_API_KEY`
- `LLM_PROVIDER_URL` (HTTPS e formato chat-completions compatível)
- `LLM_PROVIDER_MODEL`, quando o provedor exigir
- `LLM_TIMEOUT_MS`, opcional

Sem isso, o sistema continua funcional usando o fallback determinístico baseado exclusivamente no catálogo cadastrado.

## 5. Hospede o backend com HTTPS

Use um serviço Node.js que mantenha o processo web ativo e forneça HTTPS. Configuração básica:

- instalação: `npm install` (ou `npm ci` quando usar um lockfile estável);
- start: `npm start`;
- ambiente: `NODE_ENV=production`;
- healthcheck recomendado: `/api/health/ready`;
- porta: deixe o provedor definir `PORT` quando ele fizer isso automaticamente.

Cadastre no ambiente as variáveis do `.env.example`. As obrigatórias para produção são Supabase, App Secret da Meta, Verify Token e chave mestra.

Antes de publicar, rode:

```bash
npm test
npm run check:producao
```

`check:producao` encerra com código diferente de zero se faltar configuração crítica; ele não imprime os valores dos segredos.

## 6. Domínio e CORS

Aponte seu domínio para a hospedagem e deixe HTTPS ativo. Se o painel `/painel` for usado no mesmo domínio do backend, `ALLOWED_ORIGINS` pode ficar vazio. Se o frontend estiver em outro domínio, configure por exemplo:

```text
ALLOWED_ORIGINS=https://app.seudominio.com
```

Para mais de uma origem, separe por vírgulas. Não use `*` para o painel autenticado.

## 7. Crie sua conta e a primeira loja

1. Abra `https://SEU-DOMINIO/painel/login.html`.
2. Cadastre/entre com sua conta.
3. Crie a primeira loja no painel.
4. Cadastre produtos e estoque reais.
5. Abra a seção WhatsApp.
6. Cadastre o número da loja e o `Phone Number ID` da Meta.
7. Salve o access token dessa configuração. O painel limpa o campo depois do envio e nunca recupera o token em texto puro.

## 8. Teste antes de divulgar

Confira:

1. `GET /api/health/live` retorna HTTP 200;
2. `GET /api/health/ready` retorna HTTP 200;
3. login e painel funcionam pelo domínio HTTPS;
4. uma mensagem real enviada ao número do WhatsApp chega ao histórico;
5. a resposta usa apenas produtos/estoque da loja correta;
6. reenviar o mesmo evento não produz resposta duplicada;
7. desligar temporariamente o provedor de IA ainda deixa o fallback responder;
8. falha temporária de processamento entra no mecanismo de fila/retry.

## 9. Backup e operação

Mantenha em local seguro e separado do repositório: `SUPABASE_SERVICE_ROLE_KEY`, `META_APP_SECRET`, `META_WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_CREDENTIALS_MASTER_KEY` e chave do LLM. Ative backups do banco conforme o plano do seu provedor e trate a chave mestra como material de recuperação crítico.

## Resultado esperado

Depois desses passos, o produto funciona como um SaaS web: o lojista administra a loja pelo painel e o consumidor conversa pelo WhatsApp. O backend recebe eventos da Meta, identifica a configuração/loja, processa em fila, consulta o catálogo isolado do tenant, gera resposta com LLM ou fallback e envia pelo token cifrado daquela configuração.

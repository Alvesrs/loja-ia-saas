# Etapa 11E — precificação e franquias comerciais

Tabela comercial inicial definida para o SaaS:

- Trial: grátis, 100 mensagens da IA.
- Básico: R$ 99/mês, 1.000 mensagens da IA/mês.
- Pro: R$ 199/mês, 5.000 mensagens da IA/mês.
- Ilimitado: R$ 349/mês, sem franquia fixa, sujeito a política de uso justo.

A interface usa o termo **mensagens da IA** para deixar claro que o consumo é contado por mensagem de saída do atendente, e não por cliente ou conversa.

Os preços continuam configuráveis por variáveis de ambiente em centavos, permitindo alteração comercial sem mudar código.

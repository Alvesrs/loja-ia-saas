# 10S — Estoque opcional e atendimento geral

Esta atualização torna o controle de estoque opcional para o atendente.

## Comportamento

- Empresas sem estoque cadastrado continuam sendo atendidas.
- Um item sem variações de estoque não é considerado indisponível; o sistema informa apenas que o estoque/variações não são controlados.
- Serviços podem ser cadastrados como itens do catálogo sem estoque e atendidos normalmente.
- Uma empresa sem itens ativos no catálogo ainda recebe atendimento geral; o atendente não inventa nomes, preços, horários, disponibilidade ou políticas que não estejam cadastrados.
- Quando existirem variações de estoque, as regras anteriores de disponibilidade continuam valendo.

## Segurança

As regras de isolamento multi-tenant, não invenção de dados e proteção contra prompt injection foram mantidas.

## Validação

Suite automatizada: 573 testes aprovados.

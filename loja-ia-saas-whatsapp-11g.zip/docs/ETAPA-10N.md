# Etapa 10N — persistência e histórico de conversas WhatsApp

A 10N adiciona histórico durável das conversas processadas pelo webhook da Meta, sempre associado à loja e à configuração de WhatsApp que recebeu a mensagem.

## O que mudou

- Nova tabela `whatsapp_conversas`, particionada por `loja_id`, `configuracao_id` e `contato`.
- Nova tabela `whatsapp_mensagens`, com direção `entrada`/`saida`, texto, provedor, id externo opcional e timestamps.
- Nova migration `005_whatsapp_historico.sql` para bancos já existentes.
- Novo `whatsappHistorico.service.js`.
- A mensagem recebida é persistida **depois** da reserva de idempotência e antes da IA.
- A resposta é persistida somente **depois** de o envio ao WhatsApp ser confirmado.
- Reentrega de uma entrada que já foi gravada numa tentativa anterior não bloqueia retry legítimo: a unicidade do `wamid` é tratada de forma idempotente no histórico.

## Isolamento multi-tenant

O isolamento não depende apenas do código Node.js. O banco também reforça a relação entre os registros:

- `whatsapp_conversas` possui `loja_id` obrigatório.
- `(configuracao_id, loja_id)` referencia a mesma configuração da mesma loja.
- `whatsapp_mensagens` também possui `loja_id` obrigatório.
- `(conversa_id, loja_id)` referencia uma conversa da mesma loja.
- RLS está habilitado nas duas tabelas e as policies só permitem ao dono acessar registros de suas lojas.

Isso impede que uma mensagem seja ligada acidentalmente a uma conversa de outro tenant, mesmo que exista um bug em uma camada superior.

## Privacidade

O histórico guarda apenas dados funcionais necessários ao atendimento: ids internos, loja/configuração, contato, direção, texto, provedor, id externo e timestamps. Não são persistidos payload bruto da Meta, `META_APP_SECRET`, access token, API key ou outras credenciais.

## Ordem segura com idempotência

1. interpretar o webhook;
2. resolver a loja/configuração pelo número destinatário;
3. reservar o `wamid` na idempotência;
4. persistir a entrada;
5. executar a IA;
6. enviar a resposta;
7. persistir a saída;
8. concluir a idempotência.

Se ocorrer falha antes do envio, a reserva pode ser liberada para retry. Se o envio já terminou, a reserva permanece bloqueada mesmo se a gravação final falhar, evitando resposta duplicada ao cliente.

## Banco existente

Depois das migrations anteriores, execute `src/db/migrations/005_whatsapp_historico.sql` no SQL Editor do Supabase. Em instalação nova, use `src/db/schema.sql` atualizado.

## Limite desta etapa

A 10N persiste o histórico, mas ainda não cria fila assíncrona/retry programado nem telas de consulta do histórico. Esses itens ficam para checkpoints posteriores.

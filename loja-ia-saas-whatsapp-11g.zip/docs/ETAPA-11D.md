# Etapa 11D — Cobrança recorrente com Asaas

A 11D troca o provedor de cobrança principal da 11C (Mercado Pago) por Asaas sem alterar a base de planos, limites ou bloqueio de assinatura.

## Fluxo

1. O lojista escolhe um plano vendável em **Plano e uso**.
2. O backend cria um Asaas Checkout recorrente (`RECURRENT`) com cartão de crédito.
3. O navegador é redirecionado para a página hospedada pelo Asaas.
4. O backend recebe Webhooks em `/api/webhooks/asaas` e valida o header `asaas-access-token`.
5. `CHECKOUT_PAID`, `PAYMENT_CONFIRMED` e `PAYMENT_RECEIVED` ativam o plano.
6. Eventos de inativação, inadimplência, estorno ou chargeback podem suspender o acesso.
7. IDs de evento são persistidos para evitar reprocessamento de Webhooks duplicados.

## Variáveis

- `ASAAS_ENVIRONMENT=sandbox|production`
- `ASAAS_API_KEY`
- `ASAAS_WEBHOOK_AUTH_TOKEN`
- `ASAAS_TIMEOUT_MS`
- `PUBLIC_BASE_URL`
- preços por plano em centavos

Nunca exponha API Key ou token de Webhook no frontend/repositório.

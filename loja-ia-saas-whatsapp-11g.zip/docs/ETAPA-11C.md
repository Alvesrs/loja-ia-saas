# Etapa 11C — cobrança recorrente Mercado Pago

- Checkout de assinatura mensal hospedado pelo Mercado Pago via `POST /preapproval` em status `pending`.
- O backend retorna apenas `init_point`; Access Token e segredo de webhook nunca chegam ao navegador.
- Webhook público `/api/webhooks/mercadopago` valida `x-signature` com HMAC SHA-256 e `x-request-id`.
- Evento `subscription_preapproval` consulta a assinatura diretamente na API do Mercado Pago antes de alterar o SaaS.
- `authorized` ativa o plano; `paused` inativa; `cancelled` cancela, desde que o vínculo corresponda à assinatura local atual.
- Tentativas de checkout ficam em `cobrancas_assinaturas`, separadas da assinatura efetiva, para não interromper trial/plano vigente enquanto o pagamento ainda está pendente.
- Preços são definidos apenas por variáveis de ambiente em centavos; a versão não impõe preços comerciais.

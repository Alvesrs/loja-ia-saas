# Etapa 10K — envio da resposta da IA pelo WhatsApp

## Entrega

Base: arquivos da raiz de `loja-ia-saas-whatsapp-10j.zip`, cuja suíte passou
473/473 antes das alterações. O ZIP recebido continha também uma cópia
aninhada chamada `loja-ia-saas-whatsapp-10k`; essa cópia não foi usada como
base e não integra a entrega. O novo ZIP tem uma única raiz de projeto.

Fluxo: POST autenticado → parser Meta → resolução segura da loja →
whatsappAtendente → IA existente/LLM ou fallback → whatsappEnvio →
factory providers/whatsapp → adaptadorMeta → clienteHttpMeta.

## Mudanças

- Serviço `whatsappEnvio.service.js`: valida string não vazia e a correlação
  loja/contato/idExterno entre mensagem interna e resultado da IA. Busca a
  configuração por `id` E `loja_id`, verifica atividade, provedor e o mesmo
  identificador externo usado no inbound. Não escolhe configuração por contato.
- O controller delega o envio e responde somente com confirmação genérica.
  Erro de envio resulta em HTTP 502 com texto fixo, sem erro original.
- A factory existente aceita opções para configurar o adapter existente.
  Nenhuma segunda implementação HTTP da Meta foi criada.
- `phoneNumberId` vem da configuração validada. Token, versão e timeout
  continuam no adapter já existente e não são duplicados no serviço.
- O pedido interno usa o contrato existente. Somente `resposta.resposta`
  vira o corpo de texto da Meta; os IDs internos, pergunta, prompt e contexto
  não são serializados no payload de envio.
- O adapter não registra corpos de erro do provider nem mensagens de erros
  de rede. O serviço descarta message/name/stack/cause de falhas arbitrárias.
- Status continuam ignorados; eventos de campo diferente de `messages`,
  mensagens marcadas `is_echo` e envio ao próprio telefone não geram resposta.
- `.env.example` preservado, sem credenciais reais; incluída documentação
  de envio e `PORT`, que o servidor já utilizava.

## Configuração

Usar `.env.example` como referência. `META_WHATSAPP_ACCESS_TOKEN` fica apenas
no backend. Sem token o envio falha de forma controlada, sem chamar a Meta.
`META_WHATSAPP_API_VERSION` e `META_WHATSAPP_TIMEOUT_MS` mantêm os padrões
existentes quando vazios. Não há phone_number_id global: a configuração da
loja precisa estar ativa, com provedor `meta`, `identificador_externo` igual
ao ID do número Meta e `numero_whatsapp` correto.

## Verificação executada

- `npm test`: **509/509**, zero falhas, zero testes ignorados.
- `node --check`: **89 arquivos JS** de src, public e tests aprovados.
- Suíte nova: **36 testes** em `tests/whatsappEnvio.test.js`.
- Testes offline com Supabase fake e fetch fake; nenhum envio real realizado.
- Cobertura: sucesso, HMAC até envio com fallback real, LLM com HTTP fake até
  envio, destinatário, dois tenants com catálogos/números distintos, IDs
  externos forjados, configuração alterada/inativa/de outra loja, respostas
  inválidas, token ausente, HTTP 400/401/429/500, timeout com abort, erro de
  rede, resposta Meta inválida, segredo em exceções, eventos de eco/status,
  provider simulado, factory/contrato existentes e fronteira HTTP da Meta.
- As suítes antigas de inbound/IA isolam o serviço de envio com mock para
  preservar seu foco. As antigas afirmações estáticas de “nenhum envio” foram
  atualizadas para a arquitetura 10K; a suíte nova executa o adapter real
  com transporte fake, sem esse mock.
- Rota e middleware HMAC, rate limiting, limite de corpo, RLS, migrations,
  catálogo, prompt e dashboard não foram alterados funcionalmente.

## Limitações preservadas

Não há histórico, banco de mensagens, idempotência, retry, fila, processamento
assíncrono, novas migrations ou dashboard de WhatsApp. Apenas a primeira
mensagem de texto válida por payload é processada, como na base 10J.

Sem idempotência, reentregas do mesmo webhook podem gerar envios repetidos.
Uma falha após aceitação pela Meta pode deixar a entrega incerta; o sistema
não repete o envio por conta própria. HTTP 200 indica aceitação pelo fluxo,
não confirmação de leitura ou entrega ao cliente.

A autenticação preserva o contrato genérico existente: header
`X-Webhook-Signature: sha256=<HMAC>` e `WHATSAPP_WEBHOOK_SECRET` sobre o corpo
bruto. Esta entrega não adapta a assinatura nativa da Meta nem acrescenta
handshake GET, onboarding ou credenciais por tenant. Não representa validação
em produção de uma integração direta completa com a Meta.

Os testes de rota herdados usam Express fake: verificam a montagem e os
middlewares, não uma conexão HTTP real. A proteção da resposta da IA segue
os serviços já aprovados; a 10K não substitui as regras existentes do LLM.

Etapa encerrada em 10K. Nenhuma implementação de 10L incluída.

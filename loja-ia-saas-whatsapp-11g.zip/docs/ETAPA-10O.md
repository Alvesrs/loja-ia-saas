# Etapa 10O — fila persistente e retry controlado do WhatsApp

A 10O desacopla a confirmação do webhook da execução da IA e do envio à Meta. Depois de interpretar o evento, resolver a loja e reservar o `wamid`, o backend persiste um job operacional e já pode confirmar `200` ao provedor. O processamento continua pelo worker e fica recuperável após falhas/crash.

## O que mudou

- Nova tabela `whatsapp_fila_processamento` e migration `006_whatsapp_fila_retry.sql`.
- Novo `whatsappFila.service.js` para enqueue, claim, lease, conclusão e retry.
- Novo `whatsappWorker.service.js` para histórico → IA → Meta → histórico → conclusão.
- Worker periódico iniciado pelo servidor depois de `app.listen`.
- Primeiro processamento aproveita o processo receptor após o `200`, com lease já persistido; se ele cair, outro worker recupera o job quando o lease expirar.
- Claim atômico no PostgreSQL com `FOR UPDATE SKIP LOCKED`, adequado para múltiplas instâncias.
- Retry exponencial configurável, com número máximo de tentativas.

## Estados do job

- `pendente`: aguardando horário de retry.
- `processando`: pertence temporariamente a um worker (`lease_ate`).
- `enviado`: a Meta já confirmou o envio; retries seguintes só finalizam histórico/idempotência e **não reenviam**.
- `concluido`: processamento encerrado com sucesso.
- `falhou`: limite de tentativas atingido; permanece bloqueado pela idempotência para não gerar duplicidade automática.

## Segurança e multi-tenancy

A fila guarda apenas os dados internos necessários para executar o atendimento (loja/configuração, contato, texto, ids e estado operacional). Não guarda access token, App Secret, API key nem payload bruto da Meta.

O banco reforça o tenant com FK composta `(configuracao_id, loja_id)` para `whatsapp_configuracoes`. A fila tem RLS habilitado **sem policy de usuário**, pois é infraestrutura interna operada pela `service_role`. A função de claim revoga `PUBLIC` e concede execução somente a `service_role`.

## Retry e duplicidade

O `wamid` continua reservado em `whatsapp_eventos_processados` desde o webhook. Falha da IA/Meta não libera essa reserva depois que o job foi persistido: a fila passa a ser a dona dos retries, portanto reentregas da Meta são reconhecidas como duplicatas.

Quando o envio externo termina, o worker persiste `status=enviado` e a resposta usada. Se o histórico ou a conclusão da idempotência falhar depois disso, a próxima tentativa usa a resposta persistida e não chama IA/Meta outra vez.

Existe uma janela residual inevitável entre a Meta aceitar o envio e o banco conseguir gravar `status=enviado`. Uma falha exatamente nessa janela não pode garantir “exactly once” contra um sistema externo sem transação distribuída. A 10O reduz a janela e evita reenvio em todas as falhas posteriores à persistência de `enviado`.

## Variáveis opcionais

- `WHATSAPP_WORKER_INTERVALO_MS` (padrão 2000)
- `WHATSAPP_WORKER_LEASE_SEGUNDOS` (padrão 60)
- `WHATSAPP_WORKER_MAX_TENTATIVAS` (padrão 5)
- `WHATSAPP_WORKER_RETRY_BASE_MS` (padrão 5000)
- `WHATSAPP_WORKER_RETRY_MAX_MS` (padrão 300000)

Valores ausentes ou fora do intervalo seguro caem nos padrões internos.

## Banco existente

Depois da migration 005, execute `src/db/migrations/006_whatsapp_fila_retry.sql` no SQL Editor do Supabase. Em instalação nova, use `src/db/schema.sql` atualizado.

## Limite desta etapa

A 10O cria a infraestrutura operacional de fila/retry, mas ainda não traz tela de administração/reprocessamento manual de jobs falhos. Onboarding/configuração por loja e painel operacional ficam para os checkpoints seguintes.

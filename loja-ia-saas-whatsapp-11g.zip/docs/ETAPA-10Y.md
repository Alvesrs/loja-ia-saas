# Etapa 10Y — Onboarding multiempresa

A etapa 10Y transforma o painel em uma operação prática para o dono do SaaS cadastrar novos clientes/empresas sem alterar código.

## Entregas

- Nova tela `onboarding.html` para criar empresa com Prompt Mestre.
- Conexão opcional do WhatsApp Meta no mesmo fluxo (número, Phone Number ID e credencial criptografada).
- Criação de loja aceita `prompt_mestre` no mesmo POST.
- Seletor de empresa no cabeçalho para alternar entre múltiplos clientes do mesmo dono.
- A nova empresa criada passa a ser a empresa selecionada automaticamente.
- Nenhum token é persistido no navegador; ele é enviado diretamente ao endpoint seguro de credenciais existente.
- Multi-tenancy continua validada no backend pelos middlewares de autenticação e ownership.

## Fluxo recomendado

1. Abrir **Nova empresa**.
2. Informar nome e colar a Prompt Mestre preparada para o cliente.
3. Opcionalmente conectar o WhatsApp Meta.
4. Finalizar e testar o atendente.
5. Alternar entre clientes pelo seletor no cabeçalho.

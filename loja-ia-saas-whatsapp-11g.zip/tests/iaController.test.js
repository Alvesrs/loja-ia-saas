/**
 * Testes de unidade de src/controllers/ia.controller.js (endpoint público
 * do atendente).
 *
 * Cobre:
 *   - lojaId de formato inválido → 400, nunca consulta o banco;
 *   - loja inexistente ou inativa → 404 genérico (não revela se o ID
 *     existe em outra loja, nem detalhe interno);
 *   - loja válida → a resposta usa exclusivamente o catálogo DAQUELA loja
 *     (o service já filtra por loja_id — aqui confirmamos que o
 *     controller passa o lojaId correto adiante e nunca inventa produto
 *     inexistente — cenário J da auditoria).
 *
 * Usa Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * Rodar com: node --test tests/iaController.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const { perguntar } = require('../src/controllers/ia.controller');

const UUID_LOJA_A = '11111111-1111-1111-1111-111111111111';

test('lojaId com formato inválido → 400, nunca consulta o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = { params: { lojaId: 'nao-e-uuid' }, body: { pergunta: 'oi' } };
  const res = criarResMock();

  await perguntar(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('loja inexistente ou inativa → 404 genérico (nunca vaza detalhe de outra loja)', async () => {
  const fake = criarSupabaseFake({ from: { lojas: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { pergunta: 'quanto custa a camiseta?' } };
  const res = criarResMock();

  await perguntar(req, res);

  assert.equal(res.statusCode, 404);
  assert.equal(res.body.erro, 'Loja não encontrada ou inativa.');
});

test('loja inativa (existe, mas ativa=false) → 404, mesma mensagem genérica', async () => {
  const fake = criarSupabaseFake({ from: { lojas: { data: { id: UUID_LOJA_A, ativa: false }, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { pergunta: 'quanto custa a camiseta?' } };
  const res = criarResMock();

  await perguntar(req, res);

  assert.equal(res.statusCode, 404);
});

test('cenário J — loja válida, produto perguntado não existe no catálogo → não inventa, resposta padrão', async () => {
  const fake = criarSupabaseFake({
    from: {
      lojas: { data: { id: UUID_LOJA_A, ativa: true }, error: null },
      produtos: { data: [], error: null }, // catálogo real: vazio para essa pergunta
    },
  });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { pergunta: 'Vocês tem jaqueta de couro voadora?' } };
  const res = criarResMock();

  await perguntar(req, res);

  assert.equal(res.statusCode, 200);
  assert.match(res.body.resposta, /não cadastrou produtos|não encontrei esse produto/i);

  // Confirma que a busca do catálogo foi filtrada pela loja correta.
  const chamadaProdutos = fake.chamadasFrom.find((c) => c.tabela === 'produtos');
  assert.equal(chamadaProdutos.filtros.loja_id, UUID_LOJA_A);
});

test('pergunta maior que o limite de caracteres → 400, nunca consulta o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { pergunta: 'a'.repeat(501) } };
  const res = criarResMock();

  await perguntar(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasFrom.length, 0);
});

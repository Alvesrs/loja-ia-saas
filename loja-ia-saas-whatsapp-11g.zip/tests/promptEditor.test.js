const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'atendente.html'), 'utf8');
const js = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'atendente.js'), 'utf8');

test('10X) editor da Prompt Mestre oferece modelo base e expansão', () => {
  assert.match(html, /id=\"botao-modelo-prompt\"/);
  assert.match(html, /id=\"botao-expandir-prompt\"/);
  assert.match(js, /MODELO_PROMPT_BASE/);
  assert.match(js, /prompt-expandido/);
});

test('10X) editor permite Ctrl+Enter e protege alterações não salvas', () => {
  assert.match(js, /evento\.ctrlKey \|\| evento\.metaKey/);
  assert.match(js, /beforeunload/);
  assert.match(js, /promptAlterado/);
});

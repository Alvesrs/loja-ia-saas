const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const {
  reservarEventoWhatsapp,
  concluirEventoWhatsapp,
  liberarEventoWhatsapp,
  ErroIdempotenciaBanco,
  STATUS,
} = require('../src/services/whatsappIdempotencia.service');

function instalarBanco() {
  const eventos = new Map();
  const chave = (p, id) => `${p}::${id}`;
  const fake = criarSupabaseFake({
    from: {
      whatsapp_eventos_processados: (ctx) => {
        if (ctx.insertDados) {
          const d = ctx.insertDados;
          const k = chave(d.provedor, d.id_externo);
          if (eventos.has(k)) return { data: null, error: { code: '23505', message: 'duplicate' } };
          eventos.set(k, { ...d, recebido_em: '2026-09-19T00:00:00Z', processado_em: null });
          return { data: { provedor: d.provedor, id_externo: d.id_externo }, error: null };
        }
        const k = chave(ctx.filtros.provedor, ctx.filtros.id_externo);
        const atual = eventos.get(k);
        if (ctx.updateDados) {
          if (!atual) return { data: null, error: null };
          const novo = { ...atual, ...ctx.updateDados };
          eventos.set(k, novo);
          return { data: { provedor: novo.provedor, id_externo: novo.id_externo }, error: null };
        }
        if (ctx.delete) {
          if (atual && (!ctx.filtros.status || atual.status === ctx.filtros.status)) eventos.delete(k);
          return { data: null, error: null };
        }
        return { data: atual || null, error: null };
      },
    },
  });
  supabase.from = fake.from;
  return { fake, eventos };
}

const CHAVE = { provedor: ' Meta ', idExterno: ' wamid.TESTE-10M ' };

test('10M A) primeira reserva é aceita e gravada em forma canônica', async () => {
  const { eventos } = instalarBanco();
  assert.equal(await reservarEventoWhatsapp(CHAVE), true);
  const linha = eventos.get('meta::wamid.TESTE-10M');
  assert.equal(linha.status, STATUS.PROCESSANDO);
  assert.deepEqual(Object.keys(linha).sort(), ['id_externo', 'processado_em', 'provedor', 'recebido_em', 'status'].sort());
});

test('10M B) segunda reserva da mesma chave é duplicata e não lança erro', async () => {
  instalarBanco();
  assert.equal(await reservarEventoWhatsapp(CHAVE), true);
  assert.equal(await reservarEventoWhatsapp({ provedor: 'meta', idExterno: 'wamid.TESTE-10M' }), false);
});

test('10M C) ids iguais em provedores diferentes não colidem', async () => {
  instalarBanco();
  assert.equal(await reservarEventoWhatsapp({ provedor: 'meta', idExterno: 'wamid.X' }), true);
  assert.equal(await reservarEventoWhatsapp({ provedor: 'outro', idExterno: 'wamid.X' }), true);
});

test('10M D) concluir marca o evento e mantém a chave bloqueada para reentrega', async () => {
  const { eventos } = instalarBanco();
  await reservarEventoWhatsapp(CHAVE);
  await concluirEventoWhatsapp(CHAVE);
  const linha = eventos.get('meta::wamid.TESTE-10M');
  assert.equal(linha.status, STATUS.CONCLUIDO);
  assert.equal(typeof linha.processado_em, 'string');
  assert.equal(await reservarEventoWhatsapp(CHAVE), false);
});

test('10M E) liberar remove somente reserva em processamento e permite retry', async () => {
  const { eventos } = instalarBanco();
  await reservarEventoWhatsapp(CHAVE);
  await liberarEventoWhatsapp(CHAVE);
  assert.equal(eventos.size, 0);
  assert.equal(await reservarEventoWhatsapp(CHAVE), true);
});

test('10M F) liberar não apaga evento já concluído', async () => {
  const { eventos } = instalarBanco();
  await reservarEventoWhatsapp(CHAVE);
  await concluirEventoWhatsapp(CHAVE);
  await liberarEventoWhatsapp(CHAVE);
  assert.equal(eventos.get('meta::wamid.TESTE-10M').status, STATUS.CONCLUIDO);
});

test('10M G) falha de banco diferente de unique vira erro genérico, sem vazar detalhe', async () => {
  const detalhe = 'postgres.internal.local senha=SEGREDO tabela=whatsapp_eventos_processados';
  const fake = criarSupabaseFake({ from: { whatsapp_eventos_processados: { data: null, error: { code: 'XX000', message: detalhe } } } });
  supabase.from = fake.from;
  const erro = await reservarEventoWhatsapp(CHAVE).catch((e) => e);
  assert.ok(erro instanceof ErroIdempotenciaBanco);
  assert.equal(String(erro).includes('SEGREDO'), false);
  assert.equal(String(erro).includes('postgres.internal'), false);
});

test('10M H) chaves inválidas são rejeitadas antes de consultar o banco', async () => {
  const { fake } = instalarBanco();
  for (const invalida of [
    {},
    { provedor: '', idExterno: 'x' },
    { provedor: 'meta', idExterno: '' },
    { provedor: 123, idExterno: 'x' },
    { provedor: 'meta', idExterno: null },
  ]) {
    await assert.rejects(() => reservarEventoWhatsapp(invalida), TypeError);
  }
  assert.equal(fake.chamadasFrom.length, 0);
});

test('10M I) migration e schema têm PK composta, status restrito, RLS e nenhuma coluna de payload/texto/segredo', () => {
  const migration = fs.readFileSync(path.join(__dirname, '../src/db/migrations/004_whatsapp_idempotencia.sql'), 'utf8');
  const schema = fs.readFileSync(path.join(__dirname, '../src/db/schema.sql'), 'utf8');
  for (const sql of [migration, schema]) {
    assert.match(sql, /create table if not exists whatsapp_eventos_processados/i);
    assert.match(sql, /primary key\s*\(provedor,\s*id_externo\)/i);
    assert.match(sql, /status in \('processando', 'concluido'\)/i);
    assert.match(sql, /alter table whatsapp_eventos_processados enable row level security/i);
    const bloco = sql.match(/create table if not exists whatsapp_eventos_processados\s*\(([\s\S]*?)\);/i)[1];
    assert.equal(/payload|mensagem|texto|telefone|token|secret|segredo|credential|api_key/i.test(bloco), false);
  }
});

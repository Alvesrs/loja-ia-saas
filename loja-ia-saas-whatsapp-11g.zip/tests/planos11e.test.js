const test = require('node:test');
const assert = require('node:assert/strict');

test('11E mantém franquias comerciais aprovadas', () => {
  const anterior = { ...process.env };
  delete process.env.PLANO_BASICO_LIMITE_MENSAGENS;
  delete process.env.PLANO_PRO_LIMITE_MENSAGENS;
  delete require.cache[require.resolve('../src/config/planos')];
  const { PLANOS } = require('../src/config/planos');
  assert.equal(PLANOS.trial.limiteMensagensMes, 100);
  assert.equal(PLANOS.basico.limiteMensagensMes, 1000);
  assert.equal(PLANOS.pro.limiteMensagensMes, 5000);
  assert.equal(PLANOS.ilimitado.limiteMensagensMes, null);
  process.env = anterior;
});

test('11E expõe descrições comerciais e uso justo no ilimitado', () => {
  delete require.cache[require.resolve('../src/config/planos')];
  const { PLANOS } = require('../src/config/planos');
  assert.match(PLANOS.basico.descricao, /volume menor/i);
  assert.match(PLANOS.pro.descricao, /volume maior/i);
  assert.match(PLANOS.ilimitado.descricao, /uso justo/i);
});

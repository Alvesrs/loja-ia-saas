/**
 * Testes de unidade de src/controllers/pedidos.controller.js.
 *
 * Cobre os cenários da auditoria:
 *   E) usuário da Loja A tentando usar cliente da Loja B num pedido;
 *   G) pedido com quantidade inválida (zero/negativa);
 *   H) pedido com estoque insuficiente;
 *   I) tentativa de manipular o preço a partir da requisição.
 *
 * Usa Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * A função `criar_pedido` (RPC no Postgres) não roda aqui — isso já é
 * responsabilidade do teste de integração manual contra um Supabase real
 * (tests/integracao.manual.test.js). Aqui testamos a CAMADA DO CONTROLLER:
 * o que ele valida antes de chamar o RPC, e como traduz os erros que o
 * RPC pode devolver.
 *
 * Rodar com: node --test tests/pedidosController.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const { criarPedido, listarPedidos } = require('../src/controllers/pedidos.controller');

const UUID_LOJA_A = '11111111-1111-1111-1111-111111111111';
const UUID_CLIENTE_B = '33333333-3333-3333-3333-333333333333';
const UUID_ESTOQUE_1 = '44444444-4444-4444-4444-444444444444';

test('cenário E — cliente pertence a OUTRA loja → 400, RPC nunca é chamado', async () => {
  const fake = criarSupabaseFake({ from: { clientes: { data: null, error: null } } });
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { clienteId: UUID_CLIENTE_B, itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: 1 }] },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 400);
  assert.match(res.body.erro, /não pertence a esta loja/i);
  assert.equal(fake.chamadasRpc.length, 0, 'não deveria chegar a chamar criar_pedido no banco');
});

test('cenário G — quantidade zero ou negativa é rejeitada ANTES de chamar o RPC', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  for (const quantidadeInvalida of [0, -1, 1.5, 'dez']) {
    const req = {
      params: { lojaId: UUID_LOJA_A },
      body: { itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: quantidadeInvalida }] },
    };
    const res = criarResMock();

    await criarPedido(req, res);

    assert.equal(res.statusCode, 400, `quantidade ${JSON.stringify(quantidadeInvalida)} deveria ser rejeitada`);
  }
  assert.equal(fake.chamadasRpc.length, 0, 'nenhuma quantidade inválida deveria chegar ao RPC');
});

test('cenário H — RPC retorna ESTOQUE_INSUFICIENTE → controller traduz para 409', async () => {
  const fake = criarSupabaseFake({
    rpc: { criar_pedido: () => ({ data: null, error: { message: 'ESTOQUE_INSUFICIENTE' } }) },
  });
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: 999 }] },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 409);
  assert.match(res.body.erro, /estoque insuficiente/i);
});

test('cenário I — cliente tenta enviar "preco" no item do pedido: o valor é ignorado, nunca chega ao RPC', async () => {
  const fake = criarSupabaseFake({
    rpc: {
      criar_pedido: (params) => ({
        data: { id: 'pedido-1', total: 999999, itens: [] },
        error: null,
      }),
    },
  });
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: {
      // Tentativa de manipulação: o cliente envia um preço absurdamente
      // baixo junto com o item, esperando que o backend confie nele.
      itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: 1, preco: 0.01 }],
    },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 201);
  const chamadaRpc = fake.chamadasRpc[0];
  assert.ok(chamadaRpc, 'deveria ter chamado o RPC criar_pedido');
  // O item enviado ao banco deve conter APENAS estoque_id e quantidade —
  // qualquer "preco" enviado pelo cliente é descartado pelo controller;
  // o preço real vem sempre do banco (dentro do RPC, a partir do estoque).
  assert.deepEqual(chamadaRpc.params.p_itens, [{ estoque_id: UUID_ESTOQUE_1, quantidade: 1 }]);
  assert.equal('preco' in chamadaRpc.params.p_itens[0], false);
});

test('cenário C — RPC retorna ITEM_INVALIDO (estoque de OUTRA loja) → controller traduz para 400', async () => {
  const fake = criarSupabaseFake({
    rpc: { criar_pedido: () => ({ data: null, error: { message: 'ITEM_INVALIDO' } }) },
  });
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: 1 }] },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 400);
  assert.match(res.body.erro, /não pertence a esta loja/i);
});

test('cenário I/L — pedido válido: RPC é chamado com p_loja_id correto e a resposta (com total oficial do banco) é repassada como veio', async () => {
  const respostaRpc = {
    id: 'pedido-1',
    loja_id: UUID_LOJA_A,
    cliente_id: null,
    total: 139.80,
    status: 'pendente',
    itens: [{ estoque_id: UUID_ESTOQUE_1, quantidade: 2, preco_unitario: 69.90 }],
  };
  const fake = criarSupabaseFake({
    rpc: { criar_pedido: () => ({ data: respostaRpc, error: null }) },
  });
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { itens: [{ estoqueId: UUID_ESTOQUE_1, quantidade: 2 }] },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 201);
  // O pedido pertence exatamente à loja validada pelo middleware
  // (:lojaId da URL), nunca a um valor solto vindo do corpo.
  assert.equal(fake.chamadasRpc[0].params.p_loja_id, UUID_LOJA_A);
  // A resposta ao cliente é exatamente o que o banco calculou — o
  // controller não recalcula nem substitui o total.
  assert.deepEqual(res.body, respostaRpc);
});

test('listarPedidos: filtra por loja_id e repassa os dados (incluindo cliente e itens) como vieram do banco', async () => {
  const pedidosDaLoja = [
    { id: 'pedido-1', loja_id: UUID_LOJA_A, total: 50, clientes: { nome: 'Fulano' }, pedido_itens: [] },
  ];
  const fake = criarSupabaseFake({ from: { pedidos: { data: pedidosDaLoja, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A } };
  const res = criarResMock();

  await listarPedidos(req, res);

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, pedidosDaLoja);
  const chamada = fake.chamadasFrom.find((c) => c.tabela === 'pedidos');
  assert.equal(chamada.filtros.loja_id, UUID_LOJA_A);
});

test('listarPedidos: erro do banco é tratado (não vaza detalhes internos)', async () => {
  const fake = criarSupabaseFake({ from: { pedidos: { data: null, error: { message: 'timeout' } } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A } };
  const res = criarResMock();

  await listarPedidos(req, res);

  assert.equal(res.statusCode >= 400, true);
  assert.ok(res.body.erro);
});

test('itens vazios → 400, RPC nunca é chamado', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { itens: [] } };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasRpc.length, 0);
});

test('estoqueId com formato inválido (não-UUID) → 400, RPC nunca é chamado', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;
  supabase.rpc = fake.rpc;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { itens: [{ estoqueId: 'nao-e-uuid', quantidade: 1 }] },
  };
  const res = criarResMock();

  await criarPedido(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasRpc.length, 0);
});

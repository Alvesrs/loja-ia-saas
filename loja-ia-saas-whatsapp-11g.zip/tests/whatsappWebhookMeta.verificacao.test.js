const assert = require('node:assert/strict');
const { test } = require('node:test');
const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
const { instalarMockExpress } = require('./helpers/mockExpressModule');
const { criarResMock } = require('./helpers/httpMocks');
instalarMockSupabaseJs();
instalarMockExpress();

const assinatura = require('../src/services/whatsappWebhookAssinatura.service');
const { verificarWebhookMeta } = require('../src/controllers/whatsappWebhook.controller');
const rota = require('../src/routes/whatsappWebhook.routes');

function comEnv(nome, valor, fn) {
  const anterior = process.env[nome];
  if (valor === undefined) delete process.env[nome]; else process.env[nome] = valor;
  try { return fn(); } finally {
    if (anterior === undefined) delete process.env[nome]; else process.env[nome] = anterior;
  }
}

test('10L: contrato usa X-Hub-Signature-256 e META_APP_SECRET', () => {
  assert.equal(assinatura.NOME_HEADER_ASSINATURA, 'x-hub-signature-256');
  assert.equal(assinatura.NOME_VARIAVEL_SEGREDO, 'META_APP_SECRET');
  assert.equal(assinatura.NOME_VARIAVEL_VERIFY_TOKEN, 'META_WHATSAPP_VERIFY_TOKEN');
});

test('10L: handshake válido devolve exatamente hub.challenge em texto', () => {
  return comEnv('META_WHATSAPP_VERIFY_TOKEN', 'token-local-de-teste', () => {
    const req = { query: { 'hub.mode': 'subscribe', 'hub.verify_token': 'token-local-de-teste', 'hub.challenge': '123456789' } };
    const res = criarResMock();
    verificarWebhookMeta(req, res);
    assert.equal(res.statusCode, 200);
    assert.equal(res.body, '123456789');
  });
});

test('10L: token errado ou modo inválido rejeita handshake sem expor token', () => {
  return comEnv('META_WHATSAPP_VERIFY_TOKEN', 'segredo-verificacao', () => {
    for (const query of [
      { 'hub.mode': 'subscribe', 'hub.verify_token': 'errado', 'hub.challenge': '42' },
      { 'hub.mode': 'outro', 'hub.verify_token': 'segredo-verificacao', 'hub.challenge': '42' },
    ]) {
      const res = criarResMock();
      verificarWebhookMeta({ query }, res);
      assert.equal(res.statusCode, 403);
      assert.deepEqual(res.body, { erro: 'Verificação rejeitada.' });
      assert.equal(JSON.stringify(res.body).includes('segredo-verificacao'), false);
    }
  });
});

test('10L: verify token ausente no servidor falha fechado com 503', (t) => {
  t.mock.method(console, 'error', () => {});
  return comEnv('META_WHATSAPP_VERIFY_TOKEN', undefined, () => {
    const res = criarResMock();
    verificarWebhookMeta({ query: { 'hub.mode': 'subscribe', 'hub.verify_token': 'qualquer', 'hub.challenge': '42' } }, res);
    assert.equal(res.statusCode, 503);
    assert.deepEqual(res.body, { erro: 'Webhook temporariamente indisponível.' });
  });
});

test('10L: challenge vazio ou excessivo é rejeitado', () => {
  const token = 'token-local';
  for (const challenge of ['', 'x'.repeat(4097)]) {
    const r = assinatura.verificarHandshake({ modo: 'subscribe', tokenRecebido: token, challenge, tokenEsperado: token });
    assert.deepEqual(r, { ok: false, motivo: assinatura.MOTIVOS.challengeInvalido });
  }
});

test('10L: a rota contém POST de eventos e GET de handshake, ambos públicos e limitados', () => {
  const post = rota.rotas.find((r) => r.metodo === 'post');
  const get = rota.rotas.find((r) => r.metodo === 'get');
  assert.ok(post);
  assert.ok(get);
  assert.equal(post.caminho, '/');
  assert.equal(get.caminho, '/');
  assert.equal(post.handlers[0].name, 'rateLimiter');
  assert.equal(get.handlers[0].name, 'rateLimiter');
  assert.equal(get.handlers.at(-1), verificarWebhookMeta);
});

/**
 * Testes de unidade de src/controllers/clientes.controller.js — escritos
 * na Etapa 5 (Clientes V1) para validar o backend que o novo frontend de
 * Clientes passou a consumir.
 *
 * Cobre a lista de validação pedida na Etapa 5:
 *   1. listar clientes
 *   2. criar cliente válido
 *   3. validar nome (rejeitar vazio)
 *   4. validar email (rejeitar formato inválido, aceitar vazio/ausente)
 *   5. editar cliente
 *   6. excluir cliente
 *   7. busca — não se aplica aqui (é feita no frontend sobre a lista já
 *      retornada por listarClientes; ver public/js/clientes.js)
 *   9. lista vazia — não se aplica ao controller (a lista some vazia
 *      naturalmente; o estado visual "vazio" é tratado no frontend)
 *  10. erro da API — coberto indiretamente (erro de banco vira mensagem
 *      amigável, igual ao padrão de produtos)
 *  11-15. Loja A não pode listar/visualizar(editar)/editar/excluir/criar
 *      cliente da Loja B — cobertos abaixo, no mesmo padrão usado para
 *      produtos (a query .eq('id', clienteId).eq('loja_id', lojaId) não
 *      encontra nada quando o cliente é de outra loja).
 *
 * Usa Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * Rodar com: node --test tests/clientesController.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const {
  criarCliente,
  listarClientes,
  atualizarCliente,
  removerCliente,
} = require('../src/controllers/clientes.controller');

const UUID_LOJA_A = '11111111-1111-1111-1111-111111111111';
const UUID_LOJA_B = '55555555-5555-5555-5555-555555555555';
const UUID_CLIENTE_A = '33333333-3333-3333-3333-333333333333';

// --- 1) listar --------------------------------------------------------

test('1) listar clientes — devolve os clientes da loja', async () => {
  const clientesFake = [
    { id: UUID_CLIENTE_A, nome: 'Maria', telefone: '11999998888', email: 'maria@exemplo.com' },
  ];
  const fake = criarSupabaseFake({ from: { clientes: { data: clientesFake, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A } };
  const res = criarResMock();

  await listarClientes(req, res);

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, clientesFake);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

// --- 2) criar cliente válido -------------------------------------------

test('2) criar cliente válido — 201 e loja_id vem de req.params, nunca do body', async () => {
  const clienteCriado = { id: UUID_CLIENTE_A, nome: 'João', loja_id: UUID_LOJA_A };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteCriado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    // loja_id no body é uma tentativa de manipulação — o controller
    // nunca lê req.body.lojaId/loja_id, só req.params.lojaId.
    body: { nome: 'João', telefone: '11 98888-7777', loja_id: UUID_LOJA_B },
  };
  const res = criarResMock();

  await criarCliente(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(res.body.id, UUID_CLIENTE_A);
  assert.equal(
    fake.chamadasFrom[0].insertDados.loja_id,
    UUID_LOJA_A,
    'o cliente deve ser inserido na loja da URL autorizada, não na loja do body'
  );
});

test('2b) criar cliente — telefone e email são opcionais (podem ficar de fora)', async () => {
  const clienteCriado = { id: UUID_CLIENTE_A, nome: 'Ana', telefone: null, email: null };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteCriado, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: 'Ana' } };
  const res = criarResMock();

  await criarCliente(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(fake.chamadasFrom[0].insertDados.telefone, null);
  assert.equal(fake.chamadasFrom[0].insertDados.email, null);
});

// --- 3) validar nome ----------------------------------------------------

test('3) rejeitar nome vazio — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const nomeInvalido of ['', '   ', undefined, null]) {
    const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: nomeInvalido } };
    const res = criarResMock();
    await criarCliente(req, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.erro, /nome/i);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'não deveria ter tocado no banco');
});

// --- 4) validar email -----------------------------------------------------

test('4) rejeitar email em formato inválido — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const emailInvalido of ['nao-e-email', 'sem-arroba.com', 'a@b', 42]) {
    const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: 'Cliente X', email: emailInvalido } };
    const res = criarResMock();
    await criarCliente(req, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.erro, /email/i);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'não deveria ter tocado no banco');
});

test('4b) aceitar email válido, e aceitar email ausente/vazio como opcional', async () => {
  const clienteCriado = { id: UUID_CLIENTE_A, nome: 'Cliente X', email: 'cliente@exemplo.com' };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteCriado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    body: { nome: 'Cliente X', email: 'cliente@exemplo.com' },
  };
  const res = criarResMock();
  await criarCliente(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(fake.chamadasFrom[0].insertDados.email, 'cliente@exemplo.com');
});

test('4c) rejeitar telefone em formato claramente inválido — 400', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const telefoneInvalido of ['abc', '123', '11-99999-8888-extra-lixo-####']) {
    const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: 'Cliente Y', telefone: telefoneInvalido } };
    const res = criarResMock();
    await criarCliente(req, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.erro, /telefone/i);
  }
});

// --- 5) editar cliente ----------------------------------------------------

test('5) editar cliente — atualização parcial aplicada com sucesso', async () => {
  const clienteAtualizado = { id: UUID_CLIENTE_A, nome: 'Maria Silva' };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteAtualizado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A },
    body: { nome: 'Maria Silva' },
  };
  const res = criarResMock();

  await atualizarCliente(req, res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.nome, 'Maria Silva');
  assert.equal(fake.chamadasFrom[0].filtros.id, UUID_CLIENTE_A);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

test('5b) editar cliente sem enviar nenhum campo — 400', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A }, body: {} };
  const res = criarResMock();

  await atualizarCliente(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasFrom.length, 0);
});

// --- 6) excluir cliente ----------------------------------------------------

test('6) excluir cliente — 204 quando encontrado na loja certa', async () => {
  const clienteRemovido = { id: UUID_CLIENTE_A, nome: 'Maria' };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteRemovido, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A } };
  const res = criarResMock();

  await removerCliente(req, res);

  assert.equal(res.statusCode, 204);
  assert.equal(fake.chamadasFrom[0].delete, true);
  assert.equal(fake.chamadasFrom[0].filtros.id, UUID_CLIENTE_A);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

// --- 10) erro de banco vira mensagem amigável -------------------------

test('10) erro do banco ao criar cliente — mensagem amigável, sem detalhes internos', async () => {
  const erroBanco = { code: '23514', message: 'check constraint violation details internos' };
  const fake = criarSupabaseFake({ from: { clientes: { data: null, error: erroBanco } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: 'Cliente Z' } };
  const res = criarResMock();

  await criarCliente(req, res);

  assert.equal(res.statusCode, 400);
  assert.doesNotMatch(res.body.erro, /details internos/i);
});

// --- 11/12/13/14/15) isolamento entre lojas (multi-tenancy) -------------
// Nota: "listar" e "criar" de outra loja já são impedidos antes mesmo do
// controller rodar, pelo middleware exigirDonoDaLoja (:lojaId da URL
// nunca é da Loja B — ver middlewareAutorizacao.test.js). Os testes
// abaixo cobrem o que falta: um usuário da Loja A tentando visualizar
// (editar) ou excluir um clienteId que na verdade pertence à Loja B.

test('11/13) editar cliente de OUTRA loja — 404, nada é alterado', async () => {
  // O cliente existe, mas pertence à Loja B. A query
  // .eq('id', clienteId).eq('loja_id', lojaId) não encontra nada quando
  // lojaId é da Loja A, simulando o comportamento real do Postgres.
  const fake = criarSupabaseFake({ from: { clientes: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A }, // cliente na verdade é da Loja B
    body: { nome: 'Tentativa de alterar cliente alheio' },
  };
  const res = criarResMock();

  await atualizarCliente(req, res);

  assert.equal(res.statusCode, 404);
  assert.match(res.body.erro, /não encontrado/i);
});

test('14) excluir cliente de OUTRA loja — 404, nada é excluído', async () => {
  const fake = criarSupabaseFake({ from: { clientes: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A } };
  const res = criarResMock();

  await removerCliente(req, res);

  assert.equal(res.statusCode, 404);
  assert.match(res.body.erro, /não encontrado/i);
});

test('15) loja_id do body é ignorado também na edição (loja de origem continua sendo a da URL)', async () => {
  const clienteAtualizado = { id: UUID_CLIENTE_A, nome: 'Nome Novo' };
  const fake = criarSupabaseFake({ from: { clientes: { data: clienteAtualizado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, clienteId: UUID_CLIENTE_A },
    body: { nome: 'Nome Novo', loja_id: UUID_LOJA_B, lojaId: UUID_LOJA_B },
  };
  const res = criarResMock();

  await atualizarCliente(req, res);

  assert.equal(res.statusCode, 200);
  // O update nunca inclui loja_id vindo do body — só nome (campo permitido).
  assert.deepEqual(fake.chamadasFrom[0].updateDados, { nome: 'Nome Novo' });
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

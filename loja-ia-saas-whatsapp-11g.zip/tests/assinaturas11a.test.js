const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const raiz = path.join(__dirname, '..');
const ler = (rel) => fs.readFileSync(path.join(raiz, rel), 'utf8');

test('11A define catálogo técnico de planos; 11C mantém preços fora do código comercial', () => {
  const code = ler('src/config/planos.js');
  assert.match(code, /trial/);
  assert.match(code, /basico/);
  assert.match(code, /pro/);
  assert.match(code, /ilimitado/);
  assert.match(code, /PLANO_BASICO_LIMITE_MENSAGENS/);
  assert.equal(/R\$\s*\d|precoMensalCentavos:\s*\d/.test(code), false);
});

test('11A nova empresa recebe trial e rollback se trial falhar', () => {
  const code = ler('src/controllers/lojas.controller.js');
  assert.match(code, /criarTrialParaLoja\(data\.id\)/);
  assert.match(code, /\.delete\(\)/);
  assert.match(code, /Não foi possível concluir o cadastro da empresa/);
});

test('11A bloqueia IA e WhatsApp quando assinatura não permite uso', () => {
  const ia = ler('src/controllers/ia.controller.js');
  const worker = ler('src/services/whatsappWorker.service.js');
  assert.match(ia, /obterSituacaoPlano/);
  assert.match(ia, /status\(402\)/);
  assert.match(worker, /obterSituacaoPlano/);
  assert.match(worker, /bloqueado: true/);
  assert.match(worker, /concluirJob/);
});

test('11A expõe plano do lojista e Admin SaaS protegido', () => {
  const app = ler('src/app.js');
  const adminRoutes = ler('src/routes/admin.routes.js');
  const middleware = ler('src/middleware/admin.js');
  assert.match(app, /\/api\/admin/);
  assert.match(app, /assinatura/);
  assert.match(adminRoutes, /exigirAdmin/);
  assert.match(middleware, /SAAS_ADMIN_EMAILS/);
});

test('11A painel inclui páginas de plano e administração comercial', () => {
  assert.equal(fs.existsSync(path.join(raiz, 'public/plano.html')), true);
  assert.equal(fs.existsSync(path.join(raiz, 'public/admin.html')), true);
  assert.match(ler('public/js/layout.js'), /Admin SaaS/);
  assert.match(ler('public/js/plano.js'), /restanteNoMes/);
  assert.match(ler('public/js/admin.js'), /assinatura/);
});

test('11A schema inclui atualização de assinatura sem remover dados existentes', () => {
  const schema = ler('src/db/schema.sql');
  assert.match(schema, /add column if not exists atualizado_em/);
  assert.match(schema, /idx_assinaturas_loja_criado/);
});


test('11B Admin preserva visualmente plano legado e evita salvar plano acidental', () => {
  const admin = ler('public/js/admin.js');
  assert.match(admin, /sem plano comercial/);
  assert.match(admin, /if \(!plano\)/);
  assert.match(admin, /Escolha um plano comercial antes de salvar/);
});

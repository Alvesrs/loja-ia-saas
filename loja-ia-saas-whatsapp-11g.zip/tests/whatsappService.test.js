/**
 * Testes de unidade da camada de abstração de WhatsApp
 * (src/services/whatsapp.service.js).
 *
 * Etapa 10A: fundação arquitetural, SEM integração real com nenhum
 * provedor de WhatsApp. Estes testes confirmam, entre outras coisas, que
 * nenhuma chamada de rede é feita e que nenhum segredo é manipulado por
 * este service.
 *
 * Rodar com: node --test tests/whatsappService.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const http = require('node:http');
const https = require('node:https');

const {
  normalizarMensagemRecebida,
  prepararEnvioMensagem,
  identificarContato,
  identificarLoja,
  enviarMensagem,
  receberMensagem,
  ErroMensagemWhatsappInvalida,
  LIMITE_TEXTO_MENSAGEM,
} = require('../src/services/whatsapp.service');

const LOJA_ID_VALIDA = '123e4567-e89b-12d3-a456-426614174000';

// --- A. mensagem válida é normalizada corretamente ------------------------

test('normalizarMensagemRecebida: mensagem válida é normalizada corretamente', () => {
  const resultado = normalizarMensagemRecebida({
    lojaId: LOJA_ID_VALIDA,
    contato: '+55 11 91234-5678',
    texto: '  Olá, vocês têm camiseta P?  ',
    idExterno: 'wamid.ABC123',
    timestamp: '2026-09-14T12:00:00.000Z',
  });

  assert.equal(resultado.canal, 'whatsapp');
  assert.equal(resultado.lojaId, LOJA_ID_VALIDA);
  assert.equal(resultado.contato, '+55 11 91234-5678');
  assert.equal(resultado.texto, 'Olá, vocês têm camiseta P?'); // texto foi aparado (trim)
  assert.equal(resultado.idExterno, 'wamid.ABC123');
  assert.equal(resultado.timestamp, '2026-09-14T12:00:00.000Z');
});

// --- B. lojaId inválido é rejeitado ---------------------------------------

test('normalizarMensagemRecebida: rejeita lojaId inválido/ausente', () => {
  const base = { contato: '5511999999999', texto: 'Oi' };

  assert.throws(
    () => normalizarMensagemRecebida({ ...base, lojaId: 'nao-e-um-uuid' }),
    ErroMensagemWhatsappInvalida
  );
  assert.throws(
    () => normalizarMensagemRecebida({ ...base, lojaId: undefined }),
    ErroMensagemWhatsappInvalida
  );
  assert.throws(
    () => normalizarMensagemRecebida({ ...base, lojaId: 12345 }),
    ErroMensagemWhatsappInvalida
  );
});

// --- C. texto vazio é rejeitado -------------------------------------------

test('normalizarMensagemRecebida: rejeita texto vazio, só espaços, ou ausente', () => {
  const base = { lojaId: LOJA_ID_VALIDA, contato: '5511999999999' };

  assert.throws(() => normalizarMensagemRecebida({ ...base, texto: '' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, texto: '   ' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, texto: undefined }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, texto: 123 }), ErroMensagemWhatsappInvalida);
});

// --- D. texto acima do limite é rejeitado ---------------------------------

test('normalizarMensagemRecebida: rejeita texto acima do limite razoável', () => {
  const textoMuitoLongo = 'a'.repeat(LIMITE_TEXTO_MENSAGEM + 1);

  assert.throws(
    () =>
      normalizarMensagemRecebida({
        lojaId: LOJA_ID_VALIDA,
        contato: '5511999999999',
        texto: textoMuitoLongo,
      }),
    ErroMensagemWhatsappInvalida
  );

  // No limite exato ainda deve passar.
  const textoNoLimite = 'a'.repeat(LIMITE_TEXTO_MENSAGEM);
  assert.doesNotThrow(() =>
    normalizarMensagemRecebida({
      lojaId: LOJA_ID_VALIDA,
      contato: '5511999999999',
      texto: textoNoLimite,
    })
  );
});

// --- E. identificador de contato ausente é rejeitado -----------------------

test('normalizarMensagemRecebida: rejeita contato ausente/vazio', () => {
  const base = { lojaId: LOJA_ID_VALIDA, texto: 'Oi' };

  assert.throws(() => normalizarMensagemRecebida({ ...base, contato: undefined }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, contato: '' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, contato: '   ' }), ErroMensagemWhatsappInvalida);
  assert.throws(() => normalizarMensagemRecebida({ ...base, contato: 5511999999999 }), ErroMensagemWhatsappInvalida);
});

// --- F. idExterno é opcional -----------------------------------------------

test('normalizarMensagemRecebida: mensagem sem idExterno continua válida (campo opcional)', () => {
  const resultado = normalizarMensagemRecebida({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Oi, tudo bem?',
  });

  assert.equal(resultado.idExterno, null);
  assert.equal(resultado.timestamp, null);
});

test('normalizarMensagemRecebida: rejeita idExterno de tipo inválido quando fornecido', () => {
  assert.throws(
    () =>
      normalizarMensagemRecebida({
        lojaId: LOJA_ID_VALIDA,
        contato: '5511999999999',
        texto: 'Oi',
        idExterno: 12345,
      }),
    ErroMensagemWhatsappInvalida
  );
});

// --- G. nenhum request HTTP real é feito -----------------------------------

test('whatsapp.service: nenhuma chamada HTTP real é feita ao normalizar/preparar mensagens', (t) => {
  // Espiona os métodos de baixo nível usados por qualquer chamada HTTP real
  // em Node. Se alguma função deste service disparar rede, o teste falha.
  const httpSpy = t.mock.method(http, 'request', () => {
    throw new Error('http.request não deveria ter sido chamado');
  });
  const httpsSpy = t.mock.method(https, 'request', () => {
    throw new Error('https.request não deveria ter sido chamado');
  });

  normalizarMensagemRecebida({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Oi',
    idExterno: 'wamid.XYZ',
    timestamp: Date.now(),
  });

  prepararEnvioMensagem({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Resposta de teste',
  });

  assert.equal(httpSpy.mock.callCount(), 0);
  assert.equal(httpsSpy.mock.callCount(), 0);
});

test('whatsapp.service: enviarMensagem/receberMensagem são placeholders que nunca fazem rede', async (t) => {
  const httpSpy = t.mock.method(http, 'request', () => {
    throw new Error('http.request não deveria ter sido chamado');
  });
  const httpsSpy = t.mock.method(https, 'request', () => {
    throw new Error('https.request não deveria ter sido chamado');
  });

  await assert.rejects(() => enviarMensagem(), /não implementada/);
  await assert.rejects(() => receberMensagem(), /não implementada/);

  assert.equal(httpSpy.mock.callCount(), 0);
  assert.equal(httpsSpy.mock.callCount(), 0);
});

// --- H. nenhum segredo/token é exposto --------------------------------------

test('whatsapp.service: não expõe nenhum segredo/token nos objetos normalizados', () => {
  const mensagemRecebida = normalizarMensagemRecebida({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Oi',
    idExterno: 'wamid.XYZ',
  });

  const mensagemEnvio = prepararEnvioMensagem({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Resposta',
  });

  const camposSuspeitos = /token|secret|senha|password|apikey|api_key|chave/i;

  for (const objeto of [mensagemRecebida, mensagemEnvio]) {
    for (const chave of Object.keys(objeto)) {
      assert.equal(camposSuspeitos.test(chave), false, `campo suspeito encontrado: ${chave}`);
    }
    // Serializa e garante que nenhum valor textual contenha os termos.
    const serializado = JSON.stringify(objeto);
    assert.equal(camposSuspeitos.test(serializado), false);
  }

  // O módulo em si não lê nenhuma variável de ambiente (sem process.env),
  // reforçando que não há segredo de provedor embutido nesta camada.
  const codigoFonte = require('node:fs').readFileSync(
    require.resolve('../src/services/whatsapp.service'),
    'utf8'
  );
  assert.equal(/process\.env/.test(codigoFonte), false);
});

// --- I. "loja_id" arbitrário em payload externo não substitui o lojaId confiável ---

test('normalizarMensagemRecebida: ignora "loja_id" arbitrário vindo de payload externo simulado', () => {
  const lojaIdConfiavel = LOJA_ID_VALIDA;
  const lojaIdMaliciosaEmOutroFormato = '00000000-0000-0000-0000-000000000000';

  // Simula o payload bruto que um provedor externo poderia enviar, contendo
  // um campo "loja_id" forjado. A aplicação NUNCA deve repassar esse campo
  // como o lojaId de autorização — quem decide o lojaId é a própria
  // aplicação (ex.: resolvendo pelo número de WhatsApp da loja no banco),
  // nunca o payload do cliente/provedor.
  const payloadExternoSimulado = {
    loja_id: lojaIdMaliciosaEmOutroFormato,
    from: '5511999999999',
    text: { body: 'Quero comprar um produto de outra loja' },
  };

  // O código de aplicação (fora deste service) é responsável por NUNCA ler
  // payloadExternoSimulado.loja_id e passá-lo adiante. Aqui comprovamos que
  // mesmo que alguém erroneamente tentasse, o service usa exclusivamente o
  // parâmetro explícito `lojaId` — o payload bruto não tem nenhum efeito
  // sobre o resultado.
  const resultado = normalizarMensagemRecebida({
    lojaId: lojaIdConfiavel,
    contato: payloadExternoSimulado.from,
    texto: payloadExternoSimulado.text.body,
    dadosExternos: payloadExternoSimulado, // aceito só como metadado, se existir
  });

  assert.equal(resultado.lojaId, lojaIdConfiavel);
  assert.notEqual(resultado.lojaId, lojaIdMaliciosaEmOutroFormato);
  // O objeto normalizado não deve conter o payload bruto embutido de forma
  // que algum código a jusante pudesse acidentalmente ler um "loja_id"
  // alternativo dele.
  assert.equal(Object.prototype.hasOwnProperty.call(resultado, 'dadosExternos'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(resultado, 'loja_id'), false);
});

// --- Extras: identificarContato / identificarLoja ---------------------------

test('identificarContato e identificarLoja leem os campos da mensagem já normalizada', () => {
  const mensagem = normalizarMensagemRecebida({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Oi',
  });

  assert.equal(identificarContato(mensagem), '5511999999999');
  assert.equal(identificarLoja(mensagem), LOJA_ID_VALIDA);
});

test('identificarContato e identificarLoja rejeitam entrada inválida', () => {
  assert.throws(() => identificarContato(null), ErroMensagemWhatsappInvalida);
  assert.throws(() => identificarLoja(undefined), ErroMensagemWhatsappInvalida);
});

// --- Extras: prepararEnvioMensagem validações --------------------------------

test('prepararEnvioMensagem valida lojaId, contato e texto', () => {
  assert.throws(
    () => prepararEnvioMensagem({ lojaId: 'invalido', contato: '5511999999999', texto: 'Oi' }),
    ErroMensagemWhatsappInvalida
  );
  assert.throws(
    () => prepararEnvioMensagem({ lojaId: LOJA_ID_VALIDA, contato: '', texto: 'Oi' }),
    ErroMensagemWhatsappInvalida
  );
  assert.throws(
    () => prepararEnvioMensagem({ lojaId: LOJA_ID_VALIDA, contato: '5511999999999', texto: '' }),
    ErroMensagemWhatsappInvalida
  );

  const ok = prepararEnvioMensagem({
    lojaId: LOJA_ID_VALIDA,
    contato: '5511999999999',
    texto: 'Temos sim, disponível em P, M e G.',
  });
  assert.equal(ok.canal, 'whatsapp');
  assert.equal(ok.lojaId, LOJA_ID_VALIDA);
});

/**
 * Testes de unidade de src/services/autorizacao.service.js — a ÚNICA
 * barreira contra um usuário acessar/alterar dados de OUTRA loja, já que
 * o backend usa a service_role key (que ignora RLS).
 *
 * Usa um Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * Cobre os cenários B, C, D da auditoria: usuário da Loja A tentando
 * acessar produto/estoque/cliente da Loja B.
 *
 * Rodar com: node --test tests/autorizacaoService.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const {
  lojaPertenceAoUsuario,
  produtoPertenceALoja,
  clientePertenceALoja,
  buscarEstoqueDaLoja,
} = require('../src/services/autorizacao.service');

test('lojaPertenceAoUsuario: true quando a loja é do usuário, false quando é de outro usuário', async () => {
  const fake = criarSupabaseFake({
    from: {
      lojas: [{ data: { id: 'loja-A' }, error: null }, { data: null, error: null }],
    },
  });
  supabase.from = fake.from;

  assert.equal(await lojaPertenceAoUsuario('loja-A', 'usuario-A'), true);
  // Segunda chamada simula usuário B tentando a loja A: sem match.
  assert.equal(await lojaPertenceAoUsuario('loja-A', 'usuario-B'), false);
});

test('produtoPertenceALoja: nega acesso a produto de OUTRA loja (cenário B da auditoria)', async () => {
  const fake = criarSupabaseFake({
    // Simula: produto pedido pertence à loja B, mas a checagem é feita
    // com loja_id = loja A (o filtro .eq('loja_id', lojaId) no serviço
    // real garante isso — aqui simulamos o resultado desse filtro).
    from: { produtos: { data: null, error: null } },
  });
  supabase.from = fake.from;

  const resultado = await produtoPertenceALoja('produto-da-loja-B', 'loja-A');
  assert.equal(resultado, false);

  // Confirma que a checagem realmente filtrou por loja_id = 'loja-A'
  // (não bastaria o produtoId sozinho).
  const chamada = fake.chamadasFrom.find((c) => c.tabela === 'produtos');
  assert.equal(chamada.filtros.loja_id, 'loja-A');
  assert.equal(chamada.filtros.id, 'produto-da-loja-B');
});

test('produtoPertenceALoja: permite quando o produto realmente é da loja informada', async () => {
  const fake = criarSupabaseFake({
    from: { produtos: { data: { id: 'produto-1' }, error: null } },
  });
  supabase.from = fake.from;

  assert.equal(await produtoPertenceALoja('produto-1', 'loja-A'), true);
});

test('clientePertenceALoja: nega acesso a cliente de OUTRA loja (cenário D da auditoria)', async () => {
  const fake = criarSupabaseFake({
    from: { clientes: { data: null, error: null } },
  });
  supabase.from = fake.from;

  assert.equal(await clientePertenceALoja('cliente-da-loja-B', 'loja-A'), false);
});

test('buscarEstoqueDaLoja: nega quando a cadeia estoque→produto→loja não bate (cenário C da auditoria)', async () => {
  const fake = criarSupabaseFake({
    // Estoque existe, mas não pertence a esse produto/loja — o serviço
    // real filtra por estoqueId + produtoId + produtos.loja_id.
    from: { estoque: { data: null, error: null } },
  });
  supabase.from = fake.from;

  const resultado = await buscarEstoqueDaLoja('estoque-1', 'produto-da-loja-B', 'loja-A');
  assert.equal(resultado, null);

  const chamada = fake.chamadasFrom.find((c) => c.tabela === 'estoque');
  assert.equal(chamada.filtros['produtos.loja_id'], 'loja-A');
});

test('buscarEstoqueDaLoja: retorna o registro quando a cadeia completa é válida', async () => {
  const registro = { id: 'estoque-1', produto_id: 'produto-1', quantidade: 5 };
  const fake = criarSupabaseFake({
    from: { estoque: { data: registro, error: null } },
  });
  supabase.from = fake.from;

  const resultado = await buscarEstoqueDaLoja('estoque-1', 'produto-1', 'loja-A');
  assert.deepEqual(resultado, registro);
});

test('qualquer erro do banco é tratado como "não pertence" (fail-safe, nunca libera acesso por erro)', async () => {
  const fake = criarSupabaseFake({
    from: { lojas: { data: null, error: { message: 'timeout' } } },
  });
  supabase.from = fake.from;

  assert.equal(await lojaPertenceAoUsuario('loja-A', 'usuario-A'), false);
});

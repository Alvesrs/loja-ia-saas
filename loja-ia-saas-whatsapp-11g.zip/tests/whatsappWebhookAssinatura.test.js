/**
 * Testes da autenticação GENÉRICA da origem do webhook de WhatsApp (Etapa 10E):
 *   - src/services/whatsappWebhookAssinatura.service.js  (cálculo/comparação)
 *   - src/middleware/webhookAssinatura.js                (HTTP: 401/503)
 *   - integração na rota src/routes/whatsappWebhook.routes.js
 *
 * O formato testado (header X-Webhook-Signature: sha256=<hmac hex do corpo
 * bruto>) é GENÉRICO. Nenhum provedor real é usado ou simulado.
 *
 * Não abre servidor, não usa rede e não precisa do pacote "express": a rota
 * é carregada com o express falso de tests/helpers/mockExpressModule.js e a
 * cadeia de middlewares é executada em ordem, com req/res falsos. O parser
 * JSON é simulado chamando o `verify` REAL configurado na rota (é ele quem
 * grava req.corpoBruto), então o teste prova a ligação parser → assinatura.
 * (O body-parser real só roda com as dependências instaladas — ver
 * docs/ARQUITETURA.md.)
 *
 * Cenários pedidos na etapa:
 *   A) assinatura válida é aceita;
 *   B) assinatura inválida → 401;
 *   C) header ausente → 401;
 *   D) header malformado → 401;
 *   E) body alterado → 401;
 *   F) segredo ausente → 503 (nunca aceita);
 *   G) a verificação usa o body BRUTO, não JSON.stringify(req.body);
 *   H) o controller não executa quando a assinatura falha;
 *   I) comparação com crypto.timingSafeEqual;
 *   J) segredo e assinatura não aparecem em respostas (nem em logs).
 *
 * Rodar com: node --test tests/whatsappWebhookAssinatura.test.js
 */
const assert = require('node:assert/strict');
const { test, beforeEach } = require('node:test');
beforeEach((t) => t.mock.method(require('../src/services/whatsappEnvio.service'),
  'enviarRespostaWhatsapp', async () => ({ status: 'enviado' })));
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
const { instalarMockExpress } = require('./helpers/mockExpressModule');
instalarMockSupabaseJs();
instalarMockExpress();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const webhookService = require('../src/services/whatsappWebhook.service');
const { receberEvento, tratarErroDeRequisicao } = require('../src/controllers/whatsappWebhook.controller');
const { exigirLogin } = require('../src/middleware/auth');
const {
  verificarAssinatura,
  obterSegredoDoAmbiente,
  interpretarCabecalho,
  NOME_VARIAVEL_SEGREDO,
  NOME_HEADER_ASSINATURA,
  MOTIVOS,
} = require('../src/services/whatsappWebhookAssinatura.service');
const { criarVerificadorAssinatura, verificarAssinaturaWebhook } = require('../src/middleware/webhookAssinatura');

const RAIZ = path.join(__dirname, '..');
const CAMINHO_ROTA = require.resolve('../src/routes/whatsappWebhook.routes');

const SEGREDO = 'segredo-de-teste-NAO-USAR-EM-PRODUCAO-9f8e7d6c5b4a';
const RESPOSTA_401 = { erro: 'Não autorizado.' };
const RESPOSTA_503 = { erro: 'Webhook temporariamente indisponível.' };

const LOJA_A = '11111111-1111-4111-8111-111111111111';
const LOJA_B = '22222222-2222-4222-8222-222222222222';
const CFG_A = 'a1a1a1a1-a1a1-4a1a-8a1a-a1a1a1a1a1a1';
const CFG_B = 'b2b2b2b2-b2b2-4b2b-8b2b-b2b2b2b2b2b2';
const CFG_A_ANTIGA = 'c3c3c3c3-c3c3-4c3c-8c3c-c3c3c3c3c3c3';
const CONTATO = '5511988887777';

// Etapa 10I: o corpo do webhook passou a ser o payload BRUTO da Meta
// (entry[].changes[].value.messages[]), interpretado pelo
// interpretadorWebhookMeta.js (10H) antes de virar o evento genérico.
const TEXTO_MENSAGEM_VALIDA = 'Olá, tem camiseta P?';

function montarPayloadMeta({ phoneNumberId = 'phone-id-A', contato = CONTATO, texto = TEXTO_MENSAGEM_VALIDA, idExterno = 'wamid.TESTE', extra = {} } = {}) {
  return {
    entry: [
      {
        id: 'entry-id-fake',
        changes: [
          {
            field: 'messages',
            value: {
              metadata: { phone_number_id: phoneNumberId },
              messages: [{ id: idExterno, from: contato, timestamp: '1700000000', type: 'text', text: { body: texto } }],
              ...extra,
            },
          },
        ],
      },
    ],
  };
}

const EVENTO_VALIDO = montarPayloadMeta();
const CORPO_VALIDO = JSON.stringify(EVENTO_VALIDO);

// ---------------------------------------------------------------
// Utilitários de teste
// ---------------------------------------------------------------

// Implementação de REFERÊNCIA, independente do código testado.
function assinar(segredo, corpo) {
  return `sha256=${crypto.createHmac('sha256', segredo).update(corpo).digest('hex')}`;
}

// Define WHATSAPP_WEBHOOK_SECRET só durante o teste (undefined = remove).
const segredosOriginais = new WeakMap();
function usarSegredo(t, valor) {
  // Guarda o valor ORIGINAL uma única vez por teste (mesmo que o teste troque
  // o segredo várias vezes) e o restaura no fim.
  if (!segredosOriginais.has(t)) {
    segredosOriginais.set(t, process.env[NOME_VARIAVEL_SEGREDO]);
    t.after(() => {
      const original = segredosOriginais.get(t);
      if (original === undefined) delete process.env[NOME_VARIAVEL_SEGREDO];
      else process.env[NOME_VARIAVEL_SEGREDO] = original;
    });
  }
  if (valor === undefined) delete process.env[NOME_VARIAVEL_SEGREDO];
  else process.env[NOME_VARIAVEL_SEGREDO] = valor;
}

// Captura console.warn/error (o middleware só registra frases fixas + motivo).
function capturarLogs(t) {
  const linhas = [];
  t.mock.method(console, 'warn', (...args) => { linhas.push(args); });
  t.mock.method(console, 'error', (...args) => { linhas.push(args); });
  return linhas;
}

function carregarRota(ambiente = {}) {
  const chaves = ['WHATSAPP_WEBHOOK_RATE_LIMIT_MAX', 'WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS'];
  const anterior = Object.fromEntries(chaves.map((c) => [c, process.env[c]]));
  for (const c of chaves) delete process.env[c];
  Object.assign(process.env, ambiente);
  delete require.cache[CAMINHO_ROTA];
  try {
    return require(CAMINHO_ROTA);
  } finally {
    for (const c of chaves) {
      if (anterior[c] === undefined) delete process.env[c];
      else process.env[c] = anterior[c];
    }
    delete require.cache[CAMINHO_ROTA];
  }
}

const EXTRAS_SENSIVEIS = { access_token: 'EAAB-SEGREDO-DO-BANCO', api_key: 'KEY-SEGREDO', secret: 'S-SEGREDO' };
function instalarFake() {
  const linhas = [
    { id: CFG_A, loja_id: LOJA_A, provedor: 'meta', identificador_externo: 'phone-id-A', ativo: true, ...EXTRAS_SENSIVEIS },
    { id: CFG_B, loja_id: LOJA_B, provedor: 'meta', identificador_externo: 'phone-id-B', ativo: true, ...EXTRAS_SENSIVEIS },
    { id: CFG_A_ANTIGA, loja_id: LOJA_A, provedor: 'meta', identificador_externo: 'phone-id-ANTIGO', ativo: false, ...EXTRAS_SENSIVEIS },
  ];
  const fake = criarSupabaseFake({
    from: {
      whatsapp_configuracoes: (ctx) => ({
        data: linhas.filter((l) => Object.entries(ctx.filtros).every(([c, v]) => l[c] === v)).map((l) => ({ ...l })),
        error: null,
      }),
    },
  });
  supabase.from = fake.from;
  return fake;
}

// Registra o que o service devolveu/recebeu, chamando a implementação REAL.
function espiarService(t) {
  const original = webhookService.processarEventoWhatsapp;
  const registro = { chamadas: [], resultados: [] };
  t.mock.method(webhookService, 'processarEventoWhatsapp', async (...args) => {
    registro.chamadas.push(args);
    const resultado = await original(...args);
    registro.resultados.push(resultado);
    return resultado;
  });
  return registro;
}

// Simula o body-parser: chama o `verify` REAL da rota com os bytes recebidos
// (é o que grava req.corpoBruto) e depois interpreta o JSON.
function simularParserJson(parser, corpoTexto) {
  return (req, res, next) => {
    const bytes = Buffer.from(corpoTexto, 'utf8');
    parser.opcoes.verify(req, res, bytes, 'utf-8');
    try {
      req.body = JSON.parse(corpoTexto);
    } catch (erro) {
      return next(Object.assign(new SyntaxError('JSON inválido'), { type: 'entity.parse.failed', status: 400, body: corpoTexto }));
    }
    return next();
  };
}

// Executa a cadeia da rota em ordem, como o Express: um handler que responde
// sem chamar next() encerra; next(erro) vai para o tratador de erros da rota.
async function executarCadeia(handlers, req, res) {
  const executados = [];
  for (const handler of handlers) {
    let seguiu = false;
    let erro;
    executados.push(handler);
    await handler(req, res, (e) => { seguiu = true; erro = e; });
    if (erro) {
      tratarErroDeRequisicao(erro, req, res, () => {});
      return executados;
    }
    if (!seguiu) return executados;
  }
  return executados;
}

/**
 * Envia uma requisição pela cadeia REAL da rota:
 * limitador → (parser simulado) → verificação de assinatura → controller.
 */
async function enviarPelaRota({ corpo, assinatura, roteador, ip = '198.51.100.1', semParser = false, headersExtras = {} }) {
  const [limitador, parser, ...restantes] = (roteador || carregarRota()).rotas[0].handlers;
  const req = {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(assinatura === undefined ? {} : { [NOME_HEADER_ASSINATURA]: assinatura }),
      ...headersExtras,
    },
    params: {},
    query: {},
    ip,
  };
  const res = criarResMock();
  const cadeia = semParser ? [limitador, ...restantes] : [limitador, simularParserJson(parser, corpo), ...restantes];
  const executados = await executarCadeia(cadeia, req, res);
  return { req, res, executados };
}

// Middleware isolado, com req mínimo.
function passarPeloVerificador({ segredo = SEGREDO, corpoBruto, cabecalho }) {
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => segredo });
  const req = { headers: cabecalho === undefined ? {} : { [NOME_HEADER_ASSINATURA]: cabecalho }, corpoBruto };
  const res = criarResMock();
  let chamouNext = false;
  verificador(req, res, () => { chamouNext = true; });
  return { res, chamouNext };
}

function semComentarios(codigo) {
  return codigo.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`])\/\/.*$/gm, '$1');
}
function lerCodigo(arquivoRelativo) {
  return semComentarios(fs.readFileSync(path.join(RAIZ, arquivoRelativo), 'utf8'));
}

// ---------------------------------------------------------------
// A) assinatura válida
// ---------------------------------------------------------------
test('A) assinatura válida sobre {"texto":"Olá"} é aceita: a verificação chama next() e não responde', () => {
  const corpo = '{"texto":"Olá"}';
  const { res, chamouNext } = passarPeloVerificador({ corpoBruto: Buffer.from(corpo, 'utf8'), cabecalho: assinar(SEGREDO, corpo) });

  assert.equal(chamouNext, true);
  assert.equal(res.encerrada, false);
  assert.equal(res.statusCode, null);
});

test('A) o serviço confirma com ok:true e aceita dígitos hexadecimais em maiúsculas', () => {
  const corpo = Buffer.from('{"texto":"Olá"}', 'utf8');
  const minuscula = assinar(SEGREDO, corpo);
  const maiuscula = `sha256=${minuscula.slice(7).toUpperCase()}`;

  assert.deepEqual(verificarAssinatura({ segredo: SEGREDO, corpoBruto: corpo, cabecalho: minuscula }), { ok: true });
  assert.deepEqual(verificarAssinatura({ segredo: SEGREDO, corpoBruto: corpo, cabecalho: maiuscula }), { ok: true });
});

test('A) fluxo completo da rota: assinatura válida chega ao controller e o evento é aceito (200)', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  const registro = espiarService(t);

  const { res, executados } = await enviarPelaRota({ corpo: CORPO_VALIDO, assinatura: assinar(SEGREDO, CORPO_VALIDO) });

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, { status: 'recebido' });
  assert.equal(registro.chamadas.length, 1);
  assert.equal(executados.length, 4, 'limitador, parser, verificação e controller');
});

// ---------------------------------------------------------------
// B) assinatura inválida
// ---------------------------------------------------------------
test('B) assinatura incorreta → 401, sem chamar next()', () => {
  const corpo = Buffer.from(CORPO_VALIDO, 'utf8');
  const correta = assinar(SEGREDO, corpo);
  const invalidas = [
    assinar('outro-segredo-qualquer', corpo), // calculada com outro segredo
    `${correta.slice(0, -1)}${correta.endsWith('0') ? '1' : '0'}`, // um único dígito diferente
    `sha256=${'0'.repeat(64)}`,
    `sha256=${'f'.repeat(64)}`,
  ];

  for (const cabecalho of invalidas) {
    const { res, chamouNext } = passarPeloVerificador({ corpoBruto: corpo, cabecalho });
    assert.equal(res.statusCode, 401, cabecalho);
    assert.deepEqual(res.body, RESPOSTA_401);
    assert.equal(chamouNext, false);
  }
});

// ---------------------------------------------------------------
// C) header ausente
// ---------------------------------------------------------------
test('C) header ausente (ou vazio) → 401', () => {
  const corpo = Buffer.from(CORPO_VALIDO, 'utf8');
  for (const cabecalho of [undefined, '']) {
    const { res, chamouNext } = passarPeloVerificador({ corpoBruto: corpo, cabecalho });
    assert.equal(res.statusCode, 401);
    assert.deepEqual(res.body, RESPOSTA_401);
    assert.equal(chamouNext, false);
  }
  // req sem headers nenhum também não quebra nem aceita.
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => SEGREDO });
  const res = criarResMock();
  verificador({ corpoBruto: corpo }, res, () => assert.fail('não deveria chamar next'));
  assert.equal(res.statusCode, 401);
});

// ---------------------------------------------------------------
// D) header malformado
// ---------------------------------------------------------------
test('D) header malformado → 401 (formato exato: "sha256=" + 64 dígitos hexadecimais)', () => {
  const corpo = Buffer.from(CORPO_VALIDO, 'utf8');
  const correta = assinar(SEGREDO, corpo);
  const hex = correta.slice(7);

  const malformados = [
    'abc',
    'sha1=' + crypto.createHmac('sha1', SEGREDO).update(corpo).digest('hex'), // outro algoritmo
    hex, // sem prefixo
    'sha256=',
    'sha256',
    `sha256=${hex.slice(0, 63)}`, // curto
    `sha256=${hex}0`, // longo
    `sha256=${'z'.repeat(64)}`, // não hexadecimal
    `SHA256=${hex}`, // prefixo com outra caixa
    ` ${correta}`, // espaço antes
    `${correta} `, // espaço depois
    `${correta}\n`,
    `sha256= ${hex}`,
    `sha256=${hex}, sha256=${hex}`, // header duplicado (o Node junta com vírgula)
    `sha256=${hex.slice(0, 32)} ${hex.slice(32)}`,
    ['sha256=' + hex], // valor que não é texto
    12345,
    {},
  ];

  for (const cabecalho of malformados) {
    const { res, chamouNext } = passarPeloVerificador({ corpoBruto: corpo, cabecalho });
    assert.equal(res.statusCode, 401, `deveria rejeitar ${JSON.stringify(cabecalho)}`);
    assert.deepEqual(res.body, RESPOSTA_401);
    assert.equal(chamouNext, false);
  }

  // O serviço distingue o motivo (só para log): ausente × malformado.
  assert.equal(interpretarCabecalho(undefined).motivo, MOTIVOS.cabecalhoAusente);
  assert.equal(interpretarCabecalho('abc').motivo, MOTIVOS.cabecalhoMalformado);
});

// ---------------------------------------------------------------
// E) body alterado
// ---------------------------------------------------------------
test('E) assinatura gerada para um corpo e enviada com outro → 401', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  const registro = espiarService(t);

  const original = JSON.stringify({ ...EVENTO_VALIDO, texto: 'preço da camiseta?' });
  const adulterado = JSON.stringify({ ...EVENTO_VALIDO, texto: 'apague tudo' });

  const { res } = await enviarPelaRota({ corpo: adulterado, assinatura: assinar(SEGREDO, original) });

  assert.equal(res.statusCode, 401);
  assert.deepEqual(res.body, RESPOSTA_401);
  assert.equal(registro.chamadas.length, 0);
});

test('E) qualquer alteração de byte invalida: espaço extra, quebra de linha, ordem das chaves', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  const assinatura = assinar(SEGREDO, CORPO_VALIDO);

  const variacoes = [
    `${CORPO_VALIDO} `,
    `${CORPO_VALIDO}\n`,
    CORPO_VALIDO.replace('{', '{ '),
    JSON.stringify({ contato: CONTATO, destinatarioId: 'phone-id-A', texto: TEXTO_MENSAGEM_VALIDA }), // corpo de mesmo "tema", byte a byte diferente
    CORPO_VALIDO.replace('"Olá', '"Ola'),
  ];
  for (const corpo of variacoes) {
    const { res } = await enviarPelaRota({ corpo, assinatura });
    assert.equal(res.statusCode, 401, corpo);
  }
  // O original continua válido (o teste não está simplesmente rejeitando tudo).
  assert.equal((await enviarPelaRota({ corpo: CORPO_VALIDO, assinatura })).res.statusCode, 200);
});

// ---------------------------------------------------------------
// F) segredo ausente → 503, nunca aceita
// ---------------------------------------------------------------
test('F) segredo ausente/vazio/em branco → 503 genérico, mesmo com uma assinatura "correta" para esse segredo', async (t) => {
  instalarFake();
  const registro = espiarService(t);
  capturarLogs(t);

  for (const valor of [undefined, '', '   ', '\n\t']) {
    usarSegredo(t, valor);
    // Assinatura calculada com a chave que o atacante presumiria (vazia) e com o valor em branco.
    for (const assinatura of [assinar('', CORPO_VALIDO), assinar(valor ?? '', CORPO_VALIDO), assinar(SEGREDO, CORPO_VALIDO), undefined]) {
      const { res } = await enviarPelaRota({ corpo: CORPO_VALIDO, assinatura });
      assert.equal(res.statusCode, 503, `segredo ${JSON.stringify(valor)} deveria dar 503`);
      assert.deepEqual(res.body, RESPOSTA_503);
    }
  }
  assert.equal(registro.chamadas.length, 0, 'NUNCA aceita sem segredo (fail closed)');
});

test('F) a resposta 503 não revela que o problema é o segredo', async (t) => {
  usarSegredo(t, undefined);
  instalarFake();
  capturarLogs(t);

  const { res } = await enviarPelaRota({ corpo: CORPO_VALIDO, assinatura: assinar(SEGREDO, CORPO_VALIDO) });

  const exposto = JSON.stringify({ corpo: res.body, headers: res.headers });
  assert.deepEqual(res.body, { erro: 'Webhook temporariamente indisponível.' });
  assert.equal(/WHATSAPP|SECRET|segredo|secret|env|ambiente|configur/i.test(exposto), false);
});

test('F) o segredo é lido do ambiente a cada requisição (mudou → vale o novo; removido → 503)', async (t) => {
  instalarFake();
  capturarLogs(t);
  const roteador = carregarRota();
  usarSegredo(t, 'primeiro-segredo');

  const comPrimeiro = assinar('primeiro-segredo', CORPO_VALIDO);
  assert.equal((await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: comPrimeiro })).res.statusCode, 200);

  process.env[NOME_VARIAVEL_SEGREDO] = 'segundo-segredo';
  assert.equal((await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: comPrimeiro })).res.statusCode, 401);
  assert.equal((await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: assinar('segundo-segredo', CORPO_VALIDO) })).res.statusCode, 200);

  delete process.env[NOME_VARIAVEL_SEGREDO];
  assert.equal((await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: assinar('segundo-segredo', CORPO_VALIDO) })).res.statusCode, 503);
});

test('F) obterSegredoDoAmbiente: só valores utilizáveis contam, e o valor é usado sem alteração', () => {
  assert.equal(obterSegredoDoAmbiente({}), null);
  assert.equal(obterSegredoDoAmbiente({ [NOME_VARIAVEL_SEGREDO]: '' }), null);
  assert.equal(obterSegredoDoAmbiente({ [NOME_VARIAVEL_SEGREDO]: '   ' }), null);
  assert.equal(obterSegredoDoAmbiente({ [NOME_VARIAVEL_SEGREDO]: 123 }), null);
  assert.equal(obterSegredoDoAmbiente({ [NOME_VARIAVEL_SEGREDO]: ' abc ' }), ' abc ');
});

test('F) falha inesperada ao obter o segredo também é fail closed (503) e só o tipo do erro é logado', (t) => {
  const logs = capturarLogs(t);
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => { throw new Error('detalhe interno SEGREDO-VAZADO'); } });
  const res = criarResMock();
  verificador({ headers: {}, corpoBruto: Buffer.from('x') }, res, () => assert.fail('não deveria aceitar'));

  assert.equal(res.statusCode, 503);
  assert.deepEqual(res.body, RESPOSTA_503);
  assert.equal(JSON.stringify(logs).includes('SEGREDO-VAZADO'), false);
});

// ---------------------------------------------------------------
// G) a verificação usa o corpo BRUTO
// ---------------------------------------------------------------
test('G) a assinatura vale para os bytes recebidos, não para JSON.stringify(req.body)', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  // JSON válido com formatação própria: reserializar mudaria os bytes.
  const bruto = '{ "destinatarioId" : "phone-id-A",\n  "contato": "5511988887777",   "texto": "Olá" }';
  const reserializado = JSON.stringify(JSON.parse(bruto));
  assert.notEqual(bruto, reserializado);

  const sobreBruto = await enviarPelaRota({ corpo: bruto, assinatura: assinar(SEGREDO, bruto) });
  assert.equal(sobreBruto.res.statusCode, 200, 'assinatura dos bytes exatos é aceita');

  const sobreReserializado = await enviarPelaRota({ corpo: bruto, assinatura: assinar(SEGREDO, reserializado) });
  assert.equal(sobreReserializado.res.statusCode, 401, 'assinatura de JSON.stringify(req.body) NÃO é aceita');
});

test('G) o resultado depende de req.corpoBruto e não de req.body', () => {
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => SEGREDO });
  const corpoBruto = Buffer.from(CORPO_VALIDO, 'utf8');

  // corpoBruto confere com a assinatura; req.body é outra coisa qualquer → aceita.
  let passou = false;
  verificador(
    { headers: { [NOME_HEADER_ASSINATURA]: assinar(SEGREDO, corpoBruto) }, corpoBruto, body: { qualquer: 'coisa' } },
    criarResMock(),
    () => { passou = true; }
  );
  assert.equal(passou, true);

  // req.body confere com a assinatura (via JSON.stringify), mas corpoBruto é outro → recusa.
  const body = { texto: 'Olá' };
  const res = criarResMock();
  verificador(
    { headers: { [NOME_HEADER_ASSINATURA]: assinar(SEGREDO, JSON.stringify(body)) }, corpoBruto: Buffer.from('{"texto": "Olá"}', 'utf8'), body },
    res,
    () => assert.fail('não deveria aceitar')
  );
  assert.equal(res.statusCode, 401);
});

test('G) sem corpo bruto (parser não rodou, ex.: Content-Type que não é JSON) → 401, sem cair para req.body', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  const registro = espiarService(t);

  const { res } = await enviarPelaRota({
    corpo: CORPO_VALIDO,
    assinatura: assinar(SEGREDO, CORPO_VALIDO),
    semParser: true,
    headersExtras: { 'content-type': 'text/plain' },
  });
  assert.equal(res.statusCode, 401);

  // corpoBruto que não é Buffer (ex.: string) também não é aceito.
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => SEGREDO });
  for (const corpoBruto of [undefined, null, CORPO_VALIDO, { a: 1 }, []]) {
    const r = criarResMock();
    verificador({ headers: { [NOME_HEADER_ASSINATURA]: assinar(SEGREDO, CORPO_VALIDO) }, corpoBruto, body: JSON.parse(CORPO_VALIDO) }, r, () => assert.fail('não deveria aceitar'));
    assert.equal(r.statusCode, 401);
  }
  assert.equal(registro.chamadas.length, 0);
});

test('G) inspeção do código: usa req.corpoBruto e jamais JSON.stringify nem req.body', () => {
  for (const arquivo of ['src/middleware/webhookAssinatura.js', 'src/services/whatsappWebhookAssinatura.service.js']) {
    const codigo = lerCodigo(arquivo);
    assert.equal(/JSON\.stringify/.test(codigo), false, `${arquivo} não pode usar JSON.stringify`);
    assert.equal(/req\.body|\.body\b/.test(codigo), false, `${arquivo} não pode ler req.body`);
  }
  assert.match(lerCodigo('src/middleware/webhookAssinatura.js'), /req\.corpoBruto/);
  assert.match(lerCodigo('src/routes/whatsappWebhook.routes.js'), /req\.corpoBruto\s*=\s*buffer/);
});

// ---------------------------------------------------------------
// H) o controller não executa quando a assinatura falha
// ---------------------------------------------------------------
test('H) assinatura inválida/ausente/malformada, corpo alterado ou segredo ausente: o controller e o service NÃO executam', async (t) => {
  const fake = instalarFake();
  const registro = espiarService(t);
  capturarLogs(t);
  const boa = assinar(SEGREDO, CORPO_VALIDO);
  const roteador = carregarRota();
  const controller = roteador.rotas[0].handlers.at(-1);
  assert.equal(controller, receberEvento);

  const casos = [
    { nome: 'assinatura inválida', segredo: SEGREDO, assinatura: assinar('errado', CORPO_VALIDO), esperado: 401 },
    { nome: 'header ausente', segredo: SEGREDO, assinatura: undefined, esperado: 401 },
    { nome: 'header malformado', segredo: SEGREDO, assinatura: 'sha1=abc', esperado: 401 },
    { nome: 'corpo alterado', segredo: SEGREDO, assinatura: boa, corpo: `${CORPO_VALIDO} `, esperado: 401 },
    { nome: 'segredo ausente', segredo: undefined, assinatura: boa, esperado: 503 },
  ];
  for (const caso of casos) {
    usarSegredo(t, caso.segredo);
    const { res, executados } = await enviarPelaRota({ roteador, corpo: caso.corpo ?? CORPO_VALIDO, assinatura: caso.assinatura });

    assert.equal(res.statusCode, caso.esperado, caso.nome);
    assert.equal(executados.includes(controller), false, `${caso.nome}: o controller não pode ter sido chamado`);
    assert.equal(executados.at(-1), verificarAssinaturaWebhook, `${caso.nome}: a cadeia para na verificação`);
  }

  assert.equal(registro.chamadas.length, 0, 'o service do webhook não foi chamado');
  assert.equal(fake.chamadasFrom.length, 0, 'nenhuma consulta ao banco foi feita');
});

test('H) a verificação acontece DEPOIS do limitador e do parser e ANTES do controller (ordem da cadeia)', () => {
  const { handlers } = carregarRota().rotas[0];

  assert.equal(handlers.length, 4);
  assert.equal(handlers[0].name, 'rateLimiter');
  assert.equal(handlers[1].tipo, 'json');
  assert.equal(handlers[2], verificarAssinaturaWebhook);
  assert.equal(handlers[3], receberEvento);
  assert.equal(handlers.includes(exigirLogin), false, 'sem login do painel: a autenticação é a assinatura');
});

// ---------------------------------------------------------------
// I) comparação com timingSafeEqual
// ---------------------------------------------------------------
test('I) a comparação usa crypto.timingSafeEqual sobre dois Buffers de 32 bytes', (t) => {
  const original = crypto.timingSafeEqual;
  const espiao = t.mock.method(crypto, 'timingSafeEqual', (a, b) => original(a, b));
  const corpo = Buffer.from(CORPO_VALIDO, 'utf8');

  assert.equal(verificarAssinatura({ segredo: SEGREDO, corpoBruto: corpo, cabecalho: assinar(SEGREDO, corpo) }).ok, true);
  assert.equal(verificarAssinatura({ segredo: SEGREDO, corpoBruto: corpo, cabecalho: assinar('outro', corpo) }).ok, false);

  assert.equal(espiao.mock.callCount(), 2);
  for (const chamada of espiao.mock.calls) {
    const [esperada, recebida] = chamada.arguments;
    assert.equal(Buffer.isBuffer(esperada) && Buffer.isBuffer(recebida), true);
    assert.equal(esperada.length, 32);
    assert.equal(recebida.length, 32);
  }
});

test('I) se timingSafeEqual disser que difere, a requisição é recusada (a decisão vem dela)', (t) => {
  t.mock.method(crypto, 'timingSafeEqual', () => false);
  const corpo = Buffer.from(CORPO_VALIDO, 'utf8');
  const resultado = verificarAssinatura({ segredo: SEGREDO, corpoBruto: corpo, cabecalho: assinar(SEGREDO, corpo) });
  assert.deepEqual(resultado, { ok: false, motivo: MOTIVOS.assinaturaInvalida });
});

test('I) inspeção do código: sem comparação de strings/Buffers por ===, ==, .equals, Buffer.compare ou localeCompare', () => {
  const codigo = lerCodigo('src/services/whatsappWebhookAssinatura.service.js');

  assert.match(codigo, /crypto\.timingSafeEqual\(/);
  assert.equal(/\.equals\(|Buffer\.compare|localeCompare/.test(codigo), false);
  // A assinatura nunca vira string hexadecimal para ser comparada: o digest e o
  // valor recebido são comparados como Buffers.
  assert.equal(/digest\(\s*['"]hex['"]\s*\)|toString\(\s*['"]hex['"]\s*\)/.test(codigo), false);
  // As únicas comparações estritas envolvendo as assinaturas são de TAMANHO.
  for (const linha of codigo.split('\n')) {
    if (/\b(esperada|recebida)\b/.test(linha) && /(===|!==|==|!=)/.test(linha)) {
      assert.match(linha, /\.length/, `comparação suspeita: ${linha.trim()}`);
    }
  }
});

// ---------------------------------------------------------------
// J) segredo e assinatura não aparecem em respostas nem em logs
// ---------------------------------------------------------------
test('J) respostas de erro (401 e 503) nunca contêm o segredo nem a assinatura recebida/esperada', async (t) => {
  instalarFake();
  const logs = capturarLogs(t);
  const roteador = carregarRota();
  const esperadaCorreta = assinar(SEGREDO, CORPO_VALIDO);
  const recebidaErrada = assinar('chave-do-atacante', CORPO_VALIDO);

  const cenarios = [
    { segredo: SEGREDO, assinatura: recebidaErrada },
    { segredo: SEGREDO, assinatura: undefined },
    { segredo: SEGREDO, assinatura: 'sha1=abc' },
    { segredo: SEGREDO, assinatura: esperadaCorreta, corpo: `${CORPO_VALIDO} ` },
    { segredo: undefined, assinatura: recebidaErrada },
  ];
  for (const cenario of cenarios) {
    usarSegredo(t, cenario.segredo);
    const { res } = await enviarPelaRota({ roteador, corpo: cenario.corpo ?? CORPO_VALIDO, assinatura: cenario.assinatura });
    assert.ok([401, 503].includes(res.statusCode));

    const exposto = JSON.stringify({ corpo: res.body, headers: res.headers });
    for (const proibido of [SEGREDO, recebidaErrada, recebidaErrada.slice(7), esperadaCorreta, esperadaCorreta.slice(7), 'WHATSAPP_WEBHOOK_SECRET']) {
      assert.equal(exposto.includes(proibido), false, `resposta não pode conter "${proibido.slice(0, 12)}…"`);
    }
  }
  assert.ok(logs.length > 0, 'as falhas foram registradas em log');
});

test('J) o log de falha é uma frase fixa com motivo categórico: sem segredo, assinatura, corpo, mensagem nem contato', async (t) => {
  instalarFake();
  const logs = capturarLogs(t);
  const roteador = carregarRota();
  usarSegredo(t, SEGREDO);

  const recebida = assinar('chave-do-atacante', CORPO_VALIDO);
  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: recebida });
  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: undefined });
  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: 'abc' });

  const logado = logs.map((args) => args.join(' '));
  assert.equal(logado.length, 3);
  assert.match(logado[0], /Falha na verificação de assinatura \(motivo: assinatura_invalida\)/);
  assert.match(logado[1], /motivo: cabecalho_ausente/);
  assert.match(logado[2], /motivo: cabecalho_malformado/);

  const tudo = logado.join('\n');
  for (const proibido of [SEGREDO, recebida, recebida.slice(7), 'chave-do-atacante', CONTATO, TEXTO_MENSAGEM_VALIDA, 'phone_number_id', CORPO_VALIDO]) {
    assert.equal(tudo.includes(proibido), false, `log não pode conter "${proibido.slice(0, 14)}…"`);
  }
});

test('J) segredo ausente: o servidor avisa UMA vez nos logs (com o nome da variável, nunca valores) e não inunda o log', (t) => {
  const logs = capturarLogs(t);
  let segredo = null;
  const verificador = criarVerificadorAssinatura({ obterSegredo: () => segredo });
  const chamar = () => {
    const res = criarResMock();
    verificador({ headers: { [NOME_HEADER_ASSINATURA]: assinar(SEGREDO, 'x') }, corpoBruto: Buffer.from('x') }, res, () => assert.fail('não deveria aceitar'));
    return res;
  };

  assert.equal(chamar().statusCode, 503);
  assert.equal(chamar().statusCode, 503);
  assert.equal(chamar().statusCode, 503);
  assert.equal(logs.length, 1, 'aviso emitido uma única vez enquanto o segredo estiver ausente');
  assert.match(logs[0].join(' '), /META_APP_SECRET/);
  assert.equal(logs[0].join(' ').includes(SEGREDO), false);

  // Voltou o segredo e sumiu de novo → avisa de novo.
  segredo = SEGREDO;
  const res = criarResMock();
  verificador({ headers: { [NOME_HEADER_ASSINATURA]: assinar(SEGREDO, 'x') }, corpoBruto: Buffer.from('x') }, res, () => {});
  segredo = null;
  assert.equal(chamar().statusCode, 503);
  assert.equal(logs.length, 2);
});

// ---------------------------------------------------------------
// Compatibilidade com os comportamentos aprovados na 10D
// ---------------------------------------------------------------
test('10D compat) com assinatura válida, loja_id/lojaId/configuracaoId/provedor do payload continuam ignorados: a loja vem da configuração', async (t) => {
  usarSegredo(t, SEGREDO);
  const fake = instalarFake();
  const registro = espiarService(t);
  const payload = montarPayloadMeta({
    extra: { loja_id: LOJA_B, lojaId: LOJA_B, configuracaoId: CFG_B, provedor: 'provedor-forjado' },
  });
  const corpo = JSON.stringify(payload);

  const { res } = await enviarPelaRota({ corpo, assinatura: assinar(SEGREDO, corpo) });

  assert.equal(res.statusCode, 200);
  assert.equal(registro.resultados[0].lojaId, LOJA_A);
  assert.equal(registro.resultados[0].configuracaoId, CFG_A);
  const enviado = JSON.stringify(registro.chamadas) + JSON.stringify(fake.chamadasFrom);
  for (const proibido of [LOJA_B, CFG_B, 'provedor-forjado']) assert.equal(enviado.includes(proibido), false);
  assert.deepEqual(res.body, { status: 'recebido' });
});

test('10D compat) autenticação não substitui as demais regras: config inexistente/desativada → 404; mensagem inválida → 400', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  capturarLogs(t);
  const roteador = carregarRota();
  const enviar = async (payload) => {
    const corpo = JSON.stringify(payload);
    return (await enviarPelaRota({ roteador, corpo, assinatura: assinar(SEGREDO, corpo) })).res;
  };

  assert.deepEqual((await enviar(montarPayloadMeta({ phoneNumberId: 'phone-id-NAO-EXISTE' }))).statusCode, 404);
  assert.deepEqual((await enviar(montarPayloadMeta({ phoneNumberId: 'phone-id-ANTIGO' }))).statusCode, 404);
  assert.deepEqual((await enviar(montarPayloadMeta({ texto: '' }))).statusCode, 400);
  assert.deepEqual((await enviar({ entry: [{ changes: [{ value: { messages: [{}] } }] }] })).statusCode, 400); // mensagem sem id/from/destinatário, autenticada mas incompleta
});

test('10D compat) o rate limiter continua PRIMEIRO: requisições sem assinatura válida também contam e o excesso vira 429', async (t) => {
  usarSegredo(t, SEGREDO);
  const fake = instalarFake();
  capturarLogs(t);
  const roteador = carregarRota({ WHATSAPP_WEBHOOK_RATE_LIMIT_MAX: '2', WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS: '60000' });

  const semAssinatura = () => enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: undefined, ip: '203.0.113.77' });
  assert.equal((await semAssinatura()).res.statusCode, 401);
  assert.equal((await semAssinatura()).res.statusCode, 401);
  const terceira = await semAssinatura();
  assert.equal(terceira.res.statusCode, 429);
  assert.equal(terceira.executados.length, 1, 'barrada no limitador, antes do parser e da verificação');

  // Nem uma assinatura válida fura o limite.
  const valida = await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: assinar(SEGREDO, CORPO_VALIDO), ip: '203.0.113.77' });
  assert.equal(valida.res.statusCode, 429);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('10D compat) o limite de corpo (100kb) e a preservação do corpo bruto continuam configurados; JSON quebrado ainda dá 400 antes da verificação', async (t) => {
  usarSegredo(t, SEGREDO);
  instalarFake();
  const roteador = carregarRota();
  const parser = roteador.rotas[0].handlers[1];

  assert.equal(parser.opcoes.limit, '100kb');
  const req = {};
  const bruto = Buffer.from('{"a":1}');
  parser.opcoes.verify(req, {}, bruto);
  assert.equal(req.corpoBruto, bruto);

  const quebrado = '{quebrado';
  const { res, executados } = await enviarPelaRota({ roteador, corpo: quebrado, assinatura: assinar(SEGREDO, quebrado) });
  assert.equal(res.statusCode, 400);
  assert.deepEqual(res.body, { erro: 'Corpo da requisição inválido.' });
  assert.equal(executados.includes(verificarAssinaturaWebhook), false, 'o parser falhou antes; nada foi interpretado nem verificado');
});

// ---------------------------------------------------------------
// Sem rede, sem LLM, sem segredo versionado
// ---------------------------------------------------------------
test('nenhuma chamada HTTP externa nem LLM durante a verificação (sucesso e falha)', async (t) => {
  const espioes = [
    t.mock.method(http, 'request', () => { throw new Error('http.request não deveria ser chamado'); }),
    t.mock.method(http, 'get', () => { throw new Error('http.get não deveria ser chamado'); }),
    t.mock.method(https, 'request', () => { throw new Error('https.request não deveria ser chamado'); }),
    t.mock.method(https, 'get', () => { throw new Error('https.get não deveria ser chamado'); }),
    t.mock.method(globalThis, 'fetch', () => { throw new Error('fetch não deveria ser chamado'); }),
  ];
  const llm = require('../src/services/llm.service');
  const gerarResposta = t.mock.method(llm, 'gerarResposta', async () => { throw new Error('LLM não deveria ser chamado'); });
  usarSegredo(t, SEGREDO);
  instalarFake();
  capturarLogs(t);
  const roteador = carregarRota();

  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: assinar(SEGREDO, CORPO_VALIDO) });
  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: 'abc' });
  usarSegredo(t, undefined);
  await enviarPelaRota({ roteador, corpo: CORPO_VALIDO, assinatura: assinar(SEGREDO, CORPO_VALIDO) });

  for (const espiao of espioes) assert.equal(espiao.mock.callCount(), 0);
  assert.equal(gerarResposta.mock.callCount(), 0);
});

test('estático) a verificação só depende de node:crypto: sem rede, provedor, URL, banco nem outras variáveis de ambiente', () => {
  const servico = lerCodigo('src/services/whatsappWebhookAssinatura.service.js');
  const middleware = lerCodigo('src/middleware/webhookAssinatura.js');

  const dependencias = (codigo) => [...codigo.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]).sort();
  assert.deepEqual(dependencias(servico), ['node:crypto']);
  assert.deepEqual(dependencias(middleware), ['../services/whatsappWebhookAssinatura.service']);

  for (const codigo of [servico, middleware]) {
    assert.equal(/\bfetch\s*\(|https?:\/\/|XMLHttpRequest|axios|supabase/i.test(codigo), false);
    assert.equal(/twilio|z-?api|evolution|graph\.facebook/i.test(codigo), false, 'sem rede nem outros provedores');
  }
  assert.match(servico, /x-hub-signature-256/i, '10L usa o header nativo da Meta');
  assert.match(servico, /META_APP_SECRET/, '10L usa o App Secret da Meta');
  // O segredo só é lido pelo nome definido em uma constante; nenhuma outra env.
  assert.equal(/process\.env\.[A-Z_]+/.test(servico + middleware), false, 'sem process.env.X direto: o serviço lê env[NOME_VARIAVEL_SEGREDO]');
  assert.match(servico, /lerVariavelNaoVazia\(NOME_VARIAVEL_SEGREDO, env\)/);
});

test('estático) nenhum console.* da verificação registra segredo, assinatura, corpo ou cabeçalho (só frases fixas e o motivo)', () => {
  const codigo = lerCodigo('src/middleware/webhookAssinatura.js');
  const chamadas = [...codigo.matchAll(/console\.(?:log|info|warn|error|debug)\(([\s\S]*?)\);/g)].map((m) => m[1]);
  assert.equal(chamadas.length, 3, 'segredo ausente, falha de assinatura e erro inesperado');

  for (const argumentos of chamadas) {
    // Remove o TEXTO das strings (frases fixas) e mantém só o que é código:
    // as expressões dentro de ${...} e os argumentos que não são literais.
    const soCodigo = argumentos
      .replace(/'[^']*'/g, "''")
      .replace(/"[^"]*"/g, '""')
      .replace(/`([^`]*)`/g, (_, conteudo) => `\`${[...conteudo.matchAll(/\$\{([^}]*)\}/g)].map((x) => x[1]).join(' ')}\``);
    assert.equal(/\b(segredo|assinatura|cabecalho|corpoBruto|req|body|headers)\b/.test(soCodigo), false, `log suspeito: ${soCodigo.trim()}`);
  }
});

test('o segredo não está versionado: .env.example só declara a variável em branco e nada no código a define', () => {
  const exemplo = fs.readFileSync(path.join(RAIZ, '.env.example'), 'utf8');
  const linhas = exemplo.split('\n').filter((l) => l.startsWith(`${NOME_VARIAVEL_SEGREDO}=`));
  assert.deepEqual(linhas, [`${NOME_VARIAVEL_SEGREDO}=`], 'valor deve ficar em branco no arquivo de exemplo');

  // Nenhum arquivo do projeto (fora testes/docs) atribui valor à variável ou a guarda em banco.
  const pastas = ['src', 'public'];
  const encontrados = [];
  const percorrer = (dir) => {
    for (const nome of fs.readdirSync(dir)) {
      const caminho = path.join(dir, nome);
      if (fs.statSync(caminho).isDirectory()) percorrer(caminho);
      else if (/\.(js|sql|html|css|json)$/.test(nome) && semComentarios(fs.readFileSync(caminho, 'utf8')).includes(NOME_VARIAVEL_SEGREDO)) {
        encontrados.push(path.relative(RAIZ, caminho));
      }
    }
  };
  for (const pasta of pastas) percorrer(path.join(RAIZ, pasta));

  // O serviço define/usa a variável; desde a 10R o validador de produção também
  // conhece apenas o NOME da variável para garantir fail-fast. Nenhum deles contém o valor.
  assert.deepEqual(encontrados.sort(), [
    'src/config/producao.js',
    'src/services/whatsappWebhookAssinatura.service.js',
  ]);
  assert.equal(/WHATSAPP_WEBHOOK_SECRET\s*=\s*['"`]?[A-Za-z0-9]/.test(lerCodigo('src/services/whatsappWebhookAssinatura.service.js')), false);
});

/**
 * Testes de unidade de src/controllers/produtos.controller.js — escritos
 * na Etapa 3 (Produtos V1) para validar o backend que o novo frontend de
 * Produtos passou a consumir. Não altera o controller: só o exercita.
 *
 * Cobre a lista de validação pedida na Etapa 3:
 *   1. listar produtos
 *   2. criar produto válido
 *   3. rejeitar nome vazio
 *   4. rejeitar preço negativo
 *   5. editar produto
 *   6. ativar/desativar (via PATCH ativo)
 *   7. excluir produto
 *   8. tratar "produto não encontrado" (equivalente ao estado vazio/erro no front)
 *   11. produto de uma loja não pode ser alterado/excluído por outra loja
 *   12. loja_id não pode ser manipulado pelo frontend para burlar autorização
 *       (o controller sempre usa req.params.lojaId, nunca um campo do body)
 *
 * Usa Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * Rodar com: node --test tests/produtosController.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const {
  criarProduto,
  listarProdutos,
  atualizarProduto,
  removerProduto,
} = require('../src/controllers/produtos.controller');

const UUID_LOJA_A = '11111111-1111-1111-1111-111111111111';
const UUID_LOJA_B = '55555555-5555-5555-5555-555555555555';
const UUID_PRODUTO_A = '22222222-2222-2222-2222-222222222222';

// Nota: nestes testes de controller, a checagem "a loja pertence ao
// usuário" já foi feita pelo middleware exigirDonoDaLoja ANTES do
// controller rodar (ver routes/produtos.routes.js e
// middlewareAutorizacao.test.js, que cobre esse middleware). Aqui
// testamos a camada seguinte: o que o controller faz com :lojaId já
// validado, incluindo a proteção extra por query (.eq('loja_id', ...))
// que impede alterar/excluir produto de outra loja mesmo que alguém
// adivinhe um produtoId.

test('1) listar produtos — devolve os produtos da loja', async () => {
  const produtosFake = [
    { id: UUID_PRODUTO_A, nome: 'Camiseta', preco: '39.90', ativo: true, estoque: [] },
  ];
  const fake = criarSupabaseFake({ from: { produtos: { data: produtosFake, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A } };
  const res = criarResMock();

  await listarProdutos(req, res);

  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, produtosFake);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

test('2) criar produto válido — 201 e loja_id vem de req.params, nunca do body', async () => {
  const produtoCriado = { id: UUID_PRODUTO_A, nome: 'Vestido Floral', preco: 129.9, loja_id: UUID_LOJA_A };
  const fake = criarSupabaseFake({ from: { produtos: { data: produtoCriado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A },
    // loja_id no body é uma tentativa de manipulação — o controller
    // nunca lê req.body.lojaId/loja_id, só req.params.lojaId.
    body: { nome: 'Vestido Floral', preco: 129.9, loja_id: UUID_LOJA_B },
  };
  const res = criarResMock();

  await criarProduto(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(res.body.id, UUID_PRODUTO_A);
  assert.equal(
    fake.chamadasFrom[0].insertDados.loja_id,
    UUID_LOJA_A,
    'o produto deve ser inserido na loja da URL autorizada, não na loja do body'
  );
});

test('3) rejeitar nome vazio — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const nomeInvalido of ['', '   ', undefined, null]) {
    const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: nomeInvalido, preco: 10 } };
    const res = criarResMock();
    await criarProduto(req, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.erro, /nome/i);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'não deveria ter tocado no banco');
});

test('4) rejeitar preço negativo (e não numérico) — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const precoInvalido of [-1, -0.01, 'dez', undefined, null, NaN]) {
    const req = { params: { lojaId: UUID_LOJA_A }, body: { nome: 'Produto X', preco: precoInvalido } };
    const res = criarResMock();
    await criarProduto(req, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.erro, /preço/i);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'não deveria ter tocado no banco');
});

test('5) editar produto — atualização parcial aplicada com sucesso', async () => {
  const produtoAtualizado = { id: UUID_PRODUTO_A, nome: 'Camiseta Premium', preco: 59.9 };
  const fake = criarSupabaseFake({ from: { produtos: { data: produtoAtualizado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { nome: 'Camiseta Premium', preco: 59.9 },
  };
  const res = criarResMock();

  await atualizarProduto(req, res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.nome, 'Camiseta Premium');
  assert.equal(fake.chamadasFrom[0].filtros.id, UUID_PRODUTO_A);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

test('6) ativar/desativar — PATCH com { ativo } muda só esse campo', async () => {
  const produtoDesativado = { id: UUID_PRODUTO_A, nome: 'Camiseta', ativo: false };
  const fake = criarSupabaseFake({ from: { produtos: { data: produtoDesativado, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A }, body: { ativo: false } };
  const res = criarResMock();

  await atualizarProduto(req, res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.ativo, false);
  assert.deepEqual(fake.chamadasFrom[0].updateDados, { ativo: false });
});

test('6b) ativar/desativar — valor não booleano é rejeitado', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A }, body: { ativo: 'sim' } };
  const res = criarResMock();

  await atualizarProduto(req, res);

  assert.equal(res.statusCode, 400);
  assert.match(res.body.erro, /ativo/i);
});

test('7) excluir produto — 204 quando encontrado na loja certa', async () => {
  const produtoRemovido = { id: UUID_PRODUTO_A, nome: 'Camiseta' };
  const fake = criarSupabaseFake({ from: { produtos: { data: produtoRemovido, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A } };
  const res = criarResMock();

  await removerProduto(req, res);

  assert.equal(res.statusCode, 204);
  assert.equal(fake.chamadasFrom[0].delete, true);
  assert.equal(fake.chamadasFrom[0].filtros.id, UUID_PRODUTO_A);
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

test('8) excluir produto com pedidos/estoque vinculado — erro de banco vira mensagem amigável', async () => {
  const erroFk = { code: '23503', message: 'foreign key violation' };
  const fake = criarSupabaseFake({ from: { produtos: { data: null, error: erroFk } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A } };
  const res = criarResMock();

  await removerProduto(req, res);

  assert.equal(res.statusCode, 400);
  assert.match(res.body.erro, /referência inválida/i);
});

test('11) editar produto de OUTRA loja — 404, nada é alterado', async () => {
  // O produto existe, mas pertence à Loja B. A query
  // .eq('id', produtoId).eq('loja_id', lojaId) não encontra nada quando
  // lojaId é da Loja A, simulando o comportamento real do Postgres.
  const fake = criarSupabaseFake({ from: { produtos: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A }, // produto na verdade é da Loja B
    body: { nome: 'Tentativa de alterar produto alheio' },
  };
  const res = criarResMock();

  await atualizarProduto(req, res);

  assert.equal(res.statusCode, 404);
  assert.match(res.body.erro, /não encontrado/i);
});

test('11b) excluir produto de OUTRA loja — 404, nada é excluído', async () => {
  const fake = criarSupabaseFake({ from: { produtos: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A } };
  const res = criarResMock();

  await removerProduto(req, res);

  assert.equal(res.statusCode, 404);
  assert.match(res.body.erro, /não encontrado/i);
});

test('12) loja_id do body é ignorado também na edição (loja de origem continua sendo a da URL)', async () => {
  const produtoAtualizado = { id: UUID_PRODUTO_A, nome: 'Nome Novo' };
  const fake = criarSupabaseFake({ from: { produtos: { data: produtoAtualizado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { nome: 'Nome Novo', loja_id: UUID_LOJA_B, lojaId: UUID_LOJA_B },
  };
  const res = criarResMock();

  await atualizarProduto(req, res);

  assert.equal(res.statusCode, 200);
  // O update nunca inclui loja_id vindo do body — só nome (campo permitido).
  assert.deepEqual(fake.chamadasFrom[0].updateDados, { nome: 'Nome Novo' });
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, UUID_LOJA_A);
});

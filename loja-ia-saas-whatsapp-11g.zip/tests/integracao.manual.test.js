/**
 * TESTES DE INTEGRAÇÃO — cenários A a J do pedido de auditoria.
 *
 * ⚠️ NÃO executados neste ambiente de desenvolvimento: este sandbox não
 * tem acesso à rede (sem acesso ao Supabase) e não tem as dependências
 * (node_modules) instaladas. Este arquivo está pronto para rodar assim
 * que você tiver um projeto Supabase de teste e o servidor no ar.
 *
 * COMO RODAR:
 *   1. Crie um projeto Supabase separado só para teste (não use produção).
 *   2. Rode src/db/schema.sql nele.
 *   3. No painel Supabase, crie 2 usuários já confirmados (Authentication
 *      → Users → Add user → marque "Auto Confirm User"), ou desative a
 *      confirmação de e-mail nas configurações de Auth do projeto de
 *      teste, para o signUp abaixo já vir com sessão.
 *   4. Defina as variáveis de ambiente (ou um .env local):
 *        BASE_URL=http://localhost:3000
 *        SUPABASE_URL=...
 *        SUPABASE_SERVICE_ROLE_KEY=...
 *   5. Suba o servidor apontando para esse projeto de teste: npm start
 *   6. Em outro terminal: node tests/integracao.manual.test.js
 *
 * O script cria dois usuários/lojas do zero a cada execução (emails
 * aleatórios), então pode ser rodado repetidamente sem limpar nada.
 */
const assert = require('node:assert/strict');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

function log(...args) {
  console.log(...args);
}

async function api(method, path, { token, body } = {}) {
  const resp = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await resp.json();
  } catch {
    // corpo vazio (ex: 204 No Content) é esperado em alguns casos
  }
  return { status: resp.status, data };
}

async function criarUsuarioELoja(sufixo) {
  const email = `teste.${sufixo}.${Date.now()}@example.com`;
  const senha = 'SenhaForte123';

  const cadastro = await api('POST', '/api/auth/cadastrar', { body: { email, senha } });
  assert.equal(cadastro.status, 201, `cadastro falhou: ${JSON.stringify(cadastro.data)}`);

  const login = await api('POST', '/api/auth/login', { body: { email, senha } });
  assert.equal(login.status, 200, `login falhou (confirme que auto-confirm está ligado): ${JSON.stringify(login.data)}`);
  const token = login.data.token;

  const loja = await api('POST', '/api/lojas', { token, body: { nome: `Loja ${sufixo}` } });
  assert.equal(loja.status, 201, `criação de loja falhou: ${JSON.stringify(loja.data)}`);

  return { email, token, lojaId: loja.data.id };
}

async function main() {
  log('Criando usuário A e loja A...');
  const A = await criarUsuarioELoja('A');
  log('Criando usuário B e loja B...');
  const B = await criarUsuarioELoja('B');

  // Produto + estoque na loja A
  const produtoA = await api('POST', `/api/lojas/${A.lojaId}/produtos`, {
    token: A.token,
    body: { nome: 'Camiseta Teste', preco: 50 },
  });
  assert.equal(produtoA.status, 201);
  const produtoAId = produtoA.data.id;

  const estoqueA = await api('POST', `/api/lojas/${A.lojaId}/produtos/${produtoAId}/estoque`, {
    token: A.token,
    body: { tamanho: 'M', cor: 'Azul', quantidade: 3 },
  });
  assert.equal(estoqueA.status, 201);
  const estoqueAId = estoqueA.data.id;

  const clienteA = await api('POST', `/api/lojas/${A.lojaId}/clientes`, {
    token: A.token,
    body: { nome: 'Cliente da Loja A' },
  });
  assert.equal(clienteA.status, 201);
  const clienteAId = clienteA.data.id;

  // Produto na loja B (para tentativas de acesso cruzado)
  const produtoB = await api('POST', `/api/lojas/${B.lojaId}/produtos`, {
    token: B.token,
    body: { nome: 'Produto da Loja B', preco: 10 },
  });
  assert.equal(produtoB.status, 201);
  const produtoBId = produtoB.data.id;

  // ---------------------------------------------------------------
  log('\nCENÁRIO A: Usuário A acessa sua loja → permitido');
  {
    const r = await api('GET', `/api/lojas/${A.lojaId}/produtos`, { token: A.token });
    assert.equal(r.status, 200);
    log('  OK');
  }

  log('CENÁRIO B: Usuário A tenta acessar loja do usuário B → bloqueado');
  {
    const r = await api('GET', `/api/lojas/${B.lojaId}/produtos`, { token: A.token });
    assert.equal(r.status, 403);
    log('  OK (403)');
  }

  log('CENÁRIO C: Usuário A tenta modificar produto da loja B → bloqueado');
  {
    // Usando a própria lojaId de A na URL, mas produtoId pertence à loja B.
    const r = await api('PATCH', `/api/lojas/${A.lojaId}/produtos/${produtoBId}`, {
      token: A.token,
      body: { nome: 'Hackeado' },
    });
    assert.ok([403, 404].includes(r.status), `esperado 403/404, veio ${r.status}`);
    log(`  OK (${r.status})`);
  }

  log('CENÁRIO D: Usuário A tenta modificar estoque pertencente à loja B → bloqueado');
  {
    // Tenta usar produtoB "por dentro" da loja A.
    const r = await api('POST', `/api/lojas/${A.lojaId}/produtos/${produtoBId}/estoque`, {
      token: A.token,
      body: { tamanho: 'M', cor: 'Preta', quantidade: 1 },
    });
    assert.ok([403, 404].includes(r.status), `esperado 403/404, veio ${r.status}`);
    log(`  OK (${r.status})`);
  }

  log('CENÁRIO E: Pedido com estoque suficiente → permitido');
  {
    const r = await api('POST', `/api/lojas/${A.lojaId}/pedidos`, {
      token: A.token,
      body: { clienteId: clienteAId, itens: [{ estoqueId: estoqueAId, quantidade: 1 }] },
    });
    assert.equal(r.status, 201, JSON.stringify(r.data));
    assert.equal(r.data.total, 50);
    log('  OK — estoque deve ter ido de 3 para 2');
  }

  log('CENÁRIO F: Pedido acima do estoque disponível → rejeitado');
  {
    const r = await api('POST', `/api/lojas/${A.lojaId}/pedidos`, {
      token: A.token,
      body: { clienteId: clienteAId, itens: [{ estoqueId: estoqueAId, quantidade: 999 }] },
    });
    assert.equal(r.status, 409, JSON.stringify(r.data));
    log('  OK (409 estoque insuficiente)');
  }

  log('CENÁRIO G: Pedido usando cliente de outra loja → rejeitado');
  {
    const clienteB = await api('POST', `/api/lojas/${B.lojaId}/clientes`, {
      token: B.token,
      body: { nome: 'Cliente da Loja B' },
    });
    const r = await api('POST', `/api/lojas/${A.lojaId}/pedidos`, {
      token: A.token,
      body: { clienteId: clienteB.data.id, itens: [{ estoqueId: estoqueAId, quantidade: 1 }] },
    });
    assert.equal(r.status, 400, JSON.stringify(r.data));
    log('  OK (400 cliente não pertence à loja)');
  }

  log('CENÁRIO H: Pergunta sobre produto existente → responde com dados reais');
  {
    const r = await api('POST', `/api/lojas/${A.lojaId}/ia/perguntar`, {
      body: { pergunta: 'Quanto custa a camiseta teste?' },
    });
    assert.equal(r.status, 200);
    assert.match(r.data.resposta, /Camiseta Teste/);
    log('  OK');
  }

  log('CENÁRIO I: Pergunta sobre produto inexistente → não inventa produto');
  {
    const r = await api('POST', `/api/lojas/${A.lojaId}/ia/perguntar`, {
      body: { pergunta: 'Vocês tem jaqueta de couro voadora?' },
    });
    assert.equal(r.status, 200);
    assert.match(r.data.resposta, /Não encontrei esse produto/i);
    log('  OK');
  }

  log('CENÁRIO J: Estoque nunca fica negativo (mesmo tentando exaurir exatamente)');
  {
    // Sobrou 2 no estoque após o cenário E. Pede exatamente 2, depois
    // tenta pedir mais 1 (deveria falhar, pois já zerou).
    const r1 = await api('POST', `/api/lojas/${A.lojaId}/pedidos`, {
      token: A.token,
      body: { itens: [{ estoqueId: estoqueAId, quantidade: 2 }] },
    });
    assert.equal(r1.status, 201, JSON.stringify(r1.data));

    const r2 = await api('POST', `/api/lojas/${A.lojaId}/pedidos`, {
      token: A.token,
      body: { itens: [{ estoqueId: estoqueAId, quantidade: 1 }] },
    });
    assert.equal(r2.status, 409, JSON.stringify(r2.data));
    log('  OK — segunda tentativa corretamente rejeitada, estoque não ficou negativo');
  }

  log('\n✅ Todos os cenários de integração passaram.');
}

main().catch((err) => {
  console.error('\n❌ Falha nos testes de integração:', err.message);
  process.exit(1);
});

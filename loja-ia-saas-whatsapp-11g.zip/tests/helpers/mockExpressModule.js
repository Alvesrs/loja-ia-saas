/**
 * Permite carregar src/app.js e os arquivos de rotas SEM ter os pacotes
 * "express" e "cors" instalados e SEM abrir porta/servidor: o Node é
 * instruído a devolver versões falsas que apenas REGISTRAM como o código
 * as usou (quais caminhos foram montados, em que ordem, com quais
 * middlewares e opções).
 *
 * É o mesmo raciocínio de ./mockSupabaseModule.js: este ambiente de testes
 * não tem acesso à internet para `npm install`.
 *
 * O QUE ISTO PERMITE VERIFICAR: a fiação (rota, ordem dos middlewares,
 * opções como o limite do corpo, ausência de login).
 * O QUE NÃO PERMITE: o comportamento interno do Express e do body-parser
 * (parse real do JSON, 413 real por tamanho). Para isso é preciso rodar o
 * servidor de verdade com as dependências instaladas — ver o teste manual
 * sugerido em docs/ARQUITETURA.md.
 *
 * IMPORTANTE: chame `instalarMockExpress()` ANTES do primeiro require de
 * qualquer arquivo de rota ou de src/app.js.
 */
const Module = require('node:module');

let instalado = false;

function criarRoteadorFalso(opcoes) {
  const roteador = { opcoes, rotas: [], usos: [], tipo: 'router' };

  for (const metodo of ['get', 'post', 'put', 'patch', 'delete', 'all']) {
    roteador[metodo] = (caminho, ...handlers) => {
      roteador.rotas.push({ metodo, caminho, handlers: handlers.flat() });
      return roteador;
    };
  }
  roteador.use = (...args) => {
    const caminho = typeof args[0] === 'string' ? args.shift() : undefined;
    roteador.usos.push({ caminho, handlers: args.flat() });
    return roteador;
  };
  roteador.param = () => roteador;
  return roteador;
}

function criarMiddlewareFalso(tipo, opcoes) {
  const middleware = function middlewareFalso() {};
  middleware.tipo = tipo;
  middleware.opcoes = opcoes;
  return middleware;
}

function criarExpressFalso() {
  function express() {
    const app = criarRoteadorFalso();
    app.tipo = 'app';
    app.desabilitados = [];
    app.disable = (nome) => {
      app.desabilitados.push(nome);
      return app;
    };
    app.set = () => app;
    app.listen = () => {
      throw new Error('Os testes não podem abrir um servidor (listen).');
    };
    return app;
  }
  express.Router = (opcoes) => criarRoteadorFalso(opcoes);
  express.json = (opcoes) => criarMiddlewareFalso('json', opcoes);
  express.urlencoded = (opcoes) => criarMiddlewareFalso('urlencoded', opcoes);
  express.static = (pasta, opcoes) => criarMiddlewareFalso('static', { pasta, ...opcoes });
  return express;
}

function criarCorsFalso() {
  return function cors(opcoes) {
    return criarMiddlewareFalso('cors', opcoes);
  };
}

function instalarMockExpress() {
  if (instalado) return;
  instalado = true;

  const expressFalso = criarExpressFalso();
  const corsFalso = criarCorsFalso();
  const carregarOriginal = Module._load;

  Module._load = function interceptador(request) {
    if (request === 'express') return expressFalso;
    if (request === 'cors') return corsFalso;
    return carregarOriginal.apply(this, arguments);
  };
}

module.exports = { instalarMockExpress };

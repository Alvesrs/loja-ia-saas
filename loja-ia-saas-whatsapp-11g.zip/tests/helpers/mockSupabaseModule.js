/**
 * Permite testar módulos que dependem de src/config/supabase.js SEM ter
 * o pacote @supabase/supabase-js instalado (não há acesso à internet
 * neste ambiente de sandbox para rodar `npm install`) e SEM rede real.
 *
 * Funciona interceptando a resolução de módulos do Node: quando algum
 * arquivo do projeto der `require('@supabase/supabase-js')`, devolvemos
 * um `createClient` falso que retorna um cliente fake controlável pelos
 * testes (ver ./supabaseFake.js).
 *
 * IMPORTANTE: chame `instalarMockSupabaseJs()` ANTES do primeiro
 * `require('../src/config/supabase')` (direto ou indireto, ex: via
 * services/controllers/middlewares que o importam).
 */
const Module = require('node:module');
const { criarSupabaseFake } = require('./supabaseFake');

let instalado = false;

function instalarMockSupabaseJs() {
  if (instalado) return;
  instalado = true;

  // Evita o console.warn de "SUPABASE_URL não definido" poluir a saída
  // dos testes — não precisamos de valores reais, só de algo definido.
  process.env.SUPABASE_URL = process.env.SUPABASE_URL || 'https://fake.supabase.co';
  process.env.SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || 'fake-service-role-key';

  const originalLoad = Module._load;
  Module._load = function interceptador(request, parent, isMain) {
    if (request === '@supabase/supabase-js') {
      return {
        createClient() {
          // config/supabase.js só chama createClient() uma vez (o módulo
          // fica em cache do Node), então este objeto é o único cliente
          // "supabase" usado por todo o processo de teste — os testes
          // reconfiguram .from/.rpc/.auth nele a cada `test()`.
          return criarSupabaseFake({});
        },
      };
    }
    return originalLoad.apply(this, arguments);
  };
}

module.exports = { instalarMockSupabaseJs };

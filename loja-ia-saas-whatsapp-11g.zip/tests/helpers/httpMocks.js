function criarResMock() {
  return {
    statusCode: null,
    headers: {},
    body: null,
    encerrada: false,
    setHeader(nome, valor) {
      this.headers[nome] = valor;
    },
    status(codigo) {
      this.statusCode = codigo;
      return this;
    },
    json(corpo) {
      // Express usa 200 por padrão quando res.json()/res.send() é chamado
      // sem um res.status(...) explícito antes.
      if (this.statusCode === null) this.statusCode = 200;
      this.body = corpo;
      this.encerrada = true;
      return this;
    },
    send(corpo) {
      if (this.statusCode === null) this.statusCode = 200;
      this.body = corpo;
      this.encerrada = true;
      return this;
    },
  };
}

function criarNextMock() {
  const chamada = { vezes: 0 };
  const next = () => {
    chamada.vezes += 1;
  };
  next.info = chamada;
  return next;
}

module.exports = { criarResMock, criarNextMock };

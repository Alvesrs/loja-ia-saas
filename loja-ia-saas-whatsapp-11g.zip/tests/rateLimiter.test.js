/**
 * Testes de unidade do rate limiter em memória (src/middleware/rateLimiter.js).
 *
 * Correção da auditoria técnica: este limitador passou a ser usado também
 * em /api/auth/login e /api/auth/cadastrar (antes só existia em
 * /ia/perguntar), então ganhou testes dedicados.
 *
 * Não usa rede nem timers reais de espera — simula um objeto
 * res mínimo e chama o middleware diretamente.
 *
 * Rodar com: node --test tests/rateLimiter.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const { criarRateLimiter } = require('../src/middleware/rateLimiter');

function criarResMock() {
  return {
    statusCode: null,
    headers: {},
    body: null,
    setHeader(nome, valor) {
      this.headers[nome] = valor;
    },
    status(codigo) {
      this.statusCode = codigo;
      return this;
    },
    json(corpo) {
      this.body = corpo;
      return this;
    },
  };
}

test('rate limiter permite requisições até o limite e bloqueia a partir da (max+1)ª', () => {
  const limiter = criarRateLimiter({ janelaMs: 60_000, maxRequisicoes: 3, obterChave: () => 'ip-fixo' });

  for (let i = 0; i < 3; i += 1) {
    const req = { ip: 'ip-fixo' };
    const res = criarResMock();
    let chamouNext = false;
    limiter(req, res, () => {
      chamouNext = true;
    });
    assert.equal(chamouNext, true, `requisição ${i + 1} deveria passar`);
    assert.equal(res.statusCode, null);
  }

  const reqBloqueada = { ip: 'ip-fixo' };
  const resBloqueada = criarResMock();
  let chamouNextBloqueada = false;
  limiter(reqBloqueada, resBloqueada, () => {
    chamouNextBloqueada = true;
  });
  assert.equal(chamouNextBloqueada, false, 'quarta requisição deveria ser bloqueada');
  assert.equal(resBloqueada.statusCode, 429);
  assert.ok(resBloqueada.headers['Retry-After']);
});

test('chaves diferentes (ex: IP+email diferentes) têm contadores independentes', () => {
  const limiter = criarRateLimiter({
    janelaMs: 60_000,
    maxRequisicoes: 1,
    obterChave: (req) => `${req.ip}:${req.body.email}`,
  });

  const resA1 = criarResMock();
  let passouA1 = false;
  limiter({ ip: '1.1.1.1', body: { email: 'a@teste.com' } }, resA1, () => { passouA1 = true; });
  assert.equal(passouA1, true);

  // Mesmo IP, email diferente: não deve ser afetado pelo limite de "a@teste.com".
  const resB1 = criarResMock();
  let passouB1 = false;
  limiter({ ip: '1.1.1.1', body: { email: 'b@teste.com' } }, resB1, () => { passouB1 = true; });
  assert.equal(passouB1, true, 'email diferente no mesmo IP não deveria ser bloqueado');

  // Mesmo IP + mesmo email de novo: já bateu o limite de 1, deve bloquear.
  const resA2 = criarResMock();
  let passouA2 = false;
  limiter({ ip: '1.1.1.1', body: { email: 'a@teste.com' } }, resA2, () => { passouA2 = true; });
  assert.equal(passouA2, false, 'segunda tentativa da mesma chave deveria ser bloqueada');
  assert.equal(resA2.statusCode, 429);
});

test('mensagem customizada é usada na resposta de bloqueio', () => {
  const limiter = criarRateLimiter({
    janelaMs: 60_000,
    maxRequisicoes: 0,
    mensagem: 'Muitas tentativas de login. Aguarde alguns minutos e tente novamente.',
    obterChave: () => 'chave-unica',
  });

  const res = criarResMock();
  limiter({ ip: '9.9.9.9' }, res, () => {});
  assert.equal(res.statusCode, 429);
  assert.equal(res.body.erro, 'Muitas tentativas de login. Aguarde alguns minutos e tente novamente.');
});

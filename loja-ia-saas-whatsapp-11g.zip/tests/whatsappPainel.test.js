const assert = require('node:assert/strict');
const { test, beforeEach } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
require('./helpers/mockSupabaseModule').instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const historico = require('../src/services/whatsappHistorico.service');

const RAIZ = path.join(__dirname, '..');
const LOJA = '11111111-1111-4111-8111-111111111111';
const CONVERSA = '33333333-3333-4333-8333-333333333333';
let fake;

beforeEach((t) => {
  fake = criarSupabaseFake({ from: {
    whatsapp_conversas: () => ({ data: [{
      id: CONVERSA,
      loja_id: LOJA,
      configuracao_id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
      contato: '5511999999999',
      criado_em: '2026-09-19T10:00:00.000Z',
      atualizado_em: '2026-09-19T10:01:00.000Z',
      segredo_que_nao_deve_sair: 'x',
    }], error: null }),
    whatsapp_mensagens: () => ({ data: [{
      id: '44444444-4444-4444-8444-444444444444',
      conversa_id: CONVERSA,
      loja_id: LOJA,
      direcao: 'entrada',
      texto: 'Olá',
      provedor: 'meta',
      id_externo: 'wamid.teste',
      criado_em: '2026-09-19T10:00:00.000Z',
      payload_bruto: { access_token: 'nao-vazar' },
    }], error: null }),
  }});
  t.mock.method(supabase, 'from', fake.from);
});

test('10Q: listar conversas filtra por loja_id e devolve apenas colunas públicas', async () => {
  const dados = await historico.listarConversas(LOJA);
  assert.equal(fake.chamadasFrom[0].tabela, 'whatsapp_conversas');
  assert.equal(fake.chamadasFrom[0].filtros.loja_id, LOJA);
  assert.equal(fake.chamadasFrom[0].limite, 50);
  assert.equal(dados.length, 1);
  assert.equal(dados[0].loja_id, undefined);
  assert.equal(dados[0].segredo_que_nao_deve_sair, undefined);
  assert.equal(dados[0].contato, '5511999999999');
});

test('10Q: listar mensagens filtra na mesma consulta por conversa_id + loja_id', async () => {
  const dados = await historico.listarMensagens(CONVERSA, LOJA);
  const chamada = fake.chamadasFrom[0];
  assert.equal(chamada.tabela, 'whatsapp_mensagens');
  assert.equal(chamada.filtros.conversa_id, CONVERSA);
  assert.equal(chamada.filtros.loja_id, LOJA);
  assert.equal(chamada.limite, 100);
  assert.equal(dados[0].loja_id, undefined);
  assert.equal(dados[0].payload_bruto, undefined);
  assert.equal(dados[0].texto, 'Olá');
});

test('10Q: ids inválidos do histórico falham antes de consultar o banco', async () => {
  await assert.rejects(() => historico.listarConversas('loja-invalida'), TypeError);
  await assert.rejects(() => historico.listarMensagens('conversa-invalida', LOJA), TypeError);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('10Q: rotas de histórico ficam atrás de login e ownership da loja', () => {
  const code = fs.readFileSync(path.join(RAIZ, 'src/routes/whatsappConfiguracao.routes.js'), 'utf8');
  const login = code.indexOf('router.use(exigirLogin)');
  const dono = code.indexOf('router.use(exigirDonoDaLoja)');
  const conversas = code.indexOf("router.get('/historico/conversas'");
  assert.ok(login >= 0 && dono > login && conversas > dono);
  assert.match(code, /historico\/conversas\/:conversaId\/mensagens/);
});

test('10Q: painel WhatsApp existe no menu e usa APIs autenticadas por loja', () => {
  const layout = fs.readFileSync(path.join(RAIZ, 'public/js/layout.js'), 'utf8');
  const html = fs.readFileSync(path.join(RAIZ, 'public/whatsapp.html'), 'utf8');
  const js = fs.readFileSync(path.join(RAIZ, 'public/js/whatsapp.js'), 'utf8');
  assert.match(layout, /id: 'whatsapp'.*whatsapp\.html/s);
  assert.match(html, /type="password"[^>]*id="wa-token"|id="wa-token"[^>]*type="password"/);
  assert.match(js, /\/whatsapp\/historico\/conversas/);
  assert.match(js, /\/credencial/);
  assert.match(js, /access_token: token/);
});

test('10Q: frontend nunca tenta recuperar ou exibir o access token salvo', () => {
  const html = fs.readFileSync(path.join(RAIZ, 'public/whatsapp.html'), 'utf8');
  const js = fs.readFileSync(path.join(RAIZ, 'public/js/whatsapp.js'), 'utf8');
  assert.equal(/\.access_token\b/.test(js), false);
  assert.equal(/textContent\s*=\s*token|innerHTML\s*=\s*token/.test(js), false);
  assert.match(js, /waToken\.value\s*=\s*''/);
  assert.equal(html.includes('META_APP_SECRET'), false);
  assert.equal(html.includes('WHATSAPP_CREDENTIALS_MASTER_KEY'), false);
});

test('10Q: painel apenas lê histórico; não há rota de editar/apagar mensagens', () => {
  const routes = fs.readFileSync(path.join(RAIZ, 'src/routes/whatsappConfiguracao.routes.js'), 'utf8');
  assert.equal(/router\.(post|put|patch|delete)\('\/historico\//.test(routes), false);
});

test('10Q: etapa não cria migration 008 nem altera o modelo de segredos', () => {
  assert.equal(fs.existsSync(path.join(RAIZ, 'src/db/migrations/008_whatsapp_painel.sql')), false);
  const cred = fs.readFileSync(path.join(RAIZ, 'src/services/whatsappCredencial.service.js'), 'utf8');
  assert.match(cred, /aes-256-gcm/);
  assert.match(cred, /resolverAccessTokenMeta/);
});

test('10Q: empacotamento protege .env de commit acidental', () => {
  const gitignore = fs.readFileSync(path.join(RAIZ, '.gitignore'), 'utf8');
  assert.match(gitignore, /^\.env$/m);
  assert.match(gitignore, /^node_modules\/$/m);
  assert.match(gitignore, /^!\.env\.example$/m);
});

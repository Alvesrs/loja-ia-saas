/**
 * Testes do ADAPTADOR META (src/services/providers/whatsapp/adaptadorMeta.js)
 * e do CLIENTE HTTP ISOLADO (src/services/providers/whatsapp/clienteHttpMeta.js).
 *
 * Etapa 10G: infraestrutura do adaptador REAL da Meta Cloud API. Todos os
 * testes rodam OFFLINE — `fetch` nunca é chamado de verdade: cada teste que
 * simula o provedor injeta sua própria função fake via `fetchFn` (nunca
 * mexe em `global.fetch`, então nenhum outro teste do projeto pode ser
 * afetado por engano).
 *
 * Cobre os cenários pedidos na Etapa 10G, item 15:
 *   A) configuração válida: adaptador monta uma operação válida.
 *   B) credencial ausente: falha de forma segura.
 *   C) destinatário (contato) ausente: rejeita.
 *   D) texto vazio: rejeita.
 *   E) montagem correta da requisição (método, URL, headers, body) sem chamada real.
 *   F) sucesso simulado do provedor: mock HTTP retorna resposta válida.
 *   G) erro HTTP do provedor: adaptador transforma em erro interno seguro.
 *   H) timeout: não deixa a chamada pendurada.
 *   I) JSON inválido: não quebra com erro não tratado.
 *   J) resposta sem ID esperado: rejeita de maneira segura.
 *   K) access token não aparece em logs.
 *   L) access token não aparece em mensagens de erro devolvidas.
 *   M) nenhum teste depende de internet.
 *   N) adaptador simulado (10F) continua funcionando.
 *   O) o resto do módulo de provedores continua funcionando (compatibilidade).
 *
 * Rodar com: node --test tests/whatsappProvedorMeta.adaptador.test.js
 */
const assert = require('node:assert/strict');
const { test, afterEach } = require('node:test');

const { criarAdaptadorMeta, mapearStatusParaCodigoErro, extrairIdExterno } = require('../src/services/providers/whatsapp/adaptadorMeta');
const { montarRequisicaoEnvioTexto, executarRequisicao, ErroClienteHttpMeta, redigirSegredo } = require('../src/services/providers/whatsapp/clienteHttpMeta');
const { CODIGOS_ERRO_ENVIO, STATUS_ENVIO, obterProvedorWhatsapp, listarProvedoresDisponiveis } = require('../src/services/providers/whatsapp');
const { criarAdaptadorSimulado } = require('../src/services/providers/whatsapp/adaptadorSimulado');
const { ErroMensagemWhatsappInvalida } = require('../src/services/whatsapp.service');

const LOJA_A = '11111111-1111-4111-8111-111111111111';
const TOKEN_FAKE = 'EAA-token-fake-de-teste-nao-usar-em-producao';
const PHONE_NUMBER_ID_FAKE = '106540352242922';

const pedidoValido = (extra = {}) => ({ lojaId: LOJA_A, contato: '+5511988887777', texto: 'Sim, temos a camiseta P.', ...extra });

const ENV_VARS_META = ['META_WHATSAPP_ACCESS_TOKEN', 'META_WHATSAPP_API_VERSION', 'META_WHATSAPP_TIMEOUT_MS'];
function limparEnvMeta() {
  for (const chave of ENV_VARS_META) delete process.env[chave];
}

const consoleErrorOriginal = console.error;
afterEach(() => {
  limparEnvMeta();
  console.error = consoleErrorOriginal;
});

// Captura tudo que for logado via console.error durante o teste.
function capturarConsoleError() {
  const linhas = [];
  console.error = (...args) => {
    linhas.push(args.map((a) => (typeof a === 'string' ? a : JSON.stringify(a))).join(' '));
  };
  return linhas;
}

function fetchFakeSucesso(idExterno = 'wamid.HBgLMTY0NjcwNDM1OTUVAgARGBI4MjZGRDA0OUE2OTQ3RkEyMzcA') {
  return async () => ({
    ok: true,
    status: 200,
    async text() {
      return JSON.stringify({
        messaging_product: 'whatsapp',
        contacts: [{ input: '+5511988887777', wa_id: '5511988887777' }],
        messages: [{ id: idExterno }],
      });
    },
  });
}

function fetchFakeErroHttp(status, corpo) {
  return async () => ({
    ok: false,
    status,
    async text() {
      return JSON.stringify(corpo);
    },
  });
}

function fetchFakeRespostaSemId() {
  return async () => ({
    ok: true,
    status: 200,
    async text() {
      return JSON.stringify({ messaging_product: 'whatsapp', contacts: [], messages: [{}] });
    },
  });
}

function fetchFakeJsonInvalido() {
  return async () => ({
    ok: true,
    status: 200,
    async text() {
      return '{ isto nao é json';
    },
  });
}

function fetchFakeTimeout() {
  return (url, { signal } = {}) =>
    new Promise((_resolve, reject) => {
      // nunca resolve sozinho: só rejeita quando o AbortController disparar,
      // exatamente como uma chamada real pendurada faria.
      if (signal) {
        signal.addEventListener('abort', () => {
          const erro = new Error('The operation was aborted.');
          erro.name = 'AbortError';
          reject(erro);
        });
      }
    });
}

function fetchFakeFalhaDeRede() {
  return async () => {
    throw new Error('getaddrinfo ENOTFOUND graph.facebook.com');
  };
}

const adaptadorMetaConfigurado = (extra = {}) =>
  criarAdaptadorMeta({ accessToken: TOKEN_FAKE, phoneNumberId: PHONE_NUMBER_ID_FAKE, apiVersion: 'v26.0', ...extra });

// --- A) Configuração válida -------------------------------------------------

test('A) enviarMensagem() com configuração e pedido válidos aceita e devolve envio bem-sucedido', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso() });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.enviado);
  assert.equal(resultado.sucesso, true);
  assert.equal(resultado.simulado, false);
  assert.equal(resultado.provedor, 'meta');
  assert.equal(typeof resultado.idExterno, 'string');
});

test('A) criarAdaptadorMeta() lê accessToken/apiVersion do ambiente quando não informados', () => {
  process.env.META_WHATSAPP_ACCESS_TOKEN = TOKEN_FAKE;
  process.env.META_WHATSAPP_API_VERSION = 'v24.0';
  const adaptador = criarAdaptadorMeta({ phoneNumberId: PHONE_NUMBER_ID_FAKE, fetchFn: fetchFakeSucesso() });
  assert.equal(adaptador.nome, 'meta');
});

// --- B) Credencial ausente ---------------------------------------------------

test('B) enviarMensagem() sem accessToken falha de forma segura (resultado, não exceção)', async () => {
  limparEnvMeta();
  const linhas = capturarConsoleError();
  const adaptador = criarAdaptadorMeta({ phoneNumberId: PHONE_NUMBER_ID_FAKE, fetchFn: fetchFakeSucesso() });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.sucesso, false);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.erroInterno);
  assert.equal(resultado.idExterno, null);
  // nada de sensível vaza no log de configuração ausente
  for (const linha of linhas) assert.doesNotMatch(linha, /Bearer|EAA-token/);
});

test('B) enviarMensagem() sem phoneNumberId falha de forma segura (nunca usa variável de ambiente global)', async () => {
  process.env.META_WHATSAPP_ACCESS_TOKEN = TOKEN_FAKE;
  const adaptador = criarAdaptadorMeta({ fetchFn: fetchFakeSucesso() }); // phoneNumberId não informado
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.erroInterno);
});

test('B) obterProvedorWhatsapp("meta") sem configuração nenhuma devolve adaptador que falha ao enviar, sem lançar', async () => {
  limparEnvMeta();
  const adaptador = obterProvedorWhatsapp('meta');
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
});

// --- C) Contato (destinatário) ausente ---------------------------------------

test('C) enviarMensagem() rejeita com ErroMensagemWhatsappInvalida quando contato está ausente', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso() });
  const semContato = pedidoValido();
  delete semContato.contato;
  await assert.rejects(() => adaptador.enviarMensagem(semContato), ErroMensagemWhatsappInvalida);
});

// --- D) Texto vazio -----------------------------------------------------------

test('D) enviarMensagem() rejeita com ErroMensagemWhatsappInvalida quando texto está vazio', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso() });
  await assert.rejects(() => adaptador.enviarMensagem(pedidoValido({ texto: '' })), ErroMensagemWhatsappInvalida);
});

test('D) enviarMensagem() rejeita quando lojaId está ausente (mesma regra do contrato)', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso() });
  const semLoja = pedidoValido();
  delete semLoja.lojaId;
  await assert.rejects(() => adaptador.enviarMensagem(semLoja), ErroMensagemWhatsappInvalida);
});

// --- E) Montagem da requisição (sem chamada real) -----------------------------

test('E) montarRequisicaoEnvioTexto() monta método, URL, headers e body corretos', () => {
  const requisicao = montarRequisicaoEnvioTexto({
    apiVersion: 'v26.0',
    phoneNumberId: PHONE_NUMBER_ID_FAKE,
    accessToken: TOKEN_FAKE,
    para: '+5511988887777',
    texto: 'Olá!',
  });
  assert.equal(requisicao.method, 'POST');
  assert.equal(requisicao.url, `https://graph.facebook.com/v26.0/${PHONE_NUMBER_ID_FAKE}/messages`);
  assert.equal(requisicao.headers['Content-Type'], 'application/json');
  assert.equal(requisicao.headers.Authorization, `Bearer ${TOKEN_FAKE}`);
  const corpo = JSON.parse(requisicao.body);
  assert.equal(corpo.messaging_product, 'whatsapp');
  assert.equal(corpo.recipient_type, 'individual');
  assert.equal(corpo.to, '+5511988887777');
  assert.equal(corpo.type, 'text');
  assert.equal(corpo.text.body, 'Olá!');
});

test('E) montarRequisicaoEnvioTexto() lança se faltar parâmetro obrigatório (nenhuma chamada é feita)', () => {
  assert.throws(() => montarRequisicaoEnvioTexto({ apiVersion: 'v26.0', phoneNumberId: PHONE_NUMBER_ID_FAKE }));
});

// --- F) Sucesso simulado do provedor (mock HTTP) ------------------------------

test('F) enviarMensagem() com mock HTTP de sucesso devolve idExterno vindo de messages[0].id', async () => {
  const idEsperado = 'wamid.ABC123';
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso(idEsperado) });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.idExterno, idEsperado);
  assert.equal(resultado.status, STATUS_ENVIO.enviado);
});

// --- G) Erro HTTP do provedor --------------------------------------------------

test('G) enviarMensagem() com erro HTTP 401 (token inválido) devolve mensagemRejeitada, sem lançar', async () => {
  const linhas = capturarConsoleError();
  const adaptador = adaptadorMetaConfigurado({
    fetchFn: fetchFakeErroHttp(401, { error: { message: 'Invalid OAuth access token', type: 'OAuthException', code: 190 } }),
  });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.mensagemRejeitada);
  for (const linha of linhas) assert.doesNotMatch(linha, new RegExp(TOKEN_FAKE));
});

test('G) enviarMensagem() com erro HTTP 500/429 devolve provedorIndisponivel', async () => {
  const adaptador500 = adaptadorMetaConfigurado({ fetchFn: fetchFakeErroHttp(500, { error: { message: 'boom' } }) });
  const resultado500 = await adaptador500.enviarMensagem(pedidoValido());
  assert.equal(resultado500.erro.codigo, CODIGOS_ERRO_ENVIO.provedorIndisponivel);

  const adaptador429 = adaptadorMetaConfigurado({ fetchFn: fetchFakeErroHttp(429, { error: { message: 'Rate limit hit' } }) });
  const resultado429 = await adaptador429.enviarMensagem(pedidoValido());
  assert.equal(resultado429.erro.codigo, CODIGOS_ERRO_ENVIO.provedorIndisponivel);
});

test('G) mapearStatusParaCodigoErro() classifica status corretamente', () => {
  assert.equal(mapearStatusParaCodigoErro(500), CODIGOS_ERRO_ENVIO.provedorIndisponivel);
  assert.equal(mapearStatusParaCodigoErro(429), CODIGOS_ERRO_ENVIO.provedorIndisponivel);
  assert.equal(mapearStatusParaCodigoErro(400), CODIGOS_ERRO_ENVIO.mensagemRejeitada);
  assert.equal(mapearStatusParaCodigoErro(401), CODIGOS_ERRO_ENVIO.mensagemRejeitada);
});

// --- H) Timeout -----------------------------------------------------------------

test('H) enviarMensagem() em timeout devolve provedorIndisponivel e não deixa a chamada pendurada', async () => {
  const adaptador = adaptadorMetaConfigurado({ timeoutMs: 20, fetchFn: fetchFakeTimeout() });
  const inicio = Date.now();
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  const duracao = Date.now() - inicio;
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.provedorIndisponivel);
  assert.ok(duracao < 2000, `esperava que o timeout resolvesse rápido, levou ${duracao}ms`);
});

test('H) executarRequisicao() lança ErroClienteHttpMeta com código "timeout"', async () => {
  const requisicao = montarRequisicaoEnvioTexto({
    apiVersion: 'v26.0',
    phoneNumberId: PHONE_NUMBER_ID_FAKE,
    accessToken: TOKEN_FAKE,
    para: '+5511988887777',
    texto: 'oi',
  });
  await assert.rejects(
    () => executarRequisicao(requisicao, { timeoutMs: 10, fetchFn: fetchFakeTimeout() }),
    (erro) => erro instanceof ErroClienteHttpMeta && erro.codigo === 'timeout'
  );
});

// --- I) JSON inválido -------------------------------------------------------------

test('I) enviarMensagem() com resposta que não é JSON válido não quebra e devolve falha segura', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeJsonInvalido() });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.erroInterno);
});

// --- J) Resposta sem ID esperado ---------------------------------------------------

test('J) enviarMensagem() com sucesso HTTP mas sem messages[0].id rejeita de forma segura', async () => {
  const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeRespostaSemId() });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.falhou);
  assert.equal(resultado.erro.codigo, CODIGOS_ERRO_ENVIO.erroInterno);
  assert.equal(resultado.idExterno, null);
});

test('J) extrairIdExterno() devolve null quando o formato não tem o campo esperado', () => {
  assert.equal(extrairIdExterno({}), null);
  assert.equal(extrairIdExterno({ messages: [] }), null);
  assert.equal(extrairIdExterno({ messages: [{}] }), null);
  assert.equal(extrairIdExterno(null), null);
  assert.equal(extrairIdExterno({ messages: [{ id: 'wamid.OK' }] }), 'wamid.OK');
});

// --- K) Access token nunca aparece em logs -----------------------------------------

test('K) console.error nunca inclui o access token, em nenhum cenário de falha', async () => {
  const linhas = capturarConsoleError();
  const cenarios = [
    adaptadorMetaConfigurado({ fetchFn: fetchFakeErroHttp(401, { error: { message: `token ${TOKEN_FAKE} inválido` } }) }),
    adaptadorMetaConfigurado({ fetchFn: fetchFakeFalhaDeRede() }),
    adaptadorMetaConfigurado({ fetchFn: fetchFakeJsonInvalido() }),
    adaptadorMetaConfigurado({ fetchFn: fetchFakeRespostaSemId() }),
  ];
  for (const adaptador of cenarios) {
    await adaptador.enviarMensagem(pedidoValido());
  }
  for (const linha of linhas) {
    assert.doesNotMatch(linha, new RegExp(TOKEN_FAKE));
  }
});

test('K) redigirSegredo() substitui todas as ocorrências do token por um marcador', () => {
  const texto = `erro ao chamar Bearer ${TOKEN_FAKE} e de novo ${TOKEN_FAKE}`;
  const redigido = redigirSegredo(texto, TOKEN_FAKE);
  assert.ok(!redigido.includes(TOKEN_FAKE));
  assert.match(redigido, /\[TOKEN_OCULTADO\]/);
});

// --- L) Access token nunca aparece no RESULTADO devolvido ----------------------------

test('L) o resultado de falha devolvido por enviarMensagem() nunca contém o access token', async () => {
  const adaptador = adaptadorMetaConfigurado({
    fetchFn: fetchFakeErroHttp(400, { error: { message: `credencial ${TOKEN_FAKE}` } }),
  });
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  const serializado = JSON.stringify(resultado);
  assert.ok(!serializado.includes(TOKEN_FAKE));
  assert.equal(resultado.erro.mensagem, 'A mensagem foi rejeitada pelo provedor de WhatsApp.'); // mensagem fixa, não repassa o erro da Meta
});

// --- M) Nenhum teste depende de internet ---------------------------------------------
// (garantido estruturalmente: todo teste acima usa `fetchFn` fake; nenhuma chamada
// a `global.fetch`/`fetch` real acontece neste arquivo. Este teste apenas documenta
// e reforça isso checando que os cenários felizes só usam mocks locais.)

test('M) enviarMensagem() com fetchFn fake nunca toca em fetch/global.fetch reais', async () => {
  const fetchGlobalOriginal = global.fetch;
  let fetchGlobalChamado = false;
  global.fetch = (...args) => {
    fetchGlobalChamado = true;
    return fetchGlobalOriginal(...args);
  };
  try {
    const adaptador = adaptadorMetaConfigurado({ fetchFn: fetchFakeSucesso() });
    await adaptador.enviarMensagem(pedidoValido());
    assert.equal(fetchGlobalChamado, false);
  } finally {
    global.fetch = fetchGlobalOriginal;
  }
});

// --- N) Adaptador simulado (10F) continua funcionando ---------------------------------

test('N) adaptador simulado continua com status "simulado" e não faz chamada HTTP', async () => {
  const simulado = criarAdaptadorSimulado();
  const resultado = await simulado.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.simulado);
  assert.equal(resultado.simulado, true);
  assert.equal(resultado.idExterno, null);
});

// --- O) Compatibilidade: módulo de provedores continua funcionando --------------------

test('O) listarProvedoresDisponiveis() inclui "simulado" e "meta"', () => {
  const disponiveis = listarProvedoresDisponiveis();
  assert.ok(disponiveis.includes('simulado'));
  assert.ok(disponiveis.includes('meta'));
});

test('O) obterProvedorWhatsapp() continua exigindo o nome (sem padrão)', () => {
  assert.throws(() => obterProvedorWhatsapp());
  assert.throws(() => obterProvedorWhatsapp('provedor-inexistente'));
});

test('O) obterProvedorWhatsapp("simulado") continua funcionando como antes (compatibilidade com 10F)', async () => {
  const adaptador = obterProvedorWhatsapp('simulado');
  const resultado = await adaptador.enviarMensagem(pedidoValido());
  assert.equal(resultado.status, STATUS_ENVIO.simulado);
});

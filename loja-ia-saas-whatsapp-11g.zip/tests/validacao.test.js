/**
 * Testes de unidade dos helpers de validação (src/utils/validacao.js).
 * Rodar com: node tests/validacao.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const {
  ehUuid,
  ehStringNaoVazia,
  ehNumeroNaoNegativo,
  ehInteiroNaoNegativo,
  ehInteiroPositivo,
  ehEmailValido,
  ehTelefoneValido,
} = require('../src/utils/validacao');

test('ehUuid aceita UUID válido e rejeita o resto', () => {
  assert.equal(ehUuid('123e4567-e89b-12d3-a456-426614174000'), true);
  assert.equal(ehUuid('nao-e-um-uuid'), false);
  assert.equal(ehUuid(123), false);
  assert.equal(ehUuid(undefined), false);
});

test('ehStringNaoVazia rejeita string vazia/whitespace e tipos errados', () => {
  assert.equal(ehStringNaoVazia('Camiseta'), true);
  assert.equal(ehStringNaoVazia('   '), false);
  assert.equal(ehStringNaoVazia(''), false);
  assert.equal(ehStringNaoVazia(null), false);
  assert.equal(ehStringNaoVazia(42), false);
});

test('ehNumeroNaoNegativo: preço nunca pode ser negativo (CENÁRIO de validação de produto)', () => {
  assert.equal(ehNumeroNaoNegativo(49.9), true);
  assert.equal(ehNumeroNaoNegativo(0), true);
  assert.equal(ehNumeroNaoNegativo(-1), false);
  assert.equal(ehNumeroNaoNegativo('49.90'), false); // string não é número
  assert.equal(ehNumeroNaoNegativo(NaN), false);
  assert.equal(ehNumeroNaoNegativo(Infinity), false);
});

test('ehInteiroNaoNegativo: quantidade de estoque nunca pode ser negativa ou fracionária', () => {
  assert.equal(ehInteiroNaoNegativo(0), true);
  assert.equal(ehInteiroNaoNegativo(5), true);
  assert.equal(ehInteiroNaoNegativo(-1), false);
  assert.equal(ehInteiroNaoNegativo(2.5), false);
  assert.equal(ehInteiroNaoNegativo('5'), false);
});

test('ehInteiroPositivo: quantidade de item de pedido tem que ser > 0', () => {
  assert.equal(ehInteiroPositivo(1), true);
  assert.equal(ehInteiroPositivo(0), false);
  assert.equal(ehInteiroPositivo(-3), false);
  assert.equal(ehInteiroPositivo(1.5), false);
});

test('ehEmailValido: aceita formato básico válido, rejeita o resto (CENÁRIO cliente)', () => {
  assert.equal(ehEmailValido('cliente@exemplo.com'), true);
  assert.equal(ehEmailValido('  cliente@exemplo.com  '), true);
  assert.equal(ehEmailValido('sem-arroba.com'), false);
  assert.equal(ehEmailValido('a@b'), false);
  assert.equal(ehEmailValido(''), false);
  assert.equal(ehEmailValido(42), false);
  assert.equal(ehEmailValido(null), false);
});

test('ehTelefoneValido: aceita dígitos com separadores comuns, rejeita lixo (CENÁRIO cliente)', () => {
  assert.equal(ehTelefoneValido('11999998888'), true);
  assert.equal(ehTelefoneValido('(11) 99999-8888'), true);
  assert.equal(ehTelefoneValido('+55 11 99999-8888'), true);
  assert.equal(ehTelefoneValido('123'), false); // poucos dígitos
  assert.equal(ehTelefoneValido('abc'), false);
  assert.equal(ehTelefoneValido(''), false);
  assert.equal(ehTelefoneValido(null), false);
});

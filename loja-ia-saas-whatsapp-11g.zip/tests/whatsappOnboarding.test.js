const assert = require('node:assert/strict');
const { test, beforeEach } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
require('./helpers/mockSupabaseModule').instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const credenciais = require('../src/services/whatsappCredencial.service');

const RAIZ = path.join(__dirname, '..');
const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const CA = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const CB = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const TOKEN_A = 'EAATEST_TOKEN_LOJA_A_10P';
const TOKEN_B = 'EAATEST_TOKEN_LOJA_B_10P';
const MASTER = Buffer.alloc(32, 19).toString('base64');
let configs, segredoPorConfig, fake;

beforeEach((t) => {
  const anterior = process.env.WHATSAPP_CREDENTIALS_MASTER_KEY;
  process.env.WHATSAPP_CREDENTIALS_MASTER_KEY = MASTER;
  t.after(() => anterior === undefined ? delete process.env.WHATSAPP_CREDENTIALS_MASTER_KEY : process.env.WHATSAPP_CREDENTIALS_MASTER_KEY = anterior);
  configs = [
    { id: CA, loja_id: A, provedor: 'meta', numero_whatsapp: '551100000001', identificador_externo: '10001', ativo: true },
    { id: CB, loja_id: B, provedor: 'meta', numero_whatsapp: '551100000002', identificador_externo: '10002', ativo: true },
  ];
  segredoPorConfig = new Map();
  fake = criarSupabaseFake({ from: {
    whatsapp_configuracoes: (ctx) => {
      const achados = configs.filter(c => Object.entries(ctx.filtros).every(([k,v]) => c[k] === v));
      return { data: ctx.filtros.id ? achados[0] || null : achados, error: null };
    },
    whatsapp_credenciais: (ctx) => {
      if (ctx.upsertDados) { segredoPorConfig.set(ctx.upsertDados.configuracao_id, { ...ctx.upsertDados }); return { data: ctx.upsertDados, error: null }; }
      if (ctx.delete) { const atual = segredoPorConfig.get(ctx.filtros.configuracao_id); if (atual && atual.loja_id === ctx.filtros.loja_id) segredoPorConfig.delete(ctx.filtros.configuracao_id); return { data: null, error: null }; }
      const atual = segredoPorConfig.get(ctx.filtros.configuracao_id);
      if (!atual || atual.loja_id !== ctx.filtros.loja_id) return { data: null, error: null };
      return { data: atual, error: null };
    },
  }});
  t.mock.method(supabase, 'from', fake.from);
});

test('10P: salva token cifrado; banco e retorno nunca recebem token em texto puro', async () => {
  const retorno = await credenciais.salvarCredencialMeta(CA, A, TOKEN_A);
  assert.deepEqual(retorno, { configuracao_id: CA, credencial_configurada: true });
  const linha = segredoPorConfig.get(CA);
  assert.ok(linha);
  assert.equal(JSON.stringify(linha).includes(TOKEN_A), false);
  assert.ok(linha.access_token_cifrado && linha.access_token_iv && linha.access_token_tag);
  assert.equal(linha.loja_id, A);
  assert.equal(linha.provedor, 'meta');
});

test('10P: token cifrado pode ser resolvido internamente para a mesma configuração/loja', async () => {
  await credenciais.salvarCredencialMeta(CA, A, TOKEN_A);
  assert.equal(await credenciais.resolverAccessTokenMeta(CA, A), TOKEN_A);
});

test('10P: duas lojas mantêm credenciais diferentes sem mistura', async () => {
  await credenciais.salvarCredencialMeta(CA, A, TOKEN_A);
  await credenciais.salvarCredencialMeta(CB, B, TOKEN_B);
  assert.equal(await credenciais.resolverAccessTokenMeta(CA, A), TOKEN_A);
  assert.equal(await credenciais.resolverAccessTokenMeta(CB, B), TOKEN_B);
  await assert.rejects(() => credenciais.resolverAccessTokenMeta(CA, B), credenciais.ErroCredencialNaoConfigurada);
});

test('10P: estado expõe apenas booleano e remoção elimina a credencial', async () => {
  assert.deepEqual(await credenciais.obterEstadoCredencial(CA, A), { configuracao_id: CA, credencial_configurada: false });
  await credenciais.salvarCredencialMeta(CA, A, TOKEN_A);
  const estado = await credenciais.obterEstadoCredencial(CA, A);
  assert.deepEqual(estado, { configuracao_id: CA, credencial_configurada: true });
  assert.equal(JSON.stringify(estado).includes(TOKEN_A), false);
  await credenciais.removerCredencialMeta(CA, A);
  await assert.rejects(() => credenciais.resolverAccessTokenMeta(CA, A), credenciais.ErroCredencialNaoConfigurada);
});

test('10P: adulteração do ciphertext/tag falha fechada e não devolve lixo', async () => {
  await credenciais.salvarCredencialMeta(CA, A, TOKEN_A);
  segredoPorConfig.get(CA).access_token_tag = crypto.randomBytes(16).toString('base64');
  await assert.rejects(() => credenciais.resolverAccessTokenMeta(CA, A), credenciais.ErroCredencialBanco);
});

test('10P: chave mestra ausente ou com tamanho errado impede salvar segredo', async () => {
  delete process.env.WHATSAPP_CREDENTIALS_MASTER_KEY;
  await assert.rejects(() => credenciais.salvarCredencialMeta(CA, A, TOKEN_A), credenciais.ErroChaveCredenciaisAusente);
  process.env.WHATSAPP_CREDENTIALS_MASTER_KEY = Buffer.alloc(16).toString('base64');
  await assert.rejects(() => credenciais.salvarCredencialMeta(CA, A, TOKEN_A), credenciais.ErroChaveCredenciaisAusente);
});

test('10P: configuração de provedor não-Meta não aceita access token', async () => {
  configs[0].provedor = 'simulado';
  await assert.rejects(() => credenciais.salvarCredencialMeta(CA, A, TOKEN_A), credenciais.ErroCredencialInvalida);
  assert.equal(segredoPorConfig.size, 0);
});

test('10P: rotas de onboarding exigem login e dono da loja antes dos controllers', () => {
  const code = fs.readFileSync(path.join(RAIZ, 'src/routes/whatsappConfiguracao.routes.js'), 'utf8');
  assert.match(code, /router\.use\(exigirLogin\)/);
  assert.match(code, /router\.use\(exigirDonoDaLoja\)/);
  assert.match(code, /router\.put\('\/:configuracaoId\/credencial'/);
  assert.match(code, /router\.delete\('\/:configuracaoId\/credencial'/);
  assert.match(fs.readFileSync(path.join(RAIZ, 'src/app.js'), 'utf8'), /\/api\/lojas\/:lojaId\/whatsapp/);
});

test('10P: migration 007 usa FK composta, RLS e só armazena material cifrado', () => {
  const sql = fs.readFileSync(path.join(RAIZ, 'src/db/migrations/007_whatsapp_credenciais.sql'), 'utf8').toLowerCase();
  assert.match(sql, /foreign key \(configuracao_id, loja_id\)[\s\S]*references whatsapp_configuracoes\(id, loja_id\)/);
  assert.match(sql, /enable row level security/);
  assert.match(sql, /access_token_cifrado/);
  assert.match(sql, /access_token_iv/);
  assert.match(sql, /access_token_tag/);
  assert.equal(/access_token\s+text/.test(sql), false);
});

test('10P: .env.example exige chave mestra e não volta ao token global da Meta', () => {
  const env = fs.readFileSync(path.join(RAIZ, '.env.example'), 'utf8');
  assert.match(env, /^WHATSAPP_CREDENTIALS_MASTER_KEY=$/m);
  assert.equal(/^META_WHATSAPP_ACCESS_TOKEN=/m.test(env), false);
  assert.equal(env.includes(TOKEN_A), false);
  assert.equal(env.includes(TOKEN_B), false);
});

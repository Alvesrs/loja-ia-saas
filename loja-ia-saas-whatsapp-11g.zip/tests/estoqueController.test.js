/**
 * Testes de unidade de src/controllers/estoque.controller.js — escritos na
 * Etapa 4 (Estoque V1). O controller já existia (criado/auditado na Etapa
 * 3, junto do módulo Produtos); este arquivo só o exercita para a nova
 * tela de Estoque, sem alterar seu comportamento.
 *
 * Cobre a lista de validação pedida na Etapa 4:
 *   2. criar variação (adicionarVariacao)
 *   3. alterar quantidade (atualizarQuantidade)
 *   4. rejeitar quantidade negativa
 *   5. rejeitar quantidade inválida (não inteira / não numérica)
 *   6. impedir duplicação de variação (upsert por produto+tamanho+cor)
 *   11/12. isolamento entre lojas — Loja A não pode alterar estoque da Loja B
 *
 * (Os cenários de bloqueio de acesso pela cadeia usuário→loja→produto→estoque
 * já são cobertos em tests/autorizacaoService.test.js e
 * tests/middlewareAutorizacao.test.js — este arquivo foca no que o
 * controller faz depois que essa cadeia já foi validada.)
 *
 * Usa Supabase falso (sem rede) via tests/helpers/mockSupabaseModule.js.
 * Rodar com: node --test tests/estoqueController.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const { adicionarVariacao, atualizarQuantidade } = require('../src/controllers/estoque.controller');

const UUID_LOJA_A = '11111111-1111-1111-1111-111111111111';
const UUID_PRODUTO_A = '22222222-2222-2222-2222-222222222222';
const UUID_ESTOQUE_A = '33333333-3333-3333-3333-333333333333';

// --- adicionarVariacao ----------------------------------------------------

test('2) criar variação válida — 201, upsert com produto_id vindo de req.params (nunca do body)', async () => {
  const criado = {
    id: UUID_ESTOQUE_A,
    produto_id: UUID_PRODUTO_A,
    tamanho: 'M',
    cor: 'Preta',
    quantidade: 5,
  };
  const fake = criarSupabaseFake({ from: { estoque: { data: criado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { tamanho: 'M', cor: 'Preta', quantidade: 5 },
  };
  const res = criarResMock();

  await adicionarVariacao(req, res);

  assert.equal(res.statusCode, 201);
  assert.deepEqual(res.body, criado);
  assert.equal(fake.chamadasFrom[0].upsertDados.produto_id, UUID_PRODUTO_A);
  assert.equal(fake.chamadasFrom[0].upsertDados.tamanho, 'M');
  assert.equal(fake.chamadasFrom[0].upsertDados.cor, 'Preta');
});

test('2b) criar variação — tamanho e cor são aceitos como texto livre (não há enum rígido)', async () => {
  const criado = { id: UUID_ESTOQUE_A, produto_id: UUID_PRODUTO_A, tamanho: '38', cor: 'Verde-oliva', quantidade: 2 };
  const fake = criarSupabaseFake({ from: { estoque: { data: criado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { tamanho: '38', cor: 'Verde-oliva', quantidade: 2 },
  };
  const res = criarResMock();

  await adicionarVariacao(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(fake.chamadasFrom[0].upsertDados.tamanho, '38');
  assert.equal(fake.chamadasFrom[0].upsertDados.cor, 'Verde-oliva');
});

test('rejeitar tamanho/cor vazios — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const corpo of [
    { tamanho: '', cor: 'Preta', quantidade: 1 },
    { tamanho: 'M', cor: '   ', quantidade: 1 },
    { tamanho: undefined, cor: 'Preta', quantidade: 1 },
  ]) {
    const req = { params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A }, body: corpo };
    const res = criarResMock();
    await adicionarVariacao(req, res);
    assert.equal(res.statusCode, 400);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'não deveria ter tocado no banco');
});

test('4) rejeitar quantidade negativa ao criar variação — 400, nunca chega a chamar o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { tamanho: 'M', cor: 'Preta', quantidade: -1 },
  };
  const res = criarResMock();

  await adicionarVariacao(req, res);

  assert.equal(res.statusCode, 400);
  assert.match(res.body.erro, /quantidade/i);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('5) rejeitar quantidade quebrada/inválida ao criar variação — 400', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const quantidadeInvalida of [1.5, 'dez', NaN, {}]) {
    const req = {
      params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
      body: { tamanho: 'M', cor: 'Preta', quantidade: quantidadeInvalida },
    };
    const res = criarResMock();
    await adicionarVariacao(req, res);
    assert.equal(res.statusCode, 400);
  }
  assert.equal(fake.chamadasFrom.length, 0);
});

test('quantidade omitida ao criar variação — assume 0 (não rejeita)', async () => {
  const criado = { id: UUID_ESTOQUE_A, produto_id: UUID_PRODUTO_A, tamanho: 'M', cor: 'Preta', quantidade: 0 };
  const fake = criarSupabaseFake({ from: { estoque: { data: criado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { tamanho: 'M', cor: 'Preta' },
  };
  const res = criarResMock();

  await adicionarVariacao(req, res);

  assert.equal(res.statusCode, 201);
  assert.equal(fake.chamadasFrom[0].upsertDados.quantidade, 0);
});

test('6) impedir duplicação de variação — upsert usa onConflict produto_id,tamanho,cor (atualiza em vez de duplicar)', async () => {
  const atualizado = { id: UUID_ESTOQUE_A, produto_id: UUID_PRODUTO_A, tamanho: 'M', cor: 'Preta', quantidade: 9 };
  const fake = criarSupabaseFake({ from: { estoque: { data: atualizado, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A },
    body: { tamanho: 'M', cor: 'Preta', quantidade: 9 },
  };
  const res = criarResMock();

  await adicionarVariacao(req, res);

  assert.equal(res.statusCode, 201);
  assert.deepEqual(fake.chamadasFrom[0].upsertOpcoes, { onConflict: 'produto_id,tamanho,cor' });
  // Nenhuma segunda linha é criada: o "id" retornado é o mesmo registro
  // (o banco decide isso via a constraint unique real; aqui confirmamos
  // que o controller sempre pede upsert com esse onConflict, nunca insert puro).
  assert.equal(res.body.id, UUID_ESTOQUE_A);
});

// --- atualizarQuantidade ---------------------------------------------------

test('3) alterar quantidade — sucesso quando o registro pertence a esse produto/loja', async () => {
  const estoqueExistente = { id: UUID_ESTOQUE_A, produto_id: UUID_PRODUTO_A, tamanho: 'M', cor: 'Preta', quantidade: 5 };
  const atualizado = { ...estoqueExistente, quantidade: 12 };
  const fake = criarSupabaseFake({ from: { estoque: [{ data: estoqueExistente, error: null }, { data: atualizado, error: null }] } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: UUID_ESTOQUE_A },
    body: { quantidade: 12 },
  };
  const res = criarResMock();

  await atualizarQuantidade(req, res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.quantidade, 12);
});

test('4b) rejeitar quantidade negativa ao atualizar — 400, nunca consulta o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: UUID_ESTOQUE_A },
    body: { quantidade: -5 },
  };
  const res = criarResMock();

  await atualizarQuantidade(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('5b) rejeitar quantidade quebrada/inválida ao atualizar — 400', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  for (const quantidadeInvalida of [2.5, 'cinco', undefined, null]) {
    const req = {
      params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: UUID_ESTOQUE_A },
      body: { quantidade: quantidadeInvalida },
    };
    const res = criarResMock();
    await atualizarQuantidade(req, res);
    assert.equal(res.statusCode, 400);
  }
  assert.equal(fake.chamadasFrom.length, 0);
});

test('estoqueId com formato inválido — 400, nunca consulta o banco', async () => {
  const fake = criarSupabaseFake({});
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: 'nao-e-uuid' },
    body: { quantidade: 5 },
  };
  const res = criarResMock();

  await atualizarQuantidade(req, res);

  assert.equal(res.statusCode, 400);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('11/12) isolamento entre lojas — estoque de OUTRA loja/produto não é encontrado nem alterado (404)', async () => {
  // Simula: o estoqueId existe no banco, mas pertence a um produto de
  // OUTRA loja. buscarEstoqueDaLoja (services/autorizacao.service.js)
  // filtra por produtos.loja_id = lojaId e não encontra nada — igual ao
  // comportamento real do Postgres para esse cenário.
  const fake = criarSupabaseFake({ from: { estoque: { data: null, error: null } } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: UUID_ESTOQUE_A }, // na verdade é da Loja B
    body: { quantidade: 999 },
  };
  const res = criarResMock();

  await atualizarQuantidade(req, res);

  assert.equal(res.statusCode, 404);
  // Só a consulta de verificação (buscarEstoqueDaLoja) roda — o update
  // nunca é disparado porque a função retorna antes.
  assert.equal(fake.chamadasFrom.length, 1);
  assert.equal(fake.chamadasFrom[0].delete, false);
  assert.equal(fake.chamadasFrom[0].updateDados, undefined);
});

test('7) estoque zerado — quantidade 0 é um valor válido (não é tratado como "vazio")', async () => {
  const estoqueExistente = { id: UUID_ESTOQUE_A, produto_id: UUID_PRODUTO_A, tamanho: 'M', cor: 'Preta', quantidade: 3 };
  const zerado = { ...estoqueExistente, quantidade: 0 };
  const fake = criarSupabaseFake({ from: { estoque: [{ data: estoqueExistente, error: null }, { data: zerado, error: null }] } });
  supabase.from = fake.from;

  const req = {
    params: { lojaId: UUID_LOJA_A, produtoId: UUID_PRODUTO_A, estoqueId: UUID_ESTOQUE_A },
    body: { quantidade: 0 },
  };
  const res = criarResMock();

  await atualizarQuantidade(req, res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.quantidade, 0);
});

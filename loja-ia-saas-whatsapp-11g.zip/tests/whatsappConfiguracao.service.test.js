/**
 * Testes de unidade de src/services/whatsappConfiguracao.service.js.
 *
 * Etapa 10B: base de banco + camada backend para guardar a configuração de
 * WhatsApp de cada loja. SEM integração real com nenhum provedor.
 *
 * Cobre os cenários A-O pedidos na etapa:
 *   A) criação de configuração válida;
 *   B) rejeição de lojaId inválido;
 *   C) rejeição de provedor vazio;
 *   D) rejeição de número vazio;
 *   E) busca de configuração da própria loja;
 *   F) buscar configuração de outra loja → não encontrado;
 *   G) atualização exige correspondência entre configuração e loja;
 *   H) atualizar configuração de outra loja é bloqueado;
 *   I) desativação respeita o isolamento por loja;
 *   J) loja inexistente é rejeitada;
 *   K) duplicidade é tratada corretamente;
 *   L) nenhum token/API key/secret é salvo ou retornado;
 *   M) nenhum request HTTP é feito;
 *   N) nenhum código chama Meta/Twilio/Z-API/Evolution;
 *   O) configurações de lojas diferentes permanecem isoladas.
 * Extras: validações restantes, erro inesperado de banco, e coerência
 * entre a migration 003 e o schema.sql.
 *
 * Usa apenas fakes (tests/helpers/supabaseFake.js + um banco em memória
 * definido neste arquivo). Não depende de Supabase real nem de internet.
 *
 * Rodar com: node --test tests/whatsappConfiguracao.service.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();

const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const {
  criarConfiguracaoWhatsapp,
  buscarConfiguracaoWhatsapp,
  listarConfiguracoesWhatsapp,
  atualizarConfiguracaoWhatsapp,
  desativarConfiguracaoWhatsapp,
  ErroConfiguracaoInvalida,
  ErroConfiguracaoNaoEncontrada,
  ErroLojaNaoEncontrada,
  ErroConfiguracaoDuplicada,
  ErroConfiguracaoBanco,
  COLUNAS_PUBLICAS,
} = require('../src/services/whatsappConfiguracao.service');

const LOJA_A = '11111111-1111-4111-8111-111111111111';
const LOJA_B = '22222222-2222-4222-8222-222222222222';
const LOJA_INEXISTENTE = '99999999-9999-4999-8999-999999999999';
const CONFIG_INEXISTENTE = 'ffffffff-ffff-4fff-8fff-ffffffffffff';

const DADOS_VALIDOS = {
  provedor: 'meta',
  numero_whatsapp: '+55 11 91234-5678',
  identificador_externo: 'ext-123',
};

// ---------------------------------------------------------------
// Banco em memória, plugado no fake existente (tests/helpers/supabaseFake.js)
// via configuração por função. Reproduz as regras do banco que o service
// usa: FK de loja_id (23503), índices únicos parciais entre configurações
// ativas (23505) e filtros .eq() combinados (id + loja_id).
// ---------------------------------------------------------------
const DATA_FIXA = '2000-01-01T00:00:00.000Z';

function criarBanco({ lojasExistentes = [LOJA_A, LOJA_B], colunasExtrasNaSaida = null } = {}) {
  const lojas = new Set(lojasExistentes);
  const linhas = [];
  let sequencia = 0;

  const novoId = () => `aaaaaaaa-0000-4000-8000-${String(++sequencia).padStart(12, '0')}`;
  const saida = (linha) => ({ ...linha, ...(colunasExtrasNaSaida || {}) });
  const bate = (linha, filtros) => Object.entries(filtros).every(([coluna, valor]) => linha[coluna] === valor);

  function conflita(candidata, ignorarId) {
    if (!candidata.ativo) return false;
    return linhas.some(
      (l) =>
        l.id !== ignorarId &&
        l.ativo &&
        l.provedor === candidata.provedor &&
        (l.numero_whatsapp === candidata.numero_whatsapp ||
          (candidata.identificador_externo != null && l.identificador_externo === candidata.identificador_externo))
    );
  }

  const erroDuplicado = {
    code: '23505',
    message: 'duplicate key value violates unique constraint "uq_whatsapp_config_ativa_provedor_numero"',
    details: 'Key (provedor, numero_whatsapp)=(meta, +55 11 91234-5678) already exists.',
  };

  return {
    linhas,
    lojas,

    executarLojas(ctx) {
      return { data: lojas.has(ctx.filtros.id) ? { id: ctx.filtros.id } : null, error: null };
    },

    executar(ctx) {
      if (ctx.insertDados) {
        const dados = ctx.insertDados;
        if (!lojas.has(dados.loja_id)) {
          return { data: null, error: { code: '23503', message: 'violates foreign key constraint "whatsapp_configuracoes_loja_id_fkey"' } };
        }
        const nova = {
          id: novoId(),
          identificador_externo: null,
          ativo: true,
          created_at: DATA_FIXA,
          updated_at: DATA_FIXA,
          ...dados,
        };
        if (conflita(nova, null)) return { data: null, error: erroDuplicado };
        linhas.push(nova);
        return { data: saida(nova), error: null };
      }

      if (ctx.updateDados) {
        const alvo = linhas.find((l) => bate(l, ctx.filtros));
        if (!alvo) return { data: null, error: null };
        if (conflita({ ...alvo, ...ctx.updateDados }, alvo.id)) return { data: null, error: erroDuplicado };
        Object.assign(alvo, ctx.updateDados);
        return { data: saida(alvo), error: null };
      }

      const encontradas = linhas.filter((l) => bate(l, ctx.filtros));
      if (ctx.filtros.id !== undefined) {
        return { data: encontradas[0] ? saida(encontradas[0]) : null, error: null };
      }
      return { data: encontradas.map(saida), error: null };
    },
  };
}

function instalarFake(banco, extra = {}) {
  const fake = criarSupabaseFake({
    from: { whatsapp_configuracoes: banco.executar, lojas: banco.executarLojas, ...extra },
  });
  supabase.from = fake.from;
  return fake;
}

const chamadasDaTabela = (fake, tabela) => fake.chamadasFrom.filter((c) => c.tabela === tabela);
const instantaneo = (banco) => JSON.stringify(banco.linhas);

// ---------------------------------------------------------------
// A) criação de configuração válida
// ---------------------------------------------------------------
test('A) cria configuração válida para a loja, normalizando provedor e espaços', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);

  const criada = await criarConfiguracaoWhatsapp(
    { provedor: '  Meta ', numero_whatsapp: '  +55 11 91234-5678  ', identificador_externo: ' ext-123 ' },
    LOJA_A
  );

  assert.equal(criada.loja_id, LOJA_A);
  assert.equal(criada.provedor, 'meta'); // canônico: minúsculas, sem espaços nas pontas
  assert.equal(criada.numero_whatsapp, '+55 11 91234-5678'); // só aparado, sem reformatar
  assert.equal(criada.identificador_externo, 'ext-123');
  assert.equal(criada.ativo, true);
  assert.match(criada.id, /^[0-9a-f-]{36}$/);
  assert.deepEqual(Object.keys(criada).sort(), [...COLUNAS_PUBLICAS].sort());

  const insercao = chamadasDaTabela(fake, 'whatsapp_configuracoes')[0];
  assert.equal(insercao.insertDados.loja_id, LOJA_A);
  assert.equal(banco.linhas.length, 1);
});

test('A) identificador_externo é opcional; ativo=false pode ser informado na criação', async () => {
  const banco = criarBanco();
  instalarFake(banco);

  const semIdentificador = await criarConfiguracaoWhatsapp({ provedor: 'outro-provedor', numero_whatsapp: '5511999990000' }, LOJA_A);
  assert.equal(semIdentificador.identificador_externo, null);
  assert.equal(semIdentificador.ativo, true);

  const inativa = await criarConfiguracaoWhatsapp(
    { provedor: 'evolution', numero_whatsapp: '5511999990001', ativo: false },
    LOJA_A
  );
  assert.equal(inativa.ativo, false);
});

test('A) provedor é texto livre: aceita valores que nenhuma lista fechada conheceria', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp({ provedor: 'provedor-futuro-xyz', numero_whatsapp: '123' }, LOJA_A);
  assert.equal(criada.provedor, 'provedor-futuro-xyz');
  assert.equal(criada.numero_whatsapp, '123'); // sem regra rígida de formato de telefone
});

// ---------------------------------------------------------------
// B) rejeição de lojaId inválido
// ---------------------------------------------------------------
test('B) lojaId inválido é rejeitado em todas as operações, antes de qualquer consulta', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const invalidos = [undefined, null, '', 'nao-e-uuid', 123, {}, LOJA_A.slice(1), `${LOJA_A}x`];

  for (const lojaId of invalidos) {
    await assert.rejects(() => criarConfiguracaoWhatsapp(DADOS_VALIDOS, lojaId), ErroConfiguracaoInvalida);
    await assert.rejects(() => buscarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, lojaId), ErroConfiguracaoInvalida);
    await assert.rejects(() => listarConfiguracoesWhatsapp(lojaId), ErroConfiguracaoInvalida);
    await assert.rejects(() => atualizarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, lojaId, { ativo: true }), ErroConfiguracaoInvalida);
    await assert.rejects(() => desativarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, lojaId), ErroConfiguracaoInvalida);
  }
  assert.equal(fake.chamadasFrom.length, 0, 'nenhuma consulta pode ser feita com lojaId inválido');
});

test('B) id de configuração inválido é rejeitado em buscar/atualizar/desativar', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);

  for (const id of [undefined, null, '', 'abc', 42]) {
    await assert.rejects(() => buscarConfiguracaoWhatsapp(id, LOJA_A), ErroConfiguracaoInvalida);
    await assert.rejects(() => atualizarConfiguracaoWhatsapp(id, LOJA_A, { ativo: true }), ErroConfiguracaoInvalida);
    await assert.rejects(() => desativarConfiguracaoWhatsapp(id, LOJA_A), ErroConfiguracaoInvalida);
  }
  assert.equal(fake.chamadasFrom.length, 0);
});

// ---------------------------------------------------------------
// C) rejeição de provedor vazio
// ---------------------------------------------------------------
test('C) provedor vazio/ausente/não-texto é rejeitado na criação e na atualização', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const chamadasAntes = fake.chamadasFrom.length;

  for (const provedor of ['', '   ', '\t\n', undefined, null, 123, {}, []]) {
    await assert.rejects(
      () => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, numero_whatsapp: '5511000000001', provedor }, LOJA_A),
      ErroConfiguracaoInvalida
    );
  }
  for (const provedor of ['', '   ', null, 123]) {
    await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { provedor }), ErroConfiguracaoInvalida);
  }
  await assert.rejects(
    () => criarConfiguracaoWhatsapp({ numero_whatsapp: '5511000000001' }, LOJA_A),
    ErroConfiguracaoInvalida
  );
  assert.equal(fake.chamadasFrom.length, chamadasAntes, 'nenhuma consulta feita para entrada inválida');
  assert.equal(banco.linhas.length, 1);
});

// ---------------------------------------------------------------
// D) rejeição de número vazio
// ---------------------------------------------------------------
test('D) numero_whatsapp vazio/ausente/não-texto é rejeitado na criação e na atualização', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const chamadasAntes = fake.chamadasFrom.length;

  for (const numero of ['', '   ', '\n', undefined, null, 5511912345678, {}, []]) {
    await assert.rejects(
      () => criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: numero }, LOJA_A),
      ErroConfiguracaoInvalida
    );
  }
  for (const numero of ['', '  ', null, 5511912345678]) {
    await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { numero_whatsapp: numero }), ErroConfiguracaoInvalida);
  }
  assert.equal(fake.chamadasFrom.length, chamadasAntes);
  assert.equal(banco.linhas.length, 1);
});

// ---------------------------------------------------------------
// E) busca de configuração da própria loja
// ---------------------------------------------------------------
test('E) busca a configuração da própria loja filtrando por id E loja_id', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  const encontrada = await buscarConfiguracaoWhatsapp(criada.id, LOJA_A);
  assert.deepEqual(encontrada, criada);

  const consulta = chamadasDaTabela(fake, 'whatsapp_configuracoes').at(-1);
  assert.deepEqual(consulta.filtros, { id: criada.id, loja_id: LOJA_A });
});

test('E) listar devolve as configurações da própria loja (e lista vazia quando não há)', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  assert.deepEqual(await listarConfiguracoesWhatsapp(LOJA_A), []);

  const c1 = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const c2 = await criarConfiguracaoWhatsapp({ provedor: 'twilio', numero_whatsapp: '5511888880000' }, LOJA_A);

  const lista = await listarConfiguracoesWhatsapp(LOJA_A);
  assert.deepEqual(lista.map((c) => c.id), [c1.id, c2.id]);
  assert.deepEqual(chamadasDaTabela(fake, 'whatsapp_configuracoes').at(-1).filtros, { loja_id: LOJA_A });
});

// ---------------------------------------------------------------
// F) buscar configuração de outra loja → não encontrado
// ---------------------------------------------------------------
test('F) buscar a configuração de OUTRA loja resulta em não encontrado (indistinguível de inexistente)', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const deA = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  const erroOutraLoja = await buscarConfiguracaoWhatsapp(deA.id, LOJA_B).catch((e) => e);
  const erroInexistente = await buscarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A).catch((e) => e);

  assert.ok(erroOutraLoja instanceof ErroConfiguracaoNaoEncontrada);
  assert.ok(erroInexistente instanceof ErroConfiguracaoNaoEncontrada);
  assert.equal(erroOutraLoja.message, erroInexistente.message, 'a resposta não pode revelar que o id existe em outra loja');

  // A consulta feita em nome da loja B usou id E loja_id de B — nunca só o id.
  const consulta = chamadasDaTabela(fake, 'whatsapp_configuracoes').find((c) => c.filtros.loja_id === LOJA_B);
  assert.deepEqual(consulta.filtros, { id: deA.id, loja_id: LOJA_B });
});

// ---------------------------------------------------------------
// G) atualização exige correspondência entre configuração e loja
// ---------------------------------------------------------------
test('G) atualizar filtra por id E loja_id na própria instrução UPDATE e nunca envia loja_id', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  const atualizada = await atualizarConfiguracaoWhatsapp(
    criada.id,
    LOJA_A,
    { provedor: ' Twilio ', numero_whatsapp: ' 5511777770000 ', identificador_externo: null, ativo: false }
  );

  assert.equal(atualizada.id, criada.id);
  assert.equal(atualizada.loja_id, LOJA_A); // continua na mesma loja
  assert.equal(atualizada.provedor, 'twilio');
  assert.equal(atualizada.numero_whatsapp, '5511777770000');
  assert.equal(atualizada.identificador_externo, null); // null limpa o identificador
  assert.equal(atualizada.ativo, false);
  assert.notEqual(atualizada.updated_at, criada.updated_at, 'updated_at deve ser renovado');

  const consulta = chamadasDaTabela(fake, 'whatsapp_configuracoes').find((c) => c.updateDados);
  assert.deepEqual(consulta.filtros, { id: criada.id, loja_id: LOJA_A });
  assert.deepEqual(
    Object.keys(consulta.updateDados).sort(),
    ['ativo', 'identificador_externo', 'numero_whatsapp', 'provedor', 'updated_at']
  );
  assert.equal('loja_id' in consulta.updateDados, false);
  assert.equal('id' in consulta.updateDados, false);
});

test('G) atualizar com configuração inexistente na loja → não encontrado', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  await assert.rejects(
    () => atualizarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A, { ativo: false }),
    ErroConfiguracaoNaoEncontrada
  );
});

test('G) atualizar valida os dados: vazio, campos desconhecidos, tipos e undefined', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS }, LOJA_A);
  const antes = instantaneo(banco);
  const chamadasAntes = fake.chamadasFrom.length;

  for (const dados of [undefined, null, 'texto', 42, [], {}, { identificador_externo: undefined }]) {
    await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, dados), ErroConfiguracaoInvalida);
  }
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { ativo: 'true' }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { ativo: null }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { ativo: 1 }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { identificador_externo: 123 }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { identificador_externo: '   ' }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { identificador_externo: 'x'.repeat(256) }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { provedor: 'p'.repeat(51) }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { numero_whatsapp: '1'.repeat(65) }), ErroConfiguracaoInvalida);
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { campo_qualquer: 'x' }), ErroConfiguracaoInvalida);

  assert.equal(fake.chamadasFrom.length, chamadasAntes, 'nenhuma consulta para dados inválidos');
  assert.equal(instantaneo(banco), antes);
});

test('G) criar valida ativo, identificador_externo e dados que não são objeto', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);

  for (const dados of [undefined, null, 'texto', 42, []]) {
    await assert.rejects(() => criarConfiguracaoWhatsapp(dados, LOJA_A), ErroConfiguracaoInvalida);
  }
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, ativo: 'sim' }, LOJA_A), ErroConfiguracaoInvalida);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, ativo: null }, LOJA_A), ErroConfiguracaoInvalida);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, identificador_externo: 55 }, LOJA_A), ErroConfiguracaoInvalida);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, identificador_externo: {} }, LOJA_A), ErroConfiguracaoInvalida);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, identificador_externo: '' }, LOJA_A), ErroConfiguracaoInvalida);

  assert.equal(fake.chamadasFrom.length, 0);
  assert.equal(banco.linhas.length, 0);
});

// ---------------------------------------------------------------
// H) atualizar configuração de outra loja é bloqueado
// ---------------------------------------------------------------
test('H) loja B não consegue atualizar a configuração da loja A', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  const deA = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const antes = instantaneo(banco);

  await assert.rejects(
    () => atualizarConfiguracaoWhatsapp(deA.id, LOJA_B, { numero_whatsapp: '5511000000000', ativo: false }),
    ErroConfiguracaoNaoEncontrada
  );
  assert.equal(instantaneo(banco), antes, 'a configuração da loja A não pode ter mudado');
});

test('H) não é possível "mover" uma configuração para outra loja enviando loja_id em dados', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const deA = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const antes = instantaneo(banco);
  const chamadasAntes = fake.chamadasFrom.length;

  for (const chave of ['loja_id', 'lojaId', 'id', 'created_at', 'updated_at']) {
    await assert.rejects(
      () => atualizarConfiguracaoWhatsapp(deA.id, LOJA_A, { [chave]: LOJA_B }),
      ErroConfiguracaoInvalida,
      `campo ${chave} não pode ser aceito em atualizar`
    );
  }
  // Mesmo pedindo em nome da própria loja A, o loja_id no corpo é rejeitado.
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(deA.id, LOJA_A, { ativo: false, loja_id: LOJA_B }), ErroConfiguracaoInvalida);

  assert.equal(fake.chamadasFrom.length, chamadasAntes);
  assert.equal(instantaneo(banco), antes);
});

test('H) loja_id enviado em dados na CRIAÇÃO nunca determina a loja', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);

  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, loja_id: LOJA_B }, LOJA_A), ErroConfiguracaoInvalida);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, lojaId: LOJA_B }, LOJA_A), ErroConfiguracaoInvalida);

  assert.equal(banco.linhas.length, 0);
  assert.equal(chamadasDaTabela(fake, 'whatsapp_configuracoes').length, 0);
});

// ---------------------------------------------------------------
// I) desativação respeita o isolamento por loja
// ---------------------------------------------------------------
test('I) desativar filtra por id E loja_id; loja B não desativa a configuração da loja A', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const deA = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  await assert.rejects(() => desativarConfiguracaoWhatsapp(deA.id, LOJA_B), ErroConfiguracaoNaoEncontrada);
  assert.equal((await buscarConfiguracaoWhatsapp(deA.id, LOJA_A)).ativo, true, 'continua ativa');

  const desativada = await desativarConfiguracaoWhatsapp(deA.id, LOJA_A);
  assert.equal(desativada.ativo, false);
  assert.equal(desativada.loja_id, LOJA_A);
  assert.notEqual(desativada.updated_at, deA.updated_at);

  const consulta = chamadasDaTabela(fake, 'whatsapp_configuracoes').filter((c) => c.updateDados).at(-1);
  assert.deepEqual(consulta.filtros, { id: deA.id, loja_id: LOJA_A });
  assert.deepEqual(Object.keys(consulta.updateDados).sort(), ['ativo', 'updated_at']);
  assert.equal(consulta.updateDados.ativo, false);

  // Não apaga: a linha continua existindo, só inativa (nenhum DELETE foi emitido).
  assert.equal(banco.linhas.length, 1);
  assert.equal(fake.chamadasFrom.some((c) => c.delete), false);
});

test('I) desativar é idempotente e devolve não encontrado para id inexistente', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  await desativarConfiguracaoWhatsapp(criada.id, LOJA_A);
  const denovo = await desativarConfiguracaoWhatsapp(criada.id, LOJA_A);
  assert.equal(denovo.ativo, false);

  await assert.rejects(() => desativarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A), ErroConfiguracaoNaoEncontrada);
});

// ---------------------------------------------------------------
// J) loja inexistente é rejeitada
// ---------------------------------------------------------------
test('J) criar para loja inexistente é rejeitado e nada é gravado', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);

  await assert.rejects(() => criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_INEXISTENTE), ErroLojaNaoEncontrada);

  assert.equal(banco.linhas.length, 0);
  assert.equal(chamadasDaTabela(fake, 'lojas')[0].filtros.id, LOJA_INEXISTENTE);
  assert.equal(chamadasDaTabela(fake, 'whatsapp_configuracoes').length, 0, 'nem tentou inserir');
});

test('J) se a loja sumir entre a checagem e o insert, a FK do banco também é traduzida em loja não encontrada', async () => {
  const banco = criarBanco({ lojasExistentes: [LOJA_A] });
  // A pré-checagem enxerga a loja, mas o insert falha na FK (loja removida no meio).
  instalarFake(banco, {
    lojas: () => ({ data: { id: LOJA_A }, error: null }),
    whatsapp_configuracoes: () => ({ data: null, error: { code: '23503', message: 'fk' } }),
  });

  await assert.rejects(() => criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A), ErroLojaNaoEncontrada);
});

// ---------------------------------------------------------------
// K) duplicidade é tratada corretamente
// ---------------------------------------------------------------
test('K) mesmo provedor + número na MESMA loja → duplicada (provedor comparado sem diferenciar maiúsculas)', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, identificador_externo: 'outro' }, LOJA_A), ErroConfiguracaoDuplicada);
  await assert.rejects(() => criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, provedor: 'META', identificador_externo: undefined }, LOJA_A), ErroConfiguracaoDuplicada);
  assert.equal(banco.linhas.length, 1);
});

test('K) mesmo provedor + número em OUTRA loja (ativo) → duplicada, sem revelar a outra loja', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  const erro = await criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: DADOS_VALIDOS.numero_whatsapp }, LOJA_B).catch((e) => e);

  assert.ok(erro instanceof ErroConfiguracaoDuplicada);
  const exposto = JSON.stringify({ message: erro.message, ...erro });
  assert.equal(exposto.includes(LOJA_A), false, 'não pode revelar a loja dona do número');
  assert.equal(/uq_whatsapp|duplicate key|Key \(/i.test(exposto), false, 'não pode vazar texto de constraint');
  assert.equal(banco.linhas.length, 1);
});

test('K) mesmo provedor + identificador_externo (ativo) → duplicada, mesmo com número diferente', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);

  await assert.rejects(
    () => criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: '5511000000042', identificador_externo: 'ext-123' }, LOJA_B),
    ErroConfiguracaoDuplicada
  );
  // Provedor diferente com o mesmo identificador não é conflito.
  const ok = await criarConfiguracaoWhatsapp({ provedor: 'outro', numero_whatsapp: '5511000000042', identificador_externo: 'ext-123' }, LOJA_B);
  assert.equal(ok.loja_id, LOJA_B);
});

test('K) configuração DESATIVADA não bloqueia: o número pode ser cadastrado de novo', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  const antiga = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  await desativarConfiguracaoWhatsapp(antiga.id, LOJA_A);

  const nova = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_B);
  assert.equal(nova.loja_id, LOJA_B);
  assert.equal(nova.ativo, true);
});

test('K) atualizar para um número já ativo em outra configuração, ou reativar com conflito → duplicada', async () => {
  const banco = criarBanco();
  instalarFake(banco);
  const a = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const b = await criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: '5511555550000' }, LOJA_B);

  // B tenta assumir o número de A (ativo).
  await assert.rejects(
    () => atualizarConfiguracaoWhatsapp(b.id, LOJA_B, { numero_whatsapp: DADOS_VALIDOS.numero_whatsapp }),
    ErroConfiguracaoDuplicada
  );
  assert.equal((await buscarConfiguracaoWhatsapp(b.id, LOJA_B)).numero_whatsapp, '5511555550000');

  // A desativa, B assume o número, A tenta reativar → conflito.
  await desativarConfiguracaoWhatsapp(a.id, LOJA_A);
  await atualizarConfiguracaoWhatsapp(b.id, LOJA_B, { numero_whatsapp: DADOS_VALIDOS.numero_whatsapp });
  await assert.rejects(() => atualizarConfiguracaoWhatsapp(a.id, LOJA_A, { ativo: true }), ErroConfiguracaoDuplicada);
  assert.equal((await buscarConfiguracaoWhatsapp(a.id, LOJA_A)).ativo, false);
});

// ---------------------------------------------------------------
// L) nenhum token/API key/secret é salvo ou retornado
// ---------------------------------------------------------------
test('L) campos de credencial/segredo são rejeitados na criação e na atualização, sem tocar no banco', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const antes = instantaneo(banco);
  const chamadasAntes = fake.chamadasFrom.length;

  const camposDeSegredo = [
    'access_token', 'accessToken', 'token', 'api_key', 'apiKey', 'apikey', 'secret', 'client_secret',
    'senha', 'password', 'credenciais', 'credentials', 'authorization', 'bearer_token', 'chave_api',
  ];
  for (const campo of camposDeSegredo) {
    const erroCriar = await criarConfiguracaoWhatsapp({ ...DADOS_VALIDOS, numero_whatsapp: '5511000000099', [campo]: 'SEGREDO-123' }, LOJA_A).catch((e) => e);
    assert.ok(erroCriar instanceof ErroConfiguracaoInvalida, `criar deveria rejeitar "${campo}"`);
    assert.equal(erroCriar.message.includes('SEGREDO-123'), false, 'o valor do segredo não pode aparecer no erro');

    const erroAtualizar = await atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { [campo]: 'SEGREDO-123' }).catch((e) => e);
    assert.ok(erroAtualizar instanceof ErroConfiguracaoInvalida, `atualizar deveria rejeitar "${campo}"`);
  }

  assert.equal(fake.chamadasFrom.length, chamadasAntes, 'nenhuma consulta feita com segredo no payload');
  assert.equal(instantaneo(banco), antes);
  assert.equal(instantaneo(banco).includes('SEGREDO-123'), false);
});

test('L) o que é enviado ao banco contém só colunas permitidas (nunca segredo)', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  await atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { ativo: false });
  await desativarConfiguracaoWhatsapp(criada.id, LOJA_A);

  const permitidas = new Set(COLUNAS_PUBLICAS);
  for (const chamada of chamadasDaTabela(fake, 'whatsapp_configuracoes')) {
    for (const carga of [chamada.insertDados, chamada.updateDados]) {
      if (!carga) continue;
      for (const coluna of Object.keys(carga)) {
        assert.ok(permitidas.has(coluna), `coluna inesperada enviada ao banco: ${coluna}`);
        assert.equal(/token|secret|senha|password|api_?key|credenc/i.test(coluna), false);
      }
    }
  }
});

test('L) mesmo que o banco devolva colunas extras (ex.: access_token), o service nunca as retorna', async () => {
  const banco = criarBanco({ colunasExtrasNaSaida: { access_token: 'EAAB-SEGREDO', api_key: 'KEY-SEGREDO', secret: 'S-SEGREDO' } });
  instalarFake(banco);

  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  const buscada = await buscarConfiguracaoWhatsapp(criada.id, LOJA_A);
  const listada = await listarConfiguracoesWhatsapp(LOJA_A);
  const atualizada = await atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { ativo: true });
  const desativada = await desativarConfiguracaoWhatsapp(criada.id, LOJA_A);

  for (const resultado of [criada, buscada, ...listada, atualizada, desativada]) {
    assert.deepEqual(Object.keys(resultado).sort(), [...COLUNAS_PUBLICAS].sort());
    assert.equal(/SEGREDO|access_token|api_key|secret/i.test(JSON.stringify(resultado)), false);
  }
  assert.equal(listada.length, 1);
});

test('L) o service pede colunas explícitas ao banco (nunca select *)', async () => {
  const banco = criarBanco();
  const fake = instalarFake(banco);
  const codigo = semComentarios(fs.readFileSync(require.resolve('../src/services/whatsappConfiguracao.service'), 'utf8'));
  assert.equal(/select\(\s*['"`]\*['"`]\s*\)/.test(codigo), false);

  // E o fake registra as chamadas: uma busca real também não usa "*".
  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  await buscarConfiguracaoWhatsapp(criada.id, LOJA_A);
  assert.ok(chamadasDaTabela(fake, 'whatsapp_configuracoes').length >= 2);
});

// ---------------------------------------------------------------
// M) nenhum request HTTP é feito
// ---------------------------------------------------------------
test('M) nenhuma operação do service faz request HTTP (http, https ou fetch)', async (t) => {
  const httpSpy = t.mock.method(http, 'request', () => { throw new Error('http.request não deveria ter sido chamado'); });
  const httpsSpy = t.mock.method(https, 'request', () => { throw new Error('https.request não deveria ter sido chamado'); });
  const httpGetSpy = t.mock.method(http, 'get', () => { throw new Error('http.get não deveria ter sido chamado'); });
  const httpsGetSpy = t.mock.method(https, 'get', () => { throw new Error('https.get não deveria ter sido chamado'); });
  const fetchSpy = t.mock.method(globalThis, 'fetch', () => { throw new Error('fetch não deveria ter sido chamado'); });

  const banco = criarBanco();
  instalarFake(banco);

  const criada = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A);
  await buscarConfiguracaoWhatsapp(criada.id, LOJA_A);
  await listarConfiguracoesWhatsapp(LOJA_A);
  await atualizarConfiguracaoWhatsapp(criada.id, LOJA_A, { numero_whatsapp: '5511222220000' });
  await desativarConfiguracaoWhatsapp(criada.id, LOJA_A);
  await buscarConfiguracaoWhatsapp(criada.id, LOJA_B).catch(() => {});
  await criarConfiguracaoWhatsapp({ provedor: '', numero_whatsapp: '1' }, LOJA_A).catch(() => {});

  for (const espiao of [httpSpy, httpsSpy, httpGetSpy, httpsGetSpy, fetchSpy]) {
    assert.equal(espiao.mock.callCount(), 0);
  }
});

// ---------------------------------------------------------------
// N) nenhum código chama Meta/Twilio/Z-API/Evolution
// ---------------------------------------------------------------
function semComentarios(codigo) {
  return codigo
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:'"`])\/\/.*$/gm, '$1');
}

test('N) o service não importa nem referencia nenhum provedor/cliente HTTP', () => {
  const caminho = require.resolve('../src/services/whatsappConfiguracao.service');
  const codigo = semComentarios(fs.readFileSync(caminho, 'utf8'));

  // Só depende do cliente Supabase (banco) e dos validadores do projeto.
  const dependencias = [...codigo.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]).sort();
  assert.deepEqual(dependencias, ['../config/supabase', '../utils/validacao']);

  assert.equal(/\bfetch\s*\(/.test(codigo), false, 'sem fetch');
  assert.equal(/XMLHttpRequest|axios|node-fetch|got\(|undici|require\(['"]https?['"]\)|require\(['"]net['"]\)/i.test(codigo), false, 'sem cliente HTTP');
  assert.equal(/https?:\/\//i.test(codigo), false, 'sem URL');
  assert.equal(/process\.env/.test(codigo), false, 'sem variáveis de ambiente (nenhuma credencial)');
  assert.equal(
    /twilio|z-?api|evolution|graph\.facebook|\bmeta\b|whatsapp-web|baileys|wppconnect/i.test(codigo),
    false,
    'sem referência a provedores de WhatsApp no código'
  );
});

test('N) nenhum arquivo novo desta etapa (service, migration 003) referencia URL de provedor', () => {
  const raiz = path.join(__dirname, '..');
  const arquivos = [
    'src/services/whatsappConfiguracao.service.js',
    'src/db/migrations/003_whatsapp_configuracoes.sql',
  ];
  for (const arquivo of arquivos) {
    const conteudo = fs.readFileSync(path.join(raiz, arquivo), 'utf8');
    assert.equal(/https?:\/\//i.test(conteudo), false, `${arquivo} não deve conter URL`);
  }
});

// ---------------------------------------------------------------
// O) configurações de lojas diferentes permanecem isoladas
// ---------------------------------------------------------------
test('O) lojas diferentes têm configurações isoladas em listar, buscar, atualizar e desativar', async () => {
  const banco = criarBanco();
  instalarFake(banco);

  const a1 = await criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: '5511000000001' }, LOJA_A);
  const a2 = await criarConfiguracaoWhatsapp({ provedor: 'twilio', numero_whatsapp: '5511000000002' }, LOJA_A);
  const b1 = await criarConfiguracaoWhatsapp({ provedor: 'meta', numero_whatsapp: '5511000000003' }, LOJA_B);

  // listar
  assert.deepEqual((await listarConfiguracoesWhatsapp(LOJA_A)).map((c) => c.id), [a1.id, a2.id]);
  assert.deepEqual((await listarConfiguracoesWhatsapp(LOJA_B)).map((c) => c.id), [b1.id]);

  // buscar cruzado
  await assert.rejects(() => buscarConfiguracaoWhatsapp(b1.id, LOJA_A), ErroConfiguracaoNaoEncontrada);
  await assert.rejects(() => buscarConfiguracaoWhatsapp(a1.id, LOJA_B), ErroConfiguracaoNaoEncontrada);
  await assert.rejects(() => buscarConfiguracaoWhatsapp(a2.id, LOJA_B), ErroConfiguracaoNaoEncontrada);

  // atualizar/desativar em uma loja não afeta a outra
  await atualizarConfiguracaoWhatsapp(a1.id, LOJA_A, { numero_whatsapp: '5511000000010' });
  await desativarConfiguracaoWhatsapp(b1.id, LOJA_B);

  assert.equal((await buscarConfiguracaoWhatsapp(b1.id, LOJA_B)).numero_whatsapp, '5511000000003');
  assert.equal((await buscarConfiguracaoWhatsapp(b1.id, LOJA_B)).ativo, false);
  assert.equal((await buscarConfiguracaoWhatsapp(a1.id, LOJA_A)).numero_whatsapp, '5511000000010');
  assert.equal((await buscarConfiguracaoWhatsapp(a1.id, LOJA_A)).ativo, true);
  assert.equal((await buscarConfiguracaoWhatsapp(a2.id, LOJA_A)).ativo, true);

  // toda linha guardada mantém a loja de origem
  assert.deepEqual(
    banco.linhas.map((l) => [l.id, l.loja_id]),
    [[a1.id, LOJA_A], [a2.id, LOJA_A], [b1.id, LOJA_B]]
  );
});

// ---------------------------------------------------------------
// Extra: erro inesperado do banco não vaza detalhes
// ---------------------------------------------------------------
test('erro inesperado do banco vira ErroConfiguracaoBanco com mensagem genérica (sem vazar detalhes)', async (t) => {
  t.mock.method(console, 'error', () => {});
  const erroInterno = { code: 'XX000', message: 'connection to server at 10.0.0.5 failed: password authentication failed for user "postgres"' };
  const banco = criarBanco();
  instalarFake(banco, { whatsapp_configuracoes: () => ({ data: null, error: erroInterno }) });

  const operacoes = [
    () => criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A),
    () => buscarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A),
    () => listarConfiguracoesWhatsapp(LOJA_A),
    () => atualizarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A, { ativo: true }),
    () => desativarConfiguracaoWhatsapp(CONFIG_INEXISTENTE, LOJA_A),
  ];
  for (const operacao of operacoes) {
    const erro = await operacao().catch((e) => e);
    assert.ok(erro instanceof ErroConfiguracaoBanco);
    assert.equal(/password|10\.0\.0\.5|postgres|XX000/i.test(erro.message), false);
  }
});

test('erro de banco ao checar a loja também é tratado sem vazar detalhes', async (t) => {
  t.mock.method(console, 'error', () => {});
  const banco = criarBanco();
  instalarFake(banco, { lojas: () => ({ data: null, error: { code: 'XX000', message: 'detalhe interno' } }) });

  const erro = await criarConfiguracaoWhatsapp(DADOS_VALIDOS, LOJA_A).catch((e) => e);
  assert.ok(erro instanceof ErroConfiguracaoBanco);
  assert.equal(erro.message.includes('detalhe interno'), false);
});

// ---------------------------------------------------------------
// Extra: migration 003 e schema.sql coerentes, sem coluna de segredo
// ---------------------------------------------------------------
const RAIZ = path.join(__dirname, '..');
const sqlMigration = fs.readFileSync(path.join(RAIZ, 'src/db/migrations/003_whatsapp_configuracoes.sql'), 'utf8');
const sqlSchema = fs.readFileSync(path.join(RAIZ, 'src/db/schema.sql'), 'utf8');

const semComentariosSql = (sql) => sql.replace(/--.*$/gm, '');
const normalizar = (texto) => texto.replace(/\s+/g, ' ').trim();

function comandosDaTabela(sql) {
  return semComentariosSql(sql)
    .split(';')
    .map(normalizar)
    .filter((cmd) => cmd.includes('whatsapp_configuracoes') && !/^drop policy/i.test(cmd))
    .sort();
}

test('SQL) o contrato da migration 003 continua integralmente representado no schema após migrations posteriores', () => {
  const daMigration = comandosDaTabela(sqlMigration);
  const doSchema = comandosDaTabela(sqlSchema);

  assert.ok(daMigration.length >= 6, 'esperado: create table, 3 índices, enable RLS e policy');
  for (const comando of daMigration) {
    assert.ok(doSchema.includes(comando), `comando da migration 003 ausente no schema: ${comando}`);
  }
});

test('SQL) estrutura da tabela: colunas, NOT NULL, FK, defaults e índices exigidos', () => {
  for (const sql of [sqlMigration, sqlSchema]) {
    const codigo = normalizar(semComentariosSql(sql));

    assert.match(codigo, /create table if not exists whatsapp_configuracoes/);
    assert.match(codigo, /id uuid primary key default gen_random_uuid\(\)/);
    assert.match(codigo, /loja_id uuid not null references lojas\(id\) on delete cascade/);
    assert.match(codigo, /provedor text not null/);
    assert.match(codigo, /numero_whatsapp text not null/);
    assert.match(codigo, /identificador_externo text,/); // opcional: sem NOT NULL
    assert.match(codigo, /ativo boolean not null default true/);
    assert.match(codigo, /created_at timestamptz not null default now\(\)/);
    assert.match(codigo, /updated_at timestamptz not null default now\(\)/);

    assert.match(codigo, /create index if not exists idx_whatsapp_configuracoes_loja_id on whatsapp_configuracoes \(loja_id\)/);
    assert.match(codigo, /create unique index if not exists uq_whatsapp_config_ativa_provedor_numero on whatsapp_configuracoes \(provedor, numero_whatsapp\) where ativo/);
    assert.match(codigo, /create unique index if not exists uq_whatsapp_config_ativa_provedor_identificador on whatsapp_configuracoes \(provedor, identificador_externo\) where ativo and identificador_externo is not null/);

    assert.match(codigo, /alter table whatsapp_configuracoes enable row level security/);
    assert.match(codigo, /create policy "dono ve whatsapp das suas lojas" on whatsapp_configuracoes/);
  }
});

test('SQL) a tabela só tem as colunas esperadas — nenhuma coluna de token/API key/secret/senha', () => {
  const esperadas = ['ativo', 'created_at', 'id', 'identificador_externo', 'loja_id', 'numero_whatsapp', 'provedor', 'updated_at'];

  for (const sql of [sqlMigration, sqlSchema]) {
    const bloco = semComentariosSql(sql).match(/create table if not exists whatsapp_configuracoes\s*\(([\s\S]*?)\n\);/);
    assert.ok(bloco, 'bloco create table não encontrado');

    const colunas = [...bloco[1].matchAll(/^ {2}([a-z_]+) (?:uuid|text|boolean|timestamptz)\b/gm)].map((m) => m[1]).sort();
    assert.deepEqual(colunas, esperadas);
    assert.equal(/token|secret|senha|password|api_?key|credenc|chave/i.test(colunas.join(' ')), false);
  }
});

const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const historico = require('../src/services/whatsappHistorico.service');

const LOJA_A = '11111111-1111-4111-8111-111111111111';
const LOJA_B = '22222222-2222-4222-8222-222222222222';
const CFG_A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const CONVERSA = '99999999-9999-4999-8999-999999999999';

function instalarBanco() {
  const conversas = new Map();
  const mensagens = [];
  const fake = criarSupabaseFake({
    from: {
      whatsapp_conversas: (ctx) => {
        if (!ctx.upsertDados) return { data: null, error: null };
        const d = ctx.upsertDados;
        const chave = `${d.loja_id}::${d.configuracao_id}::${d.contato}`;
        const atual = conversas.get(chave) || {
          id: CONVERSA,
          loja_id: d.loja_id,
          configuracao_id: d.configuracao_id,
          contato: d.contato,
        };
        conversas.set(chave, { ...atual, atualizado_em: d.atualizado_em });
        return { data: atual, error: null };
      },
      whatsapp_mensagens: (ctx) => {
        if (ctx.insertDados) mensagens.push({ ...ctx.insertDados });
        return { data: ctx.insertDados || null, error: null };
      },
    },
  });
  supabase.from = fake.from;
  return { fake, conversas, mensagens };
}

function mensagem(overrides = {}) {
  return {
    canal: 'whatsapp',
    lojaId: LOJA_A,
    configuracaoId: CFG_A,
    contato: '5511988887777',
    texto: 'Vocês têm camiseta P?',
    idExterno: 'wamid.10N.TESTE',
    ...overrides,
  };
}

function resposta(m = mensagem(), overrides = {}) {
  return {
    lojaId: m.lojaId,
    contato: m.contato,
    idExterno: m.idExterno,
    pergunta: m.texto,
    resposta: 'Sim, temos camiseta P.',
    ...overrides,
  };
}

test('10N A) registra entrada com loja/configuração/contato confiáveis e sem payload bruto', async () => {
  const { mensagens } = instalarBanco();
  const m = mensagem();
  const r = await historico.registrarMensagemRecebida(m, { provedor: 'meta' });
  assert.deepEqual(r, { conversaId: CONVERSA });
  assert.deepEqual(mensagens, [{
    conversa_id: CONVERSA,
    loja_id: LOJA_A,
    direcao: 'entrada',
    texto: m.texto,
    provedor: 'meta',
    id_externo: m.idExterno,
  }]);
  assert.equal('payload' in mensagens[0], false);
  assert.equal('token' in mensagens[0], false);
});

test('10N B) registra saída somente na mesma conversa/loja e sem inventar id externo', async () => {
  const { mensagens } = instalarBanco();
  const m = mensagem();
  await historico.registrarMensagemEnviada(m, resposta(m), { provedor: 'meta' });
  assert.deepEqual(mensagens[0], {
    conversa_id: CONVERSA,
    loja_id: LOJA_A,
    direcao: 'saida',
    texto: 'Sim, temos camiseta P.',
    provedor: 'meta',
    id_externo: null,
  });
});

test('10N C) conversa é particionada por loja/configuração/contato', async () => {
  const { conversas } = instalarBanco();
  await historico.registrarMensagemRecebida(mensagem(), { provedor: 'meta' });
  await historico.registrarMensagemRecebida(mensagem({ lojaId: LOJA_B, configuracaoId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb' }), { provedor: 'meta' });
  assert.equal(conversas.size, 2);
  assert.ok([...conversas.keys()].some((k) => k.startsWith(`${LOJA_A}::`)));
  assert.ok([...conversas.keys()].some((k) => k.startsWith(`${LOJA_B}::`)));
});

test('10N D) resposta com loja/contato/idExterno divergente é rejeitada antes de gravar', async () => {
  const { fake, mensagens } = instalarBanco();
  const m = mensagem();
  await assert.rejects(
    () => historico.registrarMensagemEnviada(m, resposta(m, { lojaId: LOJA_B }), { provedor: 'meta' }),
    TypeError,
  );
  assert.equal(mensagens.length, 0);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('10N E) contexto inválido e texto excessivo falham antes do banco', async () => {
  const { fake } = instalarBanco();
  await assert.rejects(() => historico.registrarMensagemRecebida(mensagem({ lojaId: 'forjada' }), { provedor: 'meta' }), TypeError);
  await assert.rejects(() => historico.registrarMensagemRecebida(mensagem({ texto: 'x'.repeat(12001) }), { provedor: 'meta' }), TypeError);
  assert.equal(fake.chamadasFrom.length, 0);
});

test('10N F) erro do banco vira erro genérico sem vazar SQL/segredo', async () => {
  const fake = criarSupabaseFake({
    from: { whatsapp_conversas: { data: null, error: { message: 'postgres senha=SUPERSEGREDO' } } },
  });
  supabase.from = fake.from;
  const erro = await historico.registrarMensagemRecebida(mensagem(), { provedor: 'meta' }).catch((e) => e);
  assert.ok(erro instanceof historico.ErroHistoricoWhatsapp);
  assert.equal(String(erro).includes('SUPERSEGREDO'), false);
  assert.equal(String(erro).includes('postgres'), false);
});

test('10N G) migration/schema reforçam isolamento multi-tenant com FKs compostas e RLS', () => {
  const migration = fs.readFileSync(path.join(__dirname, '../src/db/migrations/005_whatsapp_historico.sql'), 'utf8');
  const schema = fs.readFileSync(path.join(__dirname, '../src/db/schema.sql'), 'utf8');
  for (const sql of [migration, schema]) {
    assert.match(sql, /create table if not exists whatsapp_conversas/i);
    assert.match(sql, /create table if not exists whatsapp_mensagens/i);
    assert.match(sql, /foreign key \(configuracao_id, loja_id\)[\s\S]*references whatsapp_configuracoes\(id, loja_id\)/i);
    assert.match(sql, /foreign key \(conversa_id, loja_id\)[\s\S]*references whatsapp_conversas\(id, loja_id\)/i);
    assert.match(sql, /unique \(loja_id, configuracao_id, contato\)/i);
    assert.match(sql, /alter table whatsapp_conversas enable row level security/i);
    assert.match(sql, /alter table whatsapp_mensagens enable row level security/i);
    assert.match(sql, /dono ve conversas whatsapp das suas lojas/i);
    assert.match(sql, /dono ve mensagens whatsapp das suas lojas/i);
  }
});

test('10N H) schema do histórico não possui colunas de credencial nem payload bruto', () => {
  for (const arquivo of ['../src/db/migrations/005_whatsapp_historico.sql', '../src/db/schema.sql']) {
    const sql = fs.readFileSync(path.join(__dirname, arquivo), 'utf8');
    for (const tabela of ['whatsapp_conversas', 'whatsapp_mensagens']) {
      const bloco = sql.match(new RegExp(`create table if not exists ${tabela}\\s*\\(([\\s\\S]*?)\\);`, 'i'))?.[1];
      assert.ok(bloco);
      assert.equal(/access_token|api_key|secret|segredo|senha|credential|payload/i.test(bloco), false);
    }
  }
});

test('10N I) entrada já persistida em tentativa anterior não bloqueia retry legítimo', async () => {
  const fake = criarSupabaseFake({
    from: {
      whatsapp_conversas: (ctx) => ({
        data: {
          id: CONVERSA,
          loja_id: ctx.upsertDados.loja_id,
          configuracao_id: ctx.upsertDados.configuracao_id,
          contato: ctx.upsertDados.contato,
        },
        error: null,
      }),
      whatsapp_mensagens: { data: null, error: { code: '23505', message: 'duplicate key' } },
    },
  });
  supabase.from = fake.from;
  const resultado = await historico.registrarMensagemRecebida(mensagem(), { provedor: 'meta' });
  assert.deepEqual(resultado, { conversaId: CONVERSA });
});

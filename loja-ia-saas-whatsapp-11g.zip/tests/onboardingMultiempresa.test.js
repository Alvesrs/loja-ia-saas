const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const raiz = path.join(__dirname, '..');
const ler = (rel) => fs.readFileSync(path.join(raiz, rel), 'utf8');

test('10Y inclui página de onboarding de nova empresa', () => {
  const html = ler('public/onboarding.html');
  assert.match(html, /Cadastrar nova empresa/);
  assert.match(html, /Prompt Mestre/);
  assert.match(html, /Phone Number ID/);
  assert.match(html, /Access token/);
  assert.match(html, /js\/onboarding\.js/);
});

test('10Y onboarding cria loja com prompt e permite configurar WhatsApp', () => {
  const js = ler('public/js/onboarding.js');
  assert.match(js, /apiFetch\('\/lojas'/);
  assert.match(js, /prompt_mestre/);
  assert.match(js, /\/whatsapp/);
  assert.match(js, /\/credencial/);
  assert.match(js, /salvarLojaAtual/);
});

test('10Y painel permite selecionar entre várias empresas', () => {
  const loja = ler('public/js/loja.js');
  const layout = ler('public/js/layout.js');
  assert.match(loja, /LOJA_ID_KEY/);
  assert.match(loja, /selecionarLoja/);
  assert.match(layout, /seletor-loja-topbar/);
  assert.match(layout, /Nova empresa/);
});

test('10Y criação da loja aceita Prompt Mestre no mesmo POST', () => {
  const controller = ler('src/controllers/lojas.controller.js');
  assert.match(controller, /valorPrompt/);
  assert.match(controller, /prompt_mestre: promptMestre \|\| null/);
  assert.match(controller, /TAMANHO_MAXIMO_PROMPT_MESTRE/);
});

/**
 * Testes de unidade da lógica de CORS (src/config/cors.js).
 *
 * Correção da auditoria técnica: antes, sem ALLOWED_ORIGINS definido, o
 * CORS ficava aberto para qualquer origem em qualquer ambiente (inclusive
 * produção). Agora o comportamento depende do ambiente, e este arquivo
 * testa exatamente essa regra — sem precisar subir um servidor real.
 *
 * Rodar com: node --test tests/cors.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const { construirCorsOptions, REGEX_LOCALHOST } = require('../src/config/cors');

test('com ALLOWED_ORIGINS definido, usa a lista informada em qualquer ambiente', () => {
  const opcoesProd = construirCorsOptions({
    ambiente: 'production',
    origensPermitidas: ['https://painel.exemplo.com.br'],
  });
  assert.deepEqual(opcoesProd.origin, ['https://painel.exemplo.com.br']);

  const opcoesDev = construirCorsOptions({
    ambiente: 'development',
    origensPermitidas: ['https://painel.exemplo.com.br', 'https://outra.com'],
  });
  assert.deepEqual(opcoesDev.origin, ['https://painel.exemplo.com.br', 'https://outra.com']);
});

test('em produção sem ALLOWED_ORIGINS, CORS fica fechado (fail-safe)', () => {
  const opcoes = construirCorsOptions({ ambiente: 'production', origensPermitidas: [] });
  assert.equal(opcoes.origin, false);
});

test('fora de produção sem ALLOWED_ORIGINS, libera localhost automaticamente', () => {
  const opcoesDev = construirCorsOptions({ ambiente: 'development', origensPermitidas: [] });
  assert.equal(opcoesDev.origin, REGEX_LOCALHOST);

  const opcoesSemAmbiente = construirCorsOptions({ ambiente: undefined, origensPermitidas: [] });
  assert.equal(opcoesSemAmbiente.origin, REGEX_LOCALHOST);
});

test('REGEX_LOCALHOST aceita variações comuns de localhost e rejeita domínios externos', () => {
  assert.equal(REGEX_LOCALHOST.test('http://localhost'), true);
  assert.equal(REGEX_LOCALHOST.test('http://localhost:5173'), true);
  assert.equal(REGEX_LOCALHOST.test('https://127.0.0.1:3000'), true);
  assert.equal(REGEX_LOCALHOST.test('https://malicioso.com'), false);
  assert.equal(REGEX_LOCALHOST.test('http://naolocalhost.com'), false);
});

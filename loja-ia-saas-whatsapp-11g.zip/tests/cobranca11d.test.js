const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const raiz = path.join(__dirname, '..');
const ler = (rel) => fs.readFileSync(path.join(raiz, rel), 'utf8');

test('11D usa Asaas como provedor principal de checkout e webhook', () => {
  const app = ler('src/app.js');
  const rota = ler('src/routes/assinaturas.routes.js');
  const front = ler('public/js/plano.js');
  assert.match(app, /webhooks\/asaas/);
  assert.match(rota, /asaas\.controller/);
  assert.match(front, /Assinar com Asaas/);
  assert.equal(/ASAAS_API_KEY/.test(front), false);
});

test('11D cria checkout recorrente com campos exigidos pelo Asaas', () => {
  const svc = ler('src/services/asaas.service.js');
  assert.match(svc, /billingTypes:\s*\['CREDIT_CARD'\]/);
  assert.match(svc, /chargeTypes:\s*\['RECURRENT'\]/);
  assert.match(svc, /cycle:\s*'MONTHLY'/);
  assert.match(svc, /externalReference/);
  assert.match(svc, /\/v3\/checkouts/);
});

test('11D valida token do webhook e implementa idempotência por evento', () => {
  const ctrl = ler('src/controllers/asaas.controller.js');
  const svc = ler('src/services/asaas.service.js');
  assert.match(ctrl, /asaas-access-token/);
  assert.match(svc, /cobranca_webhook_eventos/);
  assert.match(svc, /23505/);
});

test('11D migração permite separar checkout Asaas do id da assinatura', () => {
  const mig = ler('src/db/migrations/011_cobranca_asaas_11d.sql');
  assert.match(mig, /provider_checkout_id/);
  assert.match(mig, /drop not null/);
  assert.match(mig, /cobranca_webhook_eventos/);
  assert.match(mig, /enable row level security/);
});

test('11D mantém sandbox como ambiente padrão seguro', () => {
  const svc = ler('src/services/asaas.service.js');
  const env = ler('.env.example');
  assert.match(svc, /ASAAS_ENVIRONMENT \|\| 'sandbox'/);
  assert.match(env, /^ASAAS_ENVIRONMENT=sandbox$/m);
});

// 11F: Asaas exige User-Agent identificando a aplicação e vencimento futuro no checkout.

test('11G reconcilia PAYMENT de assinatura pelo checkoutSession e salva o id recorrente', () => {
  const svc = ler('src/services/asaas.service.js');
  assert.match(svc, /checkoutSession/);
  assert.match(svc, /localizarCobrancaPorAssinaturaRemota/);
  assert.match(svc, /\/v3\/payments\?subscription=/);
  assert.match(svc, /provider_assinatura_id:\s*assinaturaId,\s*status_provider:\s*tipo/);
});

test('11G não considera SUBSCRIPTION_CREATED sozinho como confirmação financeira', () => {
  const svc = ler('src/services/asaas.service.js');
  assert.match(svc, /tipo\.startsWith\('SUBSCRIPTION_'\)/);
  assert.doesNotMatch(svc, /tipo === 'SUBSCRIPTION_CREATED'[\s\S]{0,300}ativarPlano/);
  assert.match(svc, /\['PAYMENT_CONFIRMED', 'PAYMENT_RECEIVED'\]\.includes\(tipo\)/);
});

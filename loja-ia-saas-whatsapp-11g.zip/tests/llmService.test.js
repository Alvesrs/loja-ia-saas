/**
 * Testes de unidade do adaptador de LLM (src/services/llm.service.js).
 *
 * Não fazem nenhuma chamada de rede real: `global.fetch` é substituído
 * temporariamente por uma função fake em cada teste que precisa simular
 * o provedor, e restaurado no afterEach. Nenhum teste aqui consome uma
 * API paga de verdade.
 *
 *   node tests/llmService.test.js
 *
 * Cobre os cenários pedidos na Etapa 9B:
 *   A) configuração sem API key
 *   B) chamada bem-sucedida (formato chat completions, padrão OpenAI/Groq)
 *   C) erro HTTP do provedor
 *   D) resposta inválida / em formato inesperado
 *   E) timeout e falha de comunicação (rede)
 *   F) a API key nunca aparece na resposta de erro nem é logada
 */
const assert = require('node:assert/strict');
const { test, afterEach } = require('node:test');

const llmService = require('../src/services/llm.service');

const ENV_VARS_LLM = [
  'LLM_PROVIDER_API_KEY',
  'LLM_PROVIDER_URL',
  'LLM_PROVIDER_MODEL',
  'LLM_TIMEOUT_MS',
  'LLM_MAX_TOKENS',
];

const CHAVE_FAKE = 'sk-chave-fake-de-teste-nao-usar-em-producao';

function limparEnvLlm() {
  for (const chave of ENV_VARS_LLM) delete process.env[chave];
}

function configurarEnvLlmFake(extra = {}) {
  limparEnvLlm();
  process.env.LLM_PROVIDER_API_KEY = CHAVE_FAKE;
  process.env.LLM_PROVIDER_URL = 'https://provedor-fake.exemplo/openai/v1/chat/completions';
  Object.assign(process.env, extra);
}

const fetchOriginal = global.fetch;
const consoleErrorOriginal = console.error;

afterEach(() => {
  limparEnvLlm();
  global.fetch = fetchOriginal;
  console.error = consoleErrorOriginal;
});

// --- A) Configuração sem API key -----------------------------------------

test('A) estaConfigurado() retorna false quando as variáveis de ambiente não existem', () => {
  limparEnvLlm();
  assert.equal(llmService.estaConfigurado(), false);
});

test('A) estaConfigurado() retorna true quando API key e URL estão definidas', () => {
  configurarEnvLlmFake();
  assert.equal(llmService.estaConfigurado(), true);
});

test('A) gerarResposta() rejeita com ErroLlmConfiguracaoAusente quando não há configuração', async () => {
  limparEnvLlm();
  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Tem camiseta azul?' }),
    llmService.ErroLlmConfiguracaoAusente
  );
});

test('A) gerarResposta() rejeita com ErroLlmRespostaInvalida quando a pergunta está vazia', async () => {
  configurarEnvLlmFake();
  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: '' }),
    llmService.ErroLlmRespostaInvalida
  );
});

// --- B) Chamada bem-sucedida ------------------------------------------------

test('B) gerarResposta() envia messages no formato chat completions e retorna o texto', async () => {
  configurarEnvLlmFake({ LLM_PROVIDER_MODEL: 'modelo-fake-de-teste' });

  let corpoEnviado = null;
  let headersEnviados = null;
  let urlChamada = null;

  global.fetch = async (url, opcoes) => {
    urlChamada = url;
    corpoEnviado = JSON.parse(opcoes.body);
    headersEnviados = opcoes.headers;
    return {
      ok: true,
      json: async () => ({
        choices: [{ message: { role: 'assistant', content: 'Sim, temos camiseta azul em estoque.' } }],
      }),
    };
  };

  const texto = await llmService.gerarResposta({
    systemPrompt: 'Você é um atendente de loja.',
    contexto: { produtos: ['Camiseta Azul'] },
    pergunta: 'Tem camiseta azul?',
  });

  assert.equal(texto, 'Sim, temos camiseta azul em estoque.');
  assert.equal(urlChamada, 'https://provedor-fake.exemplo/openai/v1/chat/completions');
  assert.equal(corpoEnviado.model, 'modelo-fake-de-teste');
  assert.equal(corpoEnviado.max_tokens, 500);
  assert.equal(Array.isArray(corpoEnviado.messages), true);
  assert.equal(corpoEnviado.messages[0].role, 'system');
  assert.match(corpoEnviado.messages[0].content, /Você é um atendente de loja\./);
  assert.match(corpoEnviado.messages[0].content, /Camiseta Azul/);
  assert.deepEqual(corpoEnviado.messages[1], { role: 'user', content: 'Tem camiseta azul?' });
  assert.equal(headersEnviados.Authorization, `Bearer ${CHAVE_FAKE}`);
});



test('B) gerarResposta() respeita LLM_MAX_TOKENS e limita valor máximo a 900', async () => {
  configurarEnvLlmFake({ LLM_MAX_TOKENS: '2500' });

  let corpoEnviado;
  global.fetch = async (url, opcoes) => {
    corpoEnviado = JSON.parse(opcoes.body);
    return {
      ok: true,
      json: async () => ({ choices: [{ message: { content: 'Resposta curta.' } }] }),
    };
  };

  await llmService.gerarResposta({ pergunta: 'Oi' });
  assert.equal(corpoEnviado.max_tokens, 900);
});

test('B) gerarResposta() funciona sem systemPrompt/contexto (usa um system prompt padrão)', async () => {
  configurarEnvLlmFake();

  global.fetch = async (url, opcoes) => {
    const corpo = JSON.parse(opcoes.body);
    assert.equal(corpo.messages.length, 2);
    assert.equal(typeof corpo.messages[0].content, 'string');
    return {
      ok: true,
      json: async () => ({ choices: [{ message: { content: 'Olá! Como posso ajudar?' } }] }),
    };
  };

  const texto = await llmService.gerarResposta({ pergunta: 'Oi' });
  assert.equal(texto, 'Olá! Como posso ajudar?');
});

// --- C) Erro HTTP do provedor ------------------------------------------------

test('C) gerarResposta() rejeita com ErroLlmProvedor quando o provedor responde com erro HTTP', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => ({
    ok: false,
    status: 401,
    text: async () => 'Unauthorized',
  });

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmProvedor
  );
});

test('C) gerarResposta() lida com falha ao ler o corpo do erro HTTP sem quebrar', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => ({
    ok: false,
    status: 500,
    text: async () => { throw new Error('corpo indisponível'); },
  });

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmProvedor
  );
});

// --- D) Resposta inválida -----------------------------------------------

test('D) gerarResposta() rejeita com ErroLlmRespostaInvalida quando o JSON não tem texto reconhecível', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => ({
    ok: true,
    json: async () => ({ campo_desconhecido: 'valor qualquer' }),
  });

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmRespostaInvalida
  );
});

test('D) gerarResposta() rejeita com ErroLlmRespostaInvalida quando o corpo não é JSON válido', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => ({
    ok: true,
    json: async () => { throw new Error('Unexpected token < in JSON'); },
  });

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmRespostaInvalida
  );
});

// --- E) Timeout e falha de comunicação -----------------------------------

test('E) gerarResposta() rejeita com ErroLlmProvedor em timeout (respeita LLM_TIMEOUT_MS)', async () => {
  configurarEnvLlmFake({ LLM_TIMEOUT_MS: '50' });

  // Simula um provedor que nunca responde, mas respeita o AbortSignal
  // (assim como o fetch nativo faria de verdade).
  global.fetch = (url, opcoes) => new Promise((resolve, reject) => {
    opcoes.signal.addEventListener('abort', () => {
      const erro = new Error('This operation was aborted');
      erro.name = 'AbortError';
      reject(erro);
    });
  });

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmProvedor
  );
});

test('E) gerarResposta() rejeita com ErroLlmProvedor quando a chamada de rede falha (ex: DNS/conexão)', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => {
    throw new Error('ECONNREFUSED');
  };

  await assert.rejects(
    () => llmService.gerarResposta({ pergunta: 'Oi' }),
    llmService.ErroLlmProvedor
  );
});

// --- F) A API key nunca vaza em erros/logs -----------------------------

test('F) a API key não aparece na mensagem de erro devolvida quando o provedor falha (HTTP)', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => ({
    ok: false,
    status: 401,
    text: async () => 'Unauthorized: invalid_api_key',
  });

  try {
    await llmService.gerarResposta({ pergunta: 'Oi' });
    assert.fail('deveria ter lançado erro');
  } catch (erro) {
    assert.equal(erro instanceof llmService.ErroLlmProvedor, true);
    assert.equal(erro.message.includes(CHAVE_FAKE), false);
    assert.equal(JSON.stringify(erro).includes(CHAVE_FAKE), false);
  }
});

test('F) a API key não aparece na mensagem de erro devolvida quando há falha de rede', async () => {
  configurarEnvLlmFake();

  global.fetch = async () => {
    throw new Error(`falha ao conectar usando a chave ${CHAVE_FAKE}`); // erro hipotético "ruidoso"
  };

  try {
    await llmService.gerarResposta({ pergunta: 'Oi' });
    assert.fail('deveria ter lançado erro');
  } catch (erro) {
    assert.equal(erro instanceof llmService.ErroLlmProvedor, true);
    // A mensagem exposta ao chamador é sempre a mensagem genérica fixa,
    // nunca a mensagem crua do erro de rede (que, neste teste, contém a chave).
    assert.equal(erro.message.includes(CHAVE_FAKE), false);
  }
});

test('F) console.error nunca inclui a API key, mesmo se o erro de rede subjacente a mencionar', async () => {
  configurarEnvLlmFake();

  const chamadasDeLog = [];
  console.error = (...args) => { chamadasDeLog.push(args.map(String).join(' ')); };

  // Cenário defensivo: uma lib de rede hipotética inclui a chave na
  // própria mensagem de erro. O serviço deve redigir isso antes de logar.
  global.fetch = async () => {
    throw new Error(`falha ao conectar usando a chave ${CHAVE_FAKE}`);
  };

  await assert.rejects(() => llmService.gerarResposta({ pergunta: 'Oi' }));

  const logsCompletos = chamadasDeLog.join('\n');
  assert.equal(logsCompletos.includes(CHAVE_FAKE), false);
  assert.match(logsCompletos, /\[API_KEY_OCULTADA\]/);
});

test('F) redigirSegredo() substitui todas as ocorrências do segredo por um marcador', () => {
  const texto = `chave=${CHAVE_FAKE} e de novo ${CHAVE_FAKE}`;
  const resultado = llmService.redigirSegredo(texto, CHAVE_FAKE);
  assert.equal(resultado.includes(CHAVE_FAKE), false);
  assert.equal(resultado, 'chave=[API_KEY_OCULTADA] e de novo [API_KEY_OCULTADA]');
});

test('F) nenhuma chamada a console.error inclui a API key', async () => {
  configurarEnvLlmFake();

  const chamadasDeLog = [];
  console.error = (...args) => { chamadasDeLog.push(args.map(String).join(' ')); };

  global.fetch = async () => ({
    ok: false,
    status: 500,
    text: async () => 'erro interno do provedor',
  });

  await assert.rejects(() => llmService.gerarResposta({ pergunta: 'Oi' }));

  const logsCompletos = chamadasDeLog.join('\n');
  assert.equal(logsCompletos.includes(CHAVE_FAKE), false);
});

const assert = require('node:assert/strict');
const { test, afterEach } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const fila = require('../src/services/whatsappFila.service');
const worker = require('../src/services/whatsappWorker.service');
const historico = require('../src/services/whatsappHistorico.service');
const atendente = require('../src/services/whatsappAtendente.service');
const envio = require('../src/services/whatsappEnvio.service');
const idempotencia = require('../src/services/whatsappIdempotencia.service');

const LOJA = '11111111-1111-4111-8111-111111111111';
const CFG = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const JOB = '77777777-7777-4777-8777-777777777777';
const mensagem = Object.freeze({
  canal: 'whatsapp', lojaId: LOJA, configuracaoId: CFG, contato: '5511999999999',
  texto: 'oi', idExterno: 'wamid.10O', timestamp: '2026-09-19T20:00:00.000Z',
});

const envNomes = ['WHATSAPP_WORKER_LEASE_SEGUNDOS','WHATSAPP_WORKER_MAX_TENTATIVAS','WHATSAPP_WORKER_RETRY_BASE_MS','WHATSAPP_WORKER_RETRY_MAX_MS'];
const envOriginal = Object.fromEntries(envNomes.map((k) => [k, process.env[k]]));
afterEach(() => {
  for (const k of envNomes) envOriginal[k] === undefined ? delete process.env[k] : process.env[k] = envOriginal[k];
});

function job(overrides = {}) {
  return {
    id: JOB, loja_id: LOJA, configuracao_id: CFG, provedor: 'meta', destinatario_id: 'phone-A',
    contato: mensagem.contato, texto: mensagem.texto, id_externo: mensagem.idExterno,
    timestamp_mensagem: mensagem.timestamp, resposta_texto: null,
    status: fila.STATUS.PROCESSANDO, tentativas: 1, ...overrides,
  };
}

test('10O A) enqueue persiste job já com lease e primeira tentativa, sem credenciais', async () => {
  let inserido;
  const fake = criarSupabaseFake({ from: {
    whatsapp_fila_processamento: (ctx) => {
      inserido = ctx.insertDados;
      return { data: { id: JOB }, error: null };
    },
  }});
  supabase.from = fake.from;
  const criado = await fila.enfileirarMensagemWhatsapp(mensagem, { provedor: ' Meta ', destinatarioId: ' phone-A ' });
  assert.equal(criado.status, fila.STATUS.PROCESSANDO);
  assert.equal(criado.tentativas, 1);
  assert.equal(criado.provedor, 'meta');
  assert.equal(criado.loja_id, LOJA);
  assert.equal(criado.configuracao_id, CFG);
  assert.equal(typeof inserido.lease_ate, 'string');
  assert.equal(JSON.stringify(inserido).match(/token|secret|senha|api_key/i), null);
});

test('10O B) claim usa RPC atômica com lease configurado', async () => {
  process.env.WHATSAPP_WORKER_LEASE_SEGUNDOS = '90';
  const fake = criarSupabaseFake({ rpc: { claim_whatsapp_job: { data: [job({ tentativas: 2 })], error: null } } });
  supabase.rpc = fake.rpc;
  const obtido = await fila.reivindicarProximoJob();
  assert.equal(obtido.id, JOB);
  assert.deepEqual(fake.chamadasRpc[0], { nome: 'claim_whatsapp_job', params: { p_lease_segundos: 90 } });
});

test('10O C) backoff é exponencial e respeita teto', () => {
  const cfg = { baseRetryMs: 1000, maxRetryMs: 5000 };
  assert.equal(fila.calcularAtrasoMs(1, cfg), 1000);
  assert.equal(fila.calcularAtrasoMs(2, cfg), 2000);
  assert.equal(fila.calcularAtrasoMs(3, cfg), 4000);
  assert.equal(fila.calcularAtrasoMs(4, cfg), 5000);
  assert.equal(fila.calcularAtrasoMs(20, cfg), 5000);
});

test('10O D) retry antes do envio volta a pendente e no limite termina falhou', async () => {
  process.env.WHATSAPP_WORKER_MAX_TENTATIVAS = '2';
  process.env.WHATSAPP_WORKER_RETRY_BASE_MS = '1000';
  const updates = [];
  const fake = criarSupabaseFake({ from: { whatsapp_fila_processamento: (ctx) => {
    if (ctx.updateDados) { updates.push(ctx.updateDados); return { data: { id: JOB }, error: null }; }
    return { data: null, error: null };
  }}});
  supabase.from = fake.from;
  const r1 = await fila.reagendarOuFalharJob(job({ tentativas: 1 }), 'envio_whatsapp');
  const r2 = await fila.reagendarOuFalharJob(job({ tentativas: 2 }), 'envio_whatsapp');
  assert.equal(r1.status, fila.STATUS.PENDENTE);
  assert.equal(r2.status, fila.STATUS.FALHOU);
  assert.equal(updates[0].ultimo_erro_codigo, 'envio_whatsapp');
  assert.equal(updates[1].status, fila.STATUS.FALHOU);
});

test('10O E) job ENVIADO em retry não chama IA nem Meta; apenas finaliza histórico/idempotência', async (t) => {
  const chamadas = { entrada: 0, ia: 0, envio: 0, saida: 0, idem: 0, concluir: 0 };
  t.mock.method(historico, 'registrarMensagemRecebida', async () => { chamadas.entrada += 1; });
  t.mock.method(atendente, 'responderMensagemWhatsapp', async () => { chamadas.ia += 1; });
  t.mock.method(envio, 'enviarRespostaWhatsapp', async () => { chamadas.envio += 1; });
  t.mock.method(historico, 'registrarMensagemEnviada', async (_m, r) => { chamadas.saida += 1; assert.equal(r.resposta, 'já enviada'); });
  t.mock.method(idempotencia, 'concluirEventoWhatsapp', async () => { chamadas.idem += 1; });
  t.mock.method(fila, 'concluirJob', async () => { chamadas.concluir += 1; });
  const r = await worker.processarJob(job({ status: fila.STATUS.ENVIADO, resposta_texto: 'já enviada', tentativas: 2 }));
  assert.equal(r.ok, true);
  assert.deepEqual(chamadas, { entrada: 0, ia: 0, envio: 0, saida: 1, idem: 1, concluir: 1 });
});

test('10O F) falha antes do envio é reagendada e não libera a idempotência', async (t) => {
  let reagendado = 0;
  let liberado = 0;
  t.mock.method(historico, 'registrarMensagemRecebida', async () => ({}));
  t.mock.method(atendente, 'responderMensagemWhatsapp', async () => { throw new Error('falha'); });
  t.mock.method(fila, 'reagendarOuFalharJob', async () => { reagendado += 1; return { status: fila.STATUS.PENDENTE }; });
  t.mock.method(idempotencia, 'liberarEventoWhatsapp', async () => { liberado += 1; });
  const r = await worker.processarJob(job());
  assert.equal(r.ok, false);
  assert.equal(reagendado, 1);
  assert.equal(liberado, 0);
});

test('10O G) migration tem SKIP LOCKED, lease, RLS, FK multi-tenant e função restrita ao service_role', () => {
  const sql = fs.readFileSync(path.join(__dirname, '../src/db/migrations/006_whatsapp_fila_retry.sql'), 'utf8');
  assert.match(sql, /create table if not exists whatsapp_fila_processamento/i);
  assert.match(sql, /foreign key \(configuracao_id, loja_id\)/i);
  assert.match(sql, /foreign key \(provedor, id_externo\)/i);
  assert.match(sql, /for update skip locked/i);
  assert.match(sql, /lease_ate/i);
  assert.match(sql, /enable row level security/i);
  assert.match(sql, /revoke all on function claim_whatsapp_job\(integer\) from public/i);
  assert.match(sql, /grant execute on function claim_whatsapp_job\(integer\) to service_role/i);
});

test('10O H) servidor inicia worker apenas depois de escutar e env documenta knobs sem valores reais', () => {
  const server = fs.readFileSync(path.join(__dirname, '../src/server.js'), 'utf8');
  assert.match(server, /app\.listen[\s\S]*iniciarWorker\(\)/);
  const env = fs.readFileSync(path.join(__dirname, '../.env.example'), 'utf8');
  for (const nome of ['WHATSAPP_WORKER_INTERVALO_MS','WHATSAPP_WORKER_LEASE_SEGUNDOS','WHATSAPP_WORKER_MAX_TENTATIVAS','WHATSAPP_WORKER_RETRY_BASE_MS','WHATSAPP_WORKER_RETRY_MAX_MS']) {
    assert.match(env, new RegExp(`^${nome}=$`, 'm'));
  }
});

const assert = require('node:assert/strict');
const { test, beforeEach } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
require('./helpers/mockSupabaseModule').instalarMockSupabaseJs();
const supabase = require('../src/config/supabase');
const { criarSupabaseFake } = require('./helpers/supabaseFake');
const { criarResMock } = require('./helpers/httpMocks');
const controller = require('../src/controllers/whatsappWebhook.controller');
const envio = require('../src/services/whatsappEnvio.service');
const ia = require('../src/services/ia.service');
const provedores = require('../src/services/providers/whatsapp');
const { verificarAssinaturaWebhook } = require('../src/middleware/webhookAssinatura');
const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const CA = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const CB = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const TOKEN = 'TOKEN_FICTICIO_TESTE_10K';
const CONTATO = '5511988887777';
let chamadas, logs, linhas, fake, credenciaisAtivas;
const MASTER_KEY = Buffer.alloc(32, 7).toString('base64');

function credencialCifrada(configuracaoId, lojaId, token = TOKEN) {
  const chave = Buffer.from(MASTER_KEY, 'base64');
  const iv = crypto.createHash('sha256').update(configuracaoId).digest().subarray(0, 12);
  const cipher = crypto.createCipheriv('aes-256-gcm', chave, iv);
  cipher.setAAD(Buffer.from(`whatsapp:meta:${lojaId}:${configuracaoId}:v1`, 'utf8'));
  const cifrado = Buffer.concat([cipher.update(token, 'utf8'), cipher.final()]);
  return { configuracao_id: configuracaoId, loja_id: lojaId, provedor: 'meta', access_token_cifrado: cifrado.toString('base64'), access_token_iv: iv.toString('base64'), access_token_tag: cipher.getAuthTag().toString('base64'), versao_chave: 1 };
}

beforeEach((t) => {
  const valores = { WHATSAPP_CREDENTIALS_MASTER_KEY: MASTER_KEY, META_WHATSAPP_TIMEOUT_MS: '15',
    META_WHATSAPP_API_VERSION: 'v26.0', META_APP_SECRET: 'HMAC_FICTICIO_10K',
    LLM_PROVIDER_API_KEY: '', LLM_PROVIDER_URL: '', LLM_PROVIDER_MODEL: '' };
  const antes = Object.fromEntries(Object.keys(valores).map(k => [k, process.env[k]]));
  Object.assign(process.env, valores);
  t.after(() => { for (const [k,v] of Object.entries(antes)) {
    if (v === undefined) delete process.env[k]; else process.env[k] = v;
  } });
  logs = []; chamadas = []; credenciaisAtivas = true;
  t.mock.method(console, 'error', (...args) => logs.push(args));
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    chamadas.push({ url, options });
    return { ok: true, status: 200, text: async () => JSON.stringify({ messages: [{ id: 'wamid.OUT_FAKE' }] }) };
  });
  linhas = [
    { id: CA, loja_id: A, provedor: 'meta', identificador_externo: '111000', numero_whatsapp: '5511000000001', ativo: true },
    { id: CB, loja_id: B, provedor: 'meta', identificador_externo: '222000', numero_whatsapp: '5511000000002', ativo: true },
  ];
  fake = criarSupabaseFake({ from: {
    whatsapp_configuracoes: ctx => {
      const encontrados = linhas.filter(l => Object.entries(ctx.filtros).every(([k,v]) => l[k] === v));
      return { data: ctx.filtros.id ? encontrados[0] || null : encontrados, error: null };
    },
    whatsapp_credenciais: ctx => {
      if (!credenciaisAtivas) return { data: null, error: null };
      const config = linhas.find(l => l.id === ctx.filtros.configuracao_id && l.loja_id === ctx.filtros.loja_id);
      return { data: config ? credencialCifrada(config.id, config.loja_id) : null, error: null };
    },
    produtos: ctx => ({ data: [{ id: 'produto-interno', nome: ctx.filtros.loja_id === A ? 'Camiseta Aurora' : 'Vestido Zênite',
      preco: 50, descricao: 'Algodão', ativo: true, estoque: [{ cor: 'Azul', tamanho: 'P', quantidade: 3 }] }], error: null }),
  } });
  t.mock.method(supabase, 'from', fake.from);
});

function payload(phone = '111000', from = CONTATO, extra = {}) {
  return { object: 'whatsapp_business_account', loja_id: B, configuracaoId: CB,
    entry: [{ changes: [{ field: 'messages', value: {
      metadata: { phone_number_id: phone }, lojaId: B, provedor: 'simulado',
      messages: [{ id: 'wamid.IN_FAKE', from, type: 'text', text: { body: phone === '222000' ? 'Quanto custa o Vestido Zênite?' : 'Quanto custa a Camiseta Aurora?' }, ...extra }],
    } }] }] };
}
async function postar(body, assinaturaValida = true) {
  const raw = Buffer.from(JSON.stringify(body));
  const signature = crypto.createHmac('sha256', process.env.META_APP_SECRET).update(raw).digest('hex');
  const req = { body, corpoBruto: raw, headers: { 'x-hub-signature-256': `sha256=${assinaturaValida ? signature : '0'.repeat(64)}` } };
  req.get = nome => req.headers[nome.toLowerCase()];
  const res = criarResMock();
  let autorizado = false;
  verificarAssinaturaWebhook(req, res, () => { autorizado = true; });
  if (autorizado) await controller.receberEvento(req, res);
  return res;
}
function mensagem() {
  return { canal: 'whatsapp', lojaId: A, configuracaoId: CA, contato: CONTATO, texto: 'pergunta', idExterno: 'wamid.IN_FAKE' };
}
function resposta(m = mensagem()) {
  return { lojaId: m.lojaId, contato: m.contato, idExterno: m.idExterno,
    pergunta: 'PERGUNTA_INTERNA', resposta: 'Resposta final.', prompt: 'PROMPT_INTERNO', contexto: 'CONTEXTO_INTERNO' };
}
function enviar(m = mensagem(), r = resposta(m)) {
  return envio.enviarRespostaWhatsapp(m, r, { provedor: 'meta', destinatarioId: '111000' });
}

test('10K: HMAC → parser → banco → IA/fallback real → contrato → Meta com fetch fake', async () => {
  const res = await postar(payload());
  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, { status: 'recebido' });
  assert.equal(chamadas.length, 1);
  assert.equal(chamadas[0].url, 'https://graph.facebook.com/v26.0/111000/messages');
  const body = JSON.parse(chamadas[0].options.body);
  assert.equal(body.to, CONTATO);
  assert.equal(typeof body.text.body, 'string');
  assert.ok(body.text.body.trim().length > 0);
  assert.deepEqual(Object.keys(body).sort(), ['messaging_product','recipient_type','text','to','type']);
  assert.equal(chamadas[0].options.headers.Authorization, `Bearer ${TOKEN}`);
  assert.ok(fake.chamadasFrom.some(c => c.filtros.id === CA && c.filtros.loja_id === A));
});

test('10K: lojas A e B usam catálogo, número e destinatário próprios apesar de IDs forjados', async () => {
  await postar(payload());
  await postar(payload('222000', '5511977776666', { loja_id: A, configuracaoId: CA }));
  assert.equal(chamadas.length, 2);
  assert.match(chamadas[1].url, /\/222000\/messages$/);
  const body = JSON.parse(chamadas[1].options.body);
  assert.equal(body.to, '5511977776666');
  assert.equal(typeof body.text.body, 'string');
  assert.ok(body.text.body.trim().length > 0);
  const consultasProdutos = fake.chamadasFrom.filter(c => c.tabela === 'produtos');
  assert.deepEqual(consultasProdutos.map(c => c.filtros.loja_id), [A, B]);
});

test('10K: só texto final vai para Meta; pergunta, prompt, contexto e IDs não são serializados', async () => {
  await enviar();
  const body = JSON.parse(chamadas[0].options.body);
  assert.deepEqual(body.text, { body: 'Resposta final.' });
  for (const interno of [A, CA, 'wamid.IN_FAKE', 'PERGUNTA_INTERNA', 'PROMPT_INTERNO', 'CONTEXTO_INTERNO', TOKEN]) {
    assert.ok(!chamadas[0].options.body.includes(interno));
    assert.ok(!JSON.stringify(logs).includes(interno));
  }
});

test('10K: usa factory e pedido do contrato existentes; factory configura o adapter Meta real', async (t) => {
  const original = provedores.obterProvedorWhatsapp;
  const factory = t.mock.method(provedores, 'obterProvedorWhatsapp', original);
  const contrato = t.mock.method(provedores, 'criarPedidoDeEnvio', provedores.criarPedidoDeEnvio);
  await enviar();
  assert.deepEqual(factory.mock.calls[0].arguments, ['meta', { phoneNumberId: '111000', accessToken: TOKEN }]);
  assert.equal(contrato.mock.callCount(), 1);
  assert.equal(chamadas.length, 1);
});

for (const valor of ['', '  ', null, undefined, 42, {}, []]) {
  test(`10K: resposta inválida ${JSON.stringify(valor)} nunca envia`, async () => {
    await assert.rejects(enviar(mensagem(), { ...resposta(), resposta: valor }), envio.ErroEnvioWhatsapp);
    assert.equal(chamadas.length, 0);
  });
}
for (const campo of ['lojaId', 'contato', 'idExterno']) {
  test(`10K: resultado da IA com ${campo} divergente é recusado`, async () => {
    await assert.rejects(enviar(mensagem(), { ...resposta(), [campo]: 'forjado' }), envio.ErroEnvioWhatsapp);
    assert.equal(chamadas.length, 0);
  });
}
for (const alteracao of [{ ativo: false }, { loja_id: B }, { id: CB }, { identificador_externo: '333000' }, { provedor: 'simulado' }]) {
  test(`10K: configuração mudou após inbound: ${JSON.stringify(alteracao)} bloqueia envio`, async (t) => {
    const original = ia.responderPergunta;
    t.mock.method(ia, 'responderPergunta', async (...args) => {
      const texto = await original(...args); Object.assign(linhas[0], alteracao); return texto;
    });
    const res = await postar(payload());
    assert.equal(res.statusCode, 200);
    assert.equal(chamadas.length, 0);
  });
}

test('10K: configuração de outra loja não pode ser usada diretamente', async () => {
  const m = { ...mensagem(), configuracaoId: CB };
  await assert.rejects(enviar(m), envio.ErroEnvioWhatsapp);
  assert.equal(chamadas.length, 0);
});

test('10K: IA vazia falha antes do envio', async (t) => {
  t.mock.method(ia, 'responderPergunta', async () => '  ');
  assert.equal((await postar(payload())).statusCode, 200);
  assert.equal(chamadas.length, 0);
});

test('10P: ausência de credencial da configuração falha sem rede e sem falso sucesso', async () => {
  credenciaisAtivas = false;
  assert.equal((await postar(payload())).statusCode, 200);
  assert.equal(chamadas.length, 0);
});

for (const status of [400, 401, 429, 500]) {
  test(`10K: provider HTTP ${status} retorna erro seguro e não repete envio`, async (t) => {
    let vezes = 0;
    t.mock.method(globalThis, 'fetch', async () => {
      vezes++; return { ok: false, status, text: async () => JSON.stringify({ error: { message: `${TOKEN} OUTRA_API_KEY_FICTICIA` } }) };
    });
    const res = await postar(payload());
    assert.equal(res.statusCode, 200);
    assert.equal(vezes, 1);
    const saida = JSON.stringify([res.body, logs]);
    assert.ok(!saida.includes(TOKEN));
    assert.ok(!saida.includes('OUTRA_API_KEY_FICTICIA'));
  });
}

test('10K: timeout real do adapter aborta fetch fake, responde 502 e não faz retry', async (t) => {
  let vezes = 0, abortado = false;
  t.mock.method(globalThis, 'fetch', (_url, options) => new Promise((_resolve, reject) => {
    vezes++;
    options.signal.addEventListener('abort', () => {
      abortado = true; const e = new Error(TOKEN); e.name = 'AbortError'; reject(e);
    }, { once: true });
  }));
  assert.equal((await postar(payload())).statusCode, 200);
  assert.equal(vezes, 1); assert.equal(abortado, true);
  assert.ok(!JSON.stringify(logs).includes(TOKEN));
});

test('10K: exceção arbitrária do provider não vaza message/name/stack/cause', async (t) => {
  t.mock.method(provedores, 'obterProvedorWhatsapp', () => { const e = new Error(TOKEN); e.name = TOKEN; throw e; });
  const res = await postar(payload());
  assert.equal(res.statusCode, 200);
  assert.ok(!JSON.stringify([res.body, logs]).includes(TOKEN));
});

test('10K: falha de rede descarta detalhes de credenciais diferentes do token Meta', async (t) => {
  t.mock.method(globalThis, 'fetch', async () => { throw new Error('OUTRA_API_KEY_FICTICIA'); });
  assert.equal((await postar(payload())).statusCode, 200);
  assert.ok(!JSON.stringify(logs).includes('OUTRA_API_KEY_FICTICIA'));
});

test('10K: statuses, echo, evento de saída e mensagem do próprio número não geram loop', async () => {
  const status = payload(); status.entry[0].changes[0].value.messages = [];
  status.entry[0].changes[0].value.statuses = [{ id: 'wamid.OUT_FAKE', status: 'delivered' }];
  const saida = payload(); saida.entry[0].changes[0].field = 'smb_message_echoes';
  for (const body of [status, payload('111000', CONTATO, { is_echo: true }), saida, payload('111000', '5511000000001')]) {
    assert.equal((await postar(body)).statusCode, 200);
  }
  assert.equal(chamadas.length, 0);
});

test('10K: assinatura inválida, tipo não suportado e loja desconhecida não enviam', async () => {
  assert.equal((await postar(payload(), false)).statusCode, 401);
  assert.equal((await postar(payload('111000', CONTATO, { type: 'image' }))).statusCode, 200);
  assert.equal((await postar(payload('999000'))).statusCode, 404);
  assert.equal(chamadas.length, 0);
});

test('10K: provider simulado permanece disponível e não usa rede', async () => {
  linhas[0].provedor = 'simulado';
  const resultado = await envio.enviarRespostaWhatsapp(mensagem(), resposta(), { provedor: 'simulado', destinatarioId: '111000' });
  assert.deepEqual(resultado, { status: 'simulado' });
  assert.equal(chamadas.length, 0);
});

test('10K: única implementação HTTP da Meta continua no cliente existente', () => {
  const raiz = path.join(__dirname, '../src');
  function arquivos(dir) { return fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? arquivos(path.join(dir,e.name)) : [path.join(dir,e.name)]); }
  for (const file of arquivos(raiz).filter(f => f.endsWith('.js'))) {
    const code = fs.readFileSync(file, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
    if (code.includes('https://graph.facebook.com')) assert.equal(path.basename(file), 'clienteHttpMeta.js');
    if (/require\(['"].*clienteHttpMeta['"]\)/.test(code)) assert.equal(path.basename(file), 'adaptadorMeta.js');
  }
  const service = fs.readFileSync(path.join(raiz, 'services/whatsappEnvio.service.js'), 'utf8');
  assert.doesNotMatch(service, /\bfetch\s*\(|process\.env|apiKey/);
  const env = fs.readFileSync(path.join(__dirname, '../.env.example'), 'utf8');
  for (const key of ['WHATSAPP_CREDENTIALS_MASTER_KEY', 'META_WHATSAPP_API_VERSION', 'META_WHATSAPP_TIMEOUT_MS', 'META_APP_SECRET', 'META_WHATSAPP_VERIFY_TOKEN']) {
    assert.ok(env.includes(`${key}=`));
  }
  assert.ok(!env.includes(TOKEN));
});

test('10K: LLM real com HTTP fake → resposta final → adapter Meta real, sem prompt/contexto no envio', async (t) => {
  Object.assign(process.env, { LLM_PROVIDER_API_KEY: 'LLM_FICTICIA_10K', LLM_PROVIDER_URL: 'https://llm.exemplo.teste/chat', LLM_PROVIDER_MODEL: 'teste' });
  const requisicoes = [];
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    requisicoes.push({ url, options });
    if (url === process.env.LLM_PROVIDER_URL) return { ok: true, status: 200,
      json: async () => ({ choices: [{ message: { content: 'A Camiseta Aurora custa R$ 50,00.' } }] }) };
    return { ok: true, status: 200, text: async () => '{"messages":[{"id":"wamid.fake"}]}' };
  });
  assert.equal((await postar(payload())).statusCode, 200);
  assert.equal(requisicoes.length, 2);
  assert.equal(requisicoes[0].url, process.env.LLM_PROVIDER_URL);
  assert.match(requisicoes[1].url, /graph\.facebook\.com/);
  assert.deepEqual(JSON.parse(requisicoes[1].options.body), {
    messaging_product: 'whatsapp', recipient_type: 'individual', to: CONTATO,
    type: 'text', text: { body: 'A Camiseta Aurora custa R$ 50,00.' },
  });
  assert.ok(!JSON.stringify(requisicoes[0]).includes(TOKEN));
  assert.ok(!JSON.stringify(requisicoes[1]).includes(process.env.LLM_PROVIDER_API_KEY));
});

for (const body of ['{"messages":[]}', '{JSON_INVALIDO']) {
  test(`10K: resposta inválida da Meta é erro controlado (${body})`, async (t) => {
    t.mock.method(globalThis, 'fetch', async () => ({ ok: true, status: 200, text: async () => body }));
    assert.equal((await postar(payload())).statusCode, 200);
  });
}

/**
 * Testes do INTERPRETADOR DO WEBHOOK DA META
 * (src/services/providers/whatsapp/interpretadorWebhookMeta.js — Etapa 10H).
 *
 * Escopo: só a interpretação do payload bruto `entry[].changes[].value.
 * messages[]` para a estrutura interna de mensagem. Nada aqui chama IA,
 * envia mensagem, faz HTTP ou toca banco/migrations — e nada aqui está
 * ligado ao webhook HTTP real (nenhuma rota importa este módulo ainda).
 *
 * Cobre os cenários pedidos na Etapa 10H, item 7:
 *   A) payload válido com texto
 *   B) idExterno
 *   C) contato (from)
 *   D) destinatarioId (phone_number_id)
 *   E) texto
 *   F) timestamp
 *   G) múltiplos entry
 *   H) múltiplos changes
 *   I) somente statuses
 *   J) image não suportado
 *   K) ausência de messages
 *   L) ausência de phone_number_id
 *   M) ausência de from
 *   N) ausência de text.body
 *   O) tipos incorretos
 *   P) tentativa de injetar loja_id/lojaId
 *   Q) conteúdo malicioso no texto permanece apenas como texto
 *   R) não vazamento de token/segredo/payload completo em erros
 *
 * Rodar com: node --test tests/whatsappWebhookMeta.interpretador.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');

const {
  interpretarPayloadWebhookMeta,
  ErroWebhookMetaInvalido,
  TIPOS_MENSAGEM_WEBHOOK,
  MOTIVOS_MENSAGEM_INVALIDA,
} = require('../src/services/providers/whatsapp/interpretadorWebhookMeta');

const PHONE_NUMBER_ID = '106540352242922';
const TIMESTAMP_UNIX_SEGUNDOS = '1700000000';
const TIMESTAMP_ISO_ESPERADO = new Date(1700000000 * 1000).toISOString();

// Monta um payload no formato real da Meta Cloud API com uma única
// mensagem em um único entry/change, permitindo sobrescrever qualquer
// parte para os cenários de teste.
function montarPayload({
  mensagens = [mensagemTextoValida()],
  phoneNumberId = PHONE_NUMBER_ID,
  statuses,
  metadata,
} = {}) {
  const value = {
    metadata: metadata !== undefined ? metadata : { phone_number_id: phoneNumberId },
    messages: mensagens,
  };
  if (statuses !== undefined) value.statuses = statuses;

  return {
    entry: [
      {
        id: 'entry-id-fake',
        changes: [{ field: 'messages', value }],
      },
    ],
  };
}

function mensagemTextoValida(extra = {}) {
  return {
    id: 'wamid.ID_EXTERNO_FAKE',
    from: '5511988887777',
    timestamp: TIMESTAMP_UNIX_SEGUNDOS,
    type: 'text',
    text: { body: 'Olá, vocês têm a camiseta P?' },
    ...extra,
  };
}

test('A) payload válido com texto: devolve uma mensagem válida, suportada, tipo texto', () => {
  const resultado = interpretarPayloadWebhookMeta(montarPayload());
  assert.equal(resultado.length, 1);
  const [mensagem] = resultado;
  assert.equal(mensagem.valida, true);
  assert.equal(mensagem.motivoInvalida, null);
  assert.equal(mensagem.suportada, true);
  assert.equal(mensagem.tipo, TIPOS_MENSAGEM_WEBHOOK.texto);
});

test('B) idExterno é extraído de messages[].id', () => {
  const [mensagem] = interpretarPayloadWebhookMeta(montarPayload());
  assert.equal(mensagem.idExterno, 'wamid.ID_EXTERNO_FAKE');
});

test('C) contato é extraído de messages[].from', () => {
  const [mensagem] = interpretarPayloadWebhookMeta(montarPayload());
  assert.equal(mensagem.contato, '5511988887777');
});

test('D) destinatarioId é extraído de value.metadata.phone_number_id', () => {
  const [mensagem] = interpretarPayloadWebhookMeta(montarPayload({ phoneNumberId: PHONE_NUMBER_ID }));
  assert.equal(mensagem.destinatarioId, PHONE_NUMBER_ID);
});

test('E) texto é extraído de messages[].text.body', () => {
  const [mensagem] = interpretarPayloadWebhookMeta(montarPayload());
  assert.equal(mensagem.texto, 'Olá, vocês têm a camiseta P?');
});

test('F) timestamp é convertido de segundos Unix (string) para ISO 8601', () => {
  const [mensagem] = interpretarPayloadWebhookMeta(montarPayload());
  assert.equal(mensagem.timestamp, TIMESTAMP_ISO_ESPERADO);
});

test('G) múltiplos entry: mensagens de todos os entry são coletadas, na ordem', () => {
  const payload = {
    entry: [
      { changes: [{ value: { metadata: { phone_number_id: PHONE_NUMBER_ID }, messages: [mensagemTextoValida({ id: 'msg-1' })] } }] },
      { changes: [{ value: { metadata: { phone_number_id: PHONE_NUMBER_ID }, messages: [mensagemTextoValida({ id: 'msg-2' })] } }] },
    ],
  };
  const resultado = interpretarPayloadWebhookMeta(payload);
  assert.deepEqual(
    resultado.map((m) => m.idExterno),
    ['msg-1', 'msg-2']
  );
});

test('H) múltiplos changes dentro de um mesmo entry: mensagens de todos os changes são coletadas', () => {
  const payload = {
    entry: [
      {
        changes: [
          { value: { metadata: { phone_number_id: PHONE_NUMBER_ID }, messages: [mensagemTextoValida({ id: 'msg-a' })] } },
          { value: { metadata: { phone_number_id: PHONE_NUMBER_ID }, messages: [mensagemTextoValida({ id: 'msg-b' })] } },
        ],
      },
    ],
  };
  const resultado = interpretarPayloadWebhookMeta(payload);
  assert.deepEqual(
    resultado.map((m) => m.idExterno),
    ['msg-a', 'msg-b']
  );
});

test('I) somente statuses (sem messages): não gera nenhuma mensagem', () => {
  const payload = montarPayload({ mensagens: [], statuses: [{ id: 'wamid.status', status: 'delivered' }] });
  // Remove "messages" para simular exatamente o payload de um evento de status.
  delete payload.entry[0].changes[0].value.messages;
  const resultado = interpretarPayloadWebhookMeta(payload);
  assert.deepEqual(resultado, []);
});

test('J) mensagem de imagem (ou outro tipo não textual): marcada como não suportada, sem inventar conteúdo', () => {
  const payload = montarPayload({
    mensagens: [
      {
        id: 'wamid.IMG',
        from: '5511988887777',
        timestamp: TIMESTAMP_UNIX_SEGUNDOS,
        type: 'image',
        image: { id: 'media-id-fake', mime_type: 'image/jpeg' },
      },
    ],
  });
  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(mensagem.valida, true);
  assert.equal(mensagem.suportada, false);
  assert.equal(mensagem.tipo, TIPOS_MENSAGEM_WEBHOOK.naoSuportado);
  assert.equal(mensagem.texto, null);
});

test('K) ausência de messages: não lança, devolve lista vazia', () => {
  const payload = { entry: [{ changes: [{ value: { metadata: { phone_number_id: PHONE_NUMBER_ID } } }] }] };
  assert.deepEqual(interpretarPayloadWebhookMeta(payload), []);
});

test('L) ausência de phone_number_id: mensagem marcada como inválida (sem_destinatario)', () => {
  const payload = montarPayload({ metadata: {} });
  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(mensagem.valida, false);
  assert.equal(mensagem.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.semDestinatario);
  assert.equal(mensagem.destinatarioId, null);
});

test('M) ausência de from: mensagem marcada como inválida (sem_remetente)', () => {
  const payload = montarPayload({ mensagens: [mensagemTextoValida({ from: undefined })] });
  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(mensagem.valida, false);
  assert.equal(mensagem.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.semRemetente);
  assert.equal(mensagem.contato, null);
});

test('N) ausência de text.body: mensagem marcada como inválida (sem_texto), sem inventar texto', () => {
  const payload = montarPayload({ mensagens: [mensagemTextoValida({ text: {} })] });
  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(mensagem.valida, false);
  assert.equal(mensagem.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.semTexto);
  assert.equal(mensagem.texto, null);
});

test('O) tipos incorretos em vários níveis não quebram a interpretação', () => {
  assert.deepEqual(interpretarPayloadWebhookMeta({ entry: 'não é um array' }), []);
  assert.deepEqual(interpretarPayloadWebhookMeta({ entry: [{ changes: 'não é um array' }] }), []);
  assert.deepEqual(interpretarPayloadWebhookMeta({ entry: [{ changes: [{ value: 'não é um objeto' }] }] }), []);
  assert.deepEqual(interpretarPayloadWebhookMeta({ entry: [{ changes: [{ value: { messages: 'não é um array' } }] }] }), []);
  assert.deepEqual(interpretarPayloadWebhookMeta({ entry: [null, 42, 'x'] }), []);

  // messages[] com um item que não é objeto: vira mensagem inválida (não lança).
  const payload = montarPayload({ mensagens: ['isto não é uma mensagem', 123, null] });
  const resultado = interpretarPayloadWebhookMeta(payload);
  assert.equal(resultado.length, 3);
  for (const mensagem of resultado) {
    assert.equal(mensagem.valida, false);
    assert.equal(mensagem.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.formatoInvalido);
  }

  // id/from com tipos inesperados (número em vez de string) não são aceitos como válidos.
  const payloadIdNumerico = montarPayload({ mensagens: [mensagemTextoValida({ id: 123456 })] });
  const [mensagemIdNumerico] = interpretarPayloadWebhookMeta(payloadIdNumerico);
  assert.equal(mensagemIdNumerico.valida, false);
  assert.equal(mensagemIdNumerico.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.semId);

  // Payload de nível mais alto que não é objeto: lança um erro conhecido.
  for (const payloadInvalido of [null, undefined, 'texto', 42, [], true]) {
    assert.throws(() => interpretarPayloadWebhookMeta(payloadInvalido), ErroWebhookMetaInvalido);
  }
});

test('P) tentativa de injetar loja_id/lojaId em qualquer nível: nunca aparece na saída e nunca vira destinatarioId/contato', () => {
  const payload = {
    loja_id: 'loja-injetada-no-topo',
    lojaId: 'loja-injetada-no-topo-2',
    entry: [
      {
        loja_id: 'loja-injetada-no-entry',
        changes: [
          {
            lojaId: 'loja-injetada-no-change',
            value: {
              loja_id: 'loja-injetada-no-value',
              metadata: { phone_number_id: PHONE_NUMBER_ID, loja_id: 'loja-injetada-no-metadata' },
              messages: [mensagemTextoValida({ loja_id: 'loja-injetada-na-mensagem', lojaId: 'loja-injetada-na-mensagem-2' })],
            },
          },
        ],
      },
    ],
  };

  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(mensagem.valida, true);
  assert.equal(mensagem.destinatarioId, PHONE_NUMBER_ID);
  assert.equal(Object.prototype.hasOwnProperty.call(mensagem, 'lojaId'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(mensagem, 'loja_id'), false);
  assert.deepEqual(Object.keys(mensagem).sort(), [
    'contato',
    'destinatarioId',
    'idExterno',
    'motivoInvalida',
    'suportada',
    'texto',
    'timestamp',
    'tipo',
    'valida',
  ]);
});

test('Q) conteúdo malicioso no texto: permanece como texto puro, nunca interpretado/executado/removido', () => {
  const textoMalicioso = '<script>alert(1)</script> \'; DROP TABLE lojas; -- ${processo.env}';
  const payload = montarPayload({ mensagens: [mensagemTextoValida({ text: { body: textoMalicioso } })] });
  const [mensagem] = interpretarPayloadWebhookMeta(payload);
  assert.equal(typeof mensagem.texto, 'string');
  assert.equal(mensagem.texto, textoMalicioso.trim());
  assert.equal(mensagem.suportada, true);
});

test('R) erros nunca contêm o payload completo, texto da mensagem, token ou segredo', () => {
  const segredoQueNuncaDeveVazar = 'EAA-token-secreto-nao-deveria-vazar';
  const textoQueNuncaDeveVazar = 'texto sigiloso do cliente que não pode aparecer em erro nenhum';

  let erroCapturado = null;
  try {
    interpretarPayloadWebhookMeta({
      access_token: segredoQueNuncaDeveVazar,
      entry: 'propositalmente inválido para forçar um caminho de erro adjacente',
      mensagemSecreta: textoQueNuncaDeveVazar,
    });
  } catch (erro) {
    erroCapturado = erro;
  }
  // Este payload é um objeto válido (entry inválido só é ignorado), então
  // não deveria lançar; confirmamos isso e seguimos para o caso que lança de fato.
  assert.equal(erroCapturado, null);

  try {
    interpretarPayloadWebhookMeta('um payload que não é objeto e contém ' + segredoQueNuncaDeveVazar);
    assert.fail('deveria ter lançado ErroWebhookMetaInvalido');
  } catch (erro) {
    assert.ok(erro instanceof ErroWebhookMetaInvalido);
    assert.equal(erro.message.includes(segredoQueNuncaDeveVazar), false);
    assert.equal(erro.message.includes(textoQueNuncaDeveVazar), false);
    // Mensagem é fixa e curta — nunca serializa o payload recebido.
    assert.equal(erro.message, 'payload do webhook da Meta inválido: deve ser um objeto.');
  }

  // Uma mensagem de texto sigiloso que falha por outro motivo (sem from)
  // não pode ter seu conteúdo ecoado em nenhum campo de erro.
  const payloadComTextoSigiloso = montarPayload({
    mensagens: [mensagemTextoValida({ from: undefined, text: { body: textoQueNuncaDeveVazar } })],
  });
  const [mensagemInvalida] = interpretarPayloadWebhookMeta(payloadComTextoSigiloso);
  assert.equal(mensagemInvalida.valida, false);
  assert.equal(mensagemInvalida.motivoInvalida, MOTIVOS_MENSAGEM_INVALIDA.semRemetente);
  assert.equal(JSON.stringify(mensagemInvalida).includes(textoQueNuncaDeveVazar), false);
});

test('estático) resultado é imutável (Object.freeze na lista e em cada mensagem)', () => {
  const resultado = interpretarPayloadWebhookMeta(montarPayload());
  assert.ok(Object.isFrozen(resultado));
  assert.ok(Object.isFrozen(resultado[0]));
});

test('estático) este módulo não faz I/O: nenhuma dependência além do utilitário de validação interno', () => {
  const codigo = require('node:fs').readFileSync(
    require.resolve('../src/services/providers/whatsapp/interpretadorWebhookMeta.js'),
    'utf8'
  );
  const dependencias = [...codigo.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]).sort();
  assert.deepEqual(dependencias, ['../../../utils/validacao']);
  assert.equal(/\bfetch\s*\(|https?:\/\/|XMLHttpRequest|axios|supabase|console\./i.test(codigo), false);
});

test('estático) a partir da Etapa 10I, só o controller do webhook importa este módulo; rota, service e envio continuam sem importá-lo', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const RAIZ = path.join(__dirname, '..');

  // Etapa 10I: o controller passou a delegar a interpretação a este módulo.
  const codigoControlador = fs.readFileSync(path.join(RAIZ, 'src/controllers/whatsappWebhook.controller.js'), 'utf8');
  assert.equal(codigoControlador.includes('interpretadorWebhookMeta'), true, 'o controller deve delegar a interpretação ao módulo da 10H');

  // O restante do fluxo (rota, service genérico da 10C, adaptador/cliente de
  // ENVIO da Meta e a fiação do app) continua sem depender deste módulo:
  // a rota só liga HTTP ao controller, o service da 10C continua
  // provider-agnóstico, e envio/adaptador seguem desconectados nesta etapa.
  const arquivosSemInterpretador = [
    'src/routes/whatsappWebhook.routes.js',
    'src/services/whatsappWebhook.service.js',
    'src/services/providers/whatsapp/adaptadorMeta.js',
    'src/services/providers/whatsapp/index.js',
    'src/app.js',
  ];
  for (const arquivo of arquivosSemInterpretador) {
    const codigo = fs.readFileSync(path.join(RAIZ, arquivo), 'utf8');
    assert.equal(codigo.includes('interpretadorWebhookMeta'), false, `${arquivo} não deve importar o interpretador diretamente`);
  }
});

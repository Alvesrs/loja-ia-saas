const { lojaPertenceAoUsuario, produtoPertenceALoja } = require('../services/autorizacao.service');
const { ehUuid } = require('../utils/validacao');

/**
 * Middleware aplicado a TODAS as rotas aninhadas sob /api/lojas/:lojaId/*.
 * Garante, antes de qualquer controller rodar, que:
 *   1. :lojaId tem formato válido;
 *   2. a loja pertence ao usuário autenticado (req.usuario, definido por
 *      exigirLogin, que deve rodar antes deste middleware).
 *
 * Isso evita repetir a checagem em cada controller e garante que nenhuma
 * rota nova, adicionada no futuro, esqueça essa verificação.
 */
async function exigirDonoDaLoja(req, res, next) {
  const { lojaId } = req.params;

  if (!ehUuid(lojaId)) {
    return res.status(400).json({ erro: 'Identificador de loja inválido.' });
  }

  if (!req.usuario) {
    // Não deveria acontecer se exigirLogin rodou antes, mas evita
    // depender só da ordem de montagem das rotas.
    return res.status(401).json({ erro: 'Token de autenticação ausente.' });
  }

  const pertence = await lojaPertenceAoUsuario(lojaId, req.usuario.id);
  if (!pertence) {
    return res.status(403).json({ erro: 'Você não tem acesso a essa loja.' });
  }

  next();
}

/**
 * Middleware aplicado a rotas aninhadas sob
 * /api/lojas/:lojaId/produtos/:produtoId/*. Deve rodar depois de
 * `exigirDonoDaLoja` (a loja já está validada nesse ponto). Garante que
 * :produtoId pertence a essa mesma loja antes de deixar seguir para
 * estoque/etc.
 */
async function exigirProdutoDaLoja(req, res, next) {
  const { lojaId, produtoId } = req.params;

  if (!ehUuid(produtoId)) {
    return res.status(400).json({ erro: 'Identificador de produto inválido.' });
  }

  const pertence = await produtoPertenceALoja(produtoId, lojaId);
  if (!pertence) {
    return res.status(403).json({ erro: 'Esse produto não pertence a essa loja.' });
  }

  next();
}

module.exports = { exigirDonoDaLoja, exigirProdutoDaLoja };

function emailsAdmin() {
  return String(process.env.SAAS_ADMIN_EMAILS || '')
    .split(',')
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean);
}

function usuarioEhAdmin(usuario) {
  const email = String(usuario?.email || '').trim().toLowerCase();
  return Boolean(email && emailsAdmin().includes(email));
}

function exigirAdmin(req, res, next) {
  if (!req.usuario) return res.status(401).json({ erro: 'Token de autenticação ausente.' });
  if (!usuarioEhAdmin(req.usuario)) return res.status(403).json({ erro: 'Acesso restrito ao administrador do SaaS.' });
  next();
}

module.exports = { emailsAdmin, usuarioEhAdmin, exigirAdmin };

/**
 * Rate limiter simples, em memória, sem dependência externa.
 *
 * Pensado para a rota pública /ia/perguntar (consumida por clientes finais,
 * sem login). Usa janela deslizante por chave (IP por padrão).
 *
 * LIMITAÇÃO CONHECIDA: como o estado fica em memória do processo, se o
 * serviço rodar em múltiplas instâncias (scale-out horizontal), cada
 * instância terá seu próprio contador — o limite efetivo vira
 * "limite x número de instâncias". Para um Micro-SaaS rodando uma única
 * instância (ex.: Render free/starter), isso é suficiente. Se no futuro o
 * serviço escalar horizontalmente, trocar por um contador compartilhado
 * (ex.: Redis) para manter o limite exato.
 */
function criarRateLimiter({ janelaMs, maxRequisicoes, mensagem, obterChave }) {
  const registros = new Map(); // chave -> array de timestamps (ms)

  // Limpeza periódica para não crescer indefinidamente em memória.
  const intervalo = setInterval(() => {
    const agora = Date.now();
    for (const [chave, timestamps] of registros.entries()) {
      const restantes = timestamps.filter((t) => t > agora - janelaMs);
      if (restantes.length === 0) {
        registros.delete(chave);
      } else {
        registros.set(chave, restantes);
      }
    }
  }, Math.max(janelaMs, 30000));
  intervalo.unref?.();

  return function rateLimiter(req, res, next) {
    const chave = obterChave ? obterChave(req) : req.ip;
    const agora = Date.now();
    const inicioJanela = agora - janelaMs;

    const timestamps = (registros.get(chave) || []).filter((t) => t > inicioJanela);

    if (timestamps.length >= maxRequisicoes) {
      const retryAfterMs = timestamps[0] + janelaMs - agora;
      res.setHeader('Retry-After', Math.max(1, Math.ceil(retryAfterMs / 1000)).toString());
      return res.status(429).json({
        erro: mensagem || 'Muitas requisições em pouco tempo. Tente novamente em instantes.',
      });
    }

    timestamps.push(agora);
    registros.set(chave, timestamps);
    next();
  };
}

module.exports = { criarRateLimiter };

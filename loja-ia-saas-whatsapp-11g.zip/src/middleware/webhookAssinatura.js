const {
  verificarAssinatura,
  obterSegredoDoAmbiente,
  NOME_HEADER_ASSINATURA,
  NOME_VARIAVEL_SEGREDO,
  MOTIVOS,
} = require('../services/whatsappWebhookAssinatura.service');

const RESPOSTA_NAO_AUTORIZADO = Object.freeze({ erro: 'Não autorizado.' });
const RESPOSTA_INDISPONIVEL = Object.freeze({ erro: 'Webhook temporariamente indisponível.' });

function criarVerificadorAssinatura({ obterSegredo = () => obterSegredoDoAmbiente() } = {}) {
  let avisouSegredoAusente = false;

  return function verificarAssinaturaWebhook(req, res, next) {
    try {
      const segredo = obterSegredo();
      if (!segredo) {
        if (!avisouSegredoAusente) {
          avisouSegredoAusente = true;
          console.error(`[webhook whatsapp] Verificação de assinatura indisponível: ${NOME_VARIAVEL_SEGREDO} não configurada. Webhook bloqueado.`);
        }
        return res.status(503).json(RESPOSTA_INDISPONIVEL);
      }
      avisouSegredoAusente = false;

      const resultado = verificarAssinatura({
        segredo,
        corpoBruto: req.corpoBruto,
        cabecalho: req.headers ? req.headers[NOME_HEADER_ASSINATURA] : undefined,
      });

      if (!resultado.ok) {
        console.warn(`[webhook whatsapp] Falha na verificação de assinatura (motivo: ${resultado.motivo}).`);
        return res.status(401).json(RESPOSTA_NAO_AUTORIZADO);
      }
    } catch (erro) {
      console.error('[webhook whatsapp] Erro inesperado na verificação de assinatura:', erro && erro.name ? erro.name : 'Error');
      return res.status(503).json(RESPOSTA_INDISPONIVEL);
    }
    return next();
  };
}

const verificarAssinaturaWebhook = criarVerificadorAssinatura();
module.exports = { verificarAssinaturaWebhook, criarVerificadorAssinatura, MOTIVOS };

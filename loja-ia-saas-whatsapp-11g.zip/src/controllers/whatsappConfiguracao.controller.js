const configuracoes = require('../services/whatsappConfiguracao.service');
const credenciais = require('../services/whatsappCredencial.service');

function responderErro(res, erro) {
  if (erro instanceof configuracoes.ErroConfiguracaoInvalida || erro instanceof credenciais.ErroCredencialInvalida) {
    return res.status(400).json({ erro: erro.message });
  }
  if (erro instanceof configuracoes.ErroConfiguracaoNaoEncontrada) return res.status(404).json({ erro: erro.message });
  if (erro instanceof configuracoes.ErroLojaNaoEncontrada) return res.status(404).json({ erro: erro.message });
  if (erro instanceof configuracoes.ErroConfiguracaoDuplicada) return res.status(409).json({ erro: erro.message });
  if (erro instanceof credenciais.ErroChaveCredenciaisAusente) return res.status(503).json({ erro: 'Armazenamento seguro de credenciais indisponível.' });
  return res.status(500).json({ erro: 'Não foi possível completar a configuração do WhatsApp.' });
}

async function criar(req, res) {
  try {
    const config = await configuracoes.criarConfiguracaoWhatsapp(req.body, req.params.lojaId);
    return res.status(201).json(config);
  } catch (erro) { return responderErro(res, erro); }
}
async function listar(req, res) {
  try {
    const itens = await configuracoes.listarConfiguracoesWhatsapp(req.params.lojaId);
    return res.json(itens);
  } catch (erro) { return responderErro(res, erro); }
}
async function buscar(req, res) {
  try {
    const config = await configuracoes.buscarConfiguracaoWhatsapp(req.params.configuracaoId, req.params.lojaId);
    return res.json(config);
  } catch (erro) { return responderErro(res, erro); }
}
async function atualizar(req, res) {
  try {
    const config = await configuracoes.atualizarConfiguracaoWhatsapp(req.params.configuracaoId, req.params.lojaId, req.body);
    return res.json(config);
  } catch (erro) { return responderErro(res, erro); }
}
async function desativar(req, res) {
  try {
    const config = await configuracoes.desativarConfiguracaoWhatsapp(req.params.configuracaoId, req.params.lojaId);
    return res.json(config);
  } catch (erro) { return responderErro(res, erro); }
}
async function salvarCredencial(req, res) {
  try {
    const estado = await credenciais.salvarCredencialMeta(req.params.configuracaoId, req.params.lojaId, req.body && req.body.access_token);
    return res.json(estado);
  } catch (erro) { return responderErro(res, erro); }
}
async function estadoCredencial(req, res) {
  try {
    const estado = await credenciais.obterEstadoCredencial(req.params.configuracaoId, req.params.lojaId);
    return res.json(estado);
  } catch (erro) { return responderErro(res, erro); }
}
async function removerCredencial(req, res) {
  try {
    const estado = await credenciais.removerCredencialMeta(req.params.configuracaoId, req.params.lojaId);
    return res.json(estado);
  } catch (erro) { return responderErro(res, erro); }
}

module.exports = { criar, listar, buscar, atualizar, desativar, salvarCredencial, estadoCredencial, removerCredencial };

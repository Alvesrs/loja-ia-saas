const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { clientePertenceALoja } = require('../services/autorizacao.service');
const { ehUuid, ehInteiroPositivo } = require('../utils/validacao');

// Nota: a propriedade da loja já foi verificada pelo middleware
// exigirDonoDaLoja (ver routes/pedidos.routes.js).

// Mapeia os tokens de erro lançados pela função RPC `criar_pedido`
// (ver src/db/schema.sql) para mensagens amigáveis e o status HTTP certo.
const ERROS_RPC_PEDIDO = {
  CLIENTE_INVALIDO: { status: 400, mensagem: 'O cliente informado não pertence a esta loja.' },
  ITENS_VAZIOS: { status: 400, mensagem: 'Informe ao menos um item no pedido.' },
  QUANTIDADE_INVALIDA: { status: 400, mensagem: 'Quantidade inválida em um dos itens do pedido.' },
  ITEM_INVALIDO: { status: 400, mensagem: 'Um dos itens do pedido não pertence a esta loja.' },
  ESTOQUE_INSUFICIENTE: { status: 409, mensagem: 'Estoque insuficiente para um dos itens do pedido.' },
};

/**
 * Body esperado:
 * {
 *   clienteId: "uuid" (opcional),
 *   itens: [{ estoqueId: "uuid", quantidade: 2 }, ...]
 * }
 *
 * Toda a criação do pedido (validar itens, checar estoque, debitar
 * estoque, inserir pedido + pedido_itens) acontece em uma única função
 * transacional no banco (`criar_pedido`, em src/db/schema.sql). Isso
 * garante atomicidade: ou o pedido inteiro é criado com seus itens e o
 * estoque debitado corretamente, ou nada é alterado. A função também usa
 * bloqueio de linha (SELECT ... FOR UPDATE) para evitar que dois pedidos
 * simultâneos vendam a mesma unidade em estoque (condição de corrida).
 */
async function criarPedido(req, res) {
  const { lojaId } = req.params;
  const { clienteId, itens } = req.body;

  if (clienteId !== undefined && clienteId !== null) {
    if (!ehUuid(clienteId)) {
      return res.status(400).json({ erro: 'Identificador de cliente inválido.' });
    }
    const clienteValido = await clientePertenceALoja(clienteId, lojaId);
    if (!clienteValido) {
      return res.status(400).json({ erro: 'O cliente informado não pertence a esta loja.' });
    }
  }

  if (!Array.isArray(itens) || itens.length === 0) {
    return res.status(400).json({ erro: 'Informe ao menos um item no pedido.' });
  }

  const itensNormalizados = [];
  for (const item of itens) {
    if (!item || !ehUuid(item.estoqueId) || !ehInteiroPositivo(item.quantidade)) {
      return res.status(400).json({
        erro: 'Cada item deve ter "estoqueId" válido e "quantidade" inteira maior que zero.',
      });
    }
    itensNormalizados.push({ estoque_id: item.estoqueId, quantidade: item.quantidade });
  }

  const { data, error } = await supabase.rpc('criar_pedido', {
    p_loja_id: lojaId,
    p_cliente_id: clienteId || null,
    p_itens: itensNormalizados,
  });

  if (error) {
    const erroConhecido = ERROS_RPC_PEDIDO[error.message];
    if (erroConhecido) {
      return res.status(erroConhecido.status).json({ erro: erroConhecido.mensagem });
    }
    return tratarErroBanco(res, error);
  }

  return res.status(201).json(data);
}

// Traz também o nome do cliente e, para cada item, o produto/variação de
// estoque relacionados — só leitura (embed do PostgREST via as chaves
// estrangeiras já existentes em schema.sql), nada de lógica nova. Isso é
// o que permite a tela de Pedidos mostrar "cliente", "produto", "cor",
// "tamanho" sem o frontend ter que fazer chamadas extras por pedido.
async function listarPedidos(req, res) {
  const { lojaId } = req.params;

  const { data, error } = await supabase
    .from('pedidos')
    .select(`
      *,
      clientes(nome),
      pedido_itens(
        id,
        quantidade,
        preco_unitario,
        estoque(id, tamanho, cor, produtos(nome))
      )
    `)
    .eq('loja_id', lojaId)
    .order('criado_em', { ascending: false });

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

module.exports = { criarPedido, listarPedidos };

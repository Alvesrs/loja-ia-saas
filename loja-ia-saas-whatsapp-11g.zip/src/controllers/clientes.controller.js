const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { ehUuid, ehStringNaoVazia, ehEmailValido, ehTelefoneValido } = require('../utils/validacao');

// Nota: a propriedade da loja já foi verificada pelo middleware
// exigirDonoDaLoja (ver routes/clientes.routes.js). Toda consulta abaixo
// que lê/altera um cliente específico também filtra por loja_id — assim
// nenhuma rota nova esquece essa checagem, mesmo com :lojaId já validado.

// Telefone e email são opcionais: null/undefined/'' são aceitos e
// gravados como null. Quando informados, precisam passar num formato
// minimamente válido (ver src/utils/validacao.js). Nunca reformatamos o
// telefone além de remover espaços nas pontas (rule: nada de
// normalização destrutiva).

function validarTelefoneOpcional(telefone) {
  if (telefone === undefined || telefone === null || telefone === '') {
    return { valido: true, valor: null };
  }
  if (typeof telefone !== 'string' || !ehTelefoneValido(telefone)) {
    return { valido: false };
  }
  return { valido: true, valor: telefone.trim() };
}

function validarEmailOpcional(email) {
  if (email === undefined || email === null || email === '') {
    return { valido: true, valor: null };
  }
  if (typeof email !== 'string' || !ehEmailValido(email)) {
    return { valido: false };
  }
  return { valido: true, valor: email.trim() };
}

async function criarCliente(req, res) {
  const { lojaId } = req.params;
  const { nome, telefone, email } = req.body;

  if (!ehStringNaoVazia(nome)) {
    return res.status(400).json({ erro: 'Informe o nome do cliente.' });
  }

  const telefoneValidado = validarTelefoneOpcional(telefone);
  if (!telefoneValidado.valido) {
    return res.status(400).json({ erro: 'Telefone inválido.' });
  }

  const emailValidado = validarEmailOpcional(email);
  if (!emailValidado.valido) {
    return res.status(400).json({ erro: 'Email inválido.' });
  }

  const { data, error } = await supabase
    .from('clientes')
    .insert({
      loja_id: lojaId,
      nome: nome.trim(),
      telefone: telefoneValidado.valor,
      email: emailValidado.valor,
    })
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.status(201).json(data);
}

async function listarClientes(req, res) {
  const { lojaId } = req.params;

  const { data, error } = await supabase
    .from('clientes')
    .select('*')
    .eq('loja_id', lojaId)
    .order('criado_em', { ascending: false });

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

async function atualizarCliente(req, res) {
  const { lojaId, clienteId } = req.params;
  const { nome, telefone, email } = req.body;

  if (!ehUuid(clienteId)) {
    return res.status(400).json({ erro: 'Identificador de cliente inválido.' });
  }

  // Atualização parcial: só incluímos no update os campos que vieram no
  // corpo da requisição, para nunca apagar campos não enviados.
  const dadosAtualizados = {};

  if (nome !== undefined) {
    if (!ehStringNaoVazia(nome)) {
      return res.status(400).json({ erro: 'Nome inválido.' });
    }
    dadosAtualizados.nome = nome.trim();
  }

  if (telefone !== undefined) {
    const telefoneValidado = validarTelefoneOpcional(telefone);
    if (!telefoneValidado.valido) {
      return res.status(400).json({ erro: 'Telefone inválido.' });
    }
    dadosAtualizados.telefone = telefoneValidado.valor;
  }

  if (email !== undefined) {
    const emailValidado = validarEmailOpcional(email);
    if (!emailValidado.valido) {
      return res.status(400).json({ erro: 'Email inválido.' });
    }
    dadosAtualizados.email = emailValidado.valor;
  }

  if (Object.keys(dadosAtualizados).length === 0) {
    return res.status(400).json({ erro: 'Envie ao menos um campo para atualizar.' });
  }

  const { data, error } = await supabase
    .from('clientes')
    .update(dadosAtualizados)
    .eq('id', clienteId)
    .eq('loja_id', lojaId)
    .select()
    .maybeSingle();

  if (error) return tratarErroBanco(res, error);
  if (!data) return res.status(404).json({ erro: 'Cliente não encontrado nessa loja.' });
  return res.json(data);
}

async function removerCliente(req, res) {
  const { lojaId, clienteId } = req.params;

  if (!ehUuid(clienteId)) {
    return res.status(400).json({ erro: 'Identificador de cliente inválido.' });
  }

  const { data, error } = await supabase
    .from('clientes')
    .delete()
    .eq('id', clienteId)
    .eq('loja_id', lojaId)
    .select()
    .maybeSingle();

  if (error) return tratarErroBanco(res, error);
  if (!data) return res.status(404).json({ erro: 'Cliente não encontrado nessa loja.' });
  return res.status(204).send();
}

module.exports = { criarCliente, listarClientes, atualizarCliente, removerCliente };

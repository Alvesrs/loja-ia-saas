const webhookService = require('../services/whatsappWebhook.service');
const filaService = require('../services/whatsappFila.service');
const workerService = require('../services/whatsappWorker.service');
const interpretadorMeta = require('../services/providers/whatsapp/interpretadorWebhookMeta');
const idempotenciaService = require('../services/whatsappIdempotencia.service');
const { ErroWebhookMetaInvalido, TIPOS_MENSAGEM_WEBHOOK } = interpretadorMeta;
const { verificarHandshake, obterVerifyTokenDoAmbiente } = require('../services/whatsappWebhookAssinatura.service');

/**
 * 10O: payload autenticado → parser → resolução da loja → reserva idempotente → fila persistente.
 * Só a primeira mensagem de texto válida é enfileirada (limitação herdada).
 * O webhook confirma 200 após persistência do job; IA, histórico e envio são executados pelo worker.
 * HMAC, corpo bruto, limite de body e rate limit continuam na rota.
 */

const MENSAGENS = Object.freeze({
  recebido: 'recebido',
  semMensagemProcessavel: 'sem_mensagem_processavel',
  eventoInvalido: 'Evento de WhatsApp inválido.',
  naoEncontrada: 'Configuração de WhatsApp não encontrada.',
  corpoInvalido: 'Corpo da requisição inválido.',
  corpoGrande: 'Corpo da requisição muito grande.',
  erroInterno: 'Erro interno ao processar o evento.',
  duplicadoIgnorado: 'duplicado_ignorado',
});

// Provedor sempre fixo: esta rota só liga o interpretador da Meta. Nunca lido
// do body, de headers, de query/params nem de `req.contextoWebhook` — é uma
// decisão do PRÓPRIO controller, não algo que quem chama possa influenciar.
const CONTEXTO_CONFIAVEL_META = Object.freeze({ provedor: 'meta' });

// Resumo seguro de um erro para o log do servidor: tipo, código e as
// primeiras chamadas da pilha. Deliberadamente SEM `message` (pode conter
// trechos de SQL, hosts ou dados do evento) e SEM o body.
function resumirErroParaLog(erro) {
  const frames = typeof erro?.stack === 'string'
    ? erro.stack.split('\n').map((linha) => linha.trim()).filter((linha) => linha.startsWith('at ')).slice(0, 3)
    : [];
  return { tipo: erro?.name || 'Error', codigo: erro?.code ?? erro?.type ?? null, frames };
}

function responderErroInterno(res, erro) {
  console.error('[webhook whatsapp] erro inesperado:', resumirErroParaLog(erro));
  return res.status(500).json({ erro: MENSAGENS.erroInterno });
}

/**
 * Escolhe, entre as mensagens já interpretadas pelo 10H, a primeira
 * mensagem de texto válida e suportada (ver limitação de lote no cabeçalho
 * deste arquivo). Função pura, sem I/O.
 *
 * @param {ReadonlyArray<object>} mensagensInterpretadas
 * @returns {{mensagemTexto: object|null, existeInvalida: boolean}}
 */
function selecionarMensagemParaProcessar(mensagensInterpretadas) {
  let mensagemTexto = null;
  let existeInvalida = false;

  for (const mensagem of mensagensInterpretadas) {
    if (!mensagem.valida) {
      existeInvalida = true;
      continue;
    }
    if (mensagemTexto === null && mensagem.suportada && mensagem.tipo === TIPOS_MENSAGEM_WEBHOOK.texto) {
      mensagemTexto = mensagem;
    }
  }

  return { mensagemTexto, existeInvalida };
}


function verificarWebhookMeta(req, res) {
  try {
    const resultado = verificarHandshake({
      modo: req.query && req.query['hub.mode'],
      tokenRecebido: req.query && req.query['hub.verify_token'],
      challenge: req.query && req.query['hub.challenge'],
      tokenEsperado: obterVerifyTokenDoAmbiente(),
    });

    if (resultado.ok) {
      return res.status(200).send(resultado.challenge);
    }
    if (resultado.motivo === 'verify_token_ausente') {
      console.error('[webhook whatsapp] Verificação GET indisponível: token de verificação não configurado.');
      return res.status(503).json({ erro: 'Webhook temporariamente indisponível.' });
    }
    return res.status(403).json({ erro: 'Verificação rejeitada.' });
  } catch (erro) {
    return responderErroInterno(res, erro);
  }
}

async function receberEvento(req, res) {
  let mensagensInterpretadas;
  try {
    mensagensInterpretadas = interpretadorMeta.interpretarPayloadWebhookMeta(req.body);
  } catch (erro) {
    if (erro instanceof ErroWebhookMetaInvalido) {
      return res.status(400).json({ erro: MENSAGENS.eventoInvalido });
    }
    return responderErroInterno(res, erro);
  }

  const { mensagemTexto, existeInvalida } = selecionarMensagemParaProcessar(mensagensInterpretadas);

  if (mensagemTexto === null) {
    // Mensagem estruturalmente malformada (sem id/remetente/destinatário/
    // corpo): mesmo tratamento de payload inválido, sem tentar completar o
    // que faltou.
    if (existeInvalida) {
      return res.status(400).json({ erro: MENSAGENS.eventoInvalido });
    }
    // Nenhuma mensagem de texto processável: tipo não suportado (imagem,
    // áudio, ...), evento só com `statuses`, ou payload sem nenhuma
    // mensagem reconhecível. Resposta 200 controlada e idêntica nos três
    // casos — sem chamar IA, sem enviar mensagem, sem gerar texto.
    return res.status(200).json({ status: MENSAGENS.semMensagemProcessavel });
  }

  // Evento genérico entregue ao service da 10C: só os cinco campos
  // esperados, montados EXPLICITAMENTE a partir do resultado do
  // interpretador (nunca por espalhamento do payload bruto da Meta).
  const evento = {
    destinatarioId: mensagemTexto.destinatarioId,
    contato: mensagemTexto.contato,
    texto: mensagemTexto.texto,
    idExterno: mensagemTexto.idExterno,
    timestamp: mensagemTexto.timestamp,
  };

  const chaveIdempotencia = {
    provedor: CONTEXTO_CONFIAVEL_META.provedor,
    idExterno: mensagemTexto.idExterno,
  };

  let reservaCriada = false;

  try {
    const mensagemInterna = await webhookService.processarEventoWhatsapp(evento, CONTEXTO_CONFIAVEL_META);

    reservaCriada = await idempotenciaService.reservarEventoWhatsapp(chaveIdempotencia);
    if (!reservaCriada) {
      return res.status(200).json({ status: MENSAGENS.duplicadoIgnorado });
    }

    const job = await filaService.enfileirarMensagemWhatsapp(mensagemInterna, {
      provedor: CONTEXTO_CONFIAVEL_META.provedor,
      destinatarioId: mensagemTexto.destinatarioId,
    });

    // Confirma para a Meta assim que o job está duravelmente persistido. A
    // primeira tentativa pode continuar neste processo sem manter o provedor
    // esperando; o lease impede que o worker periódico pegue o mesmo job.
    res.status(200).json({ status: MENSAGENS.recebido });
    await workerService.processarJob(job);
    return res;
  } catch (erro) {
    // Se não foi possível persistir o job, a reserva é liberada para que uma
    // reentrega real da Meta possa tentar novamente. Depois do enqueue, o
    // worker assume integralmente retries e conclusão.
    if (reservaCriada) {
      try {
        await idempotenciaService.liberarEventoWhatsapp(chaveIdempotencia);
      } catch (erroLiberacao) {
        console.error('[webhook whatsapp] falha segura ao liberar reserva de idempotência:', resumirErroParaLog(erroLiberacao));
      }
    }

    if (erro instanceof webhookService.ErroEventoWhatsappInvalido) {
      return res.status(400).json({ erro: MENSAGENS.eventoInvalido });
    }
    if (erro instanceof webhookService.ErroDestinatarioNaoIdentificado) {
      return res.status(404).json({ erro: MENSAGENS.naoEncontrada });
    }
    // Inclui falha de banco (ErroConfiguracaoBanco) e qualquer outra falha
    // inesperada: não são culpa de quem enviou o evento.
    return responderErroInterno(res, erro);
  }
}

/**
 * Tratador de erros da rota do webhook (middleware de 4 argumentos).
 * Cobre o que acontece ANTES do controller, principalmente no parser JSON:
 * corpo grande demais, JSON malformado etc. Nunca devolve o erro original.
 * (Inalterado desde a Etapa 10D.)
 */
function tratarErroDeRequisicao(erro, req, res, next) {
  if (res.headersSent) return next(erro);

  if (erro && erro.type === 'entity.too.large') {
    return res.status(413).json({ erro: MENSAGENS.corpoGrande });
  }
  // Erros de leitura/interpretação do corpo lançados pelo body-parser
  // (entity.parse.failed, request.aborted, charset.unsupported, ...).
  if (erro && typeof erro.type === 'string' && /^(entity|request|charset|encoding)\./.test(erro.type)) {
    return res.status(400).json({ erro: MENSAGENS.corpoInvalido });
  }
  return responderErroInterno(res, erro);
}

module.exports = { verificarWebhookMeta, receberEvento, tratarErroDeRequisicao };

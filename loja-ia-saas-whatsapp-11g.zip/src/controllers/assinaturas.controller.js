const { obterSituacaoPlano } = require('../services/assinaturas.service');
const { listarPlanos } = require('../config/planos');

async function minhaAssinatura(req, res) {
  try {
    const situacao = await obterSituacaoPlano(req.params.lojaId);
    return res.json({ ...situacao, planosDisponiveis: listarPlanos() });
  } catch (erro) {
    console.error('[assinaturas] falha ao consultar assinatura:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Não foi possível consultar o plano da empresa.' });
  }
}

module.exports = { minhaAssinatura };

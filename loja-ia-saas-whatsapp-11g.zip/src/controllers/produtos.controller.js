const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { ehUuid, ehStringNaoVazia, ehNumeroNaoNegativo, ehBooleano } = require('../utils/validacao');

// Nota: a propriedade da loja (:lojaId pertence a req.usuario) já foi
// verificada pelo middleware exigirDonoDaLoja antes de qualquer função
// abaixo rodar (ver routes/produtos.routes.js).

async function criarProduto(req, res) {
  const { lojaId } = req.params;
  const { nome, descricao, preco, categoria } = req.body;

  if (!ehStringNaoVazia(nome)) {
    return res.status(400).json({ erro: 'Informe o nome do produto.' });
  }

  if (!ehNumeroNaoNegativo(preco)) {
    return res.status(400).json({ erro: 'Informe um preço numérico maior ou igual a zero.' });
  }

  if (descricao !== undefined && descricao !== null && typeof descricao !== 'string') {
    return res.status(400).json({ erro: 'Descrição inválida.' });
  }

  if (categoria !== undefined && categoria !== null && typeof categoria !== 'string') {
    return res.status(400).json({ erro: 'Categoria inválida.' });
  }

  const { data, error } = await supabase
    .from('produtos')
    .insert({ loja_id: lojaId, nome: nome.trim(), descricao, preco, categoria })
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.status(201).json(data);
}

async function listarProdutos(req, res) {
  const { lojaId } = req.params;

  const { data, error } = await supabase
    .from('produtos')
    .select('*, estoque(*)')
    .eq('loja_id', lojaId)
    .order('criado_em', { ascending: false });

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

async function atualizarProduto(req, res) {
  const { lojaId, produtoId } = req.params;
  const { nome, descricao, preco, categoria, ativo } = req.body;

  if (!ehUuid(produtoId)) {
    return res.status(400).json({ erro: 'Identificador de produto inválido.' });
  }

  // Atualização parcial: só incluímos no update os campos que vieram no
  // corpo da requisição, para nunca apagar campos não enviados.
  const dadosAtualizados = {};

  if (nome !== undefined) {
    if (!ehStringNaoVazia(nome)) {
      return res.status(400).json({ erro: 'Nome inválido.' });
    }
    dadosAtualizados.nome = nome.trim();
  }

  if (descricao !== undefined) {
    if (descricao !== null && typeof descricao !== 'string') {
      return res.status(400).json({ erro: 'Descrição inválida.' });
    }
    dadosAtualizados.descricao = descricao;
  }

  if (preco !== undefined) {
    if (!ehNumeroNaoNegativo(preco)) {
      return res.status(400).json({ erro: 'Informe um preço numérico maior ou igual a zero.' });
    }
    dadosAtualizados.preco = preco;
  }

  if (categoria !== undefined) {
    if (categoria !== null && typeof categoria !== 'string') {
      return res.status(400).json({ erro: 'Categoria inválida.' });
    }
    dadosAtualizados.categoria = categoria;
  }

  if (ativo !== undefined) {
    if (!ehBooleano(ativo)) {
      return res.status(400).json({ erro: '"ativo" deve ser verdadeiro ou falso.' });
    }
    dadosAtualizados.ativo = ativo;
  }

  if (Object.keys(dadosAtualizados).length === 0) {
    return res.status(400).json({ erro: 'Envie ao menos um campo para atualizar.' });
  }

  const { data, error } = await supabase
    .from('produtos')
    .update(dadosAtualizados)
    .eq('id', produtoId)
    .eq('loja_id', lojaId)
    .select()
    .maybeSingle();

  if (error) return tratarErroBanco(res, error);
  if (!data) return res.status(404).json({ erro: 'Produto não encontrado nessa loja.' });
  return res.json(data);
}

async function removerProduto(req, res) {
  const { lojaId, produtoId } = req.params;

  if (!ehUuid(produtoId)) {
    return res.status(400).json({ erro: 'Identificador de produto inválido.' });
  }

  const { data, error } = await supabase
    .from('produtos')
    .delete()
    .eq('id', produtoId)
    .eq('loja_id', lojaId)
    .select()
    .maybeSingle();

  if (error) return tratarErroBanco(res, error);
  if (!data) return res.status(404).json({ erro: 'Produto não encontrado nessa loja.' });
  return res.status(204).send();
}

module.exports = { criarProduto, listarProdutos, atualizarProduto, removerProduto };

const supabase = require('../config/supabase');
const { usuarioEhAdmin } = require('../middleware/admin');
const { listarPlanos } = require('../config/planos');
const { obterSituacaoPlano, definirAssinatura } = require('../services/assinaturas.service');
const { ehUuid } = require('../utils/validacao');

async function me(req, res) {
  return res.json({ admin: usuarioEhAdmin(req.usuario) });
}

async function listarEmpresas(req, res) {
  try {
    const { data: lojas, error } = await supabase
      .from('lojas')
      .select('id, nome, ativa, criado_em')
      .order('criado_em', { ascending: false });
    if (error) throw error;

    const empresas = [];
    for (const loja of lojas || []) {
      const situacao = await obterSituacaoPlano(loja.id);
      empresas.push({ loja, situacao });
    }
    return res.json({ empresas, planosDisponiveis: listarPlanos() });
  } catch (erro) {
    console.error('[admin] falha ao listar empresas:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Não foi possível carregar as empresas.' });
  }
}

async function atualizarAssinatura(req, res) {
  const { lojaId } = req.params;
  const { plano, status, valido_ate } = req.body || {};
  if (!ehUuid(lojaId)) return res.status(400).json({ erro: 'Identificador de loja inválido.' });

  const { data: loja, error } = await supabase.from('lojas').select('id').eq('id', lojaId).maybeSingle();
  if (error) return res.status(500).json({ erro: 'Não foi possível consultar a empresa.' });
  if (!loja) return res.status(404).json({ erro: 'Empresa não encontrada.' });

  try {
    const assinatura = await definirAssinatura(lojaId, { plano, status, valido_ate });
    const situacao = await obterSituacaoPlano(lojaId);
    return res.json({ assinatura, situacao });
  } catch (erro) {
    if (erro.message === 'plano_invalido') return res.status(400).json({ erro: 'Plano inválido.' });
    if (erro.message === 'status_invalido') return res.status(400).json({ erro: 'Status inválido.' });
    if (erro.message === 'validade_invalida') return res.status(400).json({ erro: 'Data de validade inválida.' });
    console.error('[admin] falha ao atualizar assinatura:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Não foi possível atualizar a assinatura.' });
  }
}

module.exports = { me, listarEmpresas, atualizarAssinatura };

const historico = require('../services/whatsappHistorico.service');

function responderErro(res, erro) {
  if (erro instanceof TypeError) return res.status(400).json({ erro: 'Identificador inválido.' });
  if (erro instanceof historico.ErroHistoricoWhatsapp) {
    return res.status(500).json({ erro: 'Não foi possível consultar o histórico do WhatsApp.' });
  }
  return res.status(500).json({ erro: 'Não foi possível consultar o histórico do WhatsApp.' });
}

async function listarConversas(req, res) {
  try {
    const itens = await historico.listarConversas(req.params.lojaId);
    return res.json(itens);
  } catch (erro) {
    return responderErro(res, erro);
  }
}

async function listarMensagens(req, res) {
  try {
    const itens = await historico.listarMensagens(req.params.conversaId, req.params.lojaId);
    return res.json(itens);
  } catch (erro) {
    return responderErro(res, erro);
  }
}

module.exports = { listarConversas, listarMensagens };

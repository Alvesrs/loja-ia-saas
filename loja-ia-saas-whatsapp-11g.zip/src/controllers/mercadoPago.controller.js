const { criarCheckoutAssinatura, assinaturaWebhookValida, processarAtualizacaoAssinaturaMp, configurado } = require('../services/mercadoPago.service');

async function criarCheckout(req, res) {
  try {
    const plano = String(req.body?.plano || '').trim();
    const resultado = await criarCheckoutAssinatura({ lojaId: req.params.lojaId, planoCodigo: plano, payerEmail: req.usuario?.email });
    return res.status(201).json(resultado);
  } catch (erro) {
    if (erro.message === 'mercadopago_nao_configurado') return res.status(503).json({ erro: 'Cobrança automática ainda não está configurada.' });
    if (erro.message === 'plano_nao_vendavel') return res.status(400).json({ erro: 'Este plano não pode ser comprado.' });
    if (erro.message === 'preco_nao_configurado') return res.status(503).json({ erro: 'O preço deste plano ainda não foi configurado.' });
    console.error('[mercadopago] falha ao criar checkout:', erro?.name || 'erro');
    return res.status(502).json({ erro: 'Não foi possível iniciar o pagamento agora.' });
  }
}

function statusIntegracao(req, res) {
  return res.json({ provedor: 'mercadopago', configurado: configurado() });
}

async function receberNotificacao(req, res) {
  const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
  if (!secret) return res.status(503).json({ erro: 'Webhook não configurado.' });
  const dataId = req.query['data.id'] || req.body?.data?.id;
  const valido = assinaturaWebhookValida({
    xSignature: req.headers['x-signature'],
    xRequestId: req.headers['x-request-id'],
    dataId,
    secret,
  });
  if (!valido) return res.status(401).json({ erro: 'Assinatura inválida.' });

  // Apenas eventos de vínculo/atualização de assinatura alteram a assinatura local.
  const tipo = String(req.body?.type || req.query.type || '');
  if (tipo !== 'subscription_preapproval' || !dataId) return res.status(200).json({ ok: true, ignorado: true });

  try {
    await processarAtualizacaoAssinaturaMp(String(dataId));
    return res.status(200).json({ ok: true });
  } catch (erro) {
    console.error('[mercadopago webhook] falha ao sincronizar assinatura:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Falha ao sincronizar assinatura.' });
  }
}

module.exports = { criarCheckout, statusIntegracao, receberNotificacao };

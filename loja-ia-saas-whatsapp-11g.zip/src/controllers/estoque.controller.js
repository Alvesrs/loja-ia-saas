const supabase = require('../config/supabase');
const { tratarErroBanco } = require('../utils/erros');
const { buscarEstoqueDaLoja } = require('../services/autorizacao.service');
const { ehUuid, ehStringNaoVazia, ehInteiroNaoNegativo } = require('../utils/validacao');

// Nota: :lojaId (dono do usuário) e :produtoId (pertence à loja) já foram
// verificados pelos middlewares exigirDonoDaLoja e exigirProdutoDaLoja
// antes de qualquer função abaixo rodar (ver routes/produtos.routes.js).
// Isso corrige a falha da versão anterior, em que era possível criar ou
// alterar estoque de PRODUTOS DE OUTRAS LOJAS.

async function adicionarVariacao(req, res) {
  const { produtoId } = req.params;
  const { tamanho, cor, quantidade } = req.body;

  if (!ehStringNaoVazia(tamanho) || !ehStringNaoVazia(cor)) {
    return res.status(400).json({ erro: 'Informe tamanho e cor (texto não vazio).' });
  }

  const quantidadeFinal = quantidade === undefined ? 0 : quantidade;
  if (!ehInteiroNaoNegativo(quantidadeFinal)) {
    return res.status(400).json({ erro: 'Quantidade deve ser um número inteiro maior ou igual a zero.' });
  }

  const { data, error } = await supabase
    .from('estoque')
    .upsert(
      { produto_id: produtoId, tamanho: tamanho.trim(), cor: cor.trim(), quantidade: quantidadeFinal },
      { onConflict: 'produto_id,tamanho,cor' }
    )
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.status(201).json(data);
}

async function atualizarQuantidade(req, res) {
  const { lojaId, produtoId, estoqueId } = req.params;
  const { quantidade } = req.body;

  if (!ehUuid(estoqueId)) {
    return res.status(400).json({ erro: 'Identificador de estoque inválido.' });
  }

  if (!ehInteiroNaoNegativo(quantidade)) {
    return res.status(400).json({ erro: 'Informe uma quantidade válida (inteiro >= 0).' });
  }

  // Confirma a cadeia completa: este registro de estoque pertence a este
  // produto, que pertence a esta loja. Sem isso, um usuário dono de
  // QUALQUER loja poderia alterar o estoque de OUTRA loja apenas
  // adivinhando um estoqueId.
  const estoqueAtual = await buscarEstoqueDaLoja(estoqueId, produtoId, lojaId);
  if (!estoqueAtual) {
    return res.status(404).json({ erro: 'Registro de estoque não encontrado nesse produto/loja.' });
  }

  const { data, error } = await supabase
    .from('estoque')
    .update({ quantidade, atualizado_em: new Date().toISOString() })
    .eq('id', estoqueId)
    .select()
    .single();

  if (error) return tratarErroBanco(res, error);
  return res.json(data);
}

module.exports = { adicionarVariacao, atualizarQuantidade };

const supabase = require('../config/supabase');
const { responderPergunta } = require('../services/ia.service');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');
const { obterSituacaoPlano } = require('../services/assinaturas.service');

const TAMANHO_MAXIMO_PERGUNTA = 500;

async function perguntar(req, res) {
  const { lojaId } = req.params;
  const { pergunta } = req.body;

  if (!ehUuid(lojaId)) {
    return res.status(400).json({ erro: 'Identificador de loja inválido.' });
  }

  if (!ehStringNaoVazia(pergunta)) {
    return res.status(400).json({ erro: 'Envie o campo "pergunta" com o texto do cliente.' });
  }

  if (pergunta.length > TAMANHO_MAXIMO_PERGUNTA) {
    return res.status(400).json({ erro: `A pergunta deve ter no máximo ${TAMANHO_MAXIMO_PERGUNTA} caracteres.` });
  }

  const { data: loja, error } = await supabase
    .from('lojas')
    .select('id, ativa')
    .eq('id', lojaId)
    .maybeSingle();

  if (error) {
    console.error('[erro ao buscar loja para IA]', error);
    return res.status(500).json({ erro: 'Não foi possível consultar a loja no momento.' });
  }

  if (!loja || !loja.ativa) {
    return res.status(404).json({ erro: 'Loja não encontrada ou inativa.' });
  }

  try {
    const situacaoPlano = await obterSituacaoPlano(lojaId);
    if (!situacaoPlano.ativo) {
      return res.status(402).json({
        erro: situacaoPlano.motivoBloqueio === 'limite_mensal_atingido'
          ? 'O limite mensal de atendimentos deste plano foi atingido.'
          : 'A assinatura desta empresa não está ativa.'
      });
    }

    const resposta = await responderPergunta(lojaId, pergunta);
    return res.json({ resposta });
  } catch (err) {
    console.error('[erro ao consultar catálogo para IA]', err);
    return res.status(500).json({ erro: 'Erro ao consultar o catálogo da loja.' });
  }
}

module.exports = { perguntar };

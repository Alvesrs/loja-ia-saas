const express = require('express');
const { verificarWebhookMeta, receberEvento, tratarErroDeRequisicao } = require('../controllers/whatsappWebhook.controller');
const { criarRateLimiter } = require('../middleware/rateLimiter');
const { verificarAssinaturaWebhook } = require('../middleware/webhookAssinatura');

/**
 * Etapa 10L — webhook nativo da Meta.
 *
 * GET  /api/webhooks/whatsapp: handshake de cadastro do webhook
 * POST /api/webhooks/whatsapp: eventos Meta autenticados por
 * X-Hub-Signature-256 sobre o corpo bruto.
 */
const LIMITE_CORPO = '100kb';
const router = express.Router();

const limitarWebhook = criarRateLimiter({
  janelaMs: Number(process.env.WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS) || 60_000,
  maxRequisicoes: Number(process.env.WHATSAPP_WEBHOOK_RATE_LIMIT_MAX) || 300,
  mensagem: 'Muitas requisições em pouco tempo. Tente novamente em instantes.',
});

function guardarCorpoBruto(req, res, buffer) {
  req.corpoBruto = buffer;
}

const interpretarJson = express.json({ limit: LIMITE_CORPO, verify: guardarCorpoBruto });

router.post('/', limitarWebhook, interpretarJson, verificarAssinaturaWebhook, receberEvento);
router.get('/', limitarWebhook, verificarWebhookMeta);
router.use(tratarErroDeRequisicao);

module.exports = router;

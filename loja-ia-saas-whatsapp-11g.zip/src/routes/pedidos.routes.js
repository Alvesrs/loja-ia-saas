const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');
const { criarPedido, listarPedidos } = require('../controllers/pedidos.controller');

const router = express.Router({ mergeParams: true });

router.use(exigirLogin);
router.use(exigirDonoDaLoja);
router.post('/', criarPedido);
router.get('/', listarPedidos);

module.exports = router;

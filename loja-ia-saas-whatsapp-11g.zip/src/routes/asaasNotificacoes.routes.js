const express = require('express');
const { receberNotificacao } = require('../controllers/asaas.controller');
const router = express.Router();
router.post('/', express.json({ limit: '100kb' }), receberNotificacao);
module.exports = router;

const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { criarLoja, listarMinhasLojas, atualizarPromptMestre } = require('../controllers/lojas.controller');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');

const router = express.Router();

router.use(exigirLogin);
router.post('/', criarLoja);
router.get('/', listarMinhasLojas);
router.put('/:lojaId/prompt-mestre', exigirDonoDaLoja, atualizarPromptMestre);

module.exports = router;

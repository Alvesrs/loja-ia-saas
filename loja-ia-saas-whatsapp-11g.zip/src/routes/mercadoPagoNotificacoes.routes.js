const express = require('express');
const { receberNotificacao } = require('../controllers/mercadoPago.controller');
const router = express.Router();
router.post('/', express.json({ limit: '100kb' }), receberNotificacao);
module.exports = router;

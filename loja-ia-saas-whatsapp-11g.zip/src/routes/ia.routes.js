const express = require('express');
const cors = require('cors');
const { perguntar } = require('../controllers/ia.controller');
const { criarRateLimiter } = require('../middleware/rateLimiter');

// Rota pública de propósito: é o "cliente final" perguntando sobre o
// catálogo da loja, então não exige login do lojista. Por ser pública e
// sem autenticação, protegemos contra abuso com rate limiting.
const router = express.Router({ mergeParams: true });

// CORS aberto DELIBERADAMENTE só nesta rota (correção da auditoria
// técnica de CORS: a configuração global em src/config/cors.js agora é
// restritiva por padrão, mas essa rota precisa continuar aceitando
// qualquer origem, pois é chamada a partir dos sites das PRÓPRIAS lojas
// — domínios de terceiros, desconhecidos de antemão). Isso é seguro
// porque a rota não usa cookies/sessão e só devolve catálogo público
// (produto/preço/tamanho/cor/disponibilidade), nunca dado sensível.
router.use(cors());

const limitarPerguntas = criarRateLimiter({
  janelaMs: Number(process.env.IA_RATE_LIMIT_JANELA_MS) || 60_000,
  maxRequisicoes: Number(process.env.IA_RATE_LIMIT_MAX) || 20,
  mensagem: 'Muitas perguntas em pouco tempo. Aguarde um instante e tente novamente.',
});

router.post('/perguntar', limitarPerguntas, perguntar);

module.exports = router;

const express = require('express');
const { diagnosticarConfiguracao } = require('../config/producao');
const { obterEstadoWorker } = require('../services/whatsappWorker.service');

const router = express.Router();

router.get('/live', (req, res) => {
  res.json({ ok: true, servico: 'loja-ia-saas' });
});

router.get('/ready', (req, res) => {
  const config = diagnosticarConfiguracao(process.env, { producao: process.env.NODE_ENV === 'production' });
  const worker = obterEstadoWorker();
  const corpo = {
    ok: config.ok,
    servico: 'loja-ia-saas',
    ambiente: config.ambiente,
    worker: { iniciado: worker.iniciado, cicloEmAndamento: worker.cicloEmAndamento },
    configuracao: config.ok ? 'ok' : 'invalida',
  };
  res.status(config.ok ? 200 : 503).json(corpo);
});

module.exports = router;

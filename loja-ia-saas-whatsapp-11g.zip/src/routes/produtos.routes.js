const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja, exigirProdutoDaLoja } = require('../middleware/lojaOwnership');
const {
  criarProduto,
  listarProdutos,
  atualizarProduto,
  removerProduto,
} = require('../controllers/produtos.controller');
const estoqueRoutes = require('./estoque.routes');

const router = express.Router({ mergeParams: true });

router.use(exigirLogin);
router.use(exigirDonoDaLoja);

router.post('/', criarProduto);
router.get('/', listarProdutos);
router.patch('/:produtoId', atualizarProduto);
router.delete('/:produtoId', removerProduto);

// A partir daqui, também garantimos que :produtoId pertence a :lojaId
// antes de entrar nas rotas de estoque.
router.use('/:produtoId/estoque', exigirProdutoDaLoja, estoqueRoutes);

module.exports = router;

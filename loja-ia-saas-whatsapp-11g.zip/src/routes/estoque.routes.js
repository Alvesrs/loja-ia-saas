const express = require('express');
const { adicionarVariacao, atualizarQuantidade } = require('../controllers/estoque.controller');

// exigirLogin, exigirDonoDaLoja e exigirProdutoDaLoja já foram aplicados
// no router pai (produtos.routes.js) antes de chegar aqui.
const router = express.Router({ mergeParams: true });

router.post('/', adicionarVariacao);
router.patch('/:estoqueId', atualizarQuantidade);

module.exports = router;

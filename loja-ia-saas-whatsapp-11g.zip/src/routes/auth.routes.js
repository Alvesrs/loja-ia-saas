const express = require('express');
const { cadastrar, login } = require('../controllers/auth.controller');
const { criarRateLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Rate limiting de autenticação (correção da auditoria técnica).
// Sem isso, /login e /cadastrar não tinham NENHUMA proteção contra
// abuso — um atacante podia tentar senhas ilimitadas contra um email
// (força bruta / credential stuffing) ou criar contas em massa.
// Continua em memória (sem Redis/infra paga), igual ao limitador já
// usado em /ia/perguntar — suficiente para uma única instância (MVP).

// Login: limite por IP + email, para não bloquear usuários legítimos
// atrás do mesmo IP (ex: rede corporativa/NAT) por causa de um ataque
// contra uma única conta.
const limitarLogin = criarRateLimiter({
  janelaMs: Number(process.env.AUTH_LOGIN_RATE_LIMIT_JANELA_MS) || 5 * 60_000,
  maxRequisicoes: Number(process.env.AUTH_LOGIN_RATE_LIMIT_MAX) || 10,
  mensagem: 'Muitas tentativas de login. Aguarde alguns minutos e tente novamente.',
  obterChave: (req) => `${req.ip}:${String(req.body?.email || '').trim().toLowerCase()}`,
});

// Cadastro: limite por IP, para dificultar a criação automatizada de
// contas em massa.
const limitarCadastro = criarRateLimiter({
  janelaMs: Number(process.env.AUTH_CADASTRO_RATE_LIMIT_JANELA_MS) || 15 * 60_000,
  maxRequisicoes: Number(process.env.AUTH_CADASTRO_RATE_LIMIT_MAX) || 10,
  mensagem: 'Muitas tentativas de cadastro. Aguarde alguns minutos e tente novamente.',
});

router.post('/cadastrar', limitarCadastro, cadastrar);
router.post('/login', limitarLogin, login);

module.exports = router;

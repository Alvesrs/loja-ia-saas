const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');
const {
  criarCliente,
  listarClientes,
  atualizarCliente,
  removerCliente,
} = require('../controllers/clientes.controller');

const router = express.Router({ mergeParams: true });

router.use(exigirLogin);
router.use(exigirDonoDaLoja);
router.post('/', criarCliente);
router.get('/', listarClientes);
router.patch('/:clienteId', atualizarCliente);
router.delete('/:clienteId', removerCliente);

module.exports = router;

const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');
const controller = require('../controllers/whatsappConfiguracao.controller');
const historicoController = require('../controllers/whatsappHistorico.controller');

const router = express.Router({ mergeParams: true });
router.use(exigirLogin);
router.use(exigirDonoDaLoja);

router.get('/historico/conversas', historicoController.listarConversas);
router.get('/historico/conversas/:conversaId/mensagens', historicoController.listarMensagens);

router.get('/', controller.listar);
router.post('/', controller.criar);
router.get('/:configuracaoId', controller.buscar);
router.patch('/:configuracaoId', controller.atualizar);
router.post('/:configuracaoId/desativar', controller.desativar);
router.get('/:configuracaoId/credencial', controller.estadoCredencial);
router.put('/:configuracaoId/credencial', controller.salvarCredencial);
router.delete('/:configuracaoId/credencial', controller.removerCredencial);

module.exports = router;

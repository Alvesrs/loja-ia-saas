const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirDonoDaLoja } = require('../middleware/lojaOwnership');
const { minhaAssinatura } = require('../controllers/assinaturas.controller');
const { criarCheckout, statusIntegracao } = require('../controllers/asaas.controller');

const router = express.Router({ mergeParams: true });
router.use(exigirLogin, exigirDonoDaLoja);
router.get('/', minhaAssinatura);
router.get('/cobranca', statusIntegracao);
router.post('/checkout', criarCheckout);
module.exports = router;

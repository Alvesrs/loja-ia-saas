const configuracoes = require('./whatsappConfiguracao.service');
const credenciais = require('./whatsappCredencial.service');
const provedores = require('./providers/whatsapp');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');

class ErroEnvioWhatsapp extends Error {
  constructor() {
    super('Não foi possível enviar a resposta do atendente.');
    this.name = 'ErroEnvioWhatsapp';
  }
}

/**
 * 10K: recebe apenas a mensagem interna resolvida pelo webhook e o resultado
 * da IA. O contexto vem do parser e do provedor fixado pelo controller.
 * Revalida a configuração por id E loja antes de cada envio. Não persiste,
 * não repete tentativas e não usa credenciais do payload ou da resposta.
 */
async function enviarRespostaWhatsapp(mensagem, resposta, contexto) {
  try {
    if (!mensagem || mensagem.canal !== 'whatsapp' ||
        !ehUuid(mensagem.lojaId) || !ehUuid(mensagem.configuracaoId) ||
        !ehStringNaoVazia(mensagem.contato) || !contexto ||
        !ehStringNaoVazia(contexto.destinatarioId) || !ehStringNaoVazia(contexto.provedor) ||
        !resposta || !ehStringNaoVazia(resposta.resposta) ||
        resposta.lojaId !== mensagem.lojaId || resposta.contato !== mensagem.contato ||
        resposta.idExterno !== mensagem.idExterno) throw new ErroEnvioWhatsapp();

    const config = await configuracoes.buscarConfiguracaoWhatsapp(mensagem.configuracaoId, mensagem.lojaId);
    if (config.id !== mensagem.configuracaoId || config.loja_id !== mensagem.lojaId ||
        config.ativo !== true || config.provedor !== contexto.provedor ||
        config.identificador_externo !== contexto.destinatarioId) throw new ErroEnvioWhatsapp();

    // Status não chega aqui (parser). Defesa adicional contra resposta ao
    // próprio número; não confundir o phone_number_id com o telefone.
    const digitos = (valor) => typeof valor === 'string' ? valor.replace(/\D/g, '') : '';
    const numeroProprio = digitos(config.numero_whatsapp);
    if (numeroProprio && numeroProprio === digitos(mensagem.contato)) {
      return Object.freeze({ status: 'ignorado' });
    }

    const pedido = provedores.criarPedidoDeEnvio({
      lojaId: mensagem.lojaId,
      configuracaoId: mensagem.configuracaoId,
      contato: mensagem.contato,
      texto: resposta.resposta,
    });
    const opcoesProvedor = { phoneNumberId: config.identificador_externo };
    if (config.provedor === 'meta') {
      // 10P: token resolvido pelo par configuração+loja. Nunca vem do payload
      // e nunca é devolvido para controller/painel.
      opcoesProvedor.accessToken = await credenciais.resolverAccessTokenMeta(config.id, config.loja_id);
    }
    const provedor = provedores.obterProvedorWhatsapp(config.provedor, opcoesProvedor);
    const resultado = await provedor.enviarMensagem(pedido);
    if (!resultado || resultado.sucesso !== true ||
        (config.provedor === 'meta' && !provedores.mensagemFoiEnviada(resultado))) {
      throw new ErroEnvioWhatsapp();
    }
    // Não propagar corpo, IDs externos ou detalhes arbitrários do provider.
    return Object.freeze({ status: resultado.simulado ? 'simulado' : 'enviado' });
  } catch {
    // Erros arbitrários podem carregar tokens inclusive no nome/stack/cause.
    // Não logar nem encadear o erro original.
    throw new ErroEnvioWhatsapp();
  }
}

module.exports = { enviarRespostaWhatsapp, ErroEnvioWhatsapp };

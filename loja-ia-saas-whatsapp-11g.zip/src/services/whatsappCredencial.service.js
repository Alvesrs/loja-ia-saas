const crypto = require('node:crypto');
const supabase = require('../config/supabase');
const configuracoes = require('./whatsappConfiguracao.service');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');

const TABELA = 'whatsapp_credenciais';
const ALGORITMO = 'aes-256-gcm';
const VERSAO_CHAVE = 1;
const LIMITE_TOKEN = 8192;

class ErroCredencialInvalida extends Error {
  constructor(mensagem = 'Credencial de WhatsApp inválida.') { super(mensagem); this.name = 'ErroCredencialInvalida'; }
}
class ErroCredencialNaoConfigurada extends Error {
  constructor() { super('Credencial de WhatsApp não configurada.'); this.name = 'ErroCredencialNaoConfigurada'; }
}
class ErroChaveCredenciaisAusente extends Error {
  constructor() { super('Armazenamento seguro de credenciais não configurado no servidor.'); this.name = 'ErroChaveCredenciaisAusente'; }
}
class ErroCredencialBanco extends Error {
  constructor() { super('Não foi possível completar a operação de credencial do WhatsApp.'); this.name = 'ErroCredencialBanco'; }
}

function validarIds(configuracaoId, lojaId) {
  if (!ehUuid(configuracaoId) || !ehUuid(lojaId)) throw new ErroCredencialInvalida('Identificador inválido.');
}

function lerChaveMestra() {
  const bruto = process.env.WHATSAPP_CREDENTIALS_MASTER_KEY;
  if (!ehStringNaoVazia(bruto)) throw new ErroChaveCredenciaisAusente();
  let chave;
  try { chave = Buffer.from(bruto.trim(), 'base64'); } catch { throw new ErroChaveCredenciaisAusente(); }
  if (chave.length !== 32) throw new ErroChaveCredenciaisAusente();
  return chave;
}

function aad(configuracaoId, lojaId) {
  return Buffer.from(`whatsapp:meta:${lojaId}:${configuracaoId}:v${VERSAO_CHAVE}`, 'utf8');
}

function cifrarToken(token, configuracaoId, lojaId) {
  if (!ehStringNaoVazia(token) || token.length > LIMITE_TOKEN) throw new ErroCredencialInvalida('Access token inválido.');
  const chave = lerChaveMestra();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITMO, chave, iv);
  cipher.setAAD(aad(configuracaoId, lojaId));
  const cifrado = Buffer.concat([cipher.update(token, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    access_token_cifrado: cifrado.toString('base64'),
    access_token_iv: iv.toString('base64'),
    access_token_tag: tag.toString('base64'),
    versao_chave: VERSAO_CHAVE,
  };
}

function decifrarToken(linha, configuracaoId, lojaId) {
  try {
    if (!linha || linha.versao_chave !== VERSAO_CHAVE) throw new Error('versao');
    const decipher = crypto.createDecipheriv(ALGORITMO, lerChaveMestra(), Buffer.from(linha.access_token_iv, 'base64'));
    decipher.setAAD(aad(configuracaoId, lojaId));
    decipher.setAuthTag(Buffer.from(linha.access_token_tag, 'base64'));
    const token = Buffer.concat([
      decipher.update(Buffer.from(linha.access_token_cifrado, 'base64')),
      decipher.final(),
    ]).toString('utf8');
    if (!ehStringNaoVazia(token)) throw new Error('vazio');
    return token;
  } catch (erro) {
    if (erro instanceof ErroChaveCredenciaisAusente) throw erro;
    throw new ErroCredencialBanco();
  }
}

async function garantirConfiguracaoMeta(configuracaoId, lojaId) {
  let config;
  try { config = await configuracoes.buscarConfiguracaoWhatsapp(configuracaoId, lojaId); }
  catch (erro) {
    if (erro instanceof configuracoes.ErroConfiguracaoNaoEncontrada) throw new ErroCredencialInvalida('Configuração de WhatsApp não encontrada.');
    throw erro;
  }
  if (config.provedor !== 'meta') throw new ErroCredencialInvalida('Credencial por loja só é aceita para o provedor Meta.');
  return config;
}

function erroBanco(error) {
  // Nunca loga dados cifrados/IV/tag nem token. Só código técnico neutro.
  console.error('[whatsappCredencial.service] falha de banco:', error && error.code ? error.code : 'erro');
  throw new ErroCredencialBanco();
}

async function salvarCredencialMeta(configuracaoId, lojaId, accessToken) {
  validarIds(configuracaoId, lojaId);
  await garantirConfiguracaoMeta(configuracaoId, lojaId);
  const segredo = cifrarToken(accessToken, configuracaoId, lojaId);
  const { error } = await supabase.from(TABELA).upsert({
    configuracao_id: configuracaoId,
    loja_id: lojaId,
    provedor: 'meta',
    ...segredo,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'configuracao_id' });
  if (error) erroBanco(error);
  return Object.freeze({ configuracao_id: configuracaoId, credencial_configurada: true });
}

async function obterEstadoCredencial(configuracaoId, lojaId) {
  validarIds(configuracaoId, lojaId);
  await garantirConfiguracaoMeta(configuracaoId, lojaId);
  const { data, error } = await supabase.from(TABELA)
    .select('configuracao_id')
    .eq('configuracao_id', configuracaoId)
    .eq('loja_id', lojaId)
    .maybeSingle();
  if (error) erroBanco(error);
  return Object.freeze({ configuracao_id: configuracaoId, credencial_configurada: Boolean(data) });
}

async function removerCredencialMeta(configuracaoId, lojaId) {
  validarIds(configuracaoId, lojaId);
  await garantirConfiguracaoMeta(configuracaoId, lojaId);
  const { error } = await supabase.from(TABELA)
    .delete()
    .eq('configuracao_id', configuracaoId)
    .eq('loja_id', lojaId);
  if (error) erroBanco(error);
  return Object.freeze({ configuracao_id: configuracaoId, credencial_configurada: false });
}

// Uso estritamente interno no caminho de envio. Nunca deve ser retornado por controller.
async function resolverAccessTokenMeta(configuracaoId, lojaId) {
  validarIds(configuracaoId, lojaId);
  const { data, error } = await supabase.from(TABELA)
    .select('configuracao_id, loja_id, provedor, access_token_cifrado, access_token_iv, access_token_tag, versao_chave')
    .eq('configuracao_id', configuracaoId)
    .eq('loja_id', lojaId)
    .maybeSingle();
  if (error) erroBanco(error);
  if (!data || data.provedor !== 'meta' || data.configuracao_id !== configuracaoId || data.loja_id !== lojaId) {
    throw new ErroCredencialNaoConfigurada();
  }
  return decifrarToken(data, configuracaoId, lojaId);
}

module.exports = {
  salvarCredencialMeta,
  obterEstadoCredencial,
  removerCredencialMeta,
  resolverAccessTokenMeta,
  ErroCredencialInvalida,
  ErroCredencialNaoConfigurada,
  ErroChaveCredenciaisAusente,
  ErroCredencialBanco,
};

const crypto = require('node:crypto');

/**
 * Etapa 10L — verificação nativa do webhook da Meta.
 *
 * POST: valida X-Hub-Signature-256 = sha256=<HMAC-SHA256 do corpo bruto>
 * usando META_APP_SECRET. O corpo usado é exatamente o Buffer recebido.
 *
 * GET: valida hub.mode=subscribe e hub.verify_token contra
 * META_WHATSAPP_VERIFY_TOKEN e devolve hub.challenge quando válido.
 *
 * Nenhum segredo, token, assinatura ou corpo é incluído em logs/respostas.
 */

const NOME_VARIAVEL_SEGREDO = 'META_APP_SECRET';
const NOME_VARIAVEL_VERIFY_TOKEN = 'META_WHATSAPP_VERIFY_TOKEN';
const NOME_HEADER_ASSINATURA = 'x-hub-signature-256';
const REGEX_ASSINATURA = /^sha256=([0-9a-fA-F]{64})$/;

const MOTIVOS = Object.freeze({
  segredoAusente: 'segredo_ausente',
  cabecalhoAusente: 'cabecalho_ausente',
  cabecalhoMalformado: 'cabecalho_malformado',
  corpoIndisponivel: 'corpo_indisponivel',
  assinaturaInvalida: 'assinatura_invalida',
  verifyTokenAusente: 'verify_token_ausente',
  modoInvalido: 'modo_invalido',
  tokenInvalido: 'token_invalido',
  challengeInvalido: 'challenge_invalido',
});

function lerVariavelNaoVazia(nome, env = process.env) {
  const valor = env[nome];
  if (typeof valor !== 'string' || valor.trim() === '') return null;
  return valor;
}

function obterSegredoDoAmbiente(env = process.env) {
  return lerVariavelNaoVazia(NOME_VARIAVEL_SEGREDO, env);
}

function obterVerifyTokenDoAmbiente(env = process.env) {
  return lerVariavelNaoVazia(NOME_VARIAVEL_VERIFY_TOKEN, env);
}

function interpretarCabecalho(valor) {
  if (valor === undefined || valor === null || valor === '') {
    return { motivo: MOTIVOS.cabecalhoAusente };
  }
  if (typeof valor !== 'string') return { motivo: MOTIVOS.cabecalhoMalformado };
  const correspondencia = REGEX_ASSINATURA.exec(valor);
  if (!correspondencia) return { motivo: MOTIVOS.cabecalhoMalformado };
  return { assinatura: Buffer.from(correspondencia[1], 'hex') };
}

function calcularAssinatura(segredo, corpoBruto) {
  return crypto.createHmac('sha256', segredo).update(corpoBruto).digest();
}

function verificarAssinatura({ segredo, corpoBruto, cabecalho }) {
  if (typeof segredo !== 'string' || segredo === '') return { ok: false, motivo: MOTIVOS.segredoAusente };
  const recebida = interpretarCabecalho(cabecalho);
  if (recebida.motivo) return { ok: false, motivo: recebida.motivo };
  if (!Buffer.isBuffer(corpoBruto)) return { ok: false, motivo: MOTIVOS.corpoIndisponivel };

  const esperada = calcularAssinatura(segredo, corpoBruto);
  if (esperada.length !== recebida.assinatura.length || !crypto.timingSafeEqual(esperada, recebida.assinatura)) {
    return { ok: false, motivo: MOTIVOS.assinaturaInvalida };
  }
  return { ok: true };
}

function compararTextoSeguro(recebido, esperado) {
  if (typeof recebido !== 'string' || typeof esperado !== 'string') return false;
  const a = Buffer.from(recebido, 'utf8');
  const b = Buffer.from(esperado, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function verificarHandshake({ modo, tokenRecebido, challenge, tokenEsperado }) {
  if (typeof tokenEsperado !== 'string' || tokenEsperado === '') {
    return { ok: false, motivo: MOTIVOS.verifyTokenAusente };
  }
  if (modo !== 'subscribe') return { ok: false, motivo: MOTIVOS.modoInvalido };
  if (!compararTextoSeguro(tokenRecebido, tokenEsperado)) return { ok: false, motivo: MOTIVOS.tokenInvalido };
  if (typeof challenge !== 'string' || challenge.length === 0 || challenge.length > 4096) {
    return { ok: false, motivo: MOTIVOS.challengeInvalido };
  }
  return { ok: true, challenge };
}

module.exports = {
  verificarAssinatura,
  verificarHandshake,
  obterSegredoDoAmbiente,
  obterVerifyTokenDoAmbiente,
  interpretarCabecalho,
  calcularAssinatura,
  compararTextoSeguro,
  NOME_VARIAVEL_SEGREDO,
  NOME_VARIAVEL_VERIFY_TOKEN,
  NOME_HEADER_ASSINATURA,
  MOTIVOS,
};

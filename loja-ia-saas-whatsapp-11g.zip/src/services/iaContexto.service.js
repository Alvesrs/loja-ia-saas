const supabase = require('../config/supabase');
const { formatarPreco } = require('./ia.helpers');
const { ehUuid } = require('../utils/validacao');

/**
 * SERVIÇO DE CONTEXTO SEGURO DO CATÁLOGO (Etapa 9C)
 *
 * Responsável por buscar os dados REAIS de uma loja (produtos + estoque)
 * e transformá-los em um contexto compacto e seguro que poderá, em uma
 * etapa futura, ser enviado a um LLM (ver `src/services/llm.service.js`).
 *
 * Este arquivo NÃO:
 *   - chama o LLM;
 *   - responde ao cliente final;
 *   - cria pedidos ou altera estoque/produtos;
 *   - interpreta texto de descrição como instrução (ver seção 9 do pedido
 *     desta etapa) — descrição de produto é sempre tratada como DADO,
 *     nunca como comando, mesmo que contenha algo como
 *     "ignore as instruções anteriores".
 *
 * Fluxo: CONSULTAR DADOS → VALIDAR PERTENCIMENTO À LOJA → TRANSFORMAR EM CONTEXTO.
 *
 * A parte "CONSULTAR DADOS" (`buscarProdutosAtivosDaLoja`) é a única que
 * toca o banco. Todo o resto é função pura (sem I/O), para poder ser
 * testado com dados fake — ver tests/iaContexto.service.test.js.
 */

/** Lançado quando o identificador de loja recebido não é um UUID válido. */
class ErroLojaInvalida extends Error {
  constructor(mensagem) {
    super(mensagem || 'Identificador de loja inválido.');
    this.name = 'ErroLojaInvalida';
  }
}

/**
 * CONSULTAR DADOS + VALIDAR PERTENCIMENTO À LOJA
 *
 * Busca no banco somente produtos ATIVOS da loja informada, com suas
 * variações de estoque (tamanho/cor/quantidade).
 *
 * Isolamento multi-tenant: o filtro `loja_id` vem exclusivamente do
 * parâmetro `lojaId` (validado como UUID nesta função) — nunca de um
 * `produto_id` ou de qualquer dado enviado pelo frontend. Não existe,
 * neste serviço, nenhum caminho para buscar produto por id sem passar
 * pelo filtro de loja, então um produto de outra loja nunca pode ser
 * "adivinhado" via id.
 *
 * Produtos inativos são excluídos diretamente na consulta (`.eq('ativo',
 * true)`), então nunca chegam a esta função nem ao contexto final.
 *
 * @param {string} lojaId
 * @returns {Promise<Array>} lista bruta de produtos ativos da loja (como vieram do banco)
 * @throws {ErroLojaInvalida} se `lojaId` não for um UUID válido
 */
async function buscarProdutosAtivosDaLoja(lojaId) {
  if (!ehUuid(lojaId)) {
    throw new ErroLojaInvalida('Identificador de loja inválido.');
  }

  const { data, error } = await supabase
    .from('produtos')
    .select('id, nome, descricao, preco, categoria, ativo, estoque(tamanho, cor, quantidade)')
    .eq('loja_id', lojaId)
    .eq('ativo', true);

  if (error) throw new Error(error.message);
  return data || [];
}

/**
 * Converte a quantidade real em estoque numa disponibilidade simples,
 * sem nunca expor o número exato ao contexto final:
 *   quantidade > 0  → disponível
 *   quantidade = 0, ausente ou inválida → indisponível (nunca o contrário)
 */
function estaDisponivel(quantidade) {
  return typeof quantidade === 'number' && quantidade > 0;
}

/**
 * TRANSFORMAR DADOS EM CONTEXTO (função pura)
 *
 * Recebe UM produto como veio do banco (com `estoque` aninhado) e
 * devolve sua representação de contexto: nome, descrição, preço e a
 * lista de variações com disponibilidade simples (disponível/indisponível).
 *
 * Nunca inventa tamanho, cor, preço ou produto: todo campo vem
 * diretamente do objeto `produto` recebido. A descrição é transportada
 * como texto puro (dado), nunca interpretada.
 */
function transformarProdutoEmContexto(produto) {
  const variacoes = (produto.estoque || []).map((variacao) => ({
    tamanho: variacao.tamanho,
    cor: variacao.cor,
    disponivel: estaDisponivel(variacao.quantidade),
  }));

  return {
    nome: produto.nome,
    descricao: produto.descricao || null,
    preco: produto.preco,
    variacoes,
  };
}

/**
 * TRANSFORMAR DADOS EM CONTEXTO (função pura, lista completa)
 *
 * Recebe a lista bruta de produtos (já filtrada pela consulta) e devolve
 * a lista de contexto. Como defesa em profundidade — caso esta função
 * seja chamada diretamente com dados que não passaram pela consulta
 * filtrada —, produtos com `ativo === false` são excluídos aqui também;
 * produtos sem o campo `ativo` definido são mantidos (assume-se que já
 * vieram filtrados do banco).
 */
function montarContextoCatalogo(produtosBrutos) {
  if (!Array.isArray(produtosBrutos)) return [];
  return produtosBrutos
    .filter((produto) => produto.ativo !== false)
    .map(transformarProdutoEmContexto);
}

function formatarVariacaoTexto(variacao) {
  return `- ${variacao.cor} / ${variacao.tamanho} → ${variacao.disponivel ? 'disponível' : 'indisponível'}`;
}

/** Formata um único produto de contexto no texto compacto para o LLM. */
function formatarProdutoTexto(produtoContexto) {
  const linhas = [`Produto: ${produtoContexto.nome}`];

  if (produtoContexto.descricao) {
    linhas.push(`Descrição: ${produtoContexto.descricao}`);
  }

  linhas.push(`Preço: ${formatarPreco(produtoContexto.preco)}`);

  if (produtoContexto.variacoes.length > 0) {
    linhas.push('Variações:');
    produtoContexto.variacoes.forEach((variacao) => {
      linhas.push(formatarVariacaoTexto(variacao));
    });
  } else {
    linhas.push('Estoque/variações: não controlado no sistema para este item. Isso NÃO significa indisponível.');
  }

  return linhas.join('\n');
}

/**
 * TRANSFORMAR DADOS EM CONTEXTO (texto compacto final)
 *
 * Recebe a lista já transformada (`montarContextoCatalogo`) e devolve um
 * texto único, compacto, pronto para ser anexado a um prompt de LLM
 * (parâmetro `contexto` de `llm.service.gerarResposta`, numa etapa
 * futura). Não envia o banco inteiro: apenas nome, descrição, preço e
 * disponibilidade simples por variação — do catálogo ATIVO da loja.
 */
function formatarContextoTexto(produtosContexto) {
  if (!produtosContexto || produtosContexto.length === 0) {
    return 'Não há itens ativos cadastrados no catálogo. Isso não impede atendimento geral ou prestação de serviços; apenas não há dados estruturados de catálogo para afirmar nomes, preços ou disponibilidade.';
  }
  return produtosContexto.map(formatarProdutoTexto).join('\n\n');
}

/**
 * Função principal do serviço: busca o catálogo ativo real da loja e
 * devolve tanto a lista estruturada quanto o texto compacto, prontos
 * para uso por uma etapa futura de integração com o LLM.
 *
 * @param {string} lojaId
 * @returns {Promise<{produtos: Array, texto: string}>}
 * @throws {ErroLojaInvalida} se `lojaId` não for um UUID válido
 */
async function obterContextoCatalogo(lojaId) {
  const produtosBrutos = await buscarProdutosAtivosDaLoja(lojaId);
  const produtos = montarContextoCatalogo(produtosBrutos);
  const texto = formatarContextoTexto(produtos);
  return { produtos, texto };
}

module.exports = {
  buscarProdutosAtivosDaLoja,
  transformarProdutoEmContexto,
  montarContextoCatalogo,
  formatarVariacaoTexto,
  formatarProdutoTexto,
  formatarContextoTexto,
  obterContextoCatalogo,
  estaDisponivel,
  ErroLojaInvalida,
};

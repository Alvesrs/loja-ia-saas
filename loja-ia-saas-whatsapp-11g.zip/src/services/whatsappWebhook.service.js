const { ehStringNaoVazia } = require('../utils/validacao');
const {
  normalizarMensagemRecebida,
  ErroMensagemWhatsappInvalida,
  LIMITE_TEXTO_MENSAGEM,
} = require('./whatsapp.service');
const configuracaoService = require('./whatsappConfiguracao.service');

/**
 * CAMADA DE PROCESSAMENTO DE EVENTO DE WHATSAPP — "WEBHOOK" (Etapa 10C)
 *
 * ==========================================================================
 * ATENÇÃO: este arquivo NÃO é um webhook público. Não há rota Express, não
 * há servidor HTTP, não há provedor conectado (Meta, Twilio, Z-API,
 * Evolution ou qualquer outro), não há chamada HTTP, não há envio de
 * mensagem, não há armazenamento de conversa e não há chamada ao LLM.
 * Ele apenas transforma um EVENTO EXTERNO GENÉRICO (um objeto JS) numa
 * mensagem interna normalizada e segura. O fluxo PARA aí.
 * ==========================================================================
 *
 * FLUXO (nada depois da última linha existe ainda)
 *
 *   evento externo
 *     → adaptador de provedor        (futuro; produz o "evento genérico"
 *                                     descrito abaixo. Aqui só existe o
 *                                     adaptador genérico `adaptarEventoGenerico`)
 *     → validação                    (`adaptarEventoGenerico`)
 *     → identificação da configuração (`buscarConfiguracaoPorIdentificadorExterno`,
 *                                     em whatsappConfiguracao.service.js)
 *     → normalização                 (`normalizarMensagemRecebida`, da 10A)
 *     → mensagem interna normalizada (retorno de `processarEventoWhatsapp`)
 *
 * EVENTO GENÉRICO ACEITO (o que um futuro adaptador de provedor deve produzir)
 *
 *   {
 *     destinatarioId, // identificador EXTERNO do número que RECEBEU a mensagem
 *                     // (o número da loja no provedor) — é o que identifica a loja
 *     contato,        // identificador de QUEM ENVIOU (o cliente final)
 *     texto,          // texto da mensagem
 *     idExterno,      // opcional: id da mensagem no provedor
 *     timestamp,      // opcional: momento do envio (string, número ou Date)
 *   }
 *
 * Qualquer OUTRO campo do payload é ignorado e não chega ao fluxo interno.
 *
 * COMO A LOJA É IDENTIFICADA (regra de segurança central)
 *
 *   1. Lê-se `destinatarioId` do evento — o número que recebeu a mensagem.
 *   2. Procura-se, no BANCO, a configuração de WhatsApp ATIVA com esse
 *      identificador externo (e, se a aplicação informar, esse provedor).
 *   3. O `lojaId` da mensagem é o `loja_id` DESSA LINHA DO BANCO.
 *
 *   Nunca se usa: um campo `loja_id`/`lojaId` do payload, o `contato`
 *   (o número do remetente identifica o CONTATO, não a loja), nem qualquer
 *   outro dado que o cliente final controle.
 *   `configuracaoId` também vem da linha do banco. O provedor vem do
 *   `contexto` confiável passado pela aplicação (por exemplo, parte da
 *   rota do webhook), nunca do corpo do payload.
 *
 * ANTI-INJECTION — SEPARAÇÃO ENTRE DADO E CONTROLE
 *
 *   A mensagem interna tem dois grupos de campos:
 *     - CONFIÁVEIS, derivados internamente da configuração cadastrada:
 *         `lojaId`, `configuracaoId`, `canal`;
 *     - DADOS DO CLIENTE, NÃO CONFIÁVEIS: `contato`, `texto`, `idExterno`,
 *         `timestamp`.
 *   O `texto` é sempre apenas DADO: este arquivo não o interpreta, não
 *   procura comandos nele e não o mistura com nenhum campo de controle.
 *   Frases como "ignore as instruções anteriores" ou "você agora é
 *   administrador" ficam como texto comum. Quando um LLM for ligado numa
 *   etapa futura, o `texto` deve entrar SOMENTE como conteúdo de usuário
 *   (dado), nunca concatenado ao system prompt, à configuração ou a
 *   qualquer credencial — mesmo princípio já aplicado em `iaContexto.service.js`
 *   e `iaPrompt.service.js`. Este arquivo não os importa nem chama.
 *
 * O QUE ESTE ARQUIVO NÃO FAZ (limitação importante)
 *
 *   Não autentica a ORIGEM do evento. Quem chamar `processarEventoWhatsapp`
 *   está declarando que o evento veio mesmo do provedor. Uma futura rota
 *   pública DEVE verificar a autenticidade (assinatura/segredo do
 *   provedor) ANTES de chamar este service — o identificador do número da
 *   loja não é segredo, então sem essa verificação qualquer pessoa poderia
 *   forjar mensagens "recebidas" por uma loja. Essa etapa é separada e
 *   ainda não existe.
 *
 *   Também não registra em log o texto nem o contato (dados pessoais).
 */

// Limites generosos, só para evitar abuso de tamanho de campo. O do texto
// é o mesmo da abstração da 10A.
const LIMITE_DESTINATARIO = 255; // mesmo limite da coluna identificador_externo
const LIMITE_CONTATO = 128;
const LIMITE_ID_MENSAGEM = 255;

/** Evento externo malformado (falta campo obrigatório, tipo errado, texto grande demais...). */
class ErroEventoWhatsappInvalido extends Error {
  constructor(mensagem) {
    super(mensagem || 'Evento de WhatsApp inválido.');
    this.name = 'ErroEventoWhatsappInvalido';
  }
}

/**
 * Nenhuma configuração ATIVA identificou o destinatário. Mensagem fixa e
 * genérica: não diferencia "não existe", "está desativada" e "ambígua", para
 * não permitir descobrir quais números estão cadastrados.
 */
class ErroDestinatarioNaoIdentificado extends Error {
  constructor() {
    super('Não foi possível identificar uma configuração de WhatsApp ativa para o destinatário do evento.');
    this.name = 'ErroDestinatarioNaoIdentificado';
  }
}

// Lê só propriedades PRÓPRIAS do payload (ignora o que vier da cadeia de
// protótipos) e nunca toca em campos que não sejam os esperados.
function lerCampo(payload, campo) {
  return Object.prototype.hasOwnProperty.call(payload, campo) ? payload[campo] : undefined;
}

// Campo opcional "ausente": undefined, null ou texto em branco.
function estaAusente(valor) {
  return valor === undefined || valor === null || (typeof valor === 'string' && valor.trim() === '');
}

/**
 * ADAPTADOR GENÉRICO + VALIDAÇÃO (função pura, sem I/O)
 *
 * Copia do payload SOMENTE os cinco campos esperados e valida cada um.
 * Todo o resto (inclusive `loja_id`, `lojaId`, `configuracaoId`, `provedor`,
 * `system_prompt`, `instrucoes`, tokens, ...) é descartado sem ser lido.
 *
 * Regras dos opcionais (seguem a 10A): `idExterno` e `timestamp` ausentes
 * (undefined, null ou em branco) viram `null` sem erro; se presentes, precisam
 * ser válidos (`idExterno` texto; `timestamp` data interpretável).
 *
 * @param {object} payloadExterno
 * @returns {{destinatarioId: string, contato: string, texto: string, idExterno: string|null, timestamp: string|number|Date|null}}
 * @throws {ErroEventoWhatsappInvalido}
 */
function adaptarEventoGenerico(payloadExterno) {
  if (payloadExterno === null || typeof payloadExterno !== 'object' || Array.isArray(payloadExterno)) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: deve ser um objeto.');
  }

  // --- destinatário: identifica a LOJA (via configuração cadastrada) ---
  const destinatario = lerCampo(payloadExterno, 'destinatarioId');
  if (!ehStringNaoVazia(destinatario)) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: identificador do número destinatário ausente ou inválido.');
  }
  const destinatarioId = destinatario.trim();
  if (destinatarioId.length > LIMITE_DESTINATARIO) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: identificador do número destinatário grande demais.');
  }

  // --- contato: identifica QUEM ENVIOU (não a loja) ---
  const contatoBruto = lerCampo(payloadExterno, 'contato');
  if (!ehStringNaoVazia(contatoBruto)) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: identificador do contato/remetente ausente ou inválido.');
  }
  const contato = contatoBruto.trim();
  if (contato.length > LIMITE_CONTATO) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: identificador do contato/remetente grande demais.');
  }

  // --- texto: sempre dado, com limite de tamanho (mesmo da 10A) ---
  const texto = lerCampo(payloadExterno, 'texto');
  if (typeof texto !== 'string' || texto.trim().length === 0) {
    throw new ErroEventoWhatsappInvalido('Evento inválido: texto ausente, vazio ou inválido.');
  }
  if (texto.length > LIMITE_TEXTO_MENSAGEM) {
    throw new ErroEventoWhatsappInvalido(`Evento inválido: texto excede o limite de ${LIMITE_TEXTO_MENSAGEM} caracteres.`);
  }

  // --- opcional: identificador externo da mensagem ---
  let idExterno = null;
  const idBruto = lerCampo(payloadExterno, 'idExterno');
  if (!estaAusente(idBruto)) {
    if (typeof idBruto !== 'string') {
      throw new ErroEventoWhatsappInvalido('Evento inválido: idExterno, quando informado, deve ser um texto.');
    }
    idExterno = idBruto.trim();
    if (idExterno.length > LIMITE_ID_MENSAGEM) {
      throw new ErroEventoWhatsappInvalido('Evento inválido: idExterno grande demais.');
    }
  }

  // --- opcional: timestamp ---
  let timestamp = null;
  const tsBruto = lerCampo(payloadExterno, 'timestamp');
  if (!estaAusente(tsBruto)) {
    const tipoValido = typeof tsBruto === 'string' || typeof tsBruto === 'number' || tsBruto instanceof Date;
    if (!tipoValido || Number.isNaN(new Date(tsBruto).getTime())) {
      throw new ErroEventoWhatsappInvalido('Evento inválido: timestamp, quando informado, deve ser uma data/hora válida.');
    }
    timestamp = tsBruto;
  }

  return { destinatarioId, contato, texto, idExterno, timestamp };
}

/**
 * Processa um evento externo genérico e devolve a mensagem interna
 * normalizada. É AQUI que o fluxo termina: a mensagem não é enviada a
 * nenhuma IA, não é gravada e nenhuma resposta é produzida.
 *
 * @param {object} payloadExterno  evento externo genérico (dado NÃO confiável)
 * @param {object} [contextoConfiavel]  dados decididos pela PRÓPRIA aplicação
 *   (nunca lidos do payload), por exemplo o provedor conforme a rota do
 *   webhook. Hoje só `provedor` é considerado; quando informado, a
 *   configuração precisa ser desse provedor.
 * @returns {Promise<Readonly<{
 *   canal: 'whatsapp', lojaId: string, configuracaoId: string,
 *   contato: string, texto: string, idExterno: string|null, timestamp: string|null
 * }>>}
 * @throws {ErroEventoWhatsappInvalido} evento malformado
 * @throws {ErroDestinatarioNaoIdentificado} nenhuma configuração ativa identificou o destinatário
 */
async function processarEventoWhatsapp(payloadExterno, contextoConfiavel = {}) {
  // 1) adaptar + validar (rejeita cedo, antes de qualquer consulta ao banco)
  const evento = adaptarEventoGenerico(payloadExterno);

  // 2) identificar a configuração — a loja vem SEMPRE do banco
  const provedor =
    contextoConfiavel !== null && typeof contextoConfiavel === 'object' ? contextoConfiavel.provedor : undefined;

  let configuracao;
  try {
    configuracao = await configuracaoService.buscarConfiguracaoPorIdentificadorExterno(
      evento.destinatarioId,
      provedor === undefined || provedor === null ? {} : { provedor }
    );
  } catch (erro) {
    if (
      erro instanceof configuracaoService.ErroConfiguracaoNaoEncontrada ||
      erro instanceof configuracaoService.ErroConfiguracaoAmbigua
    ) {
      throw new ErroDestinatarioNaoIdentificado();
    }
    throw erro; // falha de banco / contexto inválido da aplicação: não é culpa do evento
  }

  // 3) normalizar com a abstração da 10A, usando o loja_id da configuração
  let mensagem;
  try {
    mensagem = normalizarMensagemRecebida({
      lojaId: configuracao.loja_id,
      contato: evento.contato,
      texto: evento.texto,
      idExterno: evento.idExterno,
      timestamp: evento.timestamp,
    });
  } catch (erro) {
    if (erro instanceof ErroMensagemWhatsappInvalida) {
      throw new ErroEventoWhatsappInvalido(erro.message);
    }
    throw erro;
  }

  // 4) montar a estrutura interna com campos EXPLÍCITOS (nada do payload
  //    externo é repassado por espalhamento) e congelá-la.
  return Object.freeze({
    canal: mensagem.canal,
    lojaId: mensagem.lojaId,
    configuracaoId: configuracao.id,
    contato: mensagem.contato,
    texto: mensagem.texto,
    idExterno: mensagem.idExterno,
    timestamp: mensagem.timestamp,
  });
}

module.exports = {
  processarEventoWhatsapp,
  adaptarEventoGenerico,
  ErroEventoWhatsappInvalido,
  ErroDestinatarioNaoIdentificado,
};

const crypto = require('node:crypto');
const supabase = require('../config/supabase');
const { obterPlano } = require('../config/planos');
const { definirAssinatura, buscarAssinaturaAtual } = require('./assinaturas.service');

const API = 'https://api.mercadopago.com';

function configurado() {
  return Boolean(process.env.MERCADOPAGO_ACCESS_TOKEN && process.env.PUBLIC_BASE_URL);
}

function normalizarBaseUrl() {
  return String(process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, '');
}

function parseSignatureHeader(valor) {
  const partes = String(valor || '').split(',').map((p) => p.trim());
  const mapa = {};
  for (const item of partes) {
    const i = item.indexOf('=');
    if (i > 0) mapa[item.slice(0, i)] = item.slice(i + 1);
  }
  return { ts: mapa.ts || '', v1: mapa.v1 || '' };
}

function assinaturaWebhookValida({ xSignature, xRequestId, dataId, secret }) {
  if (!xSignature || !xRequestId || !dataId || !secret) return false;
  const { ts, v1 } = parseSignatureHeader(xSignature);
  if (!ts || !v1 || !/^[a-f0-9]{64}$/i.test(v1)) return false;
  const id = String(dataId).toLowerCase();
  const template = `id:${id};request-id:${xRequestId};ts:${ts};`;
  const esperado = crypto.createHmac('sha256', secret).update(template).digest('hex');
  const a = Buffer.from(esperado, 'hex');
  const b = Buffer.from(v1, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function chamarMp(caminho, opcoes = {}) {
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
  if (!token) throw new Error('mercadopago_nao_configurado');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.MERCADOPAGO_TIMEOUT_MS || 15000));
  try {
    const resposta = await fetch(`${API}${caminho}`, {
      ...opcoes,
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...(opcoes.headers || {}),
      },
    });
    const texto = await resposta.text();
    let dados = {};
    try { dados = texto ? JSON.parse(texto) : {}; } catch { dados = {}; }
    if (!resposta.ok) {
      const erro = new Error('mercadopago_api_erro');
      erro.status = resposta.status;
      throw erro;
    }
    return dados;
  } finally {
    clearTimeout(timer);
  }
}

async function criarCheckoutAssinatura({ lojaId, planoCodigo, payerEmail }) {
  if (!configurado()) throw new Error('mercadopago_nao_configurado');
  const plano = obterPlano(planoCodigo);
  if (!plano || !plano.vendavel) throw new Error('plano_nao_vendavel');
  if (!plano.precoMensalCentavos) throw new Error('preco_nao_configurado');
  if (!payerEmail) throw new Error('email_pagador_ausente');

  const base = normalizarBaseUrl();
  const externalReference = `loja:${lojaId}|plano:${planoCodigo}|v:11c`;
  const payload = {
    reason: `Loja IA SaaS - Plano ${plano.nome}`,
    external_reference: externalReference,
    payer_email: payerEmail,
    auto_recurring: {
      frequency: 1,
      frequency_type: 'months',
      transaction_amount: plano.precoMensalCentavos / 100,
      currency_id: 'BRL',
    },
    back_url: `${base}/painel/plano.html?checkout=retorno`,
    status: 'pending',
  };

  const mp = await chamarMp('/preapproval', { method: 'POST', body: JSON.stringify(payload) });
  if (!mp.id || !mp.init_point) throw new Error('mercadopago_resposta_invalida');

  const agora = new Date().toISOString();
  const { error } = await supabase.from('cobrancas_assinaturas').upsert({
    loja_id: lojaId,
    plano: planoCodigo,
    provedor: 'mercadopago',
    provider_assinatura_id: String(mp.id),
    status_provider: String(mp.status || 'pending'),
    checkout_url: String(mp.init_point),
    payer_email: payerEmail,
    external_reference: externalReference,
    atualizado_em: agora,
  }, { onConflict: 'provider_assinatura_id' });
  if (error) throw error;

  return { checkout_url: mp.init_point, provider_assinatura_id: String(mp.id), status: String(mp.status || 'pending') };
}

async function obterPreapproval(id) {
  return chamarMp(`/preapproval/${encodeURIComponent(id)}`, { method: 'GET' });
}

function parseExternalReference(ref) {
  const texto = String(ref || '');
  const loja = /(?:^|\|)loja:([^|]+)/.exec(texto)?.[1] || null;
  const plano = /(?:^|\|)plano:([^|]+)/.exec(texto)?.[1] || null;
  return { lojaId: loja, plano };
}

async function processarAtualizacaoAssinaturaMp(providerId) {
  const mp = await obterPreapproval(providerId);
  const { lojaId, plano } = parseExternalReference(mp.external_reference);
  if (!lojaId || !plano || !obterPlano(plano)) return { ignorado: true };

  const agora = new Date().toISOString();
  await supabase.from('cobrancas_assinaturas').upsert({
    loja_id: lojaId,
    plano,
    provedor: 'mercadopago',
    provider_assinatura_id: String(providerId),
    status_provider: String(mp.status || 'unknown'),
    checkout_url: mp.init_point || null,
    payer_email: mp.payer_email || null,
    external_reference: mp.external_reference || null,
    atualizado_em: agora,
  }, { onConflict: 'provider_assinatura_id' });

  if (mp.status === 'authorized') {
    const assinatura = await definirAssinatura(lojaId, { plano, status: 'ativo', valido_ate: null, provedor_pagamento: 'mercadopago', provider_assinatura_id: String(providerId), provider_status: mp.status });
    return { atualizado: true, assinatura };
  }

  if (['cancelled', 'paused'].includes(mp.status)) {
    const atual = await buscarAssinaturaAtual(lojaId);
    if (atual?.provider_assinatura_id === String(providerId)) {
      const status = mp.status === 'cancelled' ? 'cancelado' : 'inativo';
      const assinatura = await definirAssinatura(lojaId, { plano: atual.plano, status, valido_ate: atual.valido_ate, provedor_pagamento: 'mercadopago', provider_assinatura_id: String(providerId), provider_status: mp.status });
      return { atualizado: true, assinatura };
    }
  }
  return { atualizado: false, status: mp.status };
}

module.exports = {
  configurado,
  parseSignatureHeader,
  assinaturaWebhookValida,
  criarCheckoutAssinatura,
  processarAtualizacaoAssinaturaMp,
  parseExternalReference,
};

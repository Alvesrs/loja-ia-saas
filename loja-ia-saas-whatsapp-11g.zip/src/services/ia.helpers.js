/**
 * FUNÇÕES PURAS do atendente de IA baseado em regras.
 *
 * Nada aqui acessa banco de dados ou rede — tudo depende apenas dos
 * argumentos recebidos. Isso permite testar toda a lógica de "nunca
 * inventar produto/preço/tamanho/cor" com dados fake, sem precisar de
 * um Supabase real (ver tests/ia.helpers.test.js).
 *
 * `src/services/ia.service.js` é quem busca os dados reais no banco e
 * repassa para `montarResposta`.
 */

function normalizar(texto) {
  return (texto || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, ''); // remove acentos
}

/**
 * Tenta encontrar, entre os produtos da loja, quais batem com palavras
 * da pergunta do cliente (nome do produto, categoria).
 */
function encontrarProdutosMencionados(produtos, perguntaNormalizada) {
  return produtos.filter((produto) => {
    const nome = normalizar(produto.nome);
    const categoria = normalizar(produto.categoria);
    return (
      perguntaNormalizada.includes(nome) ||
      nome.split(' ').some((palavra) => palavra.length > 2 && perguntaNormalizada.includes(palavra)) ||
      (categoria && perguntaNormalizada.includes(categoria))
    );
  });
}

function formatarPreco(valor) {
  return `R$ ${Number(valor).toFixed(2).replace('.', ',')}`;
}

function listarTamanhosDisponiveis(produto) {
  const disponiveis = (produto.estoque || []).filter((v) => v.quantidade > 0);
  if (disponiveis.length === 0) return null;
  return [...new Set(disponiveis.map((v) => v.tamanho))].join(', ');
}

function listarCoresDisponiveis(produto) {
  const disponiveis = (produto.estoque || []).filter((v) => v.quantidade > 0);
  if (disponiveis.length === 0) return null;
  return [...new Set(disponiveis.map((v) => v.cor))].join(', ');
}

function temControleDeEstoque(produto) {
  return Array.isArray(produto && produto.estoque) && produto.estoque.length > 0;
}

/**
 * Função principal (pura): recebe a lista de produtos já carregada do
 * banco e a pergunta do cliente, e retorna uma resposta baseada
 * exclusivamente nesses dados — nunca inventa produto, preço, tamanho,
 * cor ou disponibilidade que não estejam no array `produtos`.
 */
function montarResposta(produtos, pergunta) {
  const perguntaNormalizada = normalizar(pergunta);

  if (produtos.length === 0) {
    return 'Olá! Posso ajudar com o atendimento. Esta empresa ainda não cadastrou produtos/serviços no catálogo do sistema, mas isso não impede o atendimento. Diga o que você precisa; quando uma informação específica não estiver cadastrada, eu vou informar isso sem inventar dados.';
  }

  const encontrados = encontrarProdutosMencionados(produtos, perguntaNormalizada);

  if (encontrados.length === 0) {
    return 'Não encontrei esse produto no nosso catálogo. Pode conferir o nome ou me perguntar sobre outro item?';
  }

  const querPreco = /pre[cç]o|quanto custa|valor/.test(perguntaNormalizada);
  const querTamanho = /tamanho|numera[cç][aã]o|tam\b/.test(perguntaNormalizada);
  const querCor = /\bcor\b|cores/.test(perguntaNormalizada);
  const querDisponibilidade = /tem\b|disponivel|estoque|sobrando/.test(perguntaNormalizada);

  const respostas = encontrados.map((produto) => {
    const partes = [`**${produto.nome}**`];

    if (querPreco || (!querTamanho && !querCor && !querDisponibilidade)) {
      partes.push(`Preço: ${formatarPreco(produto.preco)}`);
    }

    const controlaEstoque = temControleDeEstoque(produto);

    if ((querTamanho || querCor || querDisponibilidade) && !controlaEstoque) {
      partes.push('Este item não possui controle de estoque/variações configurado no sistema.');
    } else {
      if (querTamanho || querDisponibilidade) {
        const tamanhos = listarTamanhosDisponiveis(produto);
        partes.push(tamanhos ? `Tamanhos disponíveis: ${tamanhos}` : 'No momento não há tamanhos disponíveis em estoque.');
      }

      if (querCor || querDisponibilidade) {
        const cores = listarCoresDisponiveis(produto);
        partes.push(cores ? `Cores disponíveis: ${cores}` : 'No momento não há cores disponíveis em estoque.');
      }
    }

    return partes.join(' | ');
  });

  return respostas.join('\n');
}

module.exports = {
  normalizar,
  encontrarProdutosMencionados,
  formatarPreco,
  listarTamanhosDisponiveis,
  listarCoresDisponiveis,
  temControleDeEstoque,
  montarResposta,
};

const supabase = require('../config/supabase');

/**
 * SERVIÇO DE AUTORIZAÇÃO
 * ----------------------
 * Centraliza toda a verificação de "cadeia de propriedade":
 *   usuário → loja → produto → estoque
 *   usuário → loja → cliente
 *
 * Por que isso existe separado dos controllers:
 * O backend usa a service_role key do Supabase (ver src/config/supabase.js),
 * que ignora Row Level Security. Isso significa que a ÚNICA barreira contra
 * um usuário acessar/alterar dados de outra loja é o código abaixo. Nenhuma
 * rota autenticada deve tocar em produtos/estoque/clientes/pedidos sem
 * antes passar por uma destas funções.
 *
 * Nenhuma função aqui confia em IDs soltos vindos do cliente: cada uma
 * sempre verifica o registro completo (join) até a loja do dono.
 */

/** Confirma que a loja pertence ao usuário autenticado. */
async function lojaPertenceAoUsuario(lojaId, usuarioId) {
  const { data, error } = await supabase
    .from('lojas')
    .select('id')
    .eq('id', lojaId)
    .eq('dono_id', usuarioId)
    .maybeSingle();

  if (error || !data) return false;
  return true;
}

/** Confirma que o produto pertence à loja informada. */
async function produtoPertenceALoja(produtoId, lojaId) {
  const { data, error } = await supabase
    .from('produtos')
    .select('id')
    .eq('id', produtoId)
    .eq('loja_id', lojaId)
    .maybeSingle();

  if (error || !data) return false;
  return true;
}

/**
 * Confirma a cadeia completa estoque → produto → loja: o registro de
 * estoque precisa pertencer ao produto informado, e o produto precisa
 * pertencer à loja informada. Retorna o registro (com produto_id) quando
 * válido, ou null quando qualquer elo da cadeia falhar.
 */
async function buscarEstoqueDaLoja(estoqueId, produtoId, lojaId) {
  const { data, error } = await supabase
    .from('estoque')
    .select('id, produto_id, quantidade, tamanho, cor, produtos!inner(id, loja_id)')
    .eq('id', estoqueId)
    .eq('produto_id', produtoId)
    .eq('produtos.loja_id', lojaId)
    .maybeSingle();

  if (error || !data) return null;
  return data;
}

/** Confirma que o cliente pertence à loja informada. */
async function clientePertenceALoja(clienteId, lojaId) {
  const { data, error } = await supabase
    .from('clientes')
    .select('id')
    .eq('id', clienteId)
    .eq('loja_id', lojaId)
    .maybeSingle();

  if (error || !data) return false;
  return true;
}

module.exports = {
  lojaPertenceAoUsuario,
  produtoPertenceALoja,
  buscarEstoqueDaLoja,
  clientePertenceALoja,
};

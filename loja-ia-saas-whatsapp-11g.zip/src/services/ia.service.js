const { montarResposta } = require('./ia.helpers');
const iaContexto = require('./iaContexto.service');
const iaPrompt = require('./iaPrompt.service');
const llmService = require('./llm.service');
const supabase = require('../config/supabase');

/**
 * ATENDENTE DE IA - INTEGRAÇÃO PERGUNTA + CONTEXTO + LLM (Etapa 9E)
 *
 * Este serviço é o ponto de entrada usado pelo controller
 * (`src/controllers/ia.controller.js`) para responder a pergunta de um
 * cliente sobre o catálogo de uma loja. Ele integra, sem duplicar
 * lógica, o que já foi construído nas etapas anteriores:
 *
 *   iaContexto.service  → busca o catálogo REAL e ativo da loja e o
 *                          transforma num contexto compacto e seguro
 *                          (nunca inventa produto/preço/tamanho/cor).
 *   iaPrompt.service     → monta as instruções de sistema (prompt
 *                          mestre) e separa claramente
 *                          SYSTEM + CONTEXTO CONFIÁVEL + PERGUNTA.
 *   llm.service          → faz a chamada HTTP ao provedor de LLM
 *                          configurado (ou informa que não há provedor
 *                          configurado).
 *
 * FLUXO:
 *
 *   lojaId, pergunta
 *     → iaContexto.buscarProdutosAtivosDaLoja(lojaId)   (dados reais)
 *     → iaContexto.montarContextoCatalogo(...)          (contexto puro)
 *     → iaContexto.formatarContextoTexto(...)           (texto compacto)
 *     → iaPrompt.montarEntradaLlm({ contexto, pergunta })
 *     → llm.service.gerarResposta(entrada)              (se configurado)
 *     → texto de resposta
 *
 * FALLBACK: se não houver provedor de LLM configurado, ou se a chamada
 * ao provedor falhar por qualquer motivo (erro de configuração, rede,
 * timeout, resposta inválida), o serviço cai de volta para a lógica
 * determinística baseada em regras (`ia.helpers.montarResposta`), que
 * já existia desde a Etapa 9A e nunca inventa informação — ela só usa
 * os mesmos dados reais (`produtosBrutos`) já buscados nesta função.
 * Nenhum detalhe do erro (mensagem de provedor, headers, stack trace,
 * API key) é exposto ao cliente final: apenas registrado no log do
 * servidor (e o próprio `llm.service` já garante que a API key nunca
 * aparece nesse log).
 *
 * O `lojaId` usado para buscar o contexto vem exclusivamente do
 * parâmetro recebido do controller (que, por sua vez, já validou o
 * formato e a existência/atividade da loja) — a pergunta do cliente
 * nunca é usada para decidir de qual loja buscar dados, e nunca
 * substitui ou é tratada como instrução de sistema.
 */

/**
 * Busca o catálogo real e ativo da loja, no formato bruto (como retorna
 * o banco). Mantido para compatibilidade com o nome já usado nas etapas
 * 9A/9B/9C — agora delega para `iaContexto.service`, que já implementa
 * exatamente esta consulta com o isolamento multi-tenant validado.
 */
async function buscarContextoDaLoja(lojaId) {
  return iaContexto.buscarProdutosAtivosDaLoja(lojaId);
}

async function buscarPromptMestreDaLoja(lojaId) {
  const { data, error } = await supabase
    .from('lojas')
    .select('prompt_mestre')
    .eq('id', lojaId)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data || typeof data.prompt_mestre !== 'string') return null;
  const prompt = data.prompt_mestre.trim();
  return prompt || null;
}

/**
 * Tenta obter uma resposta do provedor de LLM configurado, usando o
 * contexto real da loja e o prompt mestre. Devolve `null` (nunca lança)
 * quando não há provedor configurado ou quando a chamada falha por
 * qualquer motivo — nesses casos o chamador deve usar o fallback
 * baseado em regras.
 */
async function tentarResponderComLlm({ textoContexto, pergunta, promptMestreLoja }) {
  if (!llmService.estaConfigurado()) {
    return null;
  }

  try {
    const entrada = iaPrompt.montarEntradaLlm({ contexto: textoContexto, pergunta, promptMestreLoja });
    const resposta = await llmService.gerarResposta(entrada);
    return resposta;
  } catch (erro) {
    // Nunca logamos a mensagem de erro do provedor sem passar antes pelo
    // próprio llm.service (que já redige a API key). Aqui só registramos
    // o tipo do erro, suficiente para diagnóstico, sem detalhe técnico
    // que possa vazar para o cliente final através de qualquer log
    // acidentalmente exposto.
    console.error(
      '[ia.service] falha ao obter resposta do LLM, usando fallback baseado em regras. Tipo do erro:',
      (erro && erro.name) || 'desconhecido'
    );
    return null;
  }
}

/**
 * Função principal: recebe a pergunta do cliente e retorna uma resposta
 * textual baseada exclusivamente nos dados reais cadastrados pelo
 * lojista (via LLM com contexto seguro, com fallback determinístico
 * quando o LLM não está configurado ou falha).
 */
async function responderPergunta(lojaId, pergunta) {
  const produtosBrutos = await iaContexto.buscarProdutosAtivosDaLoja(lojaId);
  const produtosContexto = iaContexto.montarContextoCatalogo(produtosBrutos);
  const textoContexto = iaContexto.formatarContextoTexto(produtosContexto);
  const promptMestreLoja = await buscarPromptMestreDaLoja(lojaId);

  const respostaLlm = await tentarResponderComLlm({ textoContexto, pergunta, promptMestreLoja });
  if (respostaLlm !== null) {
    return respostaLlm;
  }

  return montarResposta(produtosBrutos, pergunta);
}

module.exports = { buscarContextoDaLoja, buscarPromptMestreDaLoja, responderPergunta };

const supabase = require('../config/supabase');

/**
 * Etapa 10M — idempotência durável dos webhooks de WhatsApp.
 *
 * Cada mensagem externa é reservada no banco por (provedor, id_externo)
 * ANTES de IA/envio. A constraint UNIQUE faz a exclusão mútua também entre
 * múltiplas instâncias do backend.
 *
 * Não armazenamos texto da mensagem, telefone, payload, token ou segredo:
 * apenas o identificador opaco do evento, provedor e estado operacional.
 */

const TABELA = 'whatsapp_eventos_processados';
const STATUS = Object.freeze({ PROCESSANDO: 'processando', CONCLUIDO: 'concluido' });

class ErroIdempotenciaBanco extends Error {
  constructor() {
    super('Não foi possível controlar a idempotência do evento de WhatsApp.');
    this.name = 'ErroIdempotenciaBanco';
  }
}

function normalizarChave({ provedor, idExterno } = {}) {
  if (typeof provedor !== 'string' || !provedor.trim() || provedor.trim().length > 50) {
    throw new TypeError('Provedor inválido para idempotência.');
  }
  if (typeof idExterno !== 'string' || !idExterno.trim() || idExterno.trim().length > 512) {
    throw new TypeError('Identificador externo inválido para idempotência.');
  }
  return { provedor: provedor.trim().toLowerCase(), id_externo: idExterno.trim() };
}

function ehViolacaoUnicidade(erro) {
  return erro && String(erro.code || '') === '23505';
}

/**
 * Tenta reservar o evento. Retorna false se outra execução já o reservou
 * ou concluiu; true somente para a execução dona da nova reserva.
 */
async function reservarEventoWhatsapp(chave) {
  const dados = { ...normalizarChave(chave), status: STATUS.PROCESSANDO };
  const { error } = await supabase.from(TABELA).insert(dados).select('provedor, id_externo').single();
  if (!error) return true;
  if (ehViolacaoUnicidade(error)) return false;
  throw new ErroIdempotenciaBanco();
}

/** Marca a reserva como concluída. Nunca cria uma nova linha. */
async function concluirEventoWhatsapp(chave) {
  const normalizada = normalizarChave(chave);
  const { data, error } = await supabase
    .from(TABELA)
    .update({ status: STATUS.CONCLUIDO, processado_em: new Date().toISOString() })
    .eq('provedor', normalizada.provedor)
    .eq('id_externo', normalizada.id_externo)
    .select('provedor, id_externo')
    .maybeSingle();

  if (error) throw new ErroIdempotenciaBanco();
}

/**
 * Libera uma reserva cujo processamento falhou ANTES de o envio terminar,
 * permitindo que uma reentrega legítima da Meta tente novamente.
 */
async function liberarEventoWhatsapp(chave) {
  const normalizada = normalizarChave(chave);
  const { error } = await supabase
    .from(TABELA)
    .delete()
    .eq('provedor', normalizada.provedor)
    .eq('id_externo', normalizada.id_externo)
    .eq('status', STATUS.PROCESSANDO);
  if (error) throw new ErroIdempotenciaBanco();
}

module.exports = {
  reservarEventoWhatsapp,
  concluirEventoWhatsapp,
  liberarEventoWhatsapp,
  ErroIdempotenciaBanco,
  STATUS,
};

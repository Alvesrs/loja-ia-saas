const supabase = require('../config/supabase');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');

const TABELA = 'whatsapp_fila_processamento';
const STATUS = Object.freeze({
  PENDENTE: 'pendente',
  PROCESSANDO: 'processando',
  ENVIADO: 'enviado',
  CONCLUIDO: 'concluido',
  FALHOU: 'falhou',
});

class ErroFilaWhatsapp extends Error {
  constructor() {
    super('Não foi possível operar a fila de WhatsApp.');
    this.name = 'ErroFilaWhatsapp';
  }
}

function inteiroAmbiente(nome, padrao, min, max) {
  const bruto = process.env[nome];
  if (bruto === undefined || bruto === '') return padrao;
  const n = Number(bruto);
  return Number.isInteger(n) && n >= min && n <= max ? n : padrao;
}

function configuracaoFila() {
  return Object.freeze({
    leaseSegundos: inteiroAmbiente('WHATSAPP_WORKER_LEASE_SEGUNDOS', 60, 10, 3600),
    maxTentativas: inteiroAmbiente('WHATSAPP_WORKER_MAX_TENTATIVAS', 5, 1, 20),
    baseRetryMs: inteiroAmbiente('WHATSAPP_WORKER_RETRY_BASE_MS', 5000, 1000, 3600000),
    maxRetryMs: inteiroAmbiente('WHATSAPP_WORKER_RETRY_MAX_MS', 300000, 1000, 86400000),
  });
}

function validarMensagem(mensagem, contexto = {}) {
  if (!ehUuid(mensagem?.lojaId) || !ehUuid(mensagem?.configuracaoId) ||
      !ehStringNaoVazia(mensagem?.contato) || mensagem.contato.trim().length > 128 ||
      !ehStringNaoVazia(mensagem?.texto) || mensagem.texto.length > 12000 ||
      !ehStringNaoVazia(mensagem?.idExterno) || mensagem.idExterno.trim().length > 512 ||
      !ehStringNaoVazia(contexto.provedor) || contexto.provedor.trim().length > 50 ||
      !ehStringNaoVazia(contexto.destinatarioId) || contexto.destinatarioId.trim().length > 255) {
    throw new TypeError('Dados inválidos para fila de WhatsApp.');
  }
  return {
    loja_id: mensagem.lojaId,
    configuracao_id: mensagem.configuracaoId,
    provedor: contexto.provedor.trim().toLowerCase(),
    destinatario_id: contexto.destinatarioId.trim(),
    contato: mensagem.contato.trim(),
    texto: mensagem.texto,
    id_externo: mensagem.idExterno.trim(),
    timestamp_mensagem: mensagem.timestamp ? new Date(mensagem.timestamp).toISOString() : null,
  };
}

async function enfileirarMensagemWhatsapp(mensagem, contexto) {
  const dados = validarMensagem(mensagem, contexto);
  const cfg = configuracaoFila();
  const agora = new Date();
  const leaseAte = new Date(agora.getTime() + cfg.leaseSegundos * 1000).toISOString();
  const inserir = {
    ...dados,
    status: STATUS.PROCESSANDO,
    tentativas: 1,
    lease_ate: leaseAte,
    proxima_tentativa_em: agora.toISOString(),
  };
  const { data, error } = await supabase.from(TABELA).insert(inserir).select('id').single();
  if (error || !data || !ehUuid(data.id)) throw new ErroFilaWhatsapp();
  return validarJob({ id: data.id, ...inserir, resposta_texto: null });
}

function validarJob(job) {
  if (!job || !ehUuid(job.id) || !ehUuid(job.loja_id) || !ehUuid(job.configuracao_id) ||
      !ehStringNaoVazia(job.provedor) || !ehStringNaoVazia(job.destinatario_id) ||
      !ehStringNaoVazia(job.contato) || !ehStringNaoVazia(job.texto) ||
      !ehStringNaoVazia(job.id_externo) || !Object.values(STATUS).includes(job.status) ||
      !Number.isInteger(job.tentativas) || job.tentativas < 0) {
    throw new ErroFilaWhatsapp();
  }
  return Object.freeze({ ...job });
}

async function reivindicarProximoJob() {
  const { leaseSegundos } = configuracaoFila();
  const { data, error } = await supabase.rpc('claim_whatsapp_job', { p_lease_segundos: leaseSegundos });
  if (error) throw new ErroFilaWhatsapp();
  if (data === null || (Array.isArray(data) && data.length === 0)) return null;
  const job = Array.isArray(data) ? data[0] : data;
  return validarJob(job);
}

async function atualizarJob(id, dados) {
  if (!ehUuid(id)) throw new TypeError('Job inválido.');
  const { data, error } = await supabase.from(TABELA).update({ ...dados, atualizado_em: new Date().toISOString() })
    .eq('id', id).select('id').maybeSingle();
  if (error || !data) throw new ErroFilaWhatsapp();
}

async function marcarJobEnviado(id, respostaTexto) {
  if (!ehStringNaoVazia(respostaTexto) || respostaTexto.length > 12000) throw new TypeError('Resposta inválida.');
  await atualizarJob(id, { status: STATUS.ENVIADO, resposta_texto: respostaTexto, lease_ate: null, ultimo_erro_codigo: null });
}

async function concluirJob(id) {
  await atualizarJob(id, { status: STATUS.CONCLUIDO, concluido_em: new Date().toISOString(), lease_ate: null, ultimo_erro_codigo: null });
}

function calcularAtrasoMs(tentativas, cfg = configuracaoFila()) {
  const expoente = Math.max(0, Number(tentativas) - 1);
  return Math.min(cfg.maxRetryMs, cfg.baseRetryMs * (2 ** expoente));
}

async function reagendarOuFalharJob(job, codigo = 'falha_processamento') {
  validarJob(job);
  const cfg = configuracaoFila();
  const codigoSeguro = typeof codigo === 'string' && /^[a-z0-9_.-]{1,80}$/i.test(codigo) ? codigo : 'falha_processamento';
  if (job.tentativas >= cfg.maxTentativas) {
    await atualizarJob(job.id, { status: STATUS.FALHOU, lease_ate: null, ultimo_erro_codigo: codigoSeguro });
    return Object.freeze({ status: STATUS.FALHOU, proximaTentativaEm: null });
  }
  const atraso = calcularAtrasoMs(job.tentativas, cfg);
  const proxima = new Date(Date.now() + atraso).toISOString();
  await atualizarJob(job.id, {
    status: STATUS.PENDENTE,
    proxima_tentativa_em: proxima,
    lease_ate: null,
    ultimo_erro_codigo: codigoSeguro,
  });
  return Object.freeze({ status: STATUS.PENDENTE, proximaTentativaEm: proxima });
}

async function reagendarFinalizacaoJob(job, codigo = 'falha_finalizacao') {
  validarJob(job);
  if (job.status !== STATUS.ENVIADO || !ehStringNaoVazia(job.resposta_texto)) {
    throw new TypeError('Job enviado inválido para finalização.');
  }
  const cfg = configuracaoFila();
  const codigoSeguro = typeof codigo === 'string' && /^[a-z0-9_.-]{1,80}$/i.test(codigo) ? codigo : 'falha_finalizacao';
  if (job.tentativas >= cfg.maxTentativas) {
    await atualizarJob(job.id, { status: STATUS.FALHOU, lease_ate: null, ultimo_erro_codigo: codigoSeguro });
    return Object.freeze({ status: STATUS.FALHOU, proximaTentativaEm: null });
  }
  const atraso = calcularAtrasoMs(job.tentativas, cfg);
  const proxima = new Date(Date.now() + atraso).toISOString();
  await atualizarJob(job.id, {
    status: STATUS.ENVIADO,
    proxima_tentativa_em: proxima,
    lease_ate: null,
    ultimo_erro_codigo: codigoSeguro,
  });
  return Object.freeze({ status: STATUS.ENVIADO, proximaTentativaEm: proxima });
}

module.exports = {
  enfileirarMensagemWhatsapp,
  reivindicarProximoJob,
  marcarJobEnviado,
  concluirJob,
  reagendarOuFalharJob,
  reagendarFinalizacaoJob,
  calcularAtrasoMs,
  configuracaoFila,
  ErroFilaWhatsapp,
  STATUS,
};

const supabase = require('../config/supabase');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');

const TABELA_CONVERSAS = 'whatsapp_conversas';
const TABELA_MENSAGENS = 'whatsapp_mensagens';
const DIRECOES = Object.freeze({ ENTRADA: 'entrada', SAIDA: 'saida' });

class ErroHistoricoWhatsapp extends Error {
  constructor() {
    super('Não foi possível persistir o histórico de WhatsApp.');
    this.name = 'ErroHistoricoWhatsapp';
  }
}

function validarBase({ lojaId, configuracaoId, contato, provedor }) {
  if (!ehUuid(lojaId) || !ehUuid(configuracaoId) || !ehStringNaoVazia(contato) ||
      contato.trim().length > 128 || !ehStringNaoVazia(provedor) || provedor.trim().length > 50) {
    throw new TypeError('Contexto inválido para histórico de WhatsApp.');
  }
  return {
    loja_id: lojaId,
    configuracao_id: configuracaoId,
    contato: contato.trim(),
    provedor: provedor.trim().toLowerCase(),
  };
}

function validarTexto(texto) {
  if (!ehStringNaoVazia(texto) || texto.length > 12000) {
    throw new TypeError('Texto inválido para histórico de WhatsApp.');
  }
  return texto;
}

async function obterOuCriarConversa(base) {
  const { data, error } = await supabase
    .from(TABELA_CONVERSAS)
    .upsert({
      loja_id: base.loja_id,
      configuracao_id: base.configuracao_id,
      contato: base.contato,
      atualizado_em: new Date().toISOString(),
    }, { onConflict: 'loja_id,configuracao_id,contato' })
    .select('id, loja_id, configuracao_id, contato')
    .single();

  if (error || !data || !ehUuid(data.id) || data.loja_id !== base.loja_id ||
      data.configuracao_id !== base.configuracao_id || data.contato !== base.contato) {
    throw new ErroHistoricoWhatsapp();
  }
  return data;
}

async function inserirMensagem({ conversa, lojaId, direcao, texto, provedor, idExterno = null, duplicataPermitida = false }) {
  const { error } = await supabase.from(TABELA_MENSAGENS).insert({
    conversa_id: conversa.id,
    loja_id: lojaId,
    direcao,
    texto,
    provedor,
    id_externo: idExterno,
  });
  if (!error) return true;
  if (duplicataPermitida && String(error.code || '') === '23505') return false;
  throw new ErroHistoricoWhatsapp();
}

async function registrarMensagemRecebida(mensagem, contexto) {
  try {
    const base = validarBase({
      lojaId: mensagem?.lojaId,
      configuracaoId: mensagem?.configuracaoId,
      contato: mensagem?.contato,
      provedor: contexto?.provedor,
    });
    const texto = validarTexto(mensagem?.texto);
    const idExterno = mensagem?.idExterno;
    if (!ehStringNaoVazia(idExterno) || idExterno.trim().length > 512) {
      throw new TypeError('Identificador externo inválido para histórico de WhatsApp.');
    }
    const conversa = await obterOuCriarConversa(base);
    await inserirMensagem({
      conversa,
      lojaId: base.loja_id,
      direcao: DIRECOES.ENTRADA,
      texto,
      provedor: base.provedor,
      idExterno: idExterno.trim(),
      duplicataPermitida: true,
    });
    return Object.freeze({ conversaId: conversa.id });
  } catch (erro) {
    if (erro instanceof TypeError) throw erro;
    if (erro instanceof ErroHistoricoWhatsapp) throw erro;
    throw new ErroHistoricoWhatsapp();
  }
}

async function registrarMensagemEnviada(mensagem, resposta, contexto) {
  try {
    const base = validarBase({
      lojaId: mensagem?.lojaId,
      configuracaoId: mensagem?.configuracaoId,
      contato: mensagem?.contato,
      provedor: contexto?.provedor,
    });
    if (!resposta || resposta.lojaId !== mensagem.lojaId || resposta.contato !== mensagem.contato ||
        resposta.idExterno !== mensagem.idExterno) {
      throw new TypeError('Resposta inválida para histórico de WhatsApp.');
    }
    const texto = validarTexto(resposta.resposta);
    const conversa = await obterOuCriarConversa(base);
    await inserirMensagem({
      conversa,
      lojaId: base.loja_id,
      direcao: DIRECOES.SAIDA,
      texto,
      provedor: base.provedor,
      idExterno: null,
    });
    return Object.freeze({ conversaId: conversa.id });
  } catch (erro) {
    if (erro instanceof TypeError) throw erro;
    if (erro instanceof ErroHistoricoWhatsapp) throw erro;
    throw new ErroHistoricoWhatsapp();
  }
}



/**
 * Lista conversas visíveis no painel da loja. Nunca busca por conversa sem
 * também filtrar por loja_id: o service_role ignora RLS, então este filtro é
 * parte da autorização multi-tenant do backend.
 */
async function listarConversas(lojaId, limite = 50) {
  if (!ehUuid(lojaId) || !Number.isInteger(limite) || limite < 1 || limite > 100) {
    throw new TypeError('Parâmetros inválidos para histórico de WhatsApp.');
  }
  const { data, error } = await supabase
    .from(TABELA_CONVERSAS)
    .select('id, loja_id, configuracao_id, contato, criado_em, atualizado_em')
    .eq('loja_id', lojaId)
    .order('atualizado_em', { ascending: false })
    .limit(limite);
  if (error) throw new ErroHistoricoWhatsapp();
  return (Array.isArray(data) ? data : []).map((item) => Object.freeze({
    id: item.id,
    configuracao_id: item.configuracao_id,
    contato: item.contato,
    criado_em: item.criado_em,
    atualizado_em: item.atualizado_em,
  }));
}

/**
 * Lista mensagens de uma conversa somente dentro da mesma loja autenticada.
 * O filtro composto conversa_id + loja_id acompanha a FK composta do schema
 * e impede leitura cruzada entre tenants mesmo usando service_role.
 */
async function listarMensagens(conversaId, lojaId, limite = 100) {
  if (!ehUuid(conversaId) || !ehUuid(lojaId) || !Number.isInteger(limite) || limite < 1 || limite > 200) {
    throw new TypeError('Parâmetros inválidos para histórico de WhatsApp.');
  }
  const { data, error } = await supabase
    .from(TABELA_MENSAGENS)
    .select('id, conversa_id, direcao, texto, provedor, id_externo, criado_em')
    .eq('conversa_id', conversaId)
    .eq('loja_id', lojaId)
    .order('criado_em', { ascending: true })
    .limit(limite);
  if (error) throw new ErroHistoricoWhatsapp();
  return (Array.isArray(data) ? data : []).map((item) => Object.freeze({
    id: item.id,
    conversa_id: item.conversa_id,
    direcao: item.direcao,
    texto: item.texto,
    provedor: item.provedor,
    id_externo: item.id_externo,
    criado_em: item.criado_em,
  }));
}

module.exports = {
  listarConversas,
  listarMensagens,
  registrarMensagemRecebida,
  registrarMensagemEnviada,
  ErroHistoricoWhatsapp,
  DIRECOES,
};

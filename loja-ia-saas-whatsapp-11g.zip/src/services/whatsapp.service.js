const { ehUuid, ehStringNaoVazia, ehStringOpcionalValida } = require('../utils/validacao');

/**
 * CAMADA DE ABSTRAÇÃO — WHATSAPP (Etapa 10A — fundação, sem integração real)
 *
 * ==========================================================================
 * ATENÇÃO: este arquivo NÃO se conecta a nenhum provedor de WhatsApp.
 * Não há chamada HTTP real, não há Meta API, não há Twilio/Z-API/Evolution
 * API, não há webhook público funcional. Nada aqui envia ou recebe uma
 * mensagem de WhatsApp de verdade. É apenas a INTERFACE/CONTRATO que uma
 * futura integração real deverá implementar.
 * ==========================================================================
 *
 * POR QUE ESTA CAMADA EXISTE
 *
 * O objetivo é isolar o "canal" (WhatsApp) do "cérebro" (Atendente de IA).
 * O WhatsApp é só mais uma porta de entrada/saída de texto — a mesma que
 * hoje é a rota HTTP `/ia/perguntar` (ver `src/routes/ia.routes.js` e
 * `src/services/ia.service.js`). Este service NUNCA deve conter lógica de
 * catálogo, prompt ou resposta: isso continua 100% centralizado em
 * `ia.service.js` (e nos serviços que ele já usa: `iaContexto.service`,
 * `iaPrompt.service`, `llm.service`). Este arquivo não duplica nada disso.
 *
 * FLUXO CONCEITUAL FUTURO (nenhuma parte disto está implementada ainda):
 *
 *   WhatsApp (usuário real)
 *     → provedor de WhatsApp (Meta API / Twilio / Z-API / Evolution / etc.)
 *     → adaptador do provedor (arquivo futuro, específico do provedor
 *       escolhido — ainda não existe neste projeto)
 *     → normalizarMensagemRecebida(...)   [implementado aqui, é dado puro]
 *     → identificação da loja (lojaId confiável — nunca vindo do payload
 *       externo; ver seção de segurança abaixo)
 *     → ia.service (o mesmo "cérebro" já usado pela rota /ia/perguntar)
 *     → texto de resposta
 *     → prepararEnvioMensagem(...)        [implementado aqui, é dado puro]
 *     → adaptador do provedor (futuro)
 *     → provedor de WhatsApp
 *     → WhatsApp (usuário real)
 *
 * O QUE ESTE ARQUIVO FAZ HOJE
 *
 *   - Define o "formato" (shape) de uma mensagem recebida normalizada e de
 *     uma mensagem a enviar, com validação de entrada.
 *   - Não faz I/O de nenhum tipo (sem rede, sem banco, sem arquivo).
 *   - Não sabe nada sobre Meta, Twilio, Z-API, Evolution API ou qualquer
 *     outro provedor — de propósito, para que trocar de provedor no futuro
 *     signifique escrever um adaptador novo, sem tocar aqui.
 *
 * O QUE ESTE ARQUIVO DELIBERADAMENTE NÃO FAZ (fora do escopo desta etapa)
 *
 *   - Não envia nem recebe mensagem real.
 *   - Não expõe rota HTTP / webhook.
 *   - Não lê nem grava nada em banco de dados.
 *   - Não guarda token, API key ou segredo de nenhum provedor.
 *   - Não decide qual provedor será usado no futuro.
 *
 * SEGURANÇA — SOBRE O CAMPO "lojaId"
 *
 * `lojaId` DEVE sempre vir de uma fonte confiável da própria aplicação
 * (por exemplo: o número de WhatsApp da loja já cadastrado no banco,
 * resolvido pelo adaptador ANTES de chamar `normalizarMensagemRecebida`).
 * Um valor de "loja_id" que venha dentro do corpo/payload bruto enviado
 * pelo provedor (ou, pior, controlado indiretamente pelo cliente final no
 * WhatsApp) NUNCA deve ser aceito como autorização — o mesmo princípio já
 * aplicado em `iaContexto.service.js` e `middleware/lojaOwnership.js` para
 * as rotas HTTP autenticadas. Por isso `normalizarMensagemRecebida` exige
 * `lojaId` como parâmetro explícito da aplicação, e ignora completamente
 * qualquer campo de mesmo nome que exista dentro de `dadosExternos`.
 */

const LIMITE_TEXTO_MENSAGEM = 4000;

class ErroMensagemWhatsappInvalida extends Error {
  constructor(mensagem) {
    super(mensagem);
    this.name = 'ErroMensagemWhatsappInvalida';
  }
}

/**
 * Normaliza uma mensagem recebida de um (futuro) provedor de WhatsApp para
 * o formato interno usado pela aplicação. É uma função pura: não faz I/O,
 * não chama a IA, não persiste nada — apenas valida e formata dados.
 *
 * @param {object} params
 * @param {string} params.lojaId - UUID da loja, resolvido de forma
 *   confiável pela aplicação (ex.: a partir do número de WhatsApp da loja
 *   já cadastrado no banco). NUNCA deve vir de dado bruto do payload
 *   externo/cliente.
 * @param {string} params.contato - identificador do cliente no WhatsApp
 *   (ex.: número de telefone). String não vazia.
 * @param {string} params.texto - texto da mensagem enviada pelo cliente.
 * @param {string} [params.idExterno] - identificador da mensagem atribuído
 *   pelo provedor de WhatsApp (opcional).
 * @param {string|number|Date} [params.timestamp] - momento do envio,
 *   conforme informado pelo provedor (opcional).
 * @param {object} [params.dadosExternos] - payload bruto opcional recebido
 *   do provedor, guardado apenas para depuração/auditoria. Qualquer campo
 *   aqui dentro (incluindo um eventual "loja_id") é IGNORADO para fins de
 *   autorização — só o `lojaId` explícito acima é usado.
 * @returns {{lojaId: string, contato: string, texto: string, idExterno: string|null, timestamp: string|null, canal: 'whatsapp'}}
 */
function normalizarMensagemRecebida({ lojaId, contato, texto, idExterno, timestamp } = {}) {
  if (!ehUuid(lojaId)) {
    throw new ErroMensagemWhatsappInvalida('lojaId inválido: é obrigatório e deve ser um UUID.');
  }

  if (!ehStringNaoVazia(contato)) {
    throw new ErroMensagemWhatsappInvalida('contato inválido: é obrigatório e deve ser uma string não vazia.');
  }

  if (typeof texto !== 'string' || texto.trim().length === 0) {
    throw new ErroMensagemWhatsappInvalida('texto inválido: é obrigatório e não pode ser vazio.');
  }

  if (texto.length > LIMITE_TEXTO_MENSAGEM) {
    throw new ErroMensagemWhatsappInvalida(
      `texto inválido: excede o limite de ${LIMITE_TEXTO_MENSAGEM} caracteres.`
    );
  }

  if (!ehStringOpcionalValida(idExterno)) {
    throw new ErroMensagemWhatsappInvalida('idExterno inválido: quando informado, deve ser uma string.');
  }

  let timestampNormalizado = null;
  if (timestamp !== undefined && timestamp !== null) {
    const data = timestamp instanceof Date ? timestamp : new Date(timestamp);
    if (Number.isNaN(data.getTime())) {
      throw new ErroMensagemWhatsappInvalida('timestamp inválido: não foi possível interpretar a data/hora.');
    }
    timestampNormalizado = data.toISOString();
  }

  return {
    canal: 'whatsapp',
    lojaId,
    contato: contato.trim(),
    texto: texto.trim(),
    idExterno: idExterno ?? null,
    timestamp: timestampNormalizado,
  };
}

/**
 * Prepara (mas NÃO envia) os dados de uma mensagem de resposta a ser
 * entregue a um contato via WhatsApp. Função pura, sem I/O — o envio real
 * fica a cargo de um futuro adaptador de provedor, que ainda não existe
 * neste projeto.
 *
 * @param {object} params
 * @param {string} params.lojaId - UUID da loja de origem da resposta.
 * @param {string} params.contato - identificador do cliente destinatário.
 * @param {string} params.texto - texto da resposta a enviar.
 * @returns {{lojaId: string, contato: string, texto: string, canal: 'whatsapp'}}
 */
function prepararEnvioMensagem({ lojaId, contato, texto } = {}) {
  if (!ehUuid(lojaId)) {
    throw new ErroMensagemWhatsappInvalida('lojaId inválido: é obrigatório e deve ser um UUID.');
  }

  if (!ehStringNaoVazia(contato)) {
    throw new ErroMensagemWhatsappInvalida('contato inválido: é obrigatório e deve ser uma string não vazia.');
  }

  if (typeof texto !== 'string' || texto.trim().length === 0) {
    throw new ErroMensagemWhatsappInvalida('texto inválido: é obrigatório e não pode ser vazio.');
  }

  if (texto.length > LIMITE_TEXTO_MENSAGEM) {
    throw new ErroMensagemWhatsappInvalida(
      `texto inválido: excede o limite de ${LIMITE_TEXTO_MENSAGEM} caracteres.`
    );
  }

  return {
    canal: 'whatsapp',
    lojaId,
    contato: contato.trim(),
    texto: texto.trim(),
  };
}

/**
 * Identifica (de forma trivial, sem I/O) o identificador do contato dentro
 * de uma mensagem já normalizada. Existe como ponto único de acesso a este
 * dado, para que uma futura mudança de formato não exija alterar todos os
 * lugares que leem o contato.
 */
function identificarContato(mensagemNormalizada) {
  if (!mensagemNormalizada || typeof mensagemNormalizada !== 'object') {
    throw new ErroMensagemWhatsappInvalida('mensagem normalizada inválida.');
  }
  return mensagemNormalizada.contato ?? null;
}

/**
 * Identifica (de forma trivial, sem I/O) a loja associada a uma mensagem já
 * normalizada. Não faz lookup em banco — apenas lê o campo já validado por
 * `normalizarMensagemRecebida`.
 */
function identificarLoja(mensagemNormalizada) {
  if (!mensagemNormalizada || typeof mensagemNormalizada !== 'object') {
    throw new ErroMensagemWhatsappInvalida('mensagem normalizada inválida.');
  }
  return mensagemNormalizada.lojaId ?? null;
}

/**
 * PLACEHOLDER INTENCIONAL — envio real de mensagem.
 *
 * Esta função existe apenas para deixar explícito, no contrato da camada,
 * onde um futuro adaptador de provedor deverá "plugar" o envio real. Nesta
 * etapa ela NUNCA faz uma chamada HTTP: sempre lança, para impedir que
 * algum código chame isto pensando que uma mensagem foi de fato enviada.
 *
 * @throws {Error} sempre — integração real ainda não implementada.
 */
async function enviarMensagem() {
  throw new Error(
    'whatsapp.service.enviarMensagem: integração real com provedor de WhatsApp ainda não implementada ' +
      '(fundação arquitetural apenas — Etapa 10A). Nenhuma chamada HTTP é feita.'
  );
}

/**
 * PLACEHOLDER INTENCIONAL — recebimento real de mensagem (webhook).
 *
 * Assim como `enviarMensagem`, existe só para deixar o contrato explícito.
 * Não há webhook público nesta etapa; nenhuma rota HTTP chama esta função.
 *
 * @throws {Error} sempre — integração real ainda não implementada.
 */
async function receberMensagem() {
  throw new Error(
    'whatsapp.service.receberMensagem: integração real com provedor de WhatsApp ainda não implementada ' +
      '(fundação arquitetural apenas — Etapa 10A). Nenhum webhook está ativo.'
  );
}

module.exports = {
  LIMITE_TEXTO_MENSAGEM,
  ErroMensagemWhatsappInvalida,
  normalizarMensagemRecebida,
  prepararEnvioMensagem,
  identificarContato,
  identificarLoja,
  enviarMensagem,
  receberMensagem,
};

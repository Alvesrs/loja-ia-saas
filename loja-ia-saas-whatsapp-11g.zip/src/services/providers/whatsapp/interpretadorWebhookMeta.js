const { ehStringNaoVazia } = require('../../../utils/validacao');

/**
 * INTERPRETADOR DO PAYLOAD DE WEBHOOK DA META (Etapa 10H)
 *
 * ==========================================================================
 * ATENÇÃO — ESCOPO DESTA ETAPA (10H): este módulo SÓ interpreta o payload
 * JSON já parseado que a Meta envia para o webhook (formato
 * `entry[].changes[].value.messages[]`) e o transforma na nossa estrutura
 * interna de "mensagem interpretada". Ele:
 *
 *   - NÃO chama a IA, `ia.service` nem `llm.service`.
 *   - NÃO gera nem envia resposta alguma.
 *   - NÃO chama `adaptadorMeta.js` (envio) nem `clienteHttpMeta.js`.
 *   - NÃO faz nenhuma chamada HTTP, de rede ou de banco.
 *   - NÃO é chamado por nenhuma rota, controller ou webhook ainda: nada em
 *     `whatsappWebhook.routes.js`/`.controller.js`/`.service.js` importa
 *     este arquivo. Ligar isto ao webhook HTTP real é trabalho de uma etapa
 *     futura (10I ou posterior).
 *   - NÃO decide qual é a loja: não resolve `lojaId` a partir de banco, nem
 *     aceita QUALQUER campo de loja vindo do payload (ver seção de
 *     segurança abaixo). Devolve só `destinatarioId` (o
 *     `phone_number_id` da Meta) — a aplicação, numa etapa futura, é quem
 *     resolve `destinatarioId → configuração WhatsApp ativa → lojaId`.
 * ==========================================================================
 *
 * FORMATO DE ENTRADA (bruto, da Meta — só leitura, nunca modificado)
 *
 *   {
 *     entry: [
 *       {
 *         changes: [
 *           {
 *             value: {
 *               metadata: { phone_number_id: "..." },
 *               messages: [
 *                 { id, from, timestamp, type: "text", text: { body: "..." } }
 *                 // ou outro type (image, audio, video, document, location...)
 *               ],
 *               statuses: [ ... ]   // eventos de status de ENVIO — nunca viram mensagem recebida
 *             }
 *           }
 *         ]
 *       }
 *     ]
 *   }
 *
 * FORMATO DE SAÍDA — "mensagem interpretada" (por mensagem encontrada)
 *
 *   {
 *     valida: boolean,
 *     motivoInvalida: string | null,  // código FIXO (ver MOTIVOS_MENSAGEM_INVALIDA); nunca ecoa dado do payload
 *     suportada: boolean,             // true só quando valida && tipo === 'texto'
 *     tipo: 'texto' | 'nao_suportado' | null,
 *     idExterno: string | null,       // messages[].id
 *     contato: string | null,         // messages[].from
 *     timestamp: string | null,       // ISO 8601, a partir de messages[].timestamp (segundos desde epoch)
 *     destinatarioId: string | null,  // value.metadata.phone_number_id
 *     texto: string | null,           // messages[].text.body — SÓ quando tipo === 'texto'; nunca inventado
 *   }
 *
 * Nenhum campo de loja (`lojaId`, `loja_id`, `configuracaoId`, `provedor`)
 * existe neste formato de saída, mesmo que o payload de entrada tente
 * injetar um: este módulo simplesmente nunca lê esses nomes de campo, em
 * NENHUM nível do payload (mensagem, `value`, `change` ou `entry`).
 *
 * VALIDAÇÃO DEFENSIVA
 *
 *   - Payload que não seja um objeto (nulo, array, string, número...) faz
 *     `interpretarPayloadWebhookMeta` LANÇAR `ErroWebhookMetaInvalido`, com
 *     mensagem FIXA (nunca inclui o payload recebido).
 *   - Qualquer outra estrutura ausente ou malformada (`entry`/`changes`
 *     ausentes ou não-array, `value` ausente, `messages` ausente ou
 *     não-array, uma mensagem que não seja objeto) é tratada de forma
 *     controlada: o trecho é simplesmente ignorado (não gera mensagem, não
 *     lança erro) — um payload sem nenhuma mensagem reconhecível devolve
 *     uma lista vazia.
 *   - Uma mensagem presente mas sem `id`, sem `from` ou sem
 *     `phone_number_id` (herdado de `value.metadata`) vira uma mensagem
 *     "inválida" (`valida: false`, com o motivo correspondente) em vez de
 *     lançar erro ou de ser descartada silenciosamente — quem chama decide
 *     o que fazer com uma mensagem inválida.
 *   - `type !== 'text'` (image, audio, video, document, location, sticker,
 *     reaction, ausente, ou qualquer valor desconhecido) vira
 *     `suportada: false, tipo: 'nao_suportado'`, SEM tentar extrair ou
 *     inventar conteúdo de texto.
 *   - `type === 'text'` sem `text.body` (ausente, vazio ou não-string) vira
 *     mensagem inválida (`motivoInvalida: 'sem_texto'`) — nunca um texto
 *     vazio ou inventado.
 *   - Eventos em `value.statuses` NUNCA são lidos por este módulo: só
 *     `value.messages` é considerado.
 *   - Nenhum log é feito aqui (não há I/O), então não há risco deste módulo
 *     registrar segredo, token ou o corpo completo da mensagem.
 */

/** Payload de nível mais alto não é um objeto (erro de quem chama). */
class ErroWebhookMetaInvalido extends Error {
  constructor(mensagem) {
    super(mensagem || 'payload do webhook da Meta inválido.');
    this.name = 'ErroWebhookMetaInvalido';
  }
}

/** Tipos de mensagem reconhecidos na saída deste módulo. */
const TIPOS_MENSAGEM_WEBHOOK = Object.freeze({
  texto: 'texto',
  naoSuportado: 'nao_suportado',
});

/** Motivos FIXOS de invalidade — nunca ecoam nenhum valor recebido no payload. */
const MOTIVOS_MENSAGEM_INVALIDA = Object.freeze({
  formatoInvalido: 'formato_invalido',
  semId: 'sem_id',
  semRemetente: 'sem_remetente',
  semDestinatario: 'sem_destinatario',
  semTexto: 'sem_texto',
});

function ehObjetoSimples(valor) {
  return valor !== null && typeof valor === 'object' && !Array.isArray(valor);
}

/** Lê um campo de texto (string não vazia) de um objeto; qualquer outra coisa vira `null`. */
function extrairCampoTexto(objeto, campo) {
  if (!ehObjetoSimples(objeto)) return null;
  const valor = objeto[campo];
  return ehStringNaoVazia(valor) ? valor : null;
}

/**
 * `messages[].timestamp` da Meta é uma string com segundos desde a epoch
 * Unix (não milissegundos). Converte para ISO 8601; devolve `null` se não
 * for possível interpretar — nunca inventa uma data.
 */
function extrairTimestamp(mensagemBruta) {
  if (!ehObjetoSimples(mensagemBruta)) return null;
  const bruto = mensagemBruta.timestamp;
  if (typeof bruto !== 'string' && typeof bruto !== 'number') return null;

  const segundos = typeof bruto === 'string' ? Number(bruto) : bruto;
  if (!Number.isFinite(segundos) || segundos <= 0) return null;

  const data = new Date(segundos * 1000);
  return Number.isNaN(data.getTime()) ? null : data.toISOString();
}

/** `value.metadata.phone_number_id` — o único identificador de destinatário aceito. */
function extrairDestinatarioId(value) {
  if (!ehObjetoSimples(value)) return null;
  return extrairCampoTexto(value.metadata, 'phone_number_id');
}

function congelarMensagemInterpretada({
  valida,
  motivoInvalida = null,
  suportada = false,
  tipo = null,
  idExterno = null,
  contato = null,
  timestamp = null,
  destinatarioId = null,
  texto = null,
}) {
  return Object.freeze({
    valida,
    motivoInvalida,
    suportada,
    tipo,
    idExterno,
    contato,
    timestamp,
    destinatarioId,
    texto,
  });
}

/**
 * Interpreta UMA mensagem bruta de `value.messages[]`, já com o
 * `destinatarioId` da `value` que a contém.
 */
function interpretarMensagem(mensagemBruta, destinatarioId) {
  const base = {
    idExterno: extrairCampoTexto(mensagemBruta, 'id'),
    contato: extrairCampoTexto(mensagemBruta, 'from'),
    timestamp: extrairTimestamp(mensagemBruta),
    destinatarioId,
  };

  if (!ehObjetoSimples(mensagemBruta)) {
    return congelarMensagemInterpretada({ ...base, valida: false, motivoInvalida: MOTIVOS_MENSAGEM_INVALIDA.formatoInvalido });
  }
  if (base.idExterno === null) {
    return congelarMensagemInterpretada({ ...base, valida: false, motivoInvalida: MOTIVOS_MENSAGEM_INVALIDA.semId });
  }
  if (base.contato === null) {
    return congelarMensagemInterpretada({ ...base, valida: false, motivoInvalida: MOTIVOS_MENSAGEM_INVALIDA.semRemetente });
  }
  if (base.destinatarioId === null) {
    return congelarMensagemInterpretada({ ...base, valida: false, motivoInvalida: MOTIVOS_MENSAGEM_INVALIDA.semDestinatario });
  }

  // Só `type === 'text'` é suportado nesta etapa. Qualquer outro valor
  // (image, audio, video, document, location, sticker, reaction, ausente,
  // ou tipo desconhecido) vira "não suportado", sem inventar conteúdo.
  if (mensagemBruta.type !== 'text') {
    return congelarMensagemInterpretada({
      ...base,
      valida: true,
      suportada: false,
      tipo: TIPOS_MENSAGEM_WEBHOOK.naoSuportado,
    });
  }

  const corpoTexto = ehObjetoSimples(mensagemBruta.text) ? mensagemBruta.text.body : undefined;
  if (typeof corpoTexto !== 'string' || corpoTexto.trim().length === 0) {
    return congelarMensagemInterpretada({ ...base, valida: false, motivoInvalida: MOTIVOS_MENSAGEM_INVALIDA.semTexto });
  }

  // O texto é devolvido exatamente como recebido (só com espaços nas
  // pontas removidos, igual a `whatsapp.service.normalizarMensagemRecebida`).
  // Nenhuma interpretação, sanitização ou execução de conteúdo acontece
  // aqui: HTML, scripts ou comandos dentro do texto permanecem só como
  // texto — quem exibir/usar este valor depois é responsável por tratá-lo
  // como dado, nunca como código.
  return congelarMensagemInterpretada({
    ...base,
    valida: true,
    suportada: true,
    tipo: TIPOS_MENSAGEM_WEBHOOK.texto,
    texto: corpoTexto.trim(),
  });
}

/**
 * Interpreta o payload COMPLETO de um webhook da Meta e devolve a lista de
 * mensagens encontradas em `entry[].changes[].value.messages[]`, na ordem
 * em que aparecem (percorrendo múltiplos `entry` e múltiplos `changes`).
 *
 * Função pura: não faz I/O, não lança para estruturas internas ausentes ou
 * malformadas (só devolve menos mensagens, ou mensagens marcadas como
 * inválidas) e NUNCA lê `loja_id`, `lojaId`, `configuracaoId` ou `provedor`
 * de nenhum nível do payload.
 *
 * @param {unknown} payload - o corpo do webhook, já parseado como objeto
 *   JavaScript (não uma string JSON).
 * @returns {ReadonlyArray<object>} lista congelada de mensagens interpretadas
 *   (ver formato de saída no cabeçalho deste arquivo).
 * @throws {ErroWebhookMetaInvalido} se `payload` não for um objeto.
 */
function interpretarPayloadWebhookMeta(payload) {
  if (!ehObjetoSimples(payload)) {
    throw new ErroWebhookMetaInvalido('payload do webhook da Meta inválido: deve ser um objeto.');
  }

  const mensagens = [];
  const entradas = Array.isArray(payload.entry) ? payload.entry : [];

  for (const entrada of entradas) {
    if (!ehObjetoSimples(entrada)) continue;
    const mudancas = Array.isArray(entrada.changes) ? entrada.changes : [];

    for (const mudanca of mudancas) {
      if (!ehObjetoSimples(mudanca)) continue;
      if (mudanca.field && mudanca.field !== 'messages') continue;
      const value = mudanca.value;
      if (!ehObjetoSimples(value)) continue;

      // `value.statuses` (eventos de status de envio) é IGNORADO de
      // propósito: nunca vira mensagem recebida.
      const listaMensagens = Array.isArray(value.messages) ? value.messages : [];
      if (listaMensagens.length === 0) continue;

      const destinatarioId = extrairDestinatarioId(value);
      for (const mensagemBruta of listaMensagens) {
        if (mensagemBruta && mensagemBruta.is_echo === true) continue;
        mensagens.push(interpretarMensagem(mensagemBruta, destinatarioId));
      }
    }
  }

  return Object.freeze(mensagens);
}

module.exports = {
  ErroWebhookMetaInvalido,
  TIPOS_MENSAGEM_WEBHOOK,
  MOTIVOS_MENSAGEM_INVALIDA,
  interpretarPayloadWebhookMeta,
};

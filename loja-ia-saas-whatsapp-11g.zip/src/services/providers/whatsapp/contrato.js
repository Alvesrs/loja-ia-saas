const { ehUuid, ehStringNaoVazia } = require('../../../utils/validacao');
const { prepararEnvioMensagem, ErroMensagemWhatsappInvalida } = require('../../whatsapp.service');

/**
 * CONTRATO INTERNO DE PROVEDOR DE WHATSAPP (Etapa 10F)
 *
 * ==========================================================================
 * ATENÇÃO: este arquivo NÃO é uma integração. Não há chamada HTTP, fetch,
 * axios, SDK, credencial, token nem conhecimento de qualquer provedor
 * (Meta, Twilio, Evolution, Baileys ou outro). Ele só DEFINE o que o sistema
 * espera de um provedor de WhatsApp e o formato dos dados que entram e saem.
 * ==========================================================================
 *
 * POR QUE EXISTE
 *
 *   nosso sistema
 *        ↓  usa APENAS este contrato
 *   contrato interno de WhatsApp        (este arquivo)
 *        ↓
 *   adaptador do provedor               (ex.: adaptadorSimulado.js)
 *        ↓  [futuramente]
 *   API real do provedor
 *
 * Regras específicas de um provedor (nomes de campos, formatos de payload,
 * códigos de erro, autenticação) ficam DENTRO do adaptador dele e nunca
 * vazam para o resto do sistema. Trocar de provedor = escrever outro
 * adaptador, sem alterar quem usa o contrato.
 *
 * AS QUATRO OPERAÇÕES (OPERACOES_DO_CONTRATO)
 *
 *   enviarMensagem(pedidoDeEnvio)            → Promise<ResultadoEnvio>
 *   normalizarMensagemRecebida(entrada)      → mensagem interna normalizada
 *   identificarContato(mensagemNormalizada)  → identificador do contato
 *   identificarLoja(mensagemNormalizada)     → lojaId da mensagem
 *
 * As três últimas JÁ EXISTEM em `whatsapp.service.js` (Etapa 10A) e o
 * adaptador apenas as reutiliza: nada foi duplicado. Só o que é novo está
 * aqui: o pedido de envio com configuracaoId opcional, o formato do
 * resultado do envio e a verificação de que uma implementação cumpre o
 * contrato.
 *
 * REGRAS QUE TODA IMPLEMENTAÇÃO DO CONTRATO DEVE RESPEITAR
 *
 *   1. Validar as entradas obrigatórias (lojaId, contato, texto) e rejeitar
 *      o inválido com `ErroMensagemWhatsappInvalida`, sem inventar dados.
 *   2. NUNCA decidir a loja a partir de `loja_id`, `lojaId`,
 *      `configuracaoId` ou `provedor` vindos de um payload externo. A loja
 *      é resolvida pela aplicação (configuração ativa cadastrada, ver
 *      `whatsappWebhook.service.js`) e entregue ao adaptador como dado
 *      confiável e explícito.
 *   3. O `contato` identifica a PESSOA (remetente/destinatário no WhatsApp),
 *      jamais a loja.
 *   4. Não expor nem registrar em log credenciais, texto de mensagem ou
 *      telefone de contato; mensagens de erro fixas, sem ecoar valores.
 *   5. Devolver o resultado do envio SEMPRE pelo formato abaixo (criado com
 *      `criarResultadoEnvio`/`criarResultadoFalha`), traduzindo qualquer
 *      erro específico do provedor para os códigos genéricos do contrato.
 *
 * CREDENCIAIS (abstração — nada disto existe ainda)
 *
 *   Objetos de domínio (pedido de envio, resultado, mensagem normalizada)
 *   NUNCA carregam segredo/token. Quando um provedor real for escolhido, as
 *   credenciais dele serão fornecidas ao ADAPTADOR na sua construção, vindas
 *   de fonte segura em etapa própria (por exemplo, o ambiente do servidor) —
 *   nunca pelo pedido de envio, pelo payload externo, nem pela tabela
 *   `whatsapp_configuracoes`. `criarPedidoDeEnvio` rejeita qualquer campo
 *   com cara de credencial.
 */

const CANAL = 'whatsapp';

const OPERACOES_DO_CONTRATO = Object.freeze([
  'enviarMensagem',
  'normalizarMensagemRecebida',
  'identificarContato',
  'identificarLoja',
]);

/**
 * Status do resultado de um envio.
 *   enviado  — o provedor aceitou a mensagem para entrega (só um adaptador REAL);
 *   simulado — NADA foi enviado: resultado de um adaptador estrutural/de teste;
 *   falhou   — a tentativa falhou (ver `erro.codigo`).
 */
const STATUS_ENVIO = Object.freeze({
  enviado: 'enviado',
  simulado: 'simulado',
  falhou: 'falhou',
});

/** Códigos de erro GENÉRICOS: o resto do sistema não conhece erros de provedor. */
const CODIGOS_ERRO_ENVIO = Object.freeze({
  provedorIndisponivel: 'provedor_indisponivel',
  mensagemRejeitada: 'mensagem_rejeitada',
  erroInterno: 'erro_interno',
});

// Mensagens FIXAS por código: nunca repassam texto vindo do provedor (que
// poderia conter dados sensíveis).
const MENSAGENS_ERRO_ENVIO = Object.freeze({
  [CODIGOS_ERRO_ENVIO.provedorIndisponivel]: 'O provedor de WhatsApp está indisponível no momento.',
  [CODIGOS_ERRO_ENVIO.mensagemRejeitada]: 'A mensagem foi rejeitada pelo provedor de WhatsApp.',
  [CODIGOS_ERRO_ENVIO.erroInterno]: 'Não foi possível enviar a mensagem.',
});

// Campos aceitos no pedido de envio. `canal` só existe para que um pedido já
// montado possa ser validado de novo sem erro.
const CAMPOS_DO_PEDIDO_DE_ENVIO = Object.freeze(['canal', 'lojaId', 'contato', 'texto', 'configuracaoId']);

// Nomes de campo que indicam credencial/segredo (só para dar uma mensagem
// específica; qualquer campo fora da lista acima já é rejeitado).
const REGEX_CAMPO_SEGREDO = /token|secret|segredo|senha|passw|api[_-]?key|apikey|credencia|credential|authorization|bearer|chave/i;

/** A implementação recebida não cumpre o contrato (erro de programação). */
class ErroProvedorWhatsappInvalido extends Error {
  constructor(mensagem) {
    super(mensagem || 'Implementação de provedor de WhatsApp inválida.');
    this.name = 'ErroProvedorWhatsappInvalido';
  }
}

/** Nome de provedor sem adaptador disponível. Mensagem fixa: não ecoa o nome recebido. */
class ErroProvedorWhatsappNaoSuportado extends Error {
  constructor() {
    super('Provedor de WhatsApp não suportado.');
    this.name = 'ErroProvedorWhatsappNaoSuportado';
  }
}

function lerCampoProprio(objeto, campo) {
  return Object.prototype.hasOwnProperty.call(objeto, campo) ? objeto[campo] : undefined;
}

/**
 * Cria (e valida) o PEDIDO DE ENVIO interno.
 *
 *   { canal: 'whatsapp', lojaId, contato, texto, configuracaoId }
 *
 * - `lojaId`, `contato` e `texto` seguem as MESMAS regras de
 *   `prepararEnvioMensagem` (10A): UUID válido, contato e texto não vazios,
 *   texto até LIMITE_TEXTO_MENSAGEM.
 * - `configuracaoId` é opcional (UUID da configuração de WhatsApp da loja,
 *   fornecido pela aplicação; `null` quando não informado). NUNCA deve vir
 *   de um payload externo.
 * - Não há campo de credencial: qualquer campo fora dos permitidos é
 *   rejeitado, com mensagem específica para nomes que parecem segredo.
 *   Mensagens de erro não repetem nenhum valor recebido.
 *
 * @returns {Readonly<{canal: 'whatsapp', lojaId: string, contato: string, texto: string, configuracaoId: string|null}>}
 * @throws {ErroMensagemWhatsappInvalida}
 */
function criarPedidoDeEnvio(entrada) {
  if (entrada === null || typeof entrada !== 'object' || Array.isArray(entrada)) {
    throw new ErroMensagemWhatsappInvalida('pedido de envio inválido: deve ser um objeto.');
  }

  const chaves = Object.keys(entrada);
  if (chaves.some((c) => !CAMPOS_DO_PEDIDO_DE_ENVIO.includes(c) && REGEX_CAMPO_SEGREDO.test(c))) {
    throw new ErroMensagemWhatsappInvalida('pedido de envio inválido: credenciais e segredos não fazem parte dele.');
  }
  if (chaves.some((c) => !CAMPOS_DO_PEDIDO_DE_ENVIO.includes(c))) {
    throw new ErroMensagemWhatsappInvalida('pedido de envio inválido: contém campos não permitidos.');
  }

  const canal = lerCampoProprio(entrada, 'canal');
  if (canal !== undefined && canal !== CANAL) {
    throw new ErroMensagemWhatsappInvalida('pedido de envio inválido: canal não suportado.');
  }

  // Reaproveita a validação da 10A (não duplica regras).
  const base = prepararEnvioMensagem({
    lojaId: lerCampoProprio(entrada, 'lojaId'),
    contato: lerCampoProprio(entrada, 'contato'),
    texto: lerCampoProprio(entrada, 'texto'),
  });

  const configuracaoId = lerCampoProprio(entrada, 'configuracaoId');
  if (configuracaoId !== undefined && configuracaoId !== null && !ehUuid(configuracaoId)) {
    throw new ErroMensagemWhatsappInvalida('configuracaoId inválido: quando informado, deve ser um UUID.');
  }

  return Object.freeze({
    canal: CANAL,
    lojaId: base.lojaId,
    contato: base.contato,
    texto: base.texto,
    configuracaoId: configuracaoId ?? null,
  });
}

/**
 * Cria (e valida) o RESULTADO DE ENVIO interno — o único formato que o
 * resto do sistema conhece, qualquer que seja o provedor:
 *
 *   {
 *     canal: 'whatsapp',
 *     sucesso: boolean,            // false só quando status === 'falhou'
 *     status: 'enviado' | 'simulado' | 'falhou',
 *     simulado: boolean,           // true = NADA foi enviado
 *     idExterno: string | null,    // id da mensagem no provedor (null se não houver)
 *     provedor: string,            // nome do adaptador
 *     erro: null | { codigo, mensagem }   // só quando falhou; texto fixo e genérico
 *   }
 *
 * Para saber se uma mensagem foi entregue ao provedor de verdade, use
 * `mensagemFoiEnviada` — `sucesso: true` sozinho NÃO basta (um resultado
 * simulado também tem sucesso: true).
 *
 * Regras: `simulado` nunca tem `idExterno` (não se inventa identificador);
 * `falhou` exige um código conhecido e nunca tem `idExterno`.
 */
function criarResultadoEnvio({ provedor, status, idExterno = null, codigoErro = null } = {}) {
  if (!ehStringNaoVazia(provedor)) {
    throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: provedor obrigatório.');
  }
  if (!Object.values(STATUS_ENVIO).includes(status)) {
    throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: status desconhecido.');
  }
  if (idExterno !== null && !ehStringNaoVazia(idExterno)) {
    throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: idExterno deve ser texto ou null.');
  }
  if (status !== STATUS_ENVIO.enviado && idExterno !== null) {
    throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: só um envio real pode ter idExterno.');
  }

  let erro = null;
  if (status === STATUS_ENVIO.falhou) {
    if (!Object.values(CODIGOS_ERRO_ENVIO).includes(codigoErro)) {
      throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: falha exige um código de erro conhecido.');
    }
    erro = Object.freeze({ codigo: codigoErro, mensagem: MENSAGENS_ERRO_ENVIO[codigoErro] });
  } else if (codigoErro !== null) {
    throw new ErroProvedorWhatsappInvalido('resultado de envio inválido: código de erro só existe em falhas.');
  }

  return Object.freeze({
    canal: CANAL,
    sucesso: status !== STATUS_ENVIO.falhou,
    status,
    simulado: status === STATUS_ENVIO.simulado,
    idExterno: idExterno === null ? null : idExterno.trim(),
    provedor: provedor.trim(),
    erro,
  });
}

/** Atalho para um resultado de falha com código genérico (mensagem fixa). */
function criarResultadoFalha({ provedor, codigoErro }) {
  return criarResultadoEnvio({ provedor, status: STATUS_ENVIO.falhou, codigoErro });
}

/**
 * true SOMENTE se o resultado indica um envio REAL aceito pelo provedor.
 * Resultado simulado, falho ou qualquer coisa fora do formato → false.
 */
function mensagemFoiEnviada(resultado) {
  return (
    resultado !== null &&
    typeof resultado === 'object' &&
    resultado.sucesso === true &&
    resultado.status === STATUS_ENVIO.enviado &&
    resultado.simulado === false
  );
}

/**
 * Confere que uma implementação cumpre o contrato: tem `nome` e as quatro
 * operações como funções. Devolve a própria implementação.
 *
 * @throws {ErroProvedorWhatsappInvalido}
 */
function verificarImplementacaoDoContrato(implementacao) {
  if (implementacao === null || typeof implementacao !== 'object') {
    throw new ErroProvedorWhatsappInvalido('implementação do contrato inválida: deve ser um objeto.');
  }
  if (!ehStringNaoVazia(implementacao.nome)) {
    throw new ErroProvedorWhatsappInvalido('implementação do contrato inválida: falta o "nome" do provedor.');
  }
  const faltando = OPERACOES_DO_CONTRATO.filter((operacao) => typeof implementacao[operacao] !== 'function');
  if (faltando.length > 0) {
    throw new ErroProvedorWhatsappInvalido(`implementação do contrato incompleta: faltam ${faltando.join(', ')}.`);
  }
  return implementacao;
}

module.exports = {
  CANAL,
  OPERACOES_DO_CONTRATO,
  STATUS_ENVIO,
  CODIGOS_ERRO_ENVIO,
  CAMPOS_DO_PEDIDO_DE_ENVIO,
  ErroProvedorWhatsappInvalido,
  ErroProvedorWhatsappNaoSuportado,
  criarPedidoDeEnvio,
  criarResultadoEnvio,
  criarResultadoFalha,
  mensagemFoiEnviada,
  verificarImplementacaoDoContrato,
};

const {
  normalizarMensagemRecebida,
  identificarContato,
  identificarLoja,
  ErroMensagemWhatsappInvalida,
} = require('../../whatsapp.service');
const { criarPedidoDeEnvio, criarResultadoEnvio, criarResultadoFalha, STATUS_ENVIO, CODIGOS_ERRO_ENVIO } = require('./contrato');
const { ErroClienteHttpMeta, montarRequisicaoEnvioTexto, executarRequisicao } = require('./clienteHttpMeta');
const { ehStringNaoVazia } = require('../../../utils/validacao');

/**
 * ADAPTADOR REAL — Meta WhatsApp Cloud API (Etapa 10G)
 *
 * ==========================================================================
 * Na 10K, o serviço whatsappEnvio obtém este adapter pela factory existente,
 * com phoneNumberId da configuração ativa da mesma loja do inbound.
 * Credenciais permanecem neste adapter, somente no backend.
 *
 * O QUE ESTE ADAPTADOR FAZ
 *   enviarMensagem(pedidoDeEnvio):
 *     1. Valida o pedido com as MESMAS regras do contrato (`criarPedidoDeEnvio`).
 *     2. Monta a requisição HTTP (`clienteHttpMeta.montarRequisicaoEnvioTexto`).
 *     3. Executa a requisição com timeout (`clienteHttpMeta.executarRequisicao`).
 *     4. Traduz o resultado (sucesso, erro HTTP, timeout, rede, JSON
 *        inválido, resposta sem ID) para o formato genérico do contrato —
 *        nada específico da Meta (código, mensagem, payload) vaza para fora
 *        deste arquivo.
 *
 * O QUE ESTE ADAPTADOR **NÃO** FAZ NESTA ETAPA (fora de escopo — ver 10G)
 *   - Não implementa o fluxo "mensagem recebida → IA → resposta".
 *   - Não faz parsing do formato bruto do webhook de eventos da Meta
 *     (entry[].changes[].value.messages[]...). `normalizarMensagemRecebida`
 *     abaixo tem a MESMA forma genérica já usada pelo adaptador simulado
 *     (delega para `whatsapp.service`, Etapa 10A): recebe os cinco campos
 *     já extraídos por quem chama, e não sabe nada do JSON cru da Meta.
 *     Ensinar este adaptador a entender o webhook real da Meta é trabalho
 *     de uma etapa futura, quando o fluxo completo for conectado.
 *   - Não decide sozinho qual configuração/loja usar: `lojaId` chega
 *     sempre explícito e confiável, como em todo o contrato.
 *
 * CREDENCIAIS (ver também `docs/ARQUITETURA.md` e `.env.example`)
 *
 *   `accessToken` e `apiVersion`: podem vir de variável de ambiente
 *   (`META_WHATSAPP_ACCESS_TOKEN`, `META_WHATSAPP_API_VERSION`), pois nesta
 *   etapa o projeto ainda não tem armazenamento de credencial por loja
 *   (Etapa 10G, item 6 — isso fica para uma etapa futura de
 *   credenciais/onboarding).
 *
 *   `phoneNumberId` é DIFERENTE: cada loja teria, num cenário real, o seu
 *   próprio número de WhatsApp Business na Meta. Por isso ele
 *   PROPOSITALMENTE NÃO tem variável de ambiente global — colocá-lo como
 *   variável global faria toda mensagem de toda loja sair pelo mesmo
 *   número, o que não faz sentido multi-tenant. Em vez disso, este fábrica
 *   aceita `phoneNumberId` (e, se necessário no futuro, um
 *   `resolverCredenciais(pedidoDeEnvio)` que use `pedido.configuracaoId`
 *   para buscar a credencial certa) como parâmetro explícito — a
 *   "abstração preparada" pedida na Etapa 10G, item 13. Mesmo com a
 *   resolução por loja da 10K, criar o adaptador sem `phoneNumberId`
 *   é válido: ele só falha (de forma segura, sem lançar) quando alguém
 *   tentar de fato enviar uma mensagem.
 */

const NOME_DO_ADAPTADOR = 'meta';

// Versão da Graph API usada quando META_WHATSAPP_API_VERSION não está
// definida. Documentar aqui a versão adotada e a data em que a
// documentação oficial foi consultada (ver docs/ARQUITETURA.md para o
// registro completo): v26.0, versão estável mais recente da Graph API no
// momento da consulta a developers.facebook.com (Graph API Changelog).
const VERSAO_GRAPH_API_PADRAO = 'v26.0';

const TIMEOUT_PADRAO_MS = 15_000;

function lerCampoProprio(objeto, campo) {
  return Object.prototype.hasOwnProperty.call(objeto, campo) ? objeto[campo] : undefined;
}

/**
 * Lê `accessToken`/`apiVersion`/`timeoutMs` das variáveis de ambiente do
 * servidor. Nunca lê `phoneNumberId` daqui (ver CREDENCIAIS acima).
 * Não lança: valores ausentes viram `undefined`/o padrão, e é
 * responsabilidade de `enviarMensagem` tratar configuração incompleta como
 * falha segura (nunca lançar um erro que exponha detalhes do ambiente).
 */
function lerConfiguracaoDoAmbiente() {
  const timeoutConfigurado = Number(process.env.META_WHATSAPP_TIMEOUT_MS);
  return {
    accessToken: process.env.META_WHATSAPP_ACCESS_TOKEN,
    apiVersion: ehStringNaoVazia(process.env.META_WHATSAPP_API_VERSION)
      ? process.env.META_WHATSAPP_API_VERSION
      : VERSAO_GRAPH_API_PADRAO,
    timeoutMs: Number.isFinite(timeoutConfigurado) && timeoutConfigurado > 0 ? timeoutConfigurado : TIMEOUT_PADRAO_MS,
  };
}

/**
 * Mapeia uma resposta HTTP de ERRO (`ok: false`) da Meta para um código de
 * erro GENÉRICO do contrato. Nunca repassamos o `error.message`/`code`
 * originais da Meta para fora deste arquivo (podem conter detalhes do
 * provedor); só usamos o `status` HTTP, que é informação neutra.
 *
 *   5xx ou 429 (limite de taxa)         → provedorIndisponivel
 *   demais 4xx (ex.: número/token/etc.) → mensagemRejeitada
 */
function mapearStatusParaCodigoErro(status) {
  if (status === 429 || status >= 500) return CODIGOS_ERRO_ENVIO.provedorIndisponivel;
  return CODIGOS_ERRO_ENVIO.mensagemRejeitada;
}

/**
 * Extrai o `idExterno` (id da mensagem no formato `wamid...`) de uma
 * resposta de SUCESSO da Meta. Devolve `null` se o formato não tiver o
 * campo esperado — nunca inventa um identificador.
 */
function extrairIdExterno(dados) {
  const idBruto = dados && Array.isArray(dados.messages) && dados.messages[0] ? dados.messages[0].id : undefined;
  return ehStringNaoVazia(idBruto) ? idBruto : null;
}

/**
 * Cria o adaptador da Meta Cloud API.
 *
 * @param {object} [config]
 * @param {string} [config.accessToken] - token de acesso. Padrão:
 *   `META_WHATSAPP_ACCESS_TOKEN` do ambiente.
 * @param {string} [config.phoneNumberId] - ID do número de WhatsApp
 *   Business na Meta. SEM padrão de ambiente de propósito (ver
 *   CREDENCIAIS acima) — passar explicitamente, ou o envio falhará de
 *   forma segura.
 * @param {string} [config.apiVersion] - versão da Graph API. Padrão:
 *   `META_WHATSAPP_API_VERSION` do ambiente, ou `VERSAO_GRAPH_API_PADRAO`.
 * @param {number} [config.timeoutMs] - timeout da chamada HTTP. Padrão:
 *   `META_WHATSAPP_TIMEOUT_MS` do ambiente, ou `TIMEOUT_PADRAO_MS`.
 * @param {typeof fetch} [config.fetchFn] - implementação de `fetch` a
 *   usar. Testes injetam aqui uma função fake (nunca fazem chamada real).
 */
function criarAdaptadorMeta(config = {}) {
  const configuracaoAmbiente = lerConfiguracaoDoAmbiente();

  const accessToken = ehStringNaoVazia(config.accessToken) ? config.accessToken : configuracaoAmbiente.accessToken;
  const phoneNumberId = ehStringNaoVazia(config.phoneNumberId) ? config.phoneNumberId : undefined; // sem fallback de ambiente, de propósito
  const apiVersion = ehStringNaoVazia(config.apiVersion) ? config.apiVersion : configuracaoAmbiente.apiVersion;
  const timeoutMs = Number.isFinite(config.timeoutMs) && config.timeoutMs > 0 ? config.timeoutMs : configuracaoAmbiente.timeoutMs;
  const fetchFn = typeof config.fetchFn === 'function' ? config.fetchFn : undefined;

  return Object.freeze({
    nome: NOME_DO_ADAPTADOR,

    async enviarMensagem(pedidoDeEnvioBruto) {
      // 1) Valida o pedido com as MESMAS regras do contrato. Entrada
      //    inválida (lojaId/contato/texto ausentes ou malformados) É um
      //    erro de programação de quem chamou, então lança — igual ao
      //    adaptador simulado — em vez de virar um "resultado de falha".
      const pedido = criarPedidoDeEnvio(pedidoDeEnvioBruto);

      // 2) Configuração incompleta (credencial ausente) NÃO é culpa de
      //    quem chamou `enviarMensagem` — é a integração que ainda não
      //    está pronta. Por isso falha de forma segura (resultado
      //    genérico), sem lançar e sem detalhar o que falta.
      if (!ehStringNaoVazia(accessToken) || !ehStringNaoVazia(phoneNumberId)) {
        console.error(
          `[providers/whatsapp/adaptadorMeta] configuração incompleta: faltam ${
            !ehStringNaoVazia(accessToken) ? 'accessToken' : ''
          }${!ehStringNaoVazia(accessToken) && !ehStringNaoVazia(phoneNumberId) ? ' e ' : ''}${
            !ehStringNaoVazia(phoneNumberId) ? 'phoneNumberId' : ''
          }.`
        );
        return criarResultadoFalha({ provedor: NOME_DO_ADAPTADOR, codigoErro: CODIGOS_ERRO_ENVIO.erroInterno });
      }

      // 3) Monta a requisição (nenhuma chamada de rede ainda acontece aqui).
      const requisicao = montarRequisicaoEnvioTexto({
        apiVersion,
        phoneNumberId,
        accessToken,
        para: pedido.contato,
        texto: pedido.texto,
      });

      // 4) Executa, com timeout, mapeando qualquer falha para o contrato.
      let resultadoHttp;
      try {
        resultadoHttp = await executarRequisicao(requisicao, { timeoutMs, fetchFn });
      } catch (erro) {
        if (erro instanceof ErroClienteHttpMeta) {
          const codigoErro =
            erro.codigo === 'timeout' || erro.codigo === 'rede'
              ? CODIGOS_ERRO_ENVIO.provedorIndisponivel
              : CODIGOS_ERRO_ENVIO.erroInterno; // 'resposta_invalida'
          console.error(
            `[providers/whatsapp/adaptadorMeta] falha ao chamar a Meta Cloud API (${erro.codigo}):`,
            'Falha de comunicação.'
          );
          return criarResultadoFalha({ provedor: NOME_DO_ADAPTADOR, codigoErro });
        }
        // Erro inesperado (bug de programação): não escondemos, mas também
        // não deixamos vazar como se fosse um resultado normal do contrato.
        throw erro;
      }

      // 5) Resposta HTTP de erro (4xx/5xx): nunca repassamos o corpo da
      //    Meta (pode conter detalhes do provedor) — só o status, já
      //    mapeado para um código genérico, é usado.
      if (!resultadoHttp.ok) {
        console.error(
          '[providers/whatsapp/adaptadorMeta] Meta Cloud API retornou erro HTTP',
          resultadoHttp.status
        );
        return criarResultadoFalha({
          provedor: NOME_DO_ADAPTADOR,
          codigoErro: mapearStatusParaCodigoErro(resultadoHttp.status),
        });
      }

      // 6) Sucesso HTTP, mas sem o campo de ID esperado: tratamos como
      //    falha segura em vez de devolver um "sucesso" sem identificador.
      const idExterno = extrairIdExterno(resultadoHttp.dados);
      if (idExterno === null) {
        console.error(
          '[providers/whatsapp/adaptadorMeta] resposta de sucesso da Meta Cloud API sem "messages[0].id" reconhecível.'
        );
        return criarResultadoFalha({ provedor: NOME_DO_ADAPTADOR, codigoErro: CODIGOS_ERRO_ENVIO.erroInterno });
      }

      // 7) Envio real aceito pelo provedor.
      return criarResultadoEnvio({ provedor: NOME_DO_ADAPTADOR, status: STATUS_ENVIO.enviado, idExterno });
    },

    // As três operações abaixo são genéricas (Etapa 10A) — este adaptador
    // ainda não entende o formato bruto do webhook da Meta (ver ESCOPO
    // acima). São IDÊNTICAS às do adaptador simulado de propósito: nenhuma
    // duplicação de regra, só o mesmo delegado.
    normalizarMensagemRecebida(entrada) {
      if (entrada === null || typeof entrada !== 'object' || Array.isArray(entrada)) {
        throw new ErroMensagemWhatsappInvalida('mensagem recebida inválida: deve ser um objeto.');
      }
      const mensagem = normalizarMensagemRecebida({
        lojaId: lerCampoProprio(entrada, 'lojaId'),
        contato: lerCampoProprio(entrada, 'contato'),
        texto: lerCampoProprio(entrada, 'texto'),
        idExterno: lerCampoProprio(entrada, 'idExterno'),
        timestamp: lerCampoProprio(entrada, 'timestamp'),
      });
      return Object.freeze({ ...mensagem });
    },

    identificarContato(mensagemNormalizada) {
      return identificarContato(mensagemNormalizada);
    },

    identificarLoja(mensagemNormalizada) {
      return identificarLoja(mensagemNormalizada);
    },
  });
}

module.exports = {
  criarAdaptadorMeta,
  NOME_DO_ADAPTADOR,
  VERSAO_GRAPH_API_PADRAO,
  TIMEOUT_PADRAO_MS,
  // Exportadas apenas para teste unitário direto (mapeamento de status/ID).
  mapearStatusParaCodigoErro,
  extrairIdExterno,
};

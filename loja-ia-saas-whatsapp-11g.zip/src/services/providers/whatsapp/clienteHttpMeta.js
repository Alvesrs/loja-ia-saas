/**
 * CLIENTE HTTP ISOLADO — Meta WhatsApp Cloud API (Etapa 10G)
 *
 * ==========================================================================
 * Único arquivo do projeto que sabe como é o formato HTTP concreto da Meta
 * Cloud API (endpoint, headers, corpo, formato de erro). Nada fora de
 * `adaptadorMeta.js` deve importar este módulo, e este módulo não conhece
 * o contrato interno de WhatsApp (`./contrato.js`) nem o domínio da
 * aplicação (loja, pedido, resultado de envio) — ele só sabe montar e
 * executar UMA requisição HTTP.
 * ==========================================================================
 *
 * DOCUMENTAÇÃO OFICIAL CONSULTADA (não confiar em memória — ver README/
 * docs/ARQUITETURA.md para a data da consulta):
 *
 *   Meta for Developers → WhatsApp Business Platform → Cloud API →
 *   "Send Messages" / "Text messages" / "Messages API reference".
 *
 *   Endpoint de envio:
 *     POST https://graph.facebook.com/<VERSAO>/<PHONE_NUMBER_ID>/messages
 *     Headers: Content-Type: application/json
 *              Authorization: Bearer <ACCESS_TOKEN>
 *     Corpo (mensagem de texto):
 *       {
 *         "messaging_product": "whatsapp",
 *         "recipient_type": "individual",
 *         "to": "<numero>",
 *         "type": "text",
 *         "text": { "body": "<texto>" }
 *       }
 *     Resposta de sucesso (200):
 *       { "messaging_product": "whatsapp", "contacts": [...], "messages": [{ "id": "wamid...." }] }
 *     Resposta de erro (a Graph API, formato padrão):
 *       { "error": { "message": "...", "type": "...", "code": ..., "error_subcode": ..., "fbtrace_id": "..." } }
 *
 *   Versão da Graph API adotada nesta etapa: a mais recente estável no
 *   momento da consulta à documentação oficial (ver DOCUMENTACAO_VERSAO_PADRAO
 *   abaixo e docs/ARQUITETURA.md). Pode ser sobrescrita por configuração
 *   (variável de ambiente `META_WHATSAPP_API_VERSION`), sem alterar este
 *   arquivo, caso a Meta publique uma versão mais nova.
 *
 * O QUE ESTE ARQUIVO DELIBERADAMENTE NÃO FAZ
 *   - Não decide QUANDO enviar, não valida regra de negócio (isso é do
 *     contrato/adaptador). Só valida o mínimo para montar uma URL/corpo
 *     coerentes.
 *   - Não lê variável de ambiente (quem monta a configuração é o adaptador).
 *   - Não usa nenhuma credencial fixa: tudo vem por parâmetro.
 *   - Nunca loga nada sozinho — devolve dados/erros para quem chamou decidir
 *     o que (e como, de forma segura) logar.
 */

const DOMINIO_GRAPH_API = 'https://graph.facebook.com';

/** Erro de execução HTTP: rede, timeout ou resposta que não é um JSON válido. */
class ErroClienteHttpMeta extends Error {
  /**
   * @param {'timeout'|'rede'|'resposta_invalida'} codigo
   * @param {string} mensagem
   */
  constructor(codigo, mensagem) {
    super(mensagem);
    this.name = 'ErroClienteHttpMeta';
    this.codigo = codigo;
  }
}

/**
 * Remove qualquer ocorrência literal de um segredo de um texto antes de ele
 * ser logado. Defesa em profundidade (mesmo princípio de `llm.service.js`):
 * mesmo que uma lib subjacente inclua a URL/headers da requisição numa
 * mensagem de erro, o token de acesso nunca chega ao log do servidor.
 * Isolado aqui de propósito — este módulo não importa nada de fora de
 * `providers/whatsapp/` para permanecer completamente autocontido.
 */
function redigirSegredo(texto, segredo) {
  if (typeof texto !== 'string' || typeof segredo !== 'string' || segredo.length === 0) return texto;
  return texto.split(segredo).join('[TOKEN_OCULTADO]');
}

/**
 * MONTA (não executa) a requisição de envio de uma mensagem de texto.
 * Função pura: nenhuma chamada de rede acontece aqui. Isso permite testar
 * método, URL, headers e corpo sem depender de internet (ver Etapa 10G,
 * item 8 — testabilidade).
 *
 * @param {object} params
 * @param {string} params.apiVersion - versão da Graph API (ex.: "v26.0").
 * @param {string} params.phoneNumberId - ID do número de WhatsApp Business na Meta.
 * @param {string} params.accessToken - token de acesso (nunca logado por este módulo).
 * @param {string} params.para - número/telefone do destinatário (WhatsApp `to`).
 * @param {string} params.texto - corpo da mensagem de texto.
 * @returns {{method: 'POST', url: string, headers: Record<string,string>, body: string}}
 * @throws {Error} se algum parâmetro obrigatório estiver ausente (erro de
 *   programação do chamador — o adaptador já deve ter validado tudo antes).
 */
function montarRequisicaoEnvioTexto({ apiVersion, phoneNumberId, accessToken, para, texto } = {}) {
  const obrigatorios = { apiVersion, phoneNumberId, accessToken, para, texto };
  const faltando = Object.entries(obrigatorios)
    .filter(([, valor]) => typeof valor !== 'string' || valor.trim().length === 0)
    .map(([nome]) => nome);
  if (faltando.length > 0) {
    throw new Error(`clienteHttpMeta: parâmetro(s) obrigatório(s) ausente(s): ${faltando.join(', ')}.`);
  }

  const url = `${DOMINIO_GRAPH_API}/${apiVersion}/${phoneNumberId}/messages`;

  const corpo = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: para,
    type: 'text',
    text: { body: texto },
  };

  return Object.freeze({
    method: 'POST',
    url,
    headers: Object.freeze({
      'Content-Type': 'application/json',
      // ATENÇÃO: este header carrega o token de acesso. Nunca logar este
      // objeto `headers` (nem `accessToken`) em nenhum console.* — só o
      // status/corpo da RESPOSTA do provedor (que nunca contém nosso
      // próprio token) pode ser logado.
      Authorization: `Bearer ${accessToken}`,
    }),
    body: JSON.stringify(corpo),
  });
}

/**
 * EXECUTA uma requisição já montada, com timeout. Não lança para respostas
 * HTTP de erro (4xx/5xx) — devolve `{ ok: false, status, dados }` para que
 * quem chamou decida como mapear isso para o contrato interno. Só lança
 * (`ErroClienteHttpMeta`) para timeout, falha de rede ou resposta que não é
 * um JSON válido — casos em que não há `status`/`dados` do provedor para
 * interpretar.
 *
 * @param {{method: string, url: string, headers: object, body: string}} requisicao
 * @param {object} [opcoes]
 * @param {number} [opcoes.timeoutMs=15000]
 * @param {typeof fetch} [opcoes.fetchFn] - implementação de `fetch` a usar;
 *   testes injetam aqui uma função fake para nunca depender de rede real.
 * @returns {Promise<{ok: boolean, status: number, dados: any}>}
 * @throws {ErroClienteHttpMeta} codigo 'timeout' | 'rede' | 'resposta_invalida'
 */
async function executarRequisicao(requisicao, { timeoutMs = 15_000, fetchFn } = {}) {
  const executarFetch = typeof fetchFn === 'function' ? fetchFn : fetch;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    let resposta;
    try {
      resposta = await executarFetch(requisicao.url, {
        method: requisicao.method,
        headers: requisicao.headers,
        body: requisicao.body,
        signal: controller.signal,
      });
    } catch (erroRede) {
      if (erroRede && erroRede.name === 'AbortError') {
        throw new ErroClienteHttpMeta('timeout', 'Tempo limite excedido ao comunicar com a Meta Cloud API.');
      }
      throw new ErroClienteHttpMeta(
        'rede',
        `Falha de rede ao comunicar com a Meta Cloud API: ${erroRede && erroRede.message ? erroRede.message : 'erro desconhecido'}.`
      );
    }

    let dados = null;
    try {
      // Corpo pode vir vazio em alguns erros; texto vazio não é JSON válido,
      // então tratamos separadamente para não confundir com "resposta inválida".
      const texto = await resposta.text();
      dados = texto.length > 0 ? JSON.parse(texto) : null;
    } catch (erroParse) {
      throw new ErroClienteHttpMeta(
        'resposta_invalida',
        `A Meta Cloud API retornou uma resposta que não é um JSON válido: ${erroParse.message}.`
      );
    }

    return { ok: resposta.ok, status: resposta.status, dados };
  } finally {
    clearTimeout(timeoutId);
  }
}

module.exports = {
  DOMINIO_GRAPH_API,
  ErroClienteHttpMeta,
  redigirSegredo,
  montarRequisicaoEnvioTexto,
  executarRequisicao,
};

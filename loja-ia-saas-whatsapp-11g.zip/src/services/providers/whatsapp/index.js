const { ehStringNaoVazia } = require('../../../utils/validacao');
const contrato = require('./contrato');
const { criarAdaptadorSimulado, NOME_DO_ADAPTADOR } = require('./adaptadorSimulado');
const { criarAdaptadorMeta, NOME_DO_ADAPTADOR: NOME_DO_ADAPTADOR_META } = require('./adaptadorMeta');

/** Ponto único de seleção do provider. Na 10K, nome e phoneNumberId vêm
 * da configuração validada da loja; credenciais continuam no adapter.
 * Opções também permitem fetch fake nos testes, sem nova implementação HTTP.
 */

const ADAPTADORES = new Map([
  [NOME_DO_ADAPTADOR, criarAdaptadorSimulado],
  [NOME_DO_ADAPTADOR_META, criarAdaptadorMeta],
]);

/**
 * @param {string} nome  nome do provedor (obrigatório; comparado sem diferenciar maiúsculas)
 * @throws {ErroProvedorWhatsappNaoSuportado} nome ausente, inválido ou sem adaptador
 */
function obterProvedorWhatsapp(nome, opcoes = {}) {
  if (!ehStringNaoVazia(nome)) throw new contrato.ErroProvedorWhatsappNaoSuportado();

  const criarAdaptador = ADAPTADORES.get(nome.trim().toLowerCase());
  if (!criarAdaptador) throw new contrato.ErroProvedorWhatsappNaoSuportado();

  return contrato.verificarImplementacaoDoContrato(criarAdaptador(opcoes));
}

/** Nomes dos provedores que têm adaptador. Hoje: 'simulado' e 'meta'. */
function listarProvedoresDisponiveis() {
  return [...ADAPTADORES.keys()];
}

module.exports = { ...contrato, obterProvedorWhatsapp, listarProvedoresDisponiveis };

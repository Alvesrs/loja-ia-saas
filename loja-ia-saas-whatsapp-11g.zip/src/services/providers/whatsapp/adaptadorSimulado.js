const {
  normalizarMensagemRecebida,
  identificarContato,
  identificarLoja,
  ErroMensagemWhatsappInvalida,
} = require('../../whatsapp.service');
const { criarPedidoDeEnvio, criarResultadoEnvio, STATUS_ENVIO } = require('./contrato');

/**
 * ADAPTADOR SIMULADO DE WHATSAPP (Etapa 10F) — ESTRUTURAL E TESTÁVEL
 *
 * ==========================================================================
 * ATENÇÃO: este adaptador NÃO envia nem recebe NADA. Não faz chamada HTTP,
 * não usa fetch/axios/SDK, não acessa a internet nem o banco, não guarda
 * mensagens, não usa credenciais e não escreve em log. Implementa o
 * contrato (./contrato.js) só para provar a arquitetura e servir de
 * referência/molde: um provedor real terá a mesma forma, com a chamada
 * externa dentro de `enviarMensagem` e a tradução do payload do provedor
 * dentro de `normalizarMensagemRecebida`.
 *
 * Seu resultado de envio tem `status: 'simulado'` e `simulado: true`: quem
 * o recebe NUNCA deve entender que uma mensagem foi entregue. Use
 * `mensagemFoiEnviada(resultado)` para saber se houve envio real.
 * ==========================================================================
 *
 * O que cada operação faz aqui:
 *   - enviarMensagem: VALIDA o pedido (mesmas regras do contrato) e devolve
 *       um resultado simulado, sem idExterno (nada foi enviado, então não há
 *       identificador a inventar). Entrada inválida → ErroMensagemWhatsappInvalida.
 *   - normalizarMensagemRecebida: reaproveita a normalização da 10A. O
 *       `lojaId` é um parâmetro EXPLÍCITO e confiável, entregue pela
 *       aplicação; qualquer `loja_id`, `configuracaoId`, `provedor` ou outro
 *       campo extra na entrada é IGNORADO (só os cinco campos esperados são lidos).
 *   - identificarContato / identificarLoja: leitura dos campos já validados
 *       da mensagem normalizada (10A). O contato NUNCA é usado para
 *       identificar a loja.
 */

const NOME_DO_ADAPTADOR = 'simulado';

function lerCampoProprio(objeto, campo) {
  return Object.prototype.hasOwnProperty.call(objeto, campo) ? objeto[campo] : undefined;
}

function criarAdaptadorSimulado() {
  return Object.freeze({
    nome: NOME_DO_ADAPTADOR,

    async enviarMensagem(pedidoDeEnvio) {
      criarPedidoDeEnvio(pedidoDeEnvio); // valida; lança se inválido. Nada mais é feito com o pedido.
      return criarResultadoEnvio({ provedor: NOME_DO_ADAPTADOR, status: STATUS_ENVIO.simulado });
    },

    normalizarMensagemRecebida(entrada) {
      if (entrada === null || typeof entrada !== 'object' || Array.isArray(entrada)) {
        throw new ErroMensagemWhatsappInvalida('mensagem recebida inválida: deve ser um objeto.');
      }
      // Lê SOMENTE os cinco campos esperados (e só os próprios do objeto).
      const mensagem = normalizarMensagemRecebida({
        lojaId: lerCampoProprio(entrada, 'lojaId'),
        contato: lerCampoProprio(entrada, 'contato'),
        texto: lerCampoProprio(entrada, 'texto'),
        idExterno: lerCampoProprio(entrada, 'idExterno'),
        timestamp: lerCampoProprio(entrada, 'timestamp'),
      });
      return Object.freeze({ ...mensagem });
    },

    identificarContato(mensagemNormalizada) {
      return identificarContato(mensagemNormalizada);
    },

    identificarLoja(mensagemNormalizada) {
      return identificarLoja(mensagemNormalizada);
    },
  });
}

module.exports = { criarAdaptadorSimulado, NOME_DO_ADAPTADOR };

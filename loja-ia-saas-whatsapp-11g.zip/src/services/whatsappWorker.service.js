const fila = require('./whatsappFila.service');
const historico = require('./whatsappHistorico.service');
const atendente = require('./whatsappAtendente.service');
const envio = require('./whatsappEnvio.service');
const idempotencia = require('./whatsappIdempotencia.service');
const assinaturas = require('./assinaturas.service');

let timer = null;
let cicloEmAndamento = false;

function mensagemDoJob(job) {
  return Object.freeze({
    canal: 'whatsapp',
    lojaId: job.loja_id,
    configuracaoId: job.configuracao_id,
    contato: job.contato,
    texto: job.texto,
    idExterno: job.id_externo,
    timestamp: job.timestamp_mensagem,
  });
}

function contextoDoJob(job) {
  return Object.freeze({ provedor: job.provedor, destinatarioId: job.destinatario_id });
}

function codigoErro(erro) {
  if (erro instanceof envio.ErroEnvioWhatsapp) return 'envio_whatsapp';
  if (erro instanceof historico.ErroHistoricoWhatsapp) return 'historico_whatsapp';
  if (erro instanceof idempotencia.ErroIdempotenciaBanco) return 'idempotencia_banco';
  if (erro instanceof fila.ErroFilaWhatsapp) return 'fila_banco';
  return 'processamento_whatsapp';
}

async function processarJob(job) {
  const mensagem = mensagemDoJob(job);
  const contexto = contextoDoJob(job);

  try {
    // Estado ENVIADO significa que o efeito externo já aconteceu. Em retry,
    // finalize apenas histórico/idempotência; jamais envie de novo.
    if (job.status !== fila.STATUS.ENVIADO) {
      await historico.registrarMensagemRecebida(mensagem, contexto);

      const situacaoPlano = await assinaturas.obterSituacaoPlano(mensagem.lojaId);
      if (!situacaoPlano.ativo) {
        // Conta suspensa/expirada ou franquia mensal atingida: finaliza o job
        // sem resposta externa e sem retry infinito. O lojista enxerga o motivo
        // no painel de Plano/Admin, sem expor cobrança ao cliente final.
        await idempotencia.concluirEventoWhatsapp({ provedor: job.provedor, idExterno: job.id_externo });
        await fila.concluirJob(job.id);
        return Object.freeze({ ok: true, id: job.id, bloqueado: true, motivo: situacaoPlano.motivoBloqueio });
      }

      const resposta = await atendente.responderMensagemWhatsapp(mensagem);
      await envio.enviarRespostaWhatsapp(mensagem, resposta, contexto);
      await fila.marcarJobEnviado(job.id, resposta.resposta);
      job = { ...job, status: fila.STATUS.ENVIADO, resposta_texto: resposta.resposta };
    }

    const respostaFinal = Object.freeze({
      lojaId: mensagem.lojaId,
      contato: mensagem.contato,
      idExterno: mensagem.idExterno,
      resposta: job.resposta_texto,
    });
    await historico.registrarMensagemEnviada(mensagem, respostaFinal, contexto);
    await idempotencia.concluirEventoWhatsapp({ provedor: job.provedor, idExterno: job.id_externo });
    await fila.concluirJob(job.id);
    return Object.freeze({ ok: true, id: job.id });
  } catch (erro) {
    // Se o envio foi confirmado e o job conseguiu persistir ENVIADO, o retry
    // retomará sem novo envio. Para falhas anteriores, volta ao estado pendente.
    if (job.status === fila.STATUS.ENVIADO) {
      try {
        await fila.reagendarFinalizacaoJob(job, codigoErro(erro));
      } catch (_) {}
      return Object.freeze({ ok: false, id: job.id, codigo: codigoErro(erro) });
    }
    try {
      await fila.reagendarOuFalharJob(job, codigoErro(erro));
    } catch (_) {}
    return Object.freeze({ ok: false, id: job.id, codigo: codigoErro(erro) });
  }
}

async function executarCiclo({ maxJobs = 10 } = {}) {
  if (cicloEmAndamento) return 0;
  cicloEmAndamento = true;
  let processados = 0;
  try {
    for (let i = 0; i < maxJobs; i += 1) {
      const job = await fila.reivindicarProximoJob();
      if (!job) break;
      await processarJob(job);
      processados += 1;
    }
    return processados;
  } finally {
    cicloEmAndamento = false;
  }
}

function obterIntervaloMs() {
  const bruto = Number(process.env.WHATSAPP_WORKER_INTERVALO_MS || 2000);
  return Number.isInteger(bruto) && bruto >= 500 && bruto <= 60000 ? bruto : 2000;
}

function iniciarWorker() {
  if (timer) return timer;
  const intervalo = obterIntervaloMs();
  timer = setInterval(() => {
    executarCiclo().catch((erro) => {
      console.error('[whatsapp worker] ciclo falhou:', { tipo: erro?.name || 'Error', codigo: erro?.code || null });
    });
  }, intervalo);
  if (typeof timer.unref === 'function') timer.unref();
  return timer;
}

function pararWorker() {
  if (timer) clearInterval(timer);
  timer = null;
}

function obterEstadoWorker() {
  return Object.freeze({ iniciado: Boolean(timer), cicloEmAndamento });
}

module.exports = { processarJob, executarCiclo, iniciarWorker, pararWorker, obterIntervaloMs, obterEstadoWorker };

const supabase = require('../config/supabase');
const { ehUuid, ehStringNaoVazia, ehStringOpcionalValida, ehBooleano } = require('../utils/validacao');

/**
 * SERVIÇO DE CONFIGURAÇÃO DE WHATSAPP POR LOJA (Etapa 10B)
 *
 * ==========================================================================
 * ATENÇÃO: este arquivo só lê/grava a tabela `whatsapp_configuracoes`
 * (ver src/db/migrations/003_whatsapp_configuracoes.sql e src/db/schema.sql).
 * Ele NÃO se conecta a nenhum provedor de WhatsApp: não faz chamada HTTP,
 * não tem webhook, não envia nem recebe mensagem, não usa nenhum SDK de
 * provedor. Também NÃO armazena nem devolve segredos (access token, API
 * key, secret, senha, credenciais) — a tabela nem tem coluna para isso.
 * ==========================================================================
 *
 * O QUE A TABELA REPRESENTA
 *
 *   loja → whatsapp_configuracoes
 *
 * Uma configuração diz "esta loja usa este provedor e este número de
 * WhatsApp". É CONFIGURAÇÃO, não conversa: nenhuma mensagem é guardada.
 *
 * SEGURANÇA MULTI-TENANT (regra central deste arquivo)
 *
 * O backend usa a service_role key do Supabase, que IGNORA o RLS (ver
 * src/config/supabase.js). Portanto o RLS não é autorização aqui: a única
 * barreira entre uma loja e a configuração de outra é o filtro por
 * `loja_id` feito neste código. Por isso:
 *
 *   - TODA função de criar/buscar/listar/atualizar/desativar exige `lojaId`
 *     explícito (a única exceção é `buscarConfiguracaoPorIdentificadorExterno`,
 *     ver abaixo), vindo de uma fonte CONFIÁVEL da aplicação (ex.: `req.params.lojaId` já validado pelo middleware
 *     `exigirDonoDaLoja`, ou uma loja resolvida pelo próprio backend). Nunca
 *     um `loja_id` que o cliente final (ou um payload externo) informou.
 *   - Nenhuma função aceita `loja_id` dentro de `dados`: qualquer campo
 *     fora da lista permitida é rejeitado. Assim é impossível "mover" uma
 *     configuração para outra loja por atualização.
 *   - Buscar/atualizar/desativar filtram SEMPRE por `id` E `loja_id` na
 *     mesma consulta (sem "buscar por id e conferir depois"), então não há
 *     janela entre checar e agir. Config de outra loja é indistinguível de
 *     config inexistente: o resultado é `ErroConfiguracaoNaoEncontrada`.
 *   - EXCEÇÃO CONTROLADA — `buscarConfiguracaoPorIdentificadorExterno`
 *     (Etapa 10C): serve justamente para DESCOBRIR a loja a partir do
 *     identificador externo do número destinatário de um evento de
 *     WhatsApp, então não recebe `lojaId`. Ela só devolve configurações
 *     ativas, só as colunas mínimas, e nunca decide a loja com base em
 *     dado do payload: o `loja_id` sai da linha cadastrada no banco.
 *   - Este service NÃO verifica se o usuário logado é dono da loja: isso
 *     continua sendo papel do middleware/autorização que decide o `lojaId`
 *     confiável antes de chamar este service.
 */

const TABELA = 'whatsapp_configuracoes';

// Única lista de colunas que este service lê e devolve. Nunca `select('*')`:
// se um dia alguém adicionar uma coluna sensível por engano, ela não vaza.
const COLUNAS_PUBLICAS = [
  'id',
  'loja_id',
  'provedor',
  'numero_whatsapp',
  'identificador_externo',
  'ativo',
  'created_at',
  'updated_at',
];
const COLUNAS_SELECT = COLUNAS_PUBLICAS.join(', ');

// Colunas devolvidas pela RESOLUÇÃO de configuração (webhook, Etapa 10C):
// só o necessário para identificar a loja e a configuração. Menos do que
// COLUNAS_PUBLICAS de propósito (não leva número nem timestamps).
const COLUNAS_RESOLUCAO = ['id', 'loja_id', 'provedor', 'identificador_externo', 'ativo'];
const COLUNAS_RESOLUCAO_SELECT = COLUNAS_RESOLUCAO.join(', ');

// Únicos campos que o chamador pode informar em criar/atualizar.
const CAMPOS_PERMITIDOS = ['provedor', 'numero_whatsapp', 'identificador_externo', 'ativo'];

// Limites generosos, só para consistência e para evitar abuso de tamanho
// (têm equivalente nos CHECKs da tabela). Não são regra de formato.
const LIMITE_PROVEDOR = 50;
const LIMITE_NUMERO = 64;
const LIMITE_IDENTIFICADOR = 255;

// Nomes de campo que indicam credencial/segredo. Só servem para dar uma
// mensagem específica; qualquer campo fora de CAMPOS_PERMITIDOS já é
// rejeitado de qualquer forma.
const REGEX_CAMPO_SEGREDO = /token|secret|segredo|senha|passw|api[_-]?key|apikey|credencia|credential|authorization|bearer|chave/i;

class ErroConfiguracaoInvalida extends Error {
  constructor(mensagem) {
    super(mensagem || 'Dados inválidos para a configuração de WhatsApp.');
    this.name = 'ErroConfiguracaoInvalida';
  }
}

/** Não existe OU pertence a outra loja — de propósito, indistinguíveis. */
class ErroConfiguracaoNaoEncontrada extends Error {
  constructor() {
    super('Configuração de WhatsApp não encontrada.');
    this.name = 'ErroConfiguracaoNaoEncontrada';
  }
}

class ErroLojaNaoEncontrada extends Error {
  constructor() {
    super('Loja não encontrada.');
    this.name = 'ErroLojaNaoEncontrada';
  }
}

/**
 * Mensagem propositalmente genérica: não revela se o conflito é com outra
 * configuração da mesma loja ou de outra loja, nem qual.
 */
class ErroConfiguracaoDuplicada extends Error {
  constructor() {
    super('Já existe uma configuração ativa de WhatsApp com esse provedor e número (ou identificador).');
    this.name = 'ErroConfiguracaoDuplicada';
  }
}

/**
 * Mais de uma configuração ativa bate com o identificador informado (só
 * pode acontecer quando o provedor NÃO foi informado, já que a unicidade é
 * por provedor + identificador). Na dúvida, nunca escolhe uma loja.
 */
class ErroConfiguracaoAmbigua extends Error {
  constructor() {
    super('Mais de uma configuração de WhatsApp corresponde ao identificador informado.');
    this.name = 'ErroConfiguracaoAmbigua';
  }
}

/** Falha inesperada do banco. Nunca carrega detalhe interno na mensagem. */
class ErroConfiguracaoBanco extends Error {
  constructor() {
    super('Não foi possível completar a operação de configuração de WhatsApp.');
    this.name = 'ErroConfiguracaoBanco';
  }
}

// ---------------------------------------------------------------
// Validação (pura, sem I/O). Roda ANTES de qualquer consulta ao banco.
// ---------------------------------------------------------------

function validarLojaId(lojaId) {
  if (!ehUuid(lojaId)) {
    throw new ErroConfiguracaoInvalida('Identificador de loja inválido.');
  }
}

function validarConfiguracaoId(configuracaoId) {
  if (!ehUuid(configuracaoId)) {
    throw new ErroConfiguracaoInvalida('Identificador de configuração inválido.');
  }
}

function textoObrigatorio(valor, nomeCampo, limite) {
  if (!ehStringNaoVazia(valor)) {
    throw new ErroConfiguracaoInvalida(`"${nomeCampo}" é obrigatório e deve ser um texto não vazio.`);
  }
  const texto = valor.trim();
  if (texto.length > limite) {
    throw new ErroConfiguracaoInvalida(`"${nomeCampo}" excede o tamanho máximo de ${limite} caracteres.`);
  }
  return texto;
}

// null é um valor válido (significa "sem identificador"; em atualizar,
// serve para limpar). Texto vazio NÃO é aceito: para limpar, envie null.
function identificadorOpcional(valor) {
  if (!ehStringOpcionalValida(valor)) {
    throw new ErroConfiguracaoInvalida('"identificador_externo", quando informado, deve ser um texto.');
  }
  if (valor === undefined || valor === null) return null;
  const texto = valor.trim();
  if (texto.length === 0) {
    throw new ErroConfiguracaoInvalida('"identificador_externo" não pode ser vazio (use null para não informar).');
  }
  if (texto.length > LIMITE_IDENTIFICADOR) {
    throw new ErroConfiguracaoInvalida(`"identificador_externo" excede o tamanho máximo de ${LIMITE_IDENTIFICADOR} caracteres.`);
  }
  return texto;
}

function ativoBooleano(valor) {
  if (!ehBooleano(valor)) {
    throw new ErroConfiguracaoInvalida('"ativo" deve ser verdadeiro ou falso.');
  }
  return valor;
}

/**
 * Valida `dados` e devolve SOMENTE os campos permitidos, já normalizados
 * (provedor e número sem espaços nas pontas; provedor em minúsculas).
 * Nenhuma regra de formato de telefone é aplicada — só o necessário para
 * segurança e consistência.
 *
 * @param {object} dados
 * @param {'criar'|'atualizar'} modo
 */
function validarCampos(dados, modo) {
  if (dados === null || typeof dados !== 'object' || Array.isArray(dados)) {
    throw new ErroConfiguracaoInvalida('Dados da configuração devem ser um objeto.');
  }

  const chaves = Object.keys(dados);

  // Segredos primeiro, para dar a mensagem mais clara. Nada é lido nem
  // repassado a lugar nenhum antes de rejeitar.
  if (chaves.some((chave) => !CAMPOS_PERMITIDOS.includes(chave) && REGEX_CAMPO_SEGREDO.test(chave))) {
    throw new ErroConfiguracaoInvalida(
      'Credenciais e segredos de provedor não são aceitos nesta configuração.'
    );
  }
  // Qualquer outro campo estranho (inclusive `loja_id`, `id`, timestamps).
  if (chaves.some((chave) => !CAMPOS_PERMITIDOS.includes(chave))) {
    throw new ErroConfiguracaoInvalida('A configuração contém campos não permitidos.');
  }

  // Campo "informado" = presente E diferente de undefined. Assim
  // `{ identificador_externo: undefined }` não limpa nada sem querer; só
  // `null` limpa (ver identificadorOpcional).
  const informado = (campo) =>
    Object.prototype.hasOwnProperty.call(dados, campo) && dados[campo] !== undefined;

  const campos = {};

  if (modo === 'criar') {
    campos.provedor = textoObrigatorio(dados.provedor, 'provedor', LIMITE_PROVEDOR).toLowerCase();
    campos.numero_whatsapp = textoObrigatorio(dados.numero_whatsapp, 'numero_whatsapp', LIMITE_NUMERO);
    if (informado('identificador_externo')) {
      campos.identificador_externo = identificadorOpcional(dados.identificador_externo);
    }
    campos.ativo = informado('ativo') ? ativoBooleano(dados.ativo) : true;
    return campos;
  }

  // atualizar: só o que foi enviado; provedor/número, se enviados, seguem
  // as mesmas regras de "obrigatório e não vazio".
  if (informado('provedor')) {
    campos.provedor = textoObrigatorio(dados.provedor, 'provedor', LIMITE_PROVEDOR).toLowerCase();
  }
  if (informado('numero_whatsapp')) {
    campos.numero_whatsapp = textoObrigatorio(dados.numero_whatsapp, 'numero_whatsapp', LIMITE_NUMERO);
  }
  if (informado('identificador_externo')) {
    campos.identificador_externo = identificadorOpcional(dados.identificador_externo);
  }
  if (informado('ativo')) {
    campos.ativo = ativoBooleano(dados.ativo);
  }

  if (Object.keys(campos).length === 0) {
    throw new ErroConfiguracaoInvalida('Nenhum campo para atualizar foi informado.');
  }
  return campos;
}

// ---------------------------------------------------------------
// Saída / tratamento de erro do banco
// ---------------------------------------------------------------

/**
 * Devolve só as colunas públicas. Defesa em profundidade: mesmo que o
 * banco (ou um fake) devolva uma coluna a mais — por exemplo, um dia
 * alguém adicionar `access_token` por engano — ela nunca sai daqui.
 */
function sanitizarConfiguracao(linha) {
  const saida = {};
  for (const coluna of COLUNAS_PUBLICAS) {
    if (Object.prototype.hasOwnProperty.call(linha, coluna)) {
      saida[coluna] = linha[coluna];
    }
  }
  return saida;
}

/** Traduz o erro do banco para um erro de domínio sem detalhe interno. */
function lancarErroDeBanco(error) {
  if (error && error.code === '23505') throw new ErroConfiguracaoDuplicada(); // unique_violation
  if (error && error.code === '23503') throw new ErroLojaNaoEncontrada(); // foreign_key_violation (loja_id)
  if (error && error.code === '23514') {
    throw new ErroConfiguracaoInvalida('Dados inválidos para a configuração de WhatsApp.'); // check_violation
  }
  // Mesmo padrão de src/utils/erros.js: o erro completo fica só no log do
  // servidor; quem chamou recebe uma mensagem genérica. A tabela não tem
  // segredos, então não há credencial que possa aparecer neste log.
  console.error('[whatsappConfiguracao.service] erro de banco de dados:', error);
  throw new ErroConfiguracaoBanco();
}

async function garantirLojaExiste(lojaId) {
  const { data, error } = await supabase
    .from('lojas')
    .select('id')
    .eq('id', lojaId)
    .maybeSingle();

  if (error) lancarErroDeBanco(error);
  if (!data) throw new ErroLojaNaoEncontrada();
}

// ---------------------------------------------------------------
// Operações públicas
// ---------------------------------------------------------------

/**
 * Cria uma configuração de WhatsApp para a loja.
 *
 * `lojaId` é o ÚNICO determinante da loja gravada: `dados` não pode
 * conter `loja_id`. Duplicidade (mesmo provedor + número, ou mesmo
 * provedor + identificador externo, entre configurações ativas) é barrada
 * pelo próprio banco (índices únicos parciais) e traduzida em
 * `ErroConfiguracaoDuplicada`.
 *
 * @param {{provedor: string, numero_whatsapp: string, identificador_externo?: string|null, ativo?: boolean}} dados
 * @param {string} lojaId  UUID confiável da aplicação
 * @returns {Promise<object>} a configuração criada (só colunas públicas)
 */
async function criarConfiguracaoWhatsapp(dados, lojaId) {
  validarLojaId(lojaId);
  const campos = validarCampos(dados, 'criar');

  await garantirLojaExiste(lojaId);

  const { data, error } = await supabase
    .from(TABELA)
    .insert({ ...campos, loja_id: lojaId })
    .select(COLUNAS_SELECT)
    .single();

  if (error) lancarErroDeBanco(error);
  if (!data) throw new ErroConfiguracaoBanco();
  return sanitizarConfiguracao(data);
}

/**
 * Busca UMA configuração da loja. Filtra por `id` E `loja_id`.
 *
 * @throws {ErroConfiguracaoNaoEncontrada} se não existir ou for de outra loja
 */
async function buscarConfiguracaoWhatsapp(configuracaoId, lojaId) {
  validarConfiguracaoId(configuracaoId);
  validarLojaId(lojaId);

  const { data, error } = await supabase
    .from(TABELA)
    .select(COLUNAS_SELECT)
    .eq('id', configuracaoId)
    .eq('loja_id', lojaId)
    .maybeSingle();

  if (error) lancarErroDeBanco(error);
  if (!data) throw new ErroConfiguracaoNaoEncontrada();
  return sanitizarConfiguracao(data);
}

/**
 * Lista as configurações da loja (ativas e desativadas), da mais antiga
 * para a mais nova. Filtra por `loja_id`.
 */
async function listarConfiguracoesWhatsapp(lojaId) {
  validarLojaId(lojaId);

  const { data, error } = await supabase
    .from(TABELA)
    .select(COLUNAS_SELECT)
    .eq('loja_id', lojaId)
    .order('created_at', { ascending: true });

  if (error) lancarErroDeBanco(error);
  return (Array.isArray(data) ? data : []).map(sanitizarConfiguracao);
}

/**
 * Atualiza uma configuração da loja. A própria instrução UPDATE filtra por
 * `id` E `loja_id`, então uma loja nunca altera a configuração de outra.
 * Só provedor, numero_whatsapp, identificador_externo e ativo podem mudar
 * (nunca `loja_id`). Para reativar uma configuração, envie `ativo: true`
 * (sujeito à regra de duplicidade).
 *
 * @throws {ErroConfiguracaoNaoEncontrada} se não existir ou for de outra loja
 */
async function atualizarConfiguracaoWhatsapp(configuracaoId, lojaId, dados) {
  validarConfiguracaoId(configuracaoId);
  validarLojaId(lojaId);
  const campos = validarCampos(dados, 'atualizar');

  const { data, error } = await supabase
    .from(TABELA)
    .update({ ...campos, updated_at: new Date().toISOString() })
    .eq('id', configuracaoId)
    .eq('loja_id', lojaId)
    .select(COLUNAS_SELECT)
    .maybeSingle();

  if (error) lancarErroDeBanco(error);
  if (!data) throw new ErroConfiguracaoNaoEncontrada();
  return sanitizarConfiguracao(data);
}

/**
 * Desativa (não apaga) uma configuração da loja: `ativo = false`. Filtra
 * por `id` E `loja_id` na própria instrução UPDATE. Desativar uma
 * configuração já desativada é permitido (idempotente).
 *
 * @throws {ErroConfiguracaoNaoEncontrada} se não existir ou for de outra loja
 */
async function desativarConfiguracaoWhatsapp(configuracaoId, lojaId) {
  validarConfiguracaoId(configuracaoId);
  validarLojaId(lojaId);

  const { data, error } = await supabase
    .from(TABELA)
    .update({ ativo: false, updated_at: new Date().toISOString() })
    .eq('id', configuracaoId)
    .eq('loja_id', lojaId)
    .select(COLUNAS_SELECT)
    .maybeSingle();

  if (error) lancarErroDeBanco(error);
  if (!data) throw new ErroConfiguracaoNaoEncontrada();
  return sanitizarConfiguracao(data);
}

/**
 * RESOLUÇÃO DE CONFIGURAÇÃO POR IDENTIFICADOR EXTERNO (Etapa 10C)
 *
 * Dado o identificador externo do NÚMERO DESTINATÁRIO (o número da loja no
 * provedor — nunca o número de quem enviou a mensagem), devolve a
 * configuração ATIVA correspondente. É daqui que a futura camada de
 * webhook obtém o `loja_id` confiável: da configuração cadastrada no
 * banco, nunca de um campo do payload externo.
 *
 * Diferente das demais funções, esta NÃO recebe `lojaId`: o objetivo é
 * justamente descobrir a loja. Por isso ela é a única porta de entrada
 * "sem tenant" deste service e só deve ser chamada por código interno de
 * resolução (não por uma rota que aceite o identificador de qualquer
 * cliente autenticado para outro fim).
 *
 * Regras:
 *   - só considera configurações com `ativo = true` (desativada = inexistente);
 *   - `provedor` é opcional e deve vir de um contexto CONFIÁVEL da
 *     aplicação (ex.: parte da rota do webhook), nunca do corpo do payload.
 *     Quando informado, também filtra por ele;
 *   - se, mesmo assim, mais de uma configuração ativa bater (possível só
 *     sem `provedor`), lança `ErroConfiguracaoAmbigua` em vez de escolher;
 *   - devolve só COLUNAS_RESOLUCAO (sem número, sem timestamps e, claro,
 *     sem segredos — que a tabela nem tem).
 *
 * A checagem é repetida em código (ativo, identificador, provedor, UUIDs)
 * além do filtro na consulta, como defesa em profundidade.
 *
 * @param {string} identificadorExterno
 * @param {{provedor?: string}} [opcoes]
 * @returns {Promise<{id: string, loja_id: string, provedor: string, identificador_externo: string, ativo: boolean}>}
 * @throws {ErroConfiguracaoInvalida} identificador (ou provedor) inválido
 * @throws {ErroConfiguracaoNaoEncontrada} não existe ou está desativada
 * @throws {ErroConfiguracaoAmbigua} mais de uma configuração ativa bate
 */
async function buscarConfiguracaoPorIdentificadorExterno(identificadorExterno, opcoes = {}) {
  const identificador = textoObrigatorio(identificadorExterno, 'identificador_externo', LIMITE_IDENTIFICADOR);

  const provedorInformado = opcoes !== null && typeof opcoes === 'object' ? opcoes.provedor : undefined;
  let provedor;
  if (provedorInformado !== undefined && provedorInformado !== null) {
    provedor = textoObrigatorio(provedorInformado, 'provedor', LIMITE_PROVEDOR).toLowerCase();
  }

  let consulta = supabase
    .from(TABELA)
    .select(COLUNAS_RESOLUCAO_SELECT)
    .eq('identificador_externo', identificador)
    .eq('ativo', true);
  if (provedor !== undefined) consulta = consulta.eq('provedor', provedor);

  const { data, error } = await consulta;
  if (error) lancarErroDeBanco(error);

  const candidatas = (Array.isArray(data) ? data : []).filter(
    (linha) =>
      linha !== null &&
      typeof linha === 'object' &&
      linha.ativo === true &&
      linha.identificador_externo === identificador &&
      (provedor === undefined || linha.provedor === provedor) &&
      ehUuid(linha.id) &&
      ehUuid(linha.loja_id)
  );

  if (candidatas.length === 0) throw new ErroConfiguracaoNaoEncontrada();
  if (candidatas.length > 1) throw new ErroConfiguracaoAmbigua();

  const saida = {};
  for (const coluna of COLUNAS_RESOLUCAO) saida[coluna] = candidatas[0][coluna];
  return saida;
}

module.exports = {
  criarConfiguracaoWhatsapp,
  buscarConfiguracaoWhatsapp,
  listarConfiguracoesWhatsapp,
  atualizarConfiguracaoWhatsapp,
  desativarConfiguracaoWhatsapp,
  buscarConfiguracaoPorIdentificadorExterno,
  ErroConfiguracaoInvalida,
  ErroConfiguracaoNaoEncontrada,
  ErroLojaNaoEncontrada,
  ErroConfiguracaoDuplicada,
  ErroConfiguracaoAmbigua,
  ErroConfiguracaoBanco,
  COLUNAS_PUBLICAS,
  COLUNAS_RESOLUCAO,
  CAMPOS_PERMITIDOS,
};

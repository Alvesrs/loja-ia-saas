const iaService = require('./ia.service');
const { ehUuid, ehStringNaoVazia } = require('../utils/validacao');

/**
 * ORQUESTRADOR: MENSAGEM INTERNA DO WHATSAPP → ATENDENTE DE IA (Etapa 10J)
 *
 * ==========================================================================
 * ATENÇÃO: este arquivo produz a resposta APENAS INTERNAMENTE. Ele não envia
 * nada pelo WhatsApp, não importa o adaptador/cliente HTTP de envio da Meta,
 * não faz nenhuma chamada HTTP própria, não grava conversa/histórico, não
 * cria tabela, não faz retry nem fila e não implementa idempotência. O
 * resultado devolvido é encaminhado pelo controller ao serviço de envio da
 * etapa 10K; este módulo permanece responsável apenas pela IA.
 * ==========================================================================
 *
 * FLUXO
 *
 *   mensagem interna (saída de `whatsappWebhook.service.processarEventoWhatsapp`,
 *   10C: `lojaId` já resolvido pelo BANCO a partir do `destinatarioId`)
 *     → responderMensagemWhatsapp(mensagem)            [este arquivo]
 *     → ia.service.responderPergunta(lojaId, texto)    [IA EXISTENTE, 9A–9G]
 *         → catálogo ATIVO da loja (filtrado por `loja_id`)
 *         → contexto seguro → prompt mestre (iaPrompt) → LLM (llm.service)
 *         → fallback determinístico quando o LLM não está configurado/falha
 *     → resultado interno { lojaId, contato, idExterno, pergunta, resposta }
 *
 * NENHUMA lógica de IA é duplicada aqui: catálogo, contexto, prompt mestre,
 * proteção contra prompt injection, LLM e fallback continuam 100% em
 * `ia.service.js` e nos serviços que ele usa. Não existe bypass específico
 * para o WhatsApp — a mensagem passa exatamente pelo mesmo caminho da rota
 * `/ia/perguntar`.
 *
 * DE ONDE VÊM OS DADOS
 *
 *   - `lojaId`: SOMENTE da mensagem interna (campo CONFIÁVEL, derivado da
 *     configuração de WhatsApp ativa cadastrada no banco). Este módulo lê
 *     apenas cinco campos da mensagem — `canal`, `lojaId`, `contato`, `texto`
 *     e `idExterno` — e nunca `loja_id`, `configuracaoId` nem qualquer outro
 *     identificador de loja. Quem chama DEVE passar somente o resultado de
 *     `processarEventoWhatsapp`; nunca um objeto montado a partir do corpo
 *     da requisição.
 *   - `pergunta`: exatamente `mensagem.texto` (já aparado pela 10A), sem
 *     prefixo, sufixo, instrução ou reformatação. É dado do cliente e entra
 *     no fluxo normal da IA como pergunta — nunca como prompt de sistema.
 *   - `contato`: dado do REMETENTE, apenas preservado no resultado. Não é
 *     usado para escolher loja, catálogo, prompt, configuração ou credencial.
 *   - `idExterno`: apenas preservado (pode ser `null`), para a idempotência
 *     de uma etapa futura.
 *
 * ERROS
 *
 *   Qualquer falha da IA (banco do catálogo, contexto, etc.) vira
 *   `ErroAtendenteWhatsapp`, com mensagem FIXA e sem `cause`: nada de API key,
 *   prompt, stack, SQL, dado de outra loja ou detalhe do provedor sai daqui.
 *   Falha do LLM não chega a ser erro: `ia.service` já a trata e cai no
 *   fallback determinístico (comportamento existente, preservado).
 *   Só o TIPO do erro é registrado no log — nunca a mensagem, o texto da
 *   pergunta, a resposta nem o contato.
 */

/** A mensagem interna recebida não tem a forma esperada (falha de programação do chamador). */
class ErroMensagemAtendenteInvalida extends Error {
  constructor() {
    super('Mensagem interna de WhatsApp inválida para o atendente.');
    this.name = 'ErroMensagemAtendenteInvalida';
  }
}

/** A IA não conseguiu produzir uma resposta. Mensagem fixa: nunca repassa o erro original. */
class ErroAtendenteWhatsapp extends Error {
  constructor() {
    super('Não foi possível gerar a resposta do atendente.');
    this.name = 'ErroAtendenteWhatsapp';
  }
}

function validarMensagemInterna(mensagem) {
  const forma = mensagem !== null && typeof mensagem === 'object' && !Array.isArray(mensagem);
  if (
    !forma ||
    mensagem.canal !== 'whatsapp' ||
    !ehUuid(mensagem.lojaId) ||
    !ehStringNaoVazia(mensagem.contato) ||
    !ehStringNaoVazia(mensagem.texto) ||
    (mensagem.idExterno !== null && mensagem.idExterno !== undefined && typeof mensagem.idExterno !== 'string')
  ) {
    throw new ErroMensagemAtendenteInvalida();
  }
}

/**
 * Produz, internamente, a resposta do atendente de IA para uma mensagem
 * interna de WhatsApp. NÃO envia a resposta a ninguém.
 *
 * @param {{canal: 'whatsapp', lojaId: string, contato: string, texto: string, idExterno?: string|null}} mensagem
 *   saída de `processarEventoWhatsapp` (10C)
 * @returns {Promise<Readonly<{lojaId: string, contato: string, idExterno: string|null, pergunta: string, resposta: string}>>}
 * @throws {ErroMensagemAtendenteInvalida} mensagem sem a forma esperada (a IA NÃO é chamada)
 * @throws {ErroAtendenteWhatsapp} a IA falhou (mensagem fixa, sem detalhe interno)
 */
async function responderMensagemWhatsapp(mensagem) {
  // Mensagem inválida (inclusive texto vazio/em branco) nunca chega à IA.
  validarMensagemInterna(mensagem);

  const { lojaId, contato, texto } = mensagem;
  const idExterno = mensagem.idExterno ?? null;

  let resposta;
  try {
    resposta = await iaService.responderPergunta(lojaId, texto);
  } catch (erro) {
    console.error('[whatsappAtendente] falha ao gerar a resposta interna. Tipo do erro:', (erro && erro.name) || 'desconhecido');
    throw new ErroAtendenteWhatsapp();
  }

  if (!ehStringNaoVazia(resposta)) {
    console.error('[whatsappAtendente] a IA devolveu uma resposta vazia ou inválida.');
    throw new ErroAtendenteWhatsapp();
  }

  return Object.freeze({ lojaId, contato, idExterno, pergunta: texto, resposta });
}

module.exports = {
  responderMensagemWhatsapp,
  ErroMensagemAtendenteInvalida,
  ErroAtendenteWhatsapp,
};

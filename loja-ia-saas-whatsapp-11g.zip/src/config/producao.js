const { URL } = require('node:url');

const OBRIGATORIAS_PRODUCAO = Object.freeze([
  'SUPABASE_URL',
  'SUPABASE_SERVICE_ROLE_KEY',
  'META_APP_SECRET',
  'META_WHATSAPP_VERIFY_TOKEN',
  'WHATSAPP_CREDENTIALS_MASTER_KEY',
]);

function valor(env, nome) {
  const v = env && env[nome];
  return typeof v === 'string' ? v.trim() : '';
}

function ehHttps(texto) {
  try {
    return new URL(texto).protocol === 'https:';
  } catch {
    return false;
  }
}

function chaveMestraValida(texto) {
  if (!texto) return false;
  try {
    const bytes = Buffer.from(texto, 'base64');
    if (bytes.length !== 32) return false;
    // Rejeita entradas que Buffer aceitaria de forma permissiva como base64.
    return bytes.toString('base64').replace(/=+$/u, '') === texto.replace(/=+$/u, '');
  } catch {
    return false;
  }
}

function diagnosticarConfiguracao(env = process.env, { producao = env.NODE_ENV === 'production' } = {}) {
  const erros = [];
  const avisos = [];

  if (producao) {
    for (const nome of OBRIGATORIAS_PRODUCAO) {
      if (!valor(env, nome)) erros.push(`${nome} não definido`);
    }
  }

  const supabaseUrl = valor(env, 'SUPABASE_URL');
  if (supabaseUrl && !ehHttps(supabaseUrl)) erros.push('SUPABASE_URL deve ser uma URL HTTPS válida');

  const chaveMestra = valor(env, 'WHATSAPP_CREDENTIALS_MASTER_KEY');
  if (chaveMestra && !chaveMestraValida(chaveMestra)) {
    erros.push('WHATSAPP_CREDENTIALS_MASTER_KEY deve conter exatamente 32 bytes codificados em Base64');
  }

  const llmKey = valor(env, 'LLM_PROVIDER_API_KEY');
  const llmUrl = valor(env, 'LLM_PROVIDER_URL');
  if ((llmKey && !llmUrl) || (!llmKey && llmUrl)) {
    avisos.push('LLM incompleto: defina LLM_PROVIDER_API_KEY e LLM_PROVIDER_URL juntos; sem ambos será usado o fallback determinístico');
  }
  if (llmUrl && !ehHttps(llmUrl)) erros.push('LLM_PROVIDER_URL deve ser uma URL HTTPS válida');
  if (!llmKey && !llmUrl) avisos.push('LLM não configurado; o atendente usará o fallback determinístico baseado no catálogo');

  if (producao && !valor(env, 'ALLOWED_ORIGINS')) {
    avisos.push('ALLOWED_ORIGINS vazio: chamadas cross-origin das rotas autenticadas ficarão bloqueadas; o painel servido pelo mesmo domínio continua funcionando');
  }

  return Object.freeze({
    ok: erros.length === 0,
    ambiente: producao ? 'production' : (valor(env, 'NODE_ENV') || 'development'),
    erros: Object.freeze(erros),
    avisos: Object.freeze(avisos),
  });
}

function validarConfiguracaoDeProducao(env = process.env) {
  const diagnostico = diagnosticarConfiguracao(env, { producao: env.NODE_ENV === 'production' });
  if (!diagnostico.ok) {
    const erro = new Error(`Configuração de produção inválida: ${diagnostico.erros.join('; ')}`);
    erro.name = 'ErroConfiguracaoProducao';
    erro.diagnostico = diagnostico;
    throw erro;
  }
  return diagnostico;
}

module.exports = {
  OBRIGATORIAS_PRODUCAO,
  diagnosticarConfiguracao,
  validarConfiguracaoDeProducao,
  chaveMestraValida,
};

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.warn(
    '[config/supabaseAuth] Atenção: SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY não estão definidos. ' +
    'Configure o ambiente antes de usar autenticação.'
  );
}

// Cliente separado exclusivamente para operações de Supabase Auth que criam
// ou trocam sessão (signUp/signIn). Isso evita que um login de usuário substitua
// o contexto service_role do cliente administrativo compartilhado pelo backend,
// o que quebraria tarefas internas como o worker da fila do WhatsApp.
const supabaseAuth = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

module.exports = supabaseAuth;

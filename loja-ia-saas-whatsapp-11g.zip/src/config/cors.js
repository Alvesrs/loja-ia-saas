/**
 * CONFIGURAÇÃO DE CORS (correção da auditoria técnica)
 * -----------------------------------------------------
 * Antes: sem ALLOWED_ORIGINS definido, o CORS ficava aberto para
 * QUALQUER origem em qualquer ambiente (inclusive produção) — inclusive
 * para as rotas autenticadas do lojista (login, produtos, pedidos etc).
 *
 * Agora:
 *   - Se ALLOWED_ORIGINS estiver definido (lista separada por vírgula),
 *     essa lista é usada em qualquer ambiente. É a forma recomendada de
 *     configurar produção (ex: o domínio do painel do lojista).
 *   - Se ALLOWED_ORIGINS NÃO estiver definido:
 *       - em produção (NODE_ENV=production): CORS fica FECHADO por
 *         padrão (nenhuma origem cross-origin é liberada). Isso não
 *         afeta chamadas servidor-a-servidor/curl/apps mobile — CORS só
 *         existe para o navegador. Um aviso é logado no start do
 *         servidor para deixar claro que está faltando configuração.
 *       - fora de produção (desenvolvimento/teste): libera automaticamente
 *         origens de localhost (qualquer porta), para não exigir
 *         configuração manual ao rodar o projeto localmente.
 *
 * Exceção deliberada: a rota pública /api/lojas/:lojaId/ia/perguntar
 * continua com CORS aberto para qualquer origem (ver src/routes/ia.routes.js),
 * pois seu propósito é ser chamada a partir dos sites das PRÓPRIAS lojas
 * (domínios de terceiros, desconhecidos de antemão) e ela só devolve
 * catálogo público — sem cookies, sem autenticação, sem dado sensível.
 * Restringir CORS ali não traria proteção real e quebraria o caso de uso.
 */

const REGEX_LOCALHOST = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;

function obterOrigensPermitidas() {
  return (process.env.ALLOWED_ORIGINS || '')
    .split(',')
    .map((origem) => origem.trim())
    .filter(Boolean);
}

/**
 * Monta as opções para o middleware `cors` da API principal (tudo, exceto
 * a rota pública do atendente, que tem sua própria configuração).
 */
function construirCorsOptions({
  ambiente = process.env.NODE_ENV,
  origensPermitidas = obterOrigensPermitidas(),
} = {}) {
  if (origensPermitidas.length > 0) {
    return { origin: origensPermitidas };
  }

  if (ambiente === 'production') {
    // Sem ALLOWED_ORIGINS em produção: nenhuma origem cross-origin é
    // liberada (fail-safe). Configure ALLOWED_ORIGINS com o domínio real
    // do painel/frontend assim que ele existir.
    return { origin: false };
  }

  // Desenvolvimento/teste/ambiente não identificado: libera localhost
  // automaticamente, para não exigir configuração ao rodar localmente.
  return { origin: REGEX_LOCALHOST };
}

module.exports = { construirCorsOptions, obterOrigensPermitidas, REGEX_LOCALHOST };

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.warn(
    '[config/supabase] Atenção: SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY não estão definidos. ' +
    'Configure o arquivo .env (veja .env.example) antes de usar rotas que acessam o banco.'
  );
}

// Usamos a service_role key porque o backend controla o acesso (via middleware de auth),
// não o cliente diretamente. Isso evita problemas de RLS mal configurada travando o app
// nesta fase inicial, mas as policies de RLS continuam ativas no banco como camada extra
// de segurança para qualquer acesso direto ao Supabase.
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

module.exports = supabase;

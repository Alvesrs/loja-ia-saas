require('dotenv').config();

const { validarConfiguracaoDeProducao } = require('./config/producao');

// Em produção, falha antes de abrir a porta se faltar configuração crítica.
// Em desenvolvimento/teste, mantém a flexibilidade dos checkpoints anteriores.
const diagnostico = validarConfiguracaoDeProducao(process.env);
for (const aviso of diagnostico.avisos) console.warn('[config]', aviso);

const app = require('./app');
const { iniciarWorker, pararWorker } = require('./services/whatsappWorker.service');

const PORT = process.env.PORT || 3000;
const servidor = app.listen(PORT, () => {
  console.log(`loja-ia-saas rodando na porta ${PORT}`);
  iniciarWorker();
});

function encerrar(sinal) {
  console.log(`[shutdown] ${sinal} recebido; encerrando HTTP e worker.`);
  pararWorker();
  servidor.close((erro) => {
    if (erro) {
      console.error('[shutdown] falha ao encerrar servidor HTTP:', erro.name || 'Error');
      process.exitCode = 1;
    }
  });
}

process.once('SIGTERM', () => encerrar('SIGTERM'));
process.once('SIGINT', () => encerrar('SIGINT'));

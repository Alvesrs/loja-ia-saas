/**
 * Helpers de validação simples, sem dependência externa.
 * Suficiente para os formatos de dados deste projeto (Micro-SaaS).
 */

const REGEX_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function ehUuid(valor) {
  return typeof valor === 'string' && REGEX_UUID.test(valor);
}

function ehStringNaoVazia(valor) {
  return typeof valor === 'string' && valor.trim().length > 0;
}

function ehStringOpcionalValida(valor) {
  return valor === undefined || valor === null || typeof valor === 'string';
}

function ehNumeroNaoNegativo(valor) {
  return typeof valor === 'number' && Number.isFinite(valor) && valor >= 0;
}

function ehInteiroNaoNegativo(valor) {
  return Number.isInteger(valor) && valor >= 0;
}

function ehInteiroPositivo(valor) {
  return Number.isInteger(valor) && valor > 0;
}

function ehBooleano(valor) {
  return typeof valor === 'boolean';
}

// Validação simples de email: formato básico "algo@algo.algo", sem
// dependência externa. Suficiente para barrar entradas claramente
// inválidas (não tenta validar se o domínio existe de verdade).
const REGEX_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function ehEmailValido(valor) {
  return typeof valor === 'string' && REGEX_EMAIL.test(valor.trim());
}

// Validação simples de telefone: aceita dígitos e os separadores mais
// comuns (espaço, +, -, parênteses) e exige uma quantidade razoável de
// dígitos. Não reformata nem valida DDD/DDI — só barra entradas
// claramente inválidas (ver Etapa 5, item 11: nada de normalização
// destrutiva).
const REGEX_TELEFONE_CARACTERES = /^[0-9+()\-\s]+$/;

function ehTelefoneValido(valor) {
  if (typeof valor !== 'string') return false;
  const texto = valor.trim();
  if (texto.length === 0 || !REGEX_TELEFONE_CARACTERES.test(texto)) return false;
  const digitos = texto.replace(/\D/g, '');
  return digitos.length >= 8 && digitos.length <= 15;
}

module.exports = {
  ehUuid,
  ehStringNaoVazia,
  ehStringOpcionalValida,
  ehNumeroNaoNegativo,
  ehInteiroNaoNegativo,
  ehInteiroPositivo,
  ehBooleano,
  ehEmailValido,
  ehTelefoneValido,
};

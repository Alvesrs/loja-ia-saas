/**
 * Padroniza o tratamento de erros vindos do banco (Postgres/Supabase) para
 * que a resposta ao cliente nunca exponha detalhes internos (nomes de
 * coluna, texto bruto de constraint, stack trace etc). O erro completo
 * sempre é logado no servidor para depuração.
 */

function mensagemAmigavelBanco(error) {
  if (!error) return 'Não foi possível completar a operação.';

  switch (error.code) {
    case '23505': // unique_violation
      return 'Já existe um registro com esses dados.';
    case '23503': // foreign_key_violation
      return 'Referência inválida: um dos registros relacionados não existe.';
    case '23514': // check_violation
      return 'Dados inválidos para esta operação.';
    default:
      return 'Não foi possível completar a operação.';
  }
}

function tratarErroBanco(res, error, statusPadrao = 400) {
  console.error('[erro banco de dados]', error);
  return res.status(statusPadrao).json({ erro: mensagemAmigavelBanco(error) });
}

function tratarErroInterno(res, error, mensagemPublica = 'Erro interno no servidor.') {
  console.error('[erro interno]', error);
  return res.status(500).json({ erro: mensagemPublica });
}

module.exports = { tratarErroBanco, tratarErroInterno, mensagemAmigavelBanco };

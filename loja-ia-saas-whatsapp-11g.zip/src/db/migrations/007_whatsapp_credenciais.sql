-- ============================================================
-- MIGRAÇÃO 007 — Credenciais WhatsApp por configuração (Etapa 10P)
-- ============================================================
-- Segredos ficam separados da configuração pública. O access token é
-- cifrado pela aplicação com AES-256-GCM antes de chegar ao banco.
-- O banco nunca recebe o token em texto puro.

create table if not exists whatsapp_credenciais (
  configuracao_id uuid primary key,
  loja_id uuid not null references lojas(id) on delete cascade,
  provedor text not null,
  access_token_cifrado text not null,
  access_token_iv text not null,
  access_token_tag text not null,
  versao_chave integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint whatsapp_credenciais_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_credenciais_provedor_chk
    check (provedor = 'meta'),
  constraint whatsapp_credenciais_versao_chk
    check (versao_chave > 0),
  constraint whatsapp_credenciais_cifrado_chk
    check (char_length(access_token_cifrado) between 1 and 20000),
  constraint whatsapp_credenciais_iv_chk
    check (char_length(access_token_iv) between 1 and 128),
  constraint whatsapp_credenciais_tag_chk
    check (char_length(access_token_tag) between 1 and 128)
);

create index if not exists idx_whatsapp_credenciais_loja_id
  on whatsapp_credenciais (loja_id);

alter table whatsapp_credenciais enable row level security;

drop policy if exists "dono ve credenciais whatsapp das suas lojas" on whatsapp_credenciais;
create policy "dono ve credenciais whatsapp das suas lojas" on whatsapp_credenciais
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

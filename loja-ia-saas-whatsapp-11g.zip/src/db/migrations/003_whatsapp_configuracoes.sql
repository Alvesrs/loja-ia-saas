-- ============================================================
-- MIGRAÇÃO 003 — Configuração de WhatsApp por loja (Etapa 10B)
-- ============================================================
-- Rode este arquivo no SQL Editor do Supabase SE o seu banco já existia
-- antes desta etapa. Se está criando o projeto do zero, basta rodar o
-- schema.sql atual (ele já inclui esta tabela) — não precisa rodar esta
-- migração separadamente.
--
-- Este script é idempotente: pode ser executado mais de uma vez sem
-- causar erro ou duplicar objetos.
--
-- O QUE ESTE SCRIPT FAZ:
--   1. Cria a tabela "whatsapp_configuracoes": a configuração de WhatsApp
--      associada a uma loja (loja → whatsapp_configuracoes).
--   2. Cria índices para consultas por loja e por provedor + número /
--      identificador externo, e as regras de unicidade (ver abaixo).
--   3. Habilita RLS e cria a policy do dono da loja, no mesmo padrão das
--      demais tabelas.
--
-- O QUE ESTA TABELA É (E NÃO É):
--   - É CONFIGURAÇÃO (qual provedor/número pertence a qual loja). NÃO é
--     conversa: nenhuma mensagem é armazenada aqui.
--   - NÃO guarda segredos: não existe coluna de access token, API key,
--     secret, senha ou credencial de provedor. Esses dados serão tratados
--     de outra forma, em etapa futura. NÃO adicione tal coluna aqui.
--   - Não há integração real com nenhum provedor de WhatsApp nesta etapa.
--
-- REGRAS DE INTEGRIDADE:
--   - loja_id referencia lojas(id); se a loja for removida, as
--     configurações dela também são (on delete cascade, como nas demais
--     tabelas do projeto).
--   - "provedor" é texto livre (sem lista fechada, para aceitar provedores
--     futuros), mas sempre gravado em forma canônica: sem espaços nas
--     pontas e em minúsculas. Assim "Meta" e "meta" não viram duas
--     configurações "diferentes".
--   - "numero_whatsapp" e "identificador_externo" não têm regra de formato
--     (provedores diferentes usam formatos diferentes); só não podem ser
--     vazios, não podem ter espaços nas pontas e têm um limite de tamanho.
--
-- REGRA DE DUPLICIDADE (só entre configurações ATIVAS):
--   - Um mesmo (provedor, numero_whatsapp) só pode estar ativo em UMA
--     configuração do sistema inteiro. Isso vale também para a mesma loja
--     (não dá para cadastrar o mesmo número duas vezes) e, principalmente,
--     entre lojas: no futuro, uma mensagem recebida será atribuída a uma
--     loja pelo número; se duas lojas ativas tivessem o mesmo número, a
--     mensagem poderia ir para a loja errada.
--   - Idem para (provedor, identificador_externo), quando informado.
--   - Configurações desativadas (ativo = false) não bloqueiam ninguém: o
--     número volta a ficar livre.
-- ============================================================

-- 1) Tabela -----------------------------------------------------------
create table if not exists whatsapp_configuracoes (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  provedor text not null,
  numero_whatsapp text not null,
  identificador_externo text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint whatsapp_configuracoes_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_configuracoes_numero_chk
    check (char_length(numero_whatsapp) between 1 and 64 and numero_whatsapp !~ '^\s|\s$'),
  constraint whatsapp_configuracoes_identificador_chk
    check (identificador_externo is null or (char_length(identificador_externo) between 1 and 255 and identificador_externo !~ '^\s|\s$'))
);

-- 2) Índices e regras de unicidade -------------------------------------
-- Consultas por loja (listar/buscar a configuração de uma loja).
create index if not exists idx_whatsapp_configuracoes_loja_id
  on whatsapp_configuracoes (loja_id);

-- Unicidade entre configurações ativas + consulta futura por provedor e número.
create unique index if not exists uq_whatsapp_config_ativa_provedor_numero
  on whatsapp_configuracoes (provedor, numero_whatsapp)
  where ativo;

-- Unicidade entre configurações ativas + consulta futura por provedor e
-- identificador externo (só quando o identificador foi informado).
create unique index if not exists uq_whatsapp_config_ativa_provedor_identificador
  on whatsapp_configuracoes (provedor, identificador_externo)
  where ativo and identificador_externo is not null;

-- 3) RLS ---------------------------------------------------------------
-- Mesmo padrão das demais tabelas: o dono só enxerga/edita configurações
-- das próprias lojas em acesso direto ao Supabase. Lembrete: o backend usa
-- a service_role key, que IGNORA RLS — por isso o service
-- (src/services/whatsappConfiguracao.service.js) sempre filtra por
-- loja_id no código. O RLS é só uma camada extra, nunca a autorização.
alter table whatsapp_configuracoes enable row level security;

drop policy if exists "dono ve whatsapp das suas lojas" on whatsapp_configuracoes;
create policy "dono ve whatsapp das suas lojas" on whatsapp_configuracoes
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

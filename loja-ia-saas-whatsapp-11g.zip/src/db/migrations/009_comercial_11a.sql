-- Etapa 11A — base comercial de planos/assinaturas.
-- Idempotente e compatível com bancos existentes.

alter table public.assinaturas
  add column if not exists atualizado_em timestamptz not null default now();

create index if not exists idx_assinaturas_loja_criado
  on public.assinaturas (loja_id, criado_em desc);

comment on table public.assinaturas is
  'Estado comercial da loja. A cobrança automática será integrada em etapa posterior.';
comment on column public.assinaturas.plano is
  'Código técnico do plano (trial, basico, pro, ilimitado).';
comment on column public.assinaturas.status is
  'Estado operacional da assinatura: ativo, inativo ou cancelado.';
comment on column public.assinaturas.valido_ate is
  'Validade opcional. NULL significa sem expiração automática.';

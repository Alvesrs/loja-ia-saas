-- Etapa 10O — fila persistente + retry controlado para WhatsApp.

create table if not exists whatsapp_fila_processamento (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  configuracao_id uuid not null,
  provedor text not null,
  destinatario_id text not null,
  contato text not null,
  texto text not null,
  id_externo text not null,
  timestamp_mensagem timestamptz,
  resposta_texto text,
  status text not null default 'pendente',
  tentativas integer not null default 0,
  proxima_tentativa_em timestamptz not null default now(),
  lease_ate timestamptz,
  ultimo_erro_codigo text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  concluido_em timestamptz,
  constraint whatsapp_fila_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_fila_evento_fk
    foreign key (provedor, id_externo)
    references whatsapp_eventos_processados(provedor, id_externo) on delete cascade,
  constraint whatsapp_fila_evento_uk unique (provedor, id_externo),
  constraint whatsapp_fila_status_chk
    check (status in ('pendente', 'processando', 'enviado', 'concluido', 'falhou')),
  constraint whatsapp_fila_tentativas_chk check (tentativas >= 0),
  constraint whatsapp_fila_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_fila_destinatario_chk
    check (char_length(destinatario_id) between 1 and 255 and destinatario_id !~ '^\s|\s$'),
  constraint whatsapp_fila_contato_chk
    check (char_length(contato) between 1 and 128 and contato !~ '^\s|\s$'),
  constraint whatsapp_fila_texto_chk
    check (char_length(texto) between 1 and 12000 and texto !~ '^\s*$'),
  constraint whatsapp_fila_id_externo_chk
    check (char_length(id_externo) between 1 and 512 and id_externo !~ '^\s|\s$'),
  constraint whatsapp_fila_resposta_chk
    check (resposta_texto is null or (char_length(resposta_texto) between 1 and 12000 and resposta_texto !~ '^\s*$')),
  constraint whatsapp_fila_erro_chk
    check (ultimo_erro_codigo is null or ultimo_erro_codigo ~ '^[A-Za-z0-9_.-]{1,80}$'),
  constraint whatsapp_fila_enviado_resposta_chk
    check (status <> 'enviado' or resposta_texto is not null)
);

create index if not exists idx_whatsapp_fila_pronta
  on whatsapp_fila_processamento (status, proxima_tentativa_em, criado_em);
create index if not exists idx_whatsapp_fila_loja
  on whatsapp_fila_processamento (loja_id, criado_em desc);

alter table whatsapp_fila_processamento enable row level security;
-- Sem policy de usuário: fila é operacional interna; service_role opera o worker.

create or replace function claim_whatsapp_job(p_lease_segundos integer default 60)
returns setof whatsapp_fila_processamento
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  if p_lease_segundos is null or p_lease_segundos < 10 or p_lease_segundos > 3600 then
    raise exception 'LEASE_INVALIDA';
  end if;

  select q.id into v_id
  from whatsapp_fila_processamento q
  where (
      q.status = 'pendente'
      and q.proxima_tentativa_em <= now()
    ) or (
      q.status = 'processando'
      and q.lease_ate is not null
      and q.lease_ate <= now()
    ) or (
      q.status = 'enviado'
      and q.proxima_tentativa_em <= now()
      and (q.lease_ate is null or q.lease_ate <= now())
    )
  order by q.proxima_tentativa_em asc, q.criado_em asc
  for update skip locked
  limit 1;

  if v_id is null then
    return;
  end if;

  return query
  update whatsapp_fila_processamento q
     set status = case when q.status = 'enviado' then 'enviado' else 'processando' end,
         tentativas = q.tentativas + 1,
         lease_ate = now() + make_interval(secs => p_lease_segundos),
         atualizado_em = now()
   where q.id = v_id
   returning q.*;
end;
$$;

revoke all on function claim_whatsapp_job(integer) from public;
grant execute on function claim_whatsapp_job(integer) to service_role;

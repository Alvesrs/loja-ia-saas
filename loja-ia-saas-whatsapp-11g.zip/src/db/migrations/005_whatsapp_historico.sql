-- ============================================================
-- MIGRAÇÃO 005 — Histórico de conversas WhatsApp (Etapa 10N)
-- ============================================================
-- Rode no SQL Editor do Supabase para bancos existentes.
-- Em instalação nova, schema.sql já contém as mesmas estruturas.
--
-- Persiste somente dados funcionais da conversa (loja, configuração,
-- contato, direção, texto e ids/timestamps técnicos). Nunca persiste o
-- payload bruto da Meta, access token, app secret ou outras credenciais.
-- ============================================================

-- Permite FK composta para garantir no banco que a configuração usada por
-- uma conversa pertence à mesma loja da conversa.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'whatsapp_configuracoes_id_loja_uk'
  ) then
    alter table whatsapp_configuracoes
      add constraint whatsapp_configuracoes_id_loja_uk unique (id, loja_id);
  end if;
end $$;

create table if not exists whatsapp_conversas (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references lojas(id) on delete cascade,
  configuracao_id uuid not null,
  contato text not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  constraint whatsapp_conversas_config_loja_fk
    foreign key (configuracao_id, loja_id)
    references whatsapp_configuracoes(id, loja_id) on delete cascade,
  constraint whatsapp_conversas_contato_chk
    check (char_length(contato) between 1 and 128 and contato !~ '^\s|\s$'),
  constraint whatsapp_conversas_id_loja_uk unique (id, loja_id),
  constraint whatsapp_conversas_tenant_contato_uk unique (loja_id, configuracao_id, contato)
);

create table if not exists whatsapp_mensagens (
  id uuid primary key default gen_random_uuid(),
  conversa_id uuid not null,
  loja_id uuid not null references lojas(id) on delete cascade,
  direcao text not null,
  texto text not null,
  provedor text not null,
  id_externo text,
  criado_em timestamptz not null default now(),
  constraint whatsapp_mensagens_conversa_loja_fk
    foreign key (conversa_id, loja_id)
    references whatsapp_conversas(id, loja_id) on delete cascade,
  constraint whatsapp_mensagens_direcao_chk check (direcao in ('entrada', 'saida')),
  constraint whatsapp_mensagens_texto_chk check (char_length(texto) between 1 and 12000 and texto !~ '^\s*$'),
  constraint whatsapp_mensagens_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\s|\s$'),
  constraint whatsapp_mensagens_id_externo_chk
    check (id_externo is null or (char_length(id_externo) between 1 and 512 and id_externo !~ '^\s|\s$'))
);

create index if not exists idx_whatsapp_conversas_loja_atualizado
  on whatsapp_conversas (loja_id, atualizado_em desc);
create index if not exists idx_whatsapp_mensagens_conversa_criado
  on whatsapp_mensagens (conversa_id, criado_em);
create index if not exists idx_whatsapp_mensagens_loja_criado
  on whatsapp_mensagens (loja_id, criado_em desc);
create unique index if not exists uq_whatsapp_mensagem_entrada_externa
  on whatsapp_mensagens (provedor, id_externo)
  where direcao = 'entrada' and id_externo is not null;

alter table whatsapp_conversas enable row level security;
alter table whatsapp_mensagens enable row level security;

create policy "dono ve conversas whatsapp das suas lojas" on whatsapp_conversas
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

create policy "dono ve mensagens whatsapp das suas lojas" on whatsapp_mensagens
  for all using (loja_id in (select id from lojas where dono_id = auth.uid()))
  with check (loja_id in (select id from lojas where dono_id = auth.uid()));

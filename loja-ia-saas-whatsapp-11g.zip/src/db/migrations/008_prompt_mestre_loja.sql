-- Etapa 10W — Prompt Mestre por loja
-- Instruções flexíveis do próprio negócio para o atendente de IA.
-- Não contém segredos técnicos; continua isolado por loja e só é editável pelo dono.

alter table public.lojas
  add column if not exists prompt_mestre text;

comment on column public.lojas.prompt_mestre is
  'Instruções de negócio fornecidas pelo lojista para personalizar o atendente de IA.';

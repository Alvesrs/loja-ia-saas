-- Etapa 11C — cobrança recorrente automática via Mercado Pago.
alter table public.assinaturas
  add column if not exists provedor_pagamento text,
  add column if not exists provider_assinatura_id text,
  add column if not exists provider_status text;

create unique index if not exists idx_assinaturas_provider_assinatura
  on public.assinaturas (provider_assinatura_id)
  where provider_assinatura_id is not null;

create table if not exists public.cobrancas_assinaturas (
  id uuid primary key default gen_random_uuid(),
  loja_id uuid not null references public.lojas(id) on delete cascade,
  plano text not null,
  provedor text not null default 'mercadopago',
  provider_assinatura_id text not null unique,
  status_provider text not null,
  checkout_url text,
  payer_email text,
  external_reference text,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index if not exists idx_cobrancas_assinaturas_loja
  on public.cobrancas_assinaturas (loja_id, criado_em desc);

alter table public.cobrancas_assinaturas enable row level security;
comment on table public.cobrancas_assinaturas is 'Tentativas e vínculos de cobrança recorrente gerenciados exclusivamente pelo backend.';

-- ============================================================
-- MIGRAÇÃO 004 — Idempotência de webhook WhatsApp (Etapa 10M)
-- ============================================================
-- Rode no SQL Editor do Supabase para bancos existentes.
-- Em instalação nova, schema.sql já contém a mesma tabela.
--
-- Guarda SOMENTE a chave técnica do evento. Não persiste corpo da mensagem,
-- telefone, payload, tokens ou segredos.
-- A PK composta torna a reserva atômica entre múltiplas instâncias.
-- ============================================================

create table if not exists whatsapp_eventos_processados (
  provedor text not null,
  id_externo text not null,
  status text not null default 'processando',
  recebido_em timestamptz not null default now(),
  processado_em timestamptz,
  primary key (provedor, id_externo),
  constraint whatsapp_eventos_provedor_chk
    check (char_length(provedor) between 1 and 50 and provedor = lower(provedor) and provedor !~ '^\\s|\\s$'),
  constraint whatsapp_eventos_id_externo_chk
    check (char_length(id_externo) between 1 and 512 and id_externo !~ '^\\s|\\s$'),
  constraint whatsapp_eventos_status_chk
    check (status in ('processando', 'concluido'))
);

create index if not exists idx_whatsapp_eventos_recebido_em
  on whatsapp_eventos_processados (recebido_em);

alter table whatsapp_eventos_processados enable row level security;
-- Deliberadamente sem policy: tabela operacional interna, acessível pelo
-- backend via service_role, não diretamente por anon/authenticated.

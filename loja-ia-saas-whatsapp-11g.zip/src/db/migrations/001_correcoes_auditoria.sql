-- ============================================================
-- MIGRAÇÃO 001 — Correções da auditoria técnica (2026-09-13)
-- ============================================================
-- Rode este arquivo no SQL Editor do Supabase SE você já tinha criado o
-- banco a partir de uma versão anterior de schema.sql. Se está criando o
-- projeto do zero, basta rodar o schema.sql atual (ele já inclui tudo
-- isto) — não precisa rodar esta migração separadamente.
--
-- Este script é idempotente: pode ser executado mais de uma vez sem
-- causar erro ou duplicar objetos.
--
-- O QUE ESTE SCRIPT FAZ:
--   1. Cria índices nas foreign keys usadas nas checagens de propriedade
--      (usuário → loja → produto → estoque / cliente). Postgres não cria
--      índice automático em foreign key, só na chave primária.
--   2. Cria a função `criar_pedido`, que passa a criação de pedidos a
--      ser atômica (pedido + itens + baixa de estoque em uma única
--      transação, com bloqueio de linha para evitar overselling em
--      pedidos simultâneos).
--   3. Restringe quem pode executar `criar_pedido` (só o backend, via
--      service_role).
--
-- NÃO altera nem remove nenhuma tabela, coluna ou dado existente.
-- ============================================================

-- 1) Índices -----------------------------------------------------------
create index if not exists idx_lojas_dono_id on lojas(dono_id);
create index if not exists idx_produtos_loja_id on produtos(loja_id);
create index if not exists idx_estoque_produto_id on estoque(produto_id);
create index if not exists idx_clientes_loja_id on clientes(loja_id);
create index if not exists idx_pedidos_loja_id on pedidos(loja_id);
create index if not exists idx_pedidos_cliente_id on pedidos(cliente_id);
create index if not exists idx_pedido_itens_pedido_id on pedido_itens(pedido_id);
create index if not exists idx_pedido_itens_estoque_id on pedido_itens(estoque_id);

-- 2) Função transacional de criação de pedido ---------------------------
create or replace function criar_pedido(
  p_loja_id uuid,
  p_cliente_id uuid,
  p_itens jsonb -- array de objetos: [{ "estoque_id": "uuid", "quantidade": 2 }, ...]
) returns jsonb
language plpgsql
as $$
declare
  v_pedido_id uuid;
  v_total numeric(10,2) := 0;
  v_item jsonb;
  v_estoque_id uuid;
  v_quantidade integer;
  v_estoque_row record;
  v_preco numeric(10,2);
  v_itens_resultado jsonb := '[]'::jsonb;
begin
  if p_cliente_id is not null then
    perform 1 from clientes where id = p_cliente_id and loja_id = p_loja_id;
    if not found then
      raise exception 'CLIENTE_INVALIDO';
    end if;
  end if;

  if p_itens is null or jsonb_array_length(p_itens) = 0 then
    raise exception 'ITENS_VAZIOS';
  end if;

  insert into pedidos (loja_id, cliente_id, total, status)
  values (p_loja_id, p_cliente_id, 0, 'pendente')
  returning id into v_pedido_id;

  for v_item in select * from jsonb_array_elements(p_itens)
  loop
    v_estoque_id := (v_item->>'estoque_id')::uuid;
    v_quantidade := (v_item->>'quantidade')::integer;

    if v_quantidade is null or v_quantidade <= 0 then
      raise exception 'QUANTIDADE_INVALIDA';
    end if;

    select e.id, e.quantidade, p.preco, p.loja_id
      into v_estoque_row
      from estoque e
      join produtos p on p.id = e.produto_id
      where e.id = v_estoque_id
      for update of e;

    if not found or v_estoque_row.loja_id <> p_loja_id then
      raise exception 'ITEM_INVALIDO';
    end if;

    if v_estoque_row.quantidade < v_quantidade then
      raise exception 'ESTOQUE_INSUFICIENTE';
    end if;

    update estoque set quantidade = quantidade - v_quantidade, atualizado_em = now()
      where id = v_estoque_id;

    v_preco := v_estoque_row.preco;
    v_total := v_total + (v_preco * v_quantidade);

    insert into pedido_itens (pedido_id, estoque_id, quantidade, preco_unitario)
    values (v_pedido_id, v_estoque_id, v_quantidade, v_preco);

    v_itens_resultado := v_itens_resultado || jsonb_build_object(
      'estoque_id', v_estoque_id,
      'quantidade', v_quantidade,
      'preco_unitario', v_preco
    );
  end loop;

  update pedidos set total = v_total where id = v_pedido_id;

  return jsonb_build_object(
    'id', v_pedido_id,
    'loja_id', p_loja_id,
    'cliente_id', p_cliente_id,
    'total', v_total,
    'status', 'pendente',
    'itens', v_itens_resultado
  );
end;
$$;

-- 3) Restringir quem pode chamar a função --------------------------------
revoke all on function criar_pedido(uuid, uuid, jsonb) from public;
grant execute on function criar_pedido(uuid, uuid, jsonb) to service_role;

-- 11D: adaptação da camada comercial para Asaas Checkout + Webhooks.
alter table public.cobrancas_assinaturas
  alter column provider_assinatura_id drop not null,
  add column if not exists provider_checkout_id text;

create unique index if not exists idx_cobrancas_provider_checkout
  on public.cobrancas_assinaturas (provider_checkout_id)
  where provider_checkout_id is not null;

create table if not exists public.cobranca_webhook_eventos (
  id uuid primary key default gen_random_uuid(),
  provedor text not null,
  evento_id text not null,
  tipo text not null,
  criado_em timestamptz not null default now(),
  unique (provedor, evento_id)
);

alter table public.cobranca_webhook_eventos enable row level security;
comment on table public.cobranca_webhook_eventos is 'Idempotência de Webhooks de cobrança. Gerenciado somente pelo backend/service role.';

// Se as dependências já estiverem instaladas, também lê um .env local.
// Em CI/hospedagem, funciona só com process.env mesmo antes de carregar dotenv.
try {
  require('dotenv').config();
} catch (erro) {
  if (erro && erro.code !== 'MODULE_NOT_FOUND') throw erro;
}

const { diagnosticarConfiguracao } = require('../src/config/producao');

const d = diagnosticarConfiguracao(process.env, { producao: true });
console.log('Checklist de configuração de produção');
console.log(`Status: ${d.ok ? 'OK' : 'FALHOU'}`);
for (const erro of d.erros) console.error(`ERRO: ${erro}`);
for (const aviso of d.avisos) console.warn(`AVISO: ${aviso}`);
if (!d.ok) process.exitCode = 1;

// Wrapper único para chamadas à API existente. Centraliza:
// - anexar o token (Authorization: Bearer ...);
// - tratar sessão expirada/token inválido (401) redirecionando ao login;
// - normalizar erros para a mensagem amigável que o backend já devolve
//   em { erro: "..." } (ver src/utils/erros.js e cada controller).

class SessaoExpiradaError extends Error {}

async function apiFetch(caminho, opcoes = {}) {
  const token = obterToken();
  const headers = Object.assign(
    { 'Content-Type': 'application/json' },
    opcoes.headers || {}
  );
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`${API_BASE}${caminho}`, { ...opcoes, headers });
  } catch (e) {
    throw new Error('Não foi possível conectar ao servidor. Verifique sua conexão.');
  }

  if (res.status === 401) {
    limparSessao();
    throw new SessaoExpiradaError('Sua sessão expirou. Faça login novamente.');
  }

  let corpo = null;
  const texto = await res.text();
  if (texto) {
    try { corpo = JSON.parse(texto); } catch (e) { corpo = null; }
  }

  if (!res.ok) {
    const mensagem = (corpo && corpo.erro) || 'Ocorreu um erro inesperado. Tente novamente.';
    throw new Error(mensagem);
  }

  return corpo;
}

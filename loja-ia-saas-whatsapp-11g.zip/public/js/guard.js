// Protege as páginas administrativas. Carregado de forma SÍNCRONA (sem
// "defer") e no topo do <body>, antes de qualquer conteúdo, para que um
// usuário sem sessão nunca chegue a ver o HTML da página protegida —
// só o redirecionamento.
(function protegerPagina() {
  const sessaoBruta = localStorage.getItem('lojaia_sessao');
  if (!sessaoBruta) {
    window.location.replace('login.html');
    return;
  }
  try {
    const sessao = JSON.parse(sessaoBruta);
    if (!sessao || !sessao.token) {
      window.location.replace('login.html');
    }
  } catch (e) {
    window.location.replace('login.html');
  }
})();

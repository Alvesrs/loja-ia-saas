// Estado da loja selecionada no painel.
// Um mesmo dono pode administrar várias empresas/clientes. A seleção é
// apenas UX; toda autorização continua sendo validada no backend.

const LOJA_CACHE_KEY = 'lojaia_loja_atual';
const LOJA_ID_KEY = 'lojaia_loja_atual_id';

async function listarMinhasLojas() {
  const lojas = await apiFetch('/lojas');
  return Array.isArray(lojas) ? lojas : [];
}

function salvarLojaAtual(loja) {
  if (!loja || !loja.id) return;
  sessionStorage.setItem(LOJA_CACHE_KEY, JSON.stringify(loja));
  localStorage.setItem(LOJA_ID_KEY, loja.id);
}

function limparLojaAtual() {
  sessionStorage.removeItem(LOJA_CACHE_KEY);
  localStorage.removeItem(LOJA_ID_KEY);
}

async function obterLojaAtual({ forcarRecarregar = false } = {}) {
  if (!forcarRecarregar) {
    const emCache = sessionStorage.getItem(LOJA_CACHE_KEY);
    if (emCache) {
      try { return JSON.parse(emCache); } catch (e) { sessionStorage.removeItem(LOJA_CACHE_KEY); }
    }
  }

  const lojas = await listarMinhasLojas();
  if (!lojas.length) {
    limparLojaAtual();
    return null;
  }

  const idPreferido = localStorage.getItem(LOJA_ID_KEY);
  const loja = lojas.find((item) => item.id === idPreferido) || lojas[0];
  salvarLojaAtual(loja);
  return loja;
}

async function selecionarLoja(lojaId) {
  const lojas = await listarMinhasLojas();
  const loja = lojas.find((item) => item.id === lojaId);
  if (!loja) throw new Error('Loja não encontrada.');
  salvarLojaAtual(loja);
  return loja;
}

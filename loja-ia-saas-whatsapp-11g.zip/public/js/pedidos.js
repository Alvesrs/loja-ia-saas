// Controller da página Pedidos. Consome os endpoints já existentes:
//   GET  /api/lojas/:lojaId/pedidos   (lista, com cliente e itens já
//                                       enriquecidos com produto/variação)
//   POST /api/lojas/:lojaId/pedidos   (cria pedido — chama a função
//                                       transacional criar_pedido no banco)
//
// Para montar o formulário de criação, reaproveitamos os endpoints já
// existentes de Produtos e Clientes:
//   GET /api/lojas/:lojaId/produtos   (traz produto + estoque aninhado)
//   GET /api/lojas/:lojaId/clientes
//
// O :lojaId nunca é escolhido pelo usuário: vem de obterLojaAtual(). A
// autorização de verdade (usuário → loja → produto/estoque/cliente) é
// sempre feita pelo backend — o frontend só usa os IDs que o próprio
// backend devolveu nas respostas anteriores.
//
// REGRA DE OURO desta tela: o preço e o estoque oficiais vêm sempre do
// banco. O que é calculado aqui no navegador (resumo do pedido antes de
// enviar) é só uma ESTIMATIVA visual. Depois que o servidor responde, o
// total exibido é sempre o retornado pela API — nunca recalculado.

let lojaAtualId = null;
let pedidosCache = [];
let produtosCache = null; // carregado sob demanda (lazy) ao abrir "novo pedido"
let clientesCache = null; // idem
let requisicaoEmAndamento = false;

const listaEl = document.getElementById('lista-pedidos');
const estadoVazioEl = document.getElementById('estado-vazio');
const estadoErroEl = document.getElementById('estado-erro');
const estadoSemLojaEl = document.getElementById('estado-sem-loja');
const mensagemErroEl = document.getElementById('mensagem-erro');
const botaoNovoPedidoEl = document.getElementById('botao-novo-pedido');
const botaoPrimeiroPedidoEl = document.getElementById('botao-primeiro-pedido');

function icone(nome) {
  const icones = {
    lixeira: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
    ver: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
    caixa: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
    alerta: '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v5"/><path d="M12 16h.01"/></svg>',
  };
  return icones[nome] || '';
}

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML;
}

// ---------- Estados da tela ----------

function mostrarSomente(id) {
  ['lista-pedidos', 'skeleton-pedidos', 'estado-vazio', 'estado-erro', 'estado-sem-loja'].forEach((elId) => {
    const el = document.getElementById(elId);
    if (el) el.classList.toggle('hidden', elId !== id);
  });
}

function mostrarCarregando() {
  mostrarSomente('skeleton-pedidos');
}

function mostrarErro(mensagem) {
  mensagemErroEl.textContent = mensagem;
  mostrarSomente('estado-erro');
}

function mostrarSemLoja() {
  mostrarSomente('estado-sem-loja');
}

// ---------- Carregar ----------

async function carregarPedidos() {
  mostrarCarregando();
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      mostrarSemLoja();
      return;
    }
    lojaAtualId = loja.id;
    pedidosCache = await apiFetch(`/lojas/${lojaAtualId}/pedidos`);
    renderizarLista();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErro(erro.message || 'Não foi possível carregar os pedidos agora.');
  }
}

// ---------- Formatação ----------

function formatarData(dataIso) {
  if (!dataIso) return '—';
  const data = new Date(dataIso);
  if (Number.isNaN(data.getTime())) return '—';
  const dataTexto = data.toLocaleDateString('pt-BR');
  const horaTexto = data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  return `${dataTexto} ${horaTexto}`;
}

// Representação curta e só visual do UUID do pedido — nunca usada nas
// chamadas à API (essas sempre usam pedido.id completo).
function numeroCurto(pedido) {
  if (!pedido || !pedido.id) return '#——';
  return `#${pedido.id.slice(0, 6).toUpperCase()}`;
}

function nomeCliente(pedido) {
  return pedido.clientes && pedido.clientes.nome ? pedido.clientes.nome : null;
}

function itensDoPedido(pedido) {
  return Array.isArray(pedido.pedido_itens) ? pedido.pedido_itens : [];
}

const STATUS_INFO = {
  pendente: { classe: 'badge-pendente', label: 'Pendente' },
  confirmado: { classe: 'badge-confirmado', label: 'Confirmado' },
  cancelado: { classe: 'badge-cancelado', label: 'Cancelado' },
  entregue: { classe: 'badge-entregue', label: 'Entregue' },
};

function badgeStatus(status) {
  const info = STATUS_INFO[status] || { classe: 'badge-inativo', label: status || '—' };
  return `<span class="badge ${info.classe}">${escaparHtml(info.label)}</span>`;
}

// ---------- Lista ----------

function renderizarLinha(pedido) {
  const itens = itensDoPedido(pedido);
  const cliente = nomeCliente(pedido);
  return `
    <div class="pedido-linha" data-id="${pedido.id}">
      <div>
        <div class="pedido-numero">${numeroCurto(pedido)}</div>
        <div class="pedido-cliente-mobile">${cliente ? escaparHtml(cliente) : 'Sem cliente'}</div>
      </div>
      <div class="pedido-meta">
        <span>${cliente ? escaparHtml(cliente) : '—'}</span>
      </div>
      <div class="pedido-meta">
        <span>${itens.length} ${itens.length === 1 ? 'item' : 'itens'}</span>
      </div>
      <div class="pedido-meta">
        <span class="pedido-total">${formatarPrecoBRL(pedido.total)}</span>
      </div>
      <div class="pedido-meta">
        ${badgeStatus(pedido.status)}
      </div>
      <div class="pedido-meta">
        <span>${formatarData(pedido.criado_em)}</span>
      </div>
      <div class="pedido-acoes">
        <button type="button" class="icon-btn" data-acao="ver" title="Ver detalhes do pedido" aria-label="Ver detalhes do pedido ${numeroCurto(pedido)}">${icone('ver')}</button>
      </div>
    </div>`;
}

function renderizarLista() {
  if (pedidosCache.length === 0) {
    mostrarSomente('estado-vazio');
    return;
  }

  listaEl.innerHTML = `
    <div class="pedido-lista">
      <div class="pedido-lista-head">
        <span>Pedido</span><span>Cliente</span><span>Itens</span><span>Total</span><span>Status</span><span>Criado em</span><span></span>
      </div>
      ${pedidosCache.map(renderizarLinha).join('')}
    </div>`;
  mostrarSomente('lista-pedidos');
}

listaEl.addEventListener('click', (evento) => {
  const linha = evento.target.closest('.pedido-linha');
  if (!linha) return;
  const pedido = pedidosCache.find((p) => p.id === linha.dataset.id);
  if (pedido) abrirDetalhesPedido(pedido);
});

// ---------- Detalhes do pedido ----------

function renderizarItemDetalhe(item) {
  const estoque = item.estoque || {};
  const produto = estoque.produtos || {};
  const nomeProduto = produto.nome || 'Produto removido';
  const variacao = [estoque.cor, estoque.tamanho].filter(Boolean).join(' / ');
  const subtotal = Number(item.preco_unitario || 0) * Number(item.quantidade || 0);
  return `
    <tr>
      <td>
        <div class="pedido-detalhe-produto">${escaparHtml(nomeProduto)}</div>
        ${variacao ? `<div class="pedido-detalhe-variacao">${escaparHtml(variacao)}</div>` : ''}
      </td>
      <td>${item.quantidade}</td>
      <td>${formatarPrecoBRL(item.preco_unitario)}</td>
      <td>${formatarPrecoBRL(subtotal)}</td>
    </tr>`;
}

function abrirDetalhesPedido(pedido) {
  const itens = itensDoPedido(pedido);
  const cliente = nomeCliente(pedido);

  const html = `
    <h2>Pedido ${numeroCurto(pedido)}</h2>
    <p>${formatarData(pedido.criado_em)} · ${badgeStatus(pedido.status)}</p>
    <div class="pedido-detalhes">
      <dl>
        <dt>Cliente</dt><dd>${cliente ? escaparHtml(cliente) : 'Sem cliente vinculado'}</dd>
      </dl>
      ${itens.length > 0 ? `
        <table class="pedido-detalhe-tabela">
          <thead>
            <tr><th>Produto</th><th>Qtd.</th><th>Preço un.</th><th>Subtotal</th></tr>
          </thead>
          <tbody>${itens.map(renderizarItemDetalhe).join('')}</tbody>
        </table>` : '<p>Nenhum item encontrado para este pedido.</p>'}
      <div class="pedido-detalhe-total">
        <span>Total</span>
        <strong>${formatarPrecoBRL(pedido.total)}</strong>
      </div>
    </div>
    <div class="modal-actions">
      <button type="button" class="btn-secondary" id="botao-fechar-detalhes">Fechar</button>
    </div>`;

  const { fechar } = abrirModal(html);
  document.getElementById('botao-fechar-detalhes').addEventListener('click', fechar);
}

// ---------- Criar pedido ----------

botaoNovoPedidoEl.addEventListener('click', () => abrirModalNovoPedido());
botaoPrimeiroPedidoEl.addEventListener('click', () => abrirModalNovoPedido());

// Carrega (uma única vez, com cache em memória) os produtos com estoque
// e os clientes da loja atual, usados para montar os seletores do
// formulário. Ambos já vêm filtrados pela loja pelo próprio backend.
async function garantirDadosDeApoio() {
  const [produtos, clientes] = await Promise.all([
    produtosCache === null ? apiFetch(`/lojas/${lojaAtualId}/produtos`) : Promise.resolve(produtosCache),
    clientesCache === null ? apiFetch(`/lojas/${lojaAtualId}/clientes`) : Promise.resolve(clientesCache),
  ]);
  produtosCache = produtos;
  clientesCache = clientes;
}

function produtosComEstoqueDisponivel() {
  return (produtosCache || []).filter((p) => p.ativo !== false && Array.isArray(p.estoque) && p.estoque.length > 0);
}

let proximoItemUid = 1;

function criarLinhaItemVazia() {
  return { uid: proximoItemUid++, produtoId: '', estoqueId: '', quantidade: 1 };
}

async function abrirModalNovoPedido() {
  if (!lojaAtualId) return;

  const textoOriginal = botaoNovoPedidoEl.textContent;
  botaoNovoPedidoEl.disabled = true;
  botaoNovoPedidoEl.textContent = 'Carregando…';
  try {
    await garantirDadosDeApoio();
  } catch (erro) {
    botaoNovoPedidoEl.disabled = false;
    botaoNovoPedidoEl.textContent = textoOriginal;
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarToast(erro.message || 'Não foi possível carregar produtos e clientes.', 'erro');
    return;
  }
  botaoNovoPedidoEl.disabled = false;
  botaoNovoPedidoEl.textContent = textoOriginal;

  const produtosDisponiveis = produtosComEstoqueDisponivel();
  let itensForm = [criarLinhaItemVazia()];

  const html = `
    <h2>Novo pedido</h2>
    <p>Selecione o cliente (opcional) e os itens do pedido. O total oficial é calculado pelo servidor.</p>
    <div id="erro-form-pedido" class="error-msg hidden" role="alert"></div>
    <form id="form-pedido" novalidate>
      <div class="field">
        <label for="campo-cliente">Cliente</label>
        <select id="campo-cliente">
          <option value="">Sem cliente</option>
          ${(clientesCache || []).map((c) => `<option value="${c.id}">${escaparHtml(c.nome)}</option>`).join('')}
        </select>
      </div>

      <div id="itens-pedido-container"></div>

      <button type="button" class="btn-secondary small" id="botao-adicionar-item" style="margin-top:4px;">+ Adicionar item</button>

      <div class="pedido-resumo" id="pedido-resumo"></div>

      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="botao-cancelar-pedido">Cancelar</button>
        <button type="submit" class="btn-primary small" id="botao-salvar-pedido">Criar pedido</button>
      </div>
    </form>`;

  const { fechar } = abrirModal(html);
  const form = document.getElementById('form-pedido');
  const itensContainerEl = document.getElementById('itens-pedido-container');
  const resumoEl = document.getElementById('pedido-resumo');
  const erroFormEl = document.getElementById('erro-form-pedido');

  document.getElementById('botao-cancelar-pedido').addEventListener('click', fechar);

  if (produtosDisponiveis.length === 0) {
    itensContainerEl.innerHTML = `<p class="aviso-em-breve">Nenhum produto com estoque cadastrado. Cadastre produtos e estoque antes de criar um pedido.</p>`;
    document.getElementById('botao-adicionar-item').classList.add('hidden');
  }

  function variacoesDoProduto(produtoId) {
    const produto = produtosDisponiveis.find((p) => p.id === produtoId);
    return produto ? produto.estoque : [];
  }

  function renderizarItens() {
    itensContainerEl.innerHTML = itensForm.map((item) => {
      const variacoes = variacoesDoProduto(item.produtoId);
      return `
        <div class="pedido-item-row" data-item-uid="${item.uid}">
          <div class="field">
            <label>Produto</label>
            <select data-role="produto">
              <option value="">Selecionar produto</option>
              ${produtosDisponiveis.map((p) => `<option value="${p.id}" ${p.id === item.produtoId ? 'selected' : ''}>${escaparHtml(p.nome)}</option>`).join('')}
            </select>
          </div>
          <div class="field">
            <label>Variação</label>
            <select data-role="variacao" ${!item.produtoId ? 'disabled' : ''}>
              <option value="">Selecionar variação</option>
              ${variacoes.map((v) => `<option value="${v.id}" ${v.id === item.estoqueId ? 'selected' : ''} ${v.quantidade <= 0 ? 'disabled' : ''}>${escaparHtml(v.cor)} / ${escaparHtml(v.tamanho)} — ${v.quantidade} em estoque</option>`).join('')}
            </select>
          </div>
          <div class="field campo-quantidade">
            <label>Quantidade</label>
            <input type="number" min="1" step="1" inputmode="numeric" data-role="quantidade" value="${item.quantidade}">
          </div>
          <button type="button" class="icon-btn perigo" data-role="remover" title="Remover item" aria-label="Remover item">${icone('lixeira')}</button>
        </div>`;
    }).join('');
    renderizarResumo();
  }

  function renderizarResumo() {
    const itensValidos = itensForm.filter((item) => item.produtoId && item.estoqueId && item.quantidade > 0);
    const totalEstimado = itensValidos.reduce((soma, item) => {
      const produto = produtosDisponiveis.find((p) => p.id === item.produtoId);
      return soma + (produto ? Number(produto.preco) * item.quantidade : 0);
    }, 0);
    const quantidadeItens = itensForm.length;
    resumoEl.innerHTML = `
      <span>${quantidadeItens} ${quantidadeItens === 1 ? 'item' : 'itens'}</span>
      <span class="pedido-resumo-total">Estimativa: ${formatarPrecoBRL(totalEstimado)}</span>`;
  }

  itensContainerEl.addEventListener('change', (evento) => {
    const linha = evento.target.closest('.pedido-item-row');
    if (!linha) return;
    const item = itensForm.find((i) => i.uid === Number(linha.dataset.itemUid));
    if (!item) return;

    const papel = evento.target.dataset.role;
    if (papel === 'produto') {
      item.produtoId = evento.target.value;
      item.estoqueId = '';
      renderizarItens();
    } else if (papel === 'variacao') {
      item.estoqueId = evento.target.value;
      renderizarResumo();
    } else if (papel === 'quantidade') {
      const valor = parseInt(evento.target.value, 10);
      item.quantidade = Number.isInteger(valor) && valor > 0 ? valor : 1;
      renderizarResumo();
    }
  });

  itensContainerEl.addEventListener('click', (evento) => {
    const botao = evento.target.closest('button[data-role="remover"]');
    if (!botao) return;
    const linha = evento.target.closest('.pedido-item-row');
    const uid = Number(linha.dataset.itemUid);
    itensForm = itensForm.filter((i) => i.uid !== uid);
    renderizarItens();
  });

  document.getElementById('botao-adicionar-item').addEventListener('click', () => {
    itensForm.push(criarLinhaItemVazia());
    renderizarItens();
  });

  renderizarItens();

  form.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    if (requisicaoEmAndamento) return;

    erroFormEl.classList.add('hidden');

    // Validação leve no frontend (quantidade inteira e maior que zero,
    // item com produto/variação selecionados). A validação de verdade —
    // estoque suficiente, propriedade do estoque/cliente, preço oficial —
    // é sempre feita pelo backend/RPC criar_pedido.
    const itensParaEnviar = [];
    for (const item of itensForm) {
      if (!item.produtoId || !item.estoqueId) {
        erroFormEl.textContent = 'Selecione produto e variação em todos os itens (ou remova o item incompleto).';
        erroFormEl.classList.remove('hidden');
        return;
      }
      if (!Number.isInteger(item.quantidade) || item.quantidade <= 0) {
        erroFormEl.textContent = 'Informe uma quantidade inteira maior que zero em todos os itens.';
        erroFormEl.classList.remove('hidden');
        return;
      }
      itensParaEnviar.push({ estoqueId: item.estoqueId, quantidade: item.quantidade });
    }

    if (itensParaEnviar.length === 0) {
      erroFormEl.textContent = 'Adicione ao menos um item ao pedido.';
      erroFormEl.classList.remove('hidden');
      return;
    }

    const clienteId = document.getElementById('campo-cliente').value || null;
    const corpo = { clienteId, itens: itensParaEnviar };

    const botaoSalvar = document.getElementById('botao-salvar-pedido');
    requisicaoEmAndamento = true;
    botaoSalvar.disabled = true;
    botaoSalvar.textContent = 'Criando…';

    try {
      await apiFetch(`/lojas/${lojaAtualId}/pedidos`, {
        method: 'POST',
        body: JSON.stringify(corpo),
      });
      // O servidor é a autoridade sobre preço/estoque/total. Em vez de
      // tentar remontar o pedido no frontend com dados parciais,
      // recarregamos a lista (já vem com cliente/produto/variação
      // enriquecidos pelo backend — ver listarPedidos).
      produtosCache = null; // estoque mudou: força recarregar na próxima abertura do modal
      mostrarToast('Pedido criado.', 'sucesso');
      fechar();
      await carregarPedidos();
    } catch (erro) {
      if (erro instanceof SessaoExpiradaError) return fazerLogout();
      erroFormEl.textContent = erro.message || 'Não foi possível criar o pedido.';
      erroFormEl.classList.remove('hidden');
    } finally {
      requisicaoEmAndamento = false;
      botaoSalvar.disabled = false;
      botaoSalvar.textContent = 'Criar pedido';
    }
  });
}

// ---------- Início ----------

montarLayout('pedidos');
carregarPedidos();

function textoValidade(valor) {
  if (!valor) return 'Sem data de expiração';
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? '—' : data.toLocaleDateString('pt-BR');
}
function limiteTexto(limite) { return limite === null ? 'Mensagens da IA ilimitadas*' : `${limite.toLocaleString('pt-BR')} mensagens da IA/mês`; }
function precoTexto(centavos) { return centavos ? (centavos / 100).toLocaleString('pt-BR', { style:'currency', currency:'BRL' }) + '/mês' : 'Preço a definir'; }

async function assinarPlano(codigo, botao) {
  try {
    botao.disabled = true; botao.textContent = 'Abrindo Asaas...';
    const loja = await obterLojaAtual();
    const dados = await apiFetch(`/lojas/${loja.id}/assinatura/checkout`, { method:'POST', body:JSON.stringify({ plano:codigo }) });
    if (!dados.checkout_url) throw new Error('Link de pagamento não recebido.');
    window.location.href = dados.checkout_url;
  } catch (e) {
    mostrarToast(e.message || 'Não foi possível iniciar o pagamento.', 'erro');
    botao.disabled = false; botao.textContent = 'Assinar com Asaas';
  }
}

async function carregarPlano() {
  const card = document.getElementById('plano-card');
  const grid = document.getElementById('planos-grid');
  const erro = document.getElementById('plano-erro');
  try {
    const loja = await obterLojaAtual();
    if (!loja) throw new Error('Nenhuma empresa selecionada.');
    const [dados, cobranca] = await Promise.all([
      apiFetch(`/lojas/${loja.id}/assinatura`),
      apiFetch(`/lojas/${loja.id}/assinatura/cobranca`),
    ]);
    const assinatura = dados.assinatura;
    const plano = dados.plano;
    const limite = plano.limiteMensagensMes;
    const percentual = limite === null ? 0 : Math.min(100, Math.round((dados.usadoNoMes / Math.max(1, limite)) * 100));
    card.innerHTML = `
      <div class="billing-head"><div><span class="billing-kicker">Plano atual</span><h2>${plano.nome}</h2></div><span class="badge ${dados.ativo ? 'badge-green' : 'badge-red'}">${dados.statusEfetivo.replace('_', ' ')}</span></div>
      <div class="billing-metrics"><div><strong>${dados.usadoNoMes.toLocaleString('pt-BR')}</strong><span>mensagens da IA usadas neste mês</span></div><div><strong>${limiteTexto(limite)}</strong><span>franquia mensal</span></div><div><strong>${textoValidade(assinatura?.valido_ate)}</strong><span>validade</span></div></div>
      ${limite === null ? '' : `<div class="usage-track"><div class="usage-fill" style="width:${percentual}%"></div></div><p class="billing-note">Restam ${dados.restanteNoMes.toLocaleString('pt-BR')} mensagens da IA nesta franquia mensal.</p>`}
      ${dados.motivoBloqueio ? `<div class="billing-warning">Atendimento bloqueado: ${dados.motivoBloqueio === 'limite_mensal_atingido' ? 'limite mensal atingido' : 'assinatura inativa ou expirada'}.</div>` : ''}`;
    grid.innerHTML = dados.planosDisponiveis.map((p) => {
      const podeComprar = p.vendavel && p.precoMensalCentavos && cobranca.configurado;
      return `<article class="plan-mini"><strong>${p.nome}</strong><span>${limiteTexto(p.limiteMensagensMes)}</span><span>${precoTexto(p.precoMensalCentavos)}</span>${p.descricao ? `<small>${p.descricao}</small>` : ''}${p.codigo === 'ilimitado' ? '<small>*Uso justo se aplica.</small>' : ''}${p.vendavel ? `<button class="btn-primary small" data-assinar="${p.codigo}" ${podeComprar?'':'disabled'}>${cobranca.configurado ? (p.precoMensalCentavos ? 'Assinar com Asaas' : 'Preço não configurado') : 'Asaas não configurado'}</button>` : ''}</article>`;
    }).join('');
    grid.querySelectorAll('[data-assinar]').forEach((btn) => btn.addEventListener('click', () => assinarPlano(btn.dataset.assinar, btn)));
  } catch (e) {
    if (e instanceof SessaoExpiradaError) return fazerLogout();
    erro.textContent = e.message || 'Não foi possível carregar o plano.'; erro.classList.remove('hidden');
    card.innerHTML = '';
  }
}
montarLayout('plano');
carregarPlano();

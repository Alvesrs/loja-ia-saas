let waLojaId = null;
let waConfiguracao = null;
let waConversas = [];

const waAlerta = document.getElementById('whatsapp-alerta');
const waStatus = document.getElementById('wa-status');
const waCredStatus = document.getElementById('wa-cred-status');
const waNumero = document.getElementById('wa-numero');
const waPhoneId = document.getElementById('wa-phone-id');
const waAtivo = document.getElementById('wa-ativo');
const waToken = document.getElementById('wa-token');

function waEscapar(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML;
}

function waData(valor) {
  if (!valor) return '—';
  try { return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(valor)); }
  catch { return '—'; }
}

function waErro(mensagem) {
  waAlerta.textContent = mensagem;
  waAlerta.classList.remove('hidden');
}
function waLimparErro() { waAlerta.classList.add('hidden'); waAlerta.textContent = ''; }

function waAtualizarStatusConfig() {
  const ativa = Boolean(waConfiguracao && waConfiguracao.ativo);
  waStatus.textContent = waConfiguracao ? (ativa ? 'Ativo' : 'Inativo') : 'Não configurado';
  waStatus.className = `badge ${ativa ? 'badge-ativo' : 'badge-inativo'}`;
  document.getElementById('wa-desativar').classList.toggle('hidden', !waConfiguracao || !ativa);
}

async function waCarregarCredencial() {
  if (!waConfiguracao) {
    waCredStatus.textContent = 'Configure a conexão primeiro';
    waCredStatus.className = 'badge badge-inativo';
    document.getElementById('wa-form-token').querySelectorAll('input,button').forEach((el) => { el.disabled = true; });
    return;
  }
  document.getElementById('wa-form-token').querySelectorAll('input,button').forEach((el) => { el.disabled = false; });
  const estado = await apiFetch(`/lojas/${waLojaId}/whatsapp/${waConfiguracao.id}/credencial`);
  const ok = Boolean(estado && estado.credencial_configurada);
  waCredStatus.textContent = ok ? 'Configurada' : 'Ausente';
  waCredStatus.className = `badge ${ok ? 'badge-ativo' : 'badge-inativo'}`;
  document.getElementById('wa-remover-token').classList.toggle('hidden', !ok);
}

async function waCarregarConfiguracao() {
  const configs = await apiFetch(`/lojas/${waLojaId}/whatsapp`);
  waConfiguracao = Array.isArray(configs)
    ? (configs.find((c) => c.provedor === 'meta' && c.ativo) || configs.find((c) => c.provedor === 'meta') || null)
    : null;
  if (waConfiguracao) {
    waNumero.value = waConfiguracao.numero_whatsapp || '';
    waPhoneId.value = waConfiguracao.identificador_externo || '';
    waAtivo.checked = Boolean(waConfiguracao.ativo);
  }
  waAtualizarStatusConfig();
  await waCarregarCredencial();
}

async function waSalvarConfiguracao(evento) {
  evento.preventDefault();
  waLimparErro();
  const numero = waNumero.value.trim();
  const identificador = waPhoneId.value.trim();
  if (!numero || !identificador) return waErro('Informe o número do WhatsApp e o Phone Number ID da Meta.');
  const body = { provedor: 'meta', numero_whatsapp: numero, identificador_externo: identificador, ativo: waAtivo.checked };
  const botao = document.getElementById('wa-salvar-config');
  botao.disabled = true;
  try {
    waConfiguracao = waConfiguracao
      ? await apiFetch(`/lojas/${waLojaId}/whatsapp/${waConfiguracao.id}`, { method: 'PATCH', body: JSON.stringify(body) })
      : await apiFetch(`/lojas/${waLojaId}/whatsapp`, { method: 'POST', body: JSON.stringify(body) });
    waAtualizarStatusConfig();
    await waCarregarCredencial();
    mostrarToast('Configuração do WhatsApp salva.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    waErro(erro.message || 'Não foi possível salvar a configuração.');
  } finally { botao.disabled = false; }
}

async function waSalvarToken(evento) {
  evento.preventDefault();
  if (!waConfiguracao) return;
  waLimparErro();
  const token = waToken.value.trim();
  if (!token) return waErro('Cole um access token antes de salvar.');
  const botao = document.getElementById('wa-salvar-token');
  botao.disabled = true;
  try {
    await apiFetch(`/lojas/${waLojaId}/whatsapp/${waConfiguracao.id}/credencial`, { method: 'PUT', body: JSON.stringify({ access_token: token }) });
    waToken.value = '';
    await waCarregarCredencial();
    mostrarToast('Credencial salva com segurança.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    waErro(erro.message || 'Não foi possível salvar a credencial.');
  } finally { botao.disabled = false; }
}

async function waRemoverToken() {
  if (!waConfiguracao) return;
  const ok = await confirmar({ titulo: 'Remover credencial?', mensagem: 'O WhatsApp deixará de conseguir enviar novas respostas até um token válido ser cadastrado novamente.', textoConfirmar: 'Remover', perigo: true });
  if (!ok) return;
  try {
    await apiFetch(`/lojas/${waLojaId}/whatsapp/${waConfiguracao.id}/credencial`, { method: 'DELETE' });
    waToken.value = '';
    await waCarregarCredencial();
    mostrarToast('Credencial removida.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    waErro(erro.message || 'Não foi possível remover a credencial.');
  }
}

async function waDesativar() {
  if (!waConfiguracao) return;
  const ok = await confirmar({ titulo: 'Desativar WhatsApp?', mensagem: 'Novos eventos não serão resolvidos para esta configuração enquanto ela estiver inativa.', textoConfirmar: 'Desativar', perigo: true });
  if (!ok) return;
  try {
    waConfiguracao = await apiFetch(`/lojas/${waLojaId}/whatsapp/${waConfiguracao.id}/desativar`, { method: 'POST' });
    waAtivo.checked = false;
    waAtualizarStatusConfig();
    mostrarToast('Configuração desativada.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    waErro(erro.message || 'Não foi possível desativar.');
  }
}

function waRenderConversas() {
  const el = document.getElementById('wa-conversas');
  if (!waConversas.length) {
    el.innerHTML = '<div class="state-box"><p class="state-title">Nenhuma conversa ainda</p><p>As conversas aparecerão depois que mensagens reais forem processadas.</p></div>';
    return;
  }
  el.innerHTML = waConversas.map((c) => `<button type="button" class="wa-conversa-item" data-conversa-id="${waEscapar(c.id)}"><strong>${waEscapar(c.contato)}</strong><span>${waData(c.atualizado_em)}</span></button>`).join('');
}

async function waCarregarConversas() {
  const el = document.getElementById('wa-conversas');
  el.innerHTML = '<div class="state-box"><p>Carregando conversas…</p></div>';
  try {
    waConversas = await apiFetch(`/lojas/${waLojaId}/whatsapp/historico/conversas`);
    waRenderConversas();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    el.innerHTML = '<div class="state-box"><p class="state-title">Histórico indisponível</p><p>Tente atualizar novamente.</p></div>';
  }
}

async function waAbrirConversa(conversaId) {
  const el = document.getElementById('wa-mensagens');
  el.innerHTML = '<div class="state-box"><p>Carregando mensagens…</p></div>';
  document.querySelectorAll('.wa-conversa-item').forEach((item) => item.classList.toggle('active', item.dataset.conversaId === conversaId));
  try {
    const mensagens = await apiFetch(`/lojas/${waLojaId}/whatsapp/historico/conversas/${encodeURIComponent(conversaId)}/mensagens`);
    if (!mensagens.length) {
      el.innerHTML = '<div class="state-box"><p>Nenhuma mensagem persistida nesta conversa.</p></div>';
      return;
    }
    el.innerHTML = mensagens.map((m) => `<div class="wa-msg ${m.direcao === 'saida' ? 'saida' : 'entrada'}"><div>${waEscapar(m.texto)}</div><small>${m.direcao === 'saida' ? 'IA → cliente' : 'Cliente → IA'} · ${waData(m.criado_em)}</small></div>`).join('');
    el.scrollTop = el.scrollHeight;
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    el.innerHTML = '<div class="state-box"><p>Não foi possível carregar as mensagens.</p></div>';
  }
}

async function waInicializar() {
  montarLayout('whatsapp');
  try {
    const loja = await obterLojaAtual();
    if (!loja) return waErro('Nenhuma loja encontrada para este usuário.');
    waLojaId = loja.id;
    const url = `${window.location.origin}/api/webhooks/whatsapp`;
    document.getElementById('wa-webhook-url').textContent = url;
    await Promise.all([waCarregarConfiguracao(), waCarregarConversas()]);
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    waErro(erro.message || 'Não foi possível carregar o painel do WhatsApp.');
  }
}

document.getElementById('wa-form-config').addEventListener('submit', waSalvarConfiguracao);
document.getElementById('wa-form-token').addEventListener('submit', waSalvarToken);
document.getElementById('wa-remover-token').addEventListener('click', waRemoverToken);
document.getElementById('wa-desativar').addEventListener('click', waDesativar);
document.getElementById('wa-atualizar-conversas').addEventListener('click', waCarregarConversas);
document.getElementById('wa-conversas').addEventListener('click', (evento) => {
  const item = evento.target.closest('[data-conversa-id]');
  if (item) waAbrirConversa(item.dataset.conversaId);
});
document.getElementById('wa-copiar-webhook').addEventListener('click', async () => {
  const texto = document.getElementById('wa-webhook-url').textContent;
  try { await navigator.clipboard.writeText(texto); mostrarToast('URL do webhook copiada.', 'sucesso'); }
  catch { mostrarToast('Não foi possível copiar automaticamente.', 'erro'); }
});

waInicializar();

const onbNome = document.getElementById('onb-nome');
const onbPrompt = document.getElementById('onb-prompt');
const onbContador = document.getElementById('onb-contador');
const onbConectarWa = document.getElementById('onb-conectar-wa');
const onbWaCampos = document.getElementById('onb-wa-campos');
const onbNumero = document.getElementById('onb-numero');
const onbPhoneId = document.getElementById('onb-phone-id');
const onbToken = document.getElementById('onb-token');
const onbAlerta = document.getElementById('onboarding-alerta');
const onbFinalizar = document.getElementById('onb-finalizar');

const MODELO_ONBOARDING = `Você é o atendente virtual oficial deste negócio.\n\nOBJETIVO\n- Atenda clientes pelo WhatsApp de forma natural, útil e objetiva.\n\nSOBRE O NEGÓCIO\n- Descreva aqui produtos/serviços, público, localização e diferenciais.\n\nHORÁRIOS E EXCEÇÕES\n- Informe o horário oficial e qualquer exceção real.\n- Nunca garanta uma exceção que dependa de disponibilidade.\n\nREGRAS COMERCIAIS\n- Informe pagamentos, entrega, retirada, prazos, garantia e outras políticas.\n\nESTILO DE ATENDIMENTO\n- Responda em português do Brasil.\n- Seja cordial e direto.\n- Não invente informações.\n- Quando faltar informação, diga que precisa confirmar.\n\nSITUAÇÕES ESPECIAIS\n- Descreva aqui tudo que foge da regra normal e como a IA deve responder.`;

function onbErro(mensagem) {
  onbAlerta.textContent = mensagem;
  onbAlerta.classList.remove('hidden');
  onbAlerta.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function onbLimparErro() { onbAlerta.textContent = ''; onbAlerta.classList.add('hidden'); }
function onbAtualizarContador() { onbContador.textContent = String(onbPrompt.value.length); }

onbPrompt.addEventListener('input', onbAtualizarContador);
onbConectarWa.addEventListener('change', () => onbWaCampos.classList.toggle('hidden', !onbConectarWa.checked));
document.getElementById('onb-modelo').addEventListener('click', async () => {
  if (onbPrompt.value.trim()) {
    const ok = await confirmar({ titulo: 'Substituir a prompt atual?', mensagem: 'O modelo base substituirá o texto que está no editor.', textoConfirmar: 'Substituir' });
    if (!ok) return;
  }
  onbPrompt.value = MODELO_ONBOARDING;
  onbAtualizarContador();
  onbPrompt.focus();
});

async function criarOnboarding() {
  onbLimparErro();
  const nome = onbNome.value.trim();
  const prompt_mestre = onbPrompt.value.trim();
  if (!nome) return onbErro('Informe o nome da empresa.');
  if (!prompt_mestre) return onbErro('Cole ou escreva a Prompt Mestre da empresa.');

  if (onbConectarWa.checked) {
    if (!onbNumero.value.trim() || !onbPhoneId.value.trim() || !onbToken.value.trim()) {
      return onbErro('Para conectar o WhatsApp agora, preencha número, Phone Number ID e access token.');
    }
  }

  onbFinalizar.disabled = true;
  onbFinalizar.textContent = 'Criando…';
  let loja = null;
  try {
    loja = await apiFetch('/lojas', { method: 'POST', body: JSON.stringify({ nome, prompt_mestre }) });
    salvarLojaAtual(loja);

    if (onbConectarWa.checked) {
      const config = await apiFetch(`/lojas/${loja.id}/whatsapp`, {
        method: 'POST',
        body: JSON.stringify({
          provedor: 'meta',
          numero_whatsapp: onbNumero.value.trim(),
          identificador_externo: onbPhoneId.value.trim(),
          ativo: true,
        }),
      });
      await apiFetch(`/lojas/${loja.id}/whatsapp/${config.id}/credencial`, {
        method: 'PUT',
        body: JSON.stringify({ access_token: onbToken.value.trim() }),
      });
      onbToken.value = '';
    }

    mostrarToast('Empresa criada e selecionada.', 'sucesso');
    window.location.href = onbConectarWa.checked ? 'whatsapp.html' : 'atendente.html';
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    if (loja) {
      onbErro(`A empresa foi criada, mas a conexão do WhatsApp não terminou: ${erro.message || 'erro inesperado'}. Você pode continuar pela tela WhatsApp.`);
      salvarLojaAtual(loja);
    } else {
      onbErro(erro.message || 'Não foi possível criar a empresa.');
    }
  } finally {
    onbFinalizar.disabled = false;
    onbFinalizar.textContent = 'Criar empresa';
  }
}

onbFinalizar.addEventListener('click', criarOnboarding);
montarLayout('onboarding');
onbAtualizarContador();

// Componentes reutilizáveis usados pelas páginas administrativas
// (Produtos e, futuramente, Estoque/Clientes/Pedidos): toast de
// feedback, diálogo de confirmação e um modal genérico. Evita alert()
// cru do navegador.

function garantirContainerToast() {
  let el = document.getElementById('toast-container');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast-container';
    el.className = 'toast-container';
    document.body.appendChild(el);
  }
  return el;
}

function mostrarToast(mensagem, tipo = 'sucesso') {
  const container = garantirContainerToast();
  const toast = document.createElement('div');
  toast.className = `toast toast-${tipo}`;
  toast.setAttribute('role', 'status');
  toast.textContent = mensagem;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('visivel'));

  setTimeout(() => {
    toast.classList.remove('visivel');
    setTimeout(() => toast.remove(), 200);
  }, 3200);
}

function confirmar({ titulo, mensagem, textoConfirmar = 'Confirmar', perigo = false }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box modal-confirm" role="alertdialog" aria-modal="true" aria-labelledby="confirm-titulo">
        <h2 id="confirm-titulo">${titulo}</h2>
        <p>${mensagem}</p>
        <div class="modal-actions">
          <button type="button" class="btn-secondary" data-acao="cancelar">Cancelar</button>
          <button type="button" class="${perigo ? 'btn-danger' : 'btn-primary'}" data-acao="confirmar">${textoConfirmar}</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    function fechar(resultado) {
      overlay.remove();
      document.removeEventListener('keydown', aoTeclar);
      resolve(resultado);
    }

    function aoTeclar(evento) {
      if (evento.key === 'Escape') fechar(false);
    }

    overlay.addEventListener('click', (evento) => {
      if (evento.target === overlay) fechar(false);
    });
    overlay.querySelector('[data-acao="cancelar"]').addEventListener('click', () => fechar(false));
    overlay.querySelector('[data-acao="confirmar"]').addEventListener('click', () => fechar(true));
    document.addEventListener('keydown', aoTeclar);

    overlay.querySelector('[data-acao="confirmar"]').focus();
  });
}

// Modal genérico para formulários (usado pelo form de produto).
// `conteudoHtml` é o miolo do modal; o chamador cuida de wire-up dos
// próprios campos/eventos depois que o modal é inserido no DOM.
function abrirModal(conteudoHtml, { aoFechar } = {}) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal-box">${conteudoHtml}</div>`;
  document.body.appendChild(overlay);

  function fechar() {
    overlay.remove();
    document.removeEventListener('keydown', aoTeclar);
    if (aoFechar) aoFechar();
  }

  function aoTeclar(evento) {
    if (evento.key === 'Escape') fechar();
  }

  overlay.addEventListener('click', (evento) => {
    if (evento.target === overlay) fechar();
  });
  document.addEventListener('keydown', aoTeclar);

  return { overlay, fechar };
}

// ---------- Preço ----------

function formatarPrecoBRL(valor) {
  const numero = Number(valor);
  if (!Number.isFinite(numero)) return '—';
  return numero.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Converte o texto digitado (aceita "," ou "." como separador decimal)
// em número. Retorna null se não for um valor válido.
function interpretarPrecoDigitado(texto) {
  if (typeof texto !== 'string') return null;
  const limpo = texto.trim().replace(/\./g, '').replace(',', '.');
  // Se não havia vírgula, o replace acima pode ter removido separadores
  // de milhar de um número com ponto decimal único (ex: "19.90"). Nesse
  // caso, o texto original já era um número válido em formato "en".
  const candidato = texto.includes(',') ? limpo : texto.trim();
  const numero = Number(candidato);
  if (!Number.isFinite(numero) || numero < 0) return null;
  return Math.round(numero * 100) / 100;
}

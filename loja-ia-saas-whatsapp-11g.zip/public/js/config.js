// O painel é servido pelo mesmo servidor Express que expõe a API
// (ver app.use('/painel', ...) em src/app.js), então as chamadas usam
// caminho relativo '/api/...' e não precisam de configuração de CORS
// nem de URL fixa.
const API_BASE = '/api';

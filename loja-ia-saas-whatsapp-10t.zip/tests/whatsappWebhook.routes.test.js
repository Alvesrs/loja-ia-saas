/**
 * Testes da FIAÇÃO da rota do webhook de WhatsApp
 * (src/routes/whatsappWebhook.routes.js) e do seu registro em src/app.js.
 *
 * Etapa 10D. Não abre servidor, não usa rede e nem precisa do pacote
 * "express" instalado: usa um express/cors FALSOS (tests/helpers/
 * mockExpressModule.js) que apenas registram como o código os utilizou.
 *
 * VERIFICA: caminho e método, ordem dos middlewares, ausência de login,
 * opções do parser JSON (limite de 100kb, corpo bruto preservado), rate
 * limiter específico, tratador de erros da rota, e onde a rota fica montada
 * em app.js sem alterar as demais.
 * NÃO VERIFICA: o comportamento interno do Express/body-parser (parse real
 * do JSON, 413 real). Isso depende dos pacotes reais — ver o teste manual
 * sugerido em docs/ARQUITETURA.md.
 *
 * Cobre o cenário N (rota não exige login do painel) e complementa J
 * (limite de tamanho) e K/L (sem rede/LLM) dos testes do controller.
 *
 * Rodar com: node --test tests/whatsappWebhook.routes.test.js
 */
const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');

const { instalarMockSupabaseJs } = require('./helpers/mockSupabaseModule');
const { instalarMockExpress } = require('./helpers/mockExpressModule');
const { criarResMock } = require('./helpers/httpMocks');
instalarMockSupabaseJs();
instalarMockExpress();

const { receberEvento, tratarErroDeRequisicao } = require('../src/controllers/whatsappWebhook.controller');
const { exigirLogin } = require('../src/middleware/auth');
const { exigirDonoDaLoja, exigirProdutoDaLoja } = require('../src/middleware/lojaOwnership');
const { segurancaHeaders } = require('../src/middleware/segurancaHeaders');
const { verificarAssinaturaWebhook } = require('../src/middleware/webhookAssinatura');

const RAIZ = path.join(__dirname, '..');
const CAMINHO_ROTA = require.resolve('../src/routes/whatsappWebhook.routes');

// Recarrega o arquivo de rota com variáveis de ambiente específicas (o
// limitador lê o ambiente ao ser criado) e restaura o ambiente depois.
function carregarRotaComAmbiente(ambiente = {}) {
  const chaves = ['WHATSAPP_WEBHOOK_RATE_LIMIT_MAX', 'WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS'];
  const anterior = Object.fromEntries(chaves.map((c) => [c, process.env[c]]));
  for (const c of chaves) delete process.env[c];
  Object.assign(process.env, ambiente);
  delete require.cache[CAMINHO_ROTA];
  try {
    return require(CAMINHO_ROTA);
  } finally {
    for (const c of chaves) {
      if (anterior[c] === undefined) delete process.env[c];
      else process.env[c] = anterior[c];
    }
    delete require.cache[CAMINHO_ROTA];
  }
}

function semComentarios(codigo) {
  return codigo.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`])\/\/.*$/gm, '$1');
}

function lerCodigo(arquivoRelativo) {
  return semComentarios(fs.readFileSync(path.join(RAIZ, arquivoRelativo), 'utf8'));
}

// ---------------------------------------------------------------
// Rota: caminho, método e cadeia de middlewares
// ---------------------------------------------------------------
test('rota: POST mantém a cadeia limitador → parser JSON → assinatura Meta → controller e GET expõe o handshake', () => {
  const roteador = carregarRotaComAmbiente();

  assert.equal(roteador.rotas.length, 2, 'POST de eventos + GET de verificação');
  const [rota, rotaGet] = roteador.rotas;
  assert.equal(rota.metodo, 'post');
  assert.equal(rota.caminho, '/');

  // Atualizado na Etapa 10E: a verificação de assinatura HMAC entra entre o
  // parser e o controller (detalhes em tests/whatsappWebhookAssinatura.test.js).
  assert.equal(rota.handlers.length, 4);
  const [limitador, parser, verificacao, controller] = rota.handlers;
  assert.equal(typeof limitador, 'function');
  assert.equal(limitador.name, 'rateLimiter');
  assert.equal(parser.tipo, 'json');
  assert.equal(verificacao, verificarAssinaturaWebhook);
  assert.equal(controller, receberEvento);

  assert.equal(rotaGet.metodo, 'get');
  assert.equal(rotaGet.caminho, '/');
  assert.equal(rotaGet.handlers.length, 2);
  assert.equal(rotaGet.handlers[0], limitador, 'GET reutiliza o mesmo rate limiter');
  assert.equal(typeof rotaGet.handlers[1], 'function');
});

test('rota: o tratador de erros da rota (corpo grande, JSON inválido) está registrado depois da rota', () => {
  const roteador = carregarRotaComAmbiente();

  assert.equal(roteador.usos.length, 1);
  const [{ caminho, handlers }] = roteador.usos;
  assert.equal(caminho, undefined);
  assert.deepEqual(handlers, [tratarErroDeRequisicao]);
  assert.equal(tratarErroDeRequisicao.length, 4, 'middleware de erro do Express precisa de 4 argumentos');
});

// ---------------------------------------------------------------
// N) rota não exige login do painel
// ---------------------------------------------------------------
test('N) a rota NÃO usa login do painel nem posse de loja, e não tem :lojaId no caminho', () => {
  const roteador = carregarRotaComAmbiente();

  const todos = [...roteador.rotas.flatMap((r) => r.handlers), ...roteador.usos.flatMap((u) => u.handlers)];
  for (const proibido of [exigirLogin, exigirDonoDaLoja, exigirProdutoDaLoja]) {
    assert.equal(todos.includes(proibido), false);
  }
  assert.equal(roteador.rotas[0].caminho.includes(':'), false, 'sem parâmetro de loja no caminho');
  assert.equal(roteador.opcoes, undefined, 'sem mergeParams: nada de :lojaId herdado');

  for (const arquivo of ['src/routes/whatsappWebhook.routes.js', 'src/controllers/whatsappWebhook.controller.js']) {
    const codigo = lerCodigo(arquivo);
    assert.equal(/middleware\/auth|lojaOwnership|exigirLogin|exigirDonoDaLoja|req\.usuario|authorization/i.test(codigo), false, `${arquivo} não pode depender de login`);
  }
});

test('N) em app.js nenhum middleware de login/posse é aplicado antes do webhook', () => {
  const app = carregarApp();
  const indiceWebhook = app.usos.findIndex((u) => u.caminho === '/api/webhooks/whatsapp');
  assert.ok(indiceWebhook > 0);

  for (const uso of app.usos.slice(0, indiceWebhook)) {
    for (const handler of uso.handlers) {
      assert.notEqual(handler, exigirLogin);
      assert.notEqual(handler, exigirDonoDaLoja);
    }
  }
});

// ---------------------------------------------------------------
// J) limite de tamanho do body
// ---------------------------------------------------------------
test('J) o parser JSON da rota tem limite de 100kb e guarda o corpo bruto para a futura verificação de assinatura', () => {
  const roteador = carregarRotaComAmbiente();
  const parser = roteador.rotas[0].handlers[1];

  assert.equal(parser.opcoes.limit, '100kb');
  assert.equal(typeof parser.opcoes.verify, 'function');

  const req = {};
  const bruto = Buffer.from('{"texto":"oi"}');
  parser.opcoes.verify(req, {}, bruto);
  assert.equal(req.corpoBruto, bruto, 'bytes originais preservados em req.corpoBruto');
});

test('J) o limite da rota é o mesmo do parser global do app (100kb)', () => {
  const app = carregarApp();
  const parserGlobal = app.usos.find((u) => u.handlers.some((h) => h.tipo === 'json')).handlers.find((h) => h.tipo === 'json');
  const parserDaRota = carregarRotaComAmbiente().rotas[0].handlers[1];
  assert.equal(parserGlobal.opcoes.limit, '100kb');
  assert.equal(parserDaRota.opcoes.limit, parserGlobal.opcoes.limit);
});

// ---------------------------------------------------------------
// Rate limiting específico
// ---------------------------------------------------------------
function chamarLimitador(limitador, ip) {
  const req = { ip };
  const res = criarResMock();
  let passou = false;
  limitador(req, res, () => { passou = true; });
  return { passou, res };
}

test('rate limit: o webhook usa o limitador do projeto com limite próprio, configurável por ambiente', () => {
  const roteador = carregarRotaComAmbiente({ WHATSAPP_WEBHOOK_RATE_LIMIT_MAX: '2', WHATSAPP_WEBHOOK_RATE_LIMIT_JANELA_MS: '60000' });
  const limitador = roteador.rotas[0].handlers[0];

  assert.equal(chamarLimitador(limitador, '198.51.100.7').passou, true);
  assert.equal(chamarLimitador(limitador, '198.51.100.7').passou, true);

  const bloqueada = chamarLimitador(limitador, '198.51.100.7');
  assert.equal(bloqueada.passou, false);
  assert.equal(bloqueada.res.statusCode, 429);
  assert.deepEqual(bloqueada.res.body, { erro: 'Muitas requisições em pouco tempo. Tente novamente em instantes.' });
  assert.ok(Number(bloqueada.res.headers['Retry-After']) >= 1);

  // Outro IP não é afetado (a chave padrão é req.ip).
  assert.equal(chamarLimitador(limitador, '198.51.100.8').passou, true);
});

test('rate limit: sem variáveis de ambiente, o padrão é generoso (300 por minuto) e separado do limitador do login/IA', () => {
  const roteador = carregarRotaComAmbiente();
  const limitador = roteador.rotas[0].handlers[0];

  for (let i = 0; i < 300; i += 1) {
    assert.equal(chamarLimitador(limitador, '203.0.113.50').passou, true, `requisição ${i + 1}`);
  }
  assert.equal(chamarLimitador(limitador, '203.0.113.50').res.statusCode, 429);

  // Instância própria: outra carga do arquivo cria outro contador, sem misturar com este.
  const outra = carregarRotaComAmbiente().rotas[0].handlers[0];
  assert.equal(chamarLimitador(outra, '203.0.113.50').passou, true);
});

test('rate limit: o limitador vem ANTES do parser (excesso é barrado sem ler o corpo)', () => {
  const { handlers } = carregarRotaComAmbiente().rotas[0];
  const posicaoLimitador = handlers.findIndex((h) => h.name === 'rateLimiter');
  const posicaoParser = handlers.findIndex((h) => h.tipo === 'json');
  assert.equal(posicaoLimitador, 0);
  assert.equal(posicaoParser, 1);
  assert.equal(posicaoLimitador < posicaoParser, true);
});

// ---------------------------------------------------------------
// Registro em src/app.js
// ---------------------------------------------------------------
function carregarApp() {
  const caminhoApp = require.resolve('../src/app');
  delete require.cache[caminhoApp];
  return require(caminhoApp);
}

test('app.js: monta o webhook em /api/webhooks/whatsapp, depois de CORS e headers de segurança e antes do parser JSON global', () => {
  const app = carregarApp();

  const caminhos = app.usos.map((u) => u.caminho);
  assert.deepEqual(caminhos, [
    undefined, // cors
    undefined, // headers de segurança
    '/api/webhooks/whatsapp', // NOVO (10D)
    undefined, // parser JSON global
    '/api/health', // 10R: healthchecks de produção
    '/api/auth',
    '/api/lojas',
    '/api/lojas/:lojaId/produtos',
    '/api/lojas/:lojaId/clientes',
    '/api/lojas/:lojaId/pedidos',
    '/api/lojas/:lojaId/ia',
    '/api/lojas/:lojaId/whatsapp',
    '/painel',
    '/politica-de-privacidade',
    '/exclusao-de-dados',
    undefined, // 404
    undefined, // tratador de erros global
  ]);

  assert.equal(app.usos[0].handlers[0].tipo, 'cors');
  assert.equal(app.usos[1].handlers[0], segurancaHeaders);
  assert.equal(app.usos[3].handlers[0].tipo, 'json');
  assert.equal(app.usos[3].handlers[0].opcoes.limit, '100kb', 'parser global inalterado');

  // O que foi montado no caminho do webhook é o roteador do arquivo de rota.
  const roteadorMontado = app.usos[2].handlers[0];
  assert.equal(roteadorMontado.tipo, 'router');
  assert.equal(roteadorMontado.rotas[0].caminho, '/');
  assert.equal(roteadorMontado.rotas[0].metodo, 'post');
  assert.equal(roteadorMontado.rotas[0].handlers.at(-1), receberEvento);
});

test('app.js: as demais rotas continuam iguais (healthcheck, x-powered-by, sem servidor aberto)', () => {
  const app = carregarApp();
  assert.deepEqual(app.rotas.map((r) => [r.metodo, r.caminho]), [['get', '/']]);
  assert.deepEqual(app.desabilitados, ['x-powered-by']);
});

test('nenhuma outra rota existente referencia o webhook', () => {
  const pastaRotas = path.join(RAIZ, 'src/routes');
  for (const arquivo of fs.readdirSync(pastaRotas)) {
    if (arquivo === 'whatsappWebhook.routes.js') continue;
    const codigo = fs.readFileSync(path.join(pastaRotas, arquivo), 'utf8');
    assert.equal(/webhook/i.test(codigo), false, `${arquivo} não deve referenciar o webhook`);
  }
});

// ---------------------------------------------------------------
// Estático: a rota só liga HTTP ao controller
// ---------------------------------------------------------------
test('estático) a rota não acessa banco, service, rede nem provedor: só express, limitador, verificação de assinatura e controller', () => {
  const codigo = lerCodigo('src/routes/whatsappWebhook.routes.js');

  const dependencias = [...codigo.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]).sort();
  assert.deepEqual(dependencias, ['../controllers/whatsappWebhook.controller', '../middleware/rateLimiter', '../middleware/webhookAssinatura', 'express']);

  assert.equal(/\bfetch\s*\(|https?:\/\/|XMLHttpRequest|axios/i.test(codigo), false);
  assert.equal(/twilio|z-?api|evolution|graph\.facebook|\bmeta\b/i.test(codigo), false);
  assert.equal(/supabase|whatsappWebhook\.service|whatsappConfiguracao|loja_id|lojaId|configuracaoId/.test(codigo), false);
  assert.equal(/\.listen\(/.test(codigo), false, 'a rota não abre servidor');
});

test('estático) nenhum token/segredo/URL de provedor foi adicionado nos arquivos novos', () => {
  for (const arquivo of ['src/routes/whatsappWebhook.routes.js', 'src/controllers/whatsappWebhook.controller.js']) {
    const codigo = lerCodigo(arquivo);
    assert.equal(/Bearer\s|sk-[A-Za-z0-9]|EAA[A-Za-z0-9]{6,}|api[_-]?key\s*[:=]\s*['"]/i.test(codigo), false, arquivo);
    assert.equal(/https?:\/\//i.test(codigo), false, arquivo);
  }
});

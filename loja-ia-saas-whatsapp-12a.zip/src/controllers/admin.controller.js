const supabase = require('../config/supabase');
const { usuarioEhAdmin } = require('../middleware/admin');
const { listarPlanos } = require('../config/planos');
const { obterSituacaoPlano, definirAssinatura } = require('../services/assinaturas.service');
const { ehUuid } = require('../utils/validacao');

async function me(req, res) {
  return res.json({ admin: usuarioEhAdmin(req.usuario) });
}

async function listarEmpresas(req, res) {
  try {
    const pagina = Number(req.query?.pagina || 1);
    const busca = String(req.query?.busca || '').trim();
    if (!Number.isSafeInteger(pagina) || pagina < 1 || pagina > 100000 || busca.length > 100) {
      return res.status(400).json({ erro: 'Página ou busca inválida.' });
    }
    const tamanho = 20;
    let consulta = supabase.from('lojas').select('id, nome, ativa, criado_em', { count: 'exact' });
    // Busca literal, sem curingas fornecidos pelo cliente.
    if (busca) consulta = consulta.ilike('nome', '%' + busca.replace(/[\\%_]/g, '\\$&') + '%');
    const { data: lojas, error, count } = await consulta
      .order('criado_em', { ascending: false }).order('id', { ascending: true })
      .range((pagina - 1) * tamanho, pagina * tamanho - 1);
    if (error) throw error;
    const empresas = [];
    for (let i = 0; i < (lojas || []).length; i += 5) {
      const lote = await Promise.all(lojas.slice(i, i + 5).map(async (loja) => ({
        loja, situacao: await obterSituacaoPlano(loja.id),
      })));
      empresas.push(...lote);
    }
    return res.json({ empresas, planosDisponiveis: listarPlanos(), pagina,
      total: count || 0, totalPaginas: Math.ceil((count || 0) / tamanho) });
  } catch (erro) {
    console.error('[admin] falha ao listar empresas:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Não foi possível carregar as empresas.' });
  }
}

async function atualizarAssinatura(req, res) {
  const { lojaId } = req.params;
  const { plano, status, valido_ate } = req.body || {};
  if (!ehUuid(lojaId)) return res.status(400).json({ erro: 'Identificador de loja inválido.' });

  const { data: loja, error } = await supabase.from('lojas').select('id').eq('id', lojaId).maybeSingle();
  if (error) return res.status(500).json({ erro: 'Não foi possível consultar a empresa.' });
  if (!loja) return res.status(404).json({ erro: 'Empresa não encontrada.' });

  try {
    const assinatura = await definirAssinatura(lojaId, { plano, status, valido_ate });
    const situacao = await obterSituacaoPlano(lojaId);
    return res.json({ assinatura, situacao });
  } catch (erro) {
    if (erro.message === 'plano_invalido') return res.status(400).json({ erro: 'Plano inválido.' });
    if (erro.message === 'status_invalido') return res.status(400).json({ erro: 'Status inválido.' });
    if (erro.message === 'validade_invalida') return res.status(400).json({ erro: 'Data de validade inválida.' });
    console.error('[admin] falha ao atualizar assinatura:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Não foi possível atualizar a assinatura.' });
  }
}

async function operacao(req, res) {
  try {
    const fila = {};
    for (const status of ['pendente', 'processando', 'enviado', 'falhou']) {
      const { count, error } = await supabase.from('whatsapp_fila_processamento')
        .select('id', { count: 'exact', head: true }).eq('status', status);
      if (error) throw error;
      fila[status] = count || 0;
    }
    const { diagnosticarConfiguracao } = require('../config/producao');
    const { obterEstadoWorker } = require('../services/whatsappWorker.service');
    const asaas = require('../services/asaas.service');
    return res.json({ versao: '12A', fila, worker: obterEstadoWorker(),
      configuracao: diagnosticarConfiguracao(),
      cobranca: { ambiente: asaas.ambiente(), configurado: asaas.configurado(), webhook: asaas.webhookConfigurado() } });
  } catch (_) {
    return res.status(503).json({ erro: 'Diagnóstico indisponível. Verifique o banco e as migrations aplicadas.' });
  }
}

module.exports = { me, listarEmpresas, atualizarAssinatura, operacao };

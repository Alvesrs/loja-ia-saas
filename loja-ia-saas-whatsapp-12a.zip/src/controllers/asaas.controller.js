const { criarCheckoutAssinatura, processarEventoAsaas, configurado, webhookConfigurado, webhookValido, ambiente } = require('../services/asaas.service');

async function criarCheckout(req, res) {
  try {
    const plano = String(req.body?.plano || '').trim();
    const resultado = await criarCheckoutAssinatura({ lojaId: req.params.lojaId, planoCodigo: plano });
    return res.status(201).json(resultado);
  } catch (erro) {
    if (erro.message === 'asaas_nao_configurado') return res.status(503).json({ erro: 'Cobrança automática ainda não está configurada.' });
    if (erro.message === 'plano_nao_vendavel') return res.status(400).json({ erro: 'Este plano não pode ser comprado.' });
    if (erro.message === 'preco_nao_configurado') return res.status(503).json({ erro: 'O preço deste plano ainda não foi configurado.' });
    console.error('[asaas] falha ao criar checkout:', erro?.name || 'erro');
    return res.status(502).json({ erro: 'Não foi possível iniciar o pagamento agora.' });
  }
}

function statusIntegracao(req, res) {
  return res.json({ provedor: 'asaas', configurado: configurado(), webhook_configurado: webhookConfigurado(), ambiente: ambiente() });
}

async function receberNotificacao(req, res) {
  if (!webhookConfigurado()) return res.status(503).json({ erro: 'Webhook não configurado.' });
  if (!webhookValido(req.headers['asaas-access-token'])) return res.status(401).json({ erro: 'Token de webhook inválido.' });
  try {
    const resultado = await processarEventoAsaas(req.body || {});
    return res.status(200).json({ ok: true, ...resultado });
  } catch (erro) {
    if (erro.message === 'evento_invalido') return res.status(400).json({ erro: 'Evento de cobrança inválido.' });
    console.error('[asaas webhook] falha ao sincronizar cobrança:', erro?.name || 'erro');
    return res.status(500).json({ erro: 'Falha ao sincronizar cobrança.' });
  }
}

module.exports = { criarCheckout, statusIntegracao, receberNotificacao };

const express = require('express');
const { exigirLogin } = require('../middleware/auth');
const { exigirAdmin } = require('../middleware/admin');
const controller = require('../controllers/admin.controller');

const router = express.Router();
router.use(exigirLogin);
router.get('/me', controller.me);
router.get('/operacao', exigirAdmin, controller.operacao);
router.get('/empresas', exigirAdmin, controller.listarEmpresas);
router.put('/lojas/:lojaId/assinatura', exigirAdmin, controller.atualizarAssinatura);
module.exports = router;

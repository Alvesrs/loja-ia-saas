const supabase = require('../config/supabase');
const { obterPlano, diasTrial } = require('../config/planos');

function inicioDoMesUtc(agora = new Date()) {
  return new Date(Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth(), 1, 0, 0, 0, 0));
}

function fimDoMesUtc(agora = new Date()) {
  return new Date(Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth() + 1, 1, 0, 0, 0, 0));
}

function assinaturaEstaValida(assinatura, agora = new Date()) {
  if (!assinatura || assinatura.status !== 'ativo') return false;
  if (!assinatura.valido_ate) return true;
  const validade = new Date(assinatura.valido_ate);
  return !Number.isNaN(validade.getTime()) && validade.getTime() >= agora.getTime();
}

async function buscarAssinaturaAtual(lojaId) {
  const { data, error } = await supabase
    .from('assinaturas')
    .select('id, loja_id, plano, status, valido_ate, criado_em, atualizado_em, provedor_pagamento, provider_assinatura_id, provider_status')
    .eq('loja_id', lojaId)
    .order('criado_em', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data || null;
}

async function criarTrialParaLoja(lojaId, agora = new Date()) {
  const validade = new Date(agora.getTime() + diasTrial() * 24 * 60 * 60 * 1000);
  const { data, error } = await supabase
    .from('assinaturas')
    .insert({ loja_id: lojaId, plano: 'trial', status: 'ativo', valido_ate: validade.toISOString(), atualizado_em: agora.toISOString() })
    .select('id, loja_id, plano, status, valido_ate, criado_em, atualizado_em, provedor_pagamento, provider_assinatura_id, provider_status')
    .single();
  if (error) throw error;
  return data;
}

async function contarMensagensSaidaNoMes(lojaId, agora = new Date()) {
  const inicio = inicioDoMesUtc(agora).toISOString();
  const fim = fimDoMesUtc(agora).toISOString();
  const { count, error } = await supabase
    .from('whatsapp_mensagens')
    .select('id', { count: 'exact', head: true })
    .eq('loja_id', lojaId)
    .eq('direcao', 'saida')
    .gte('criado_em', inicio)
    .lt('criado_em', fim);
  if (error) throw error;
  return Number(count || 0);
}

async function obterSituacaoPlano(lojaId, agora = new Date()) {
  const assinatura = await buscarAssinaturaAtual(lojaId);

  // Compatibilidade com lojas anteriores à 11A: não derruba produção.
  // O admin pode atribuir um plano depois; até lá ficam marcadas como legado.
  if (!assinatura) {
    return {
      assinatura: null,
      plano: { codigo: 'legado', nome: 'Legado', limiteMensagensMes: null },
      statusEfetivo: 'ativo',
      ativo: true,
      usadoNoMes: await contarMensagensSaidaNoMes(lojaId, agora),
      restanteNoMes: null,
      motivoBloqueio: null,
    };
  }

  const plano = obterPlano(assinatura.plano) || { codigo: assinatura.plano, nome: assinatura.plano, limiteMensagensMes: 0 };
  const ativo = assinaturaEstaValida(assinatura, agora) && Boolean(obterPlano(assinatura.plano));
  const usadoNoMes = await contarMensagensSaidaNoMes(lojaId, agora);
  const limite = plano.limiteMensagensMes;
  const excedeu = limite !== null && usadoNoMes >= limite;
  let motivoBloqueio = null;
  if (!ativo) motivoBloqueio = assinatura.status !== 'ativo' ? 'assinatura_inativa' : 'assinatura_expirada';
  else if (excedeu) motivoBloqueio = 'limite_mensal_atingido';

  return {
    assinatura,
    plano,
    statusEfetivo: ativo ? (excedeu ? 'limite_atingido' : 'ativo') : 'inativo',
    ativo: ativo && !excedeu,
    usadoNoMes,
    restanteNoMes: limite === null ? null : Math.max(0, limite - usadoNoMes),
    motivoBloqueio,
  };
}

async function definirAssinatura(lojaId, { plano, status, valido_ate, provedor_pagamento, provider_assinatura_id, provider_status }) {
  if (!obterPlano(plano)) throw new Error('plano_invalido');
  if (!['ativo', 'inativo', 'cancelado'].includes(status)) throw new Error('status_invalido');
  if (valido_ate !== null && valido_ate !== undefined && Number.isNaN(new Date(valido_ate).getTime())) throw new Error('validade_invalida');

  const existente = await buscarAssinaturaAtual(lojaId);
  const payload = {
    plano,
    status,
    valido_ate: valido_ate || null,
    atualizado_em: new Date().toISOString(),
    ...(provedor_pagamento !== undefined ? { provedor_pagamento } : {}),
    ...(provider_assinatura_id !== undefined ? { provider_assinatura_id } : {}),
    ...(provider_status !== undefined ? { provider_status } : {}),
  };

  let consulta;
  if (existente) {
    consulta = supabase.from('assinaturas').update(payload).eq('id', existente.id).eq('loja_id', lojaId);
  } else {
    consulta = supabase.from('assinaturas').insert({ loja_id: lojaId, ...payload });
  }
  const { data, error } = await consulta.select('id, loja_id, plano, status, valido_ate, criado_em, atualizado_em, provedor_pagamento, provider_assinatura_id, provider_status').single();
  if (error) throw error;
  return data;
}

module.exports = {
  inicioDoMesUtc,
  fimDoMesUtc,
  assinaturaEstaValida,
  buscarAssinaturaAtual,
  criarTrialParaLoja,
  contarMensagensSaidaNoMes,
  obterSituacaoPlano,
  definirAssinatura,
};

const supabase = require('../config/supabase');
const { obterPlano } = require('../config/planos');
const { definirAssinatura, buscarAssinaturaAtual } = require('./assinaturas.service');

function ambiente() {
  return String(process.env.ASAAS_ENVIRONMENT || 'sandbox').toLowerCase() === 'production' ? 'production' : 'sandbox';
}

function apiBase() {
  return ambiente() === 'production' ? 'https://api.asaas.com' : 'https://api-sandbox.asaas.com';
}

function configurado() {
  return Boolean(process.env.ASAAS_API_KEY && process.env.PUBLIC_BASE_URL);
}

function webhookConfigurado() {
  return Boolean(process.env.ASAAS_WEBHOOK_AUTH_TOKEN);
}

function normalizarBaseUrl() {
  return String(process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, '');
}

function webhookValido(recebido) {
  const esperado = String(process.env.ASAAS_WEBHOOK_AUTH_TOKEN || '');
  const valor = String(recebido || '');
  if (!esperado || !valor) return false;
  const a = Buffer.from(esperado);
  const b = Buffer.from(valor);
  return a.length === b.length && require('node:crypto').timingSafeEqual(a, b);
}

async function chamarAsaas(caminho, opcoes = {}) {
  const token = process.env.ASAAS_API_KEY;
  if (!token) throw new Error('asaas_nao_configurado');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.ASAAS_TIMEOUT_MS || 20000));
  try {
    const resposta = await fetch(`${apiBase()}${caminho}`, {
      ...opcoes,
      signal: controller.signal,
      headers: {
        access_token: token,
        'Content-Type': 'application/json',
        'User-Agent': `LojaIASaaS/11H (Node.js; ${ambiente()})`,
        ...(opcoes.headers || {}),
      },
    });
    const texto = await resposta.text();
    let dados = {};
    try { dados = texto ? JSON.parse(texto) : {}; } catch { dados = {}; }
    if (!resposta.ok) {
      const erro = new Error('asaas_api_erro');
      erro.status = resposta.status;
      erro.dados = dados;
      const detalhes = Array.isArray(dados?.errors) ? dados.errors.map((e) => ({ code: String(e?.code || ''), description: String(e?.description || '') })) : [];
      console.error('[asaas] API rejeitou requisição', { status: resposta.status });
      throw erro;
    }
    return dados;
  } finally {
    clearTimeout(timer);
  }
}

function formatarDataHoraAsaas(data = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${data.getFullYear()}-${pad(data.getMonth() + 1)}-${pad(data.getDate())} ${pad(data.getHours())}:${pad(data.getMinutes())}:${pad(data.getSeconds())}`;
}

function parseExternalReference(ref) {
  const texto = String(ref || '');
  return {
    lojaId: /(?:^|\|)loja:([^|]+)/.exec(texto)?.[1] || null,
    plano: /(?:^|\|)plano:([^|]+)/.exec(texto)?.[1] || null,
  };
}

async function criarCheckoutAssinatura({ lojaId, planoCodigo }) {
  if (!configurado()) throw new Error('asaas_nao_configurado');
  const plano = obterPlano(planoCodigo);
  if (!plano || !plano.vendavel) throw new Error('plano_nao_vendavel');
  if (!plano.precoMensalCentavos) throw new Error('preco_nao_configurado');

  const base = normalizarBaseUrl();
  const externalReference = `loja:${lojaId}|plano:${planoCodigo}|v:11g`;
  const payload = {
    billingTypes: ['CREDIT_CARD'],
    chargeTypes: ['RECURRENT'],
    minutesToExpire: 60,
    externalReference,
    callback: {
      successUrl: `${base}/painel/plano.html?checkout=sucesso`,
      cancelUrl: `${base}/painel/plano.html?checkout=cancelado`,
      expiredUrl: `${base}/painel/plano.html?checkout=expirado`,
    },
    items: [{
      name: `Plano ${plano.nome}`,
      description: `Assinatura mensal Loja IA SaaS - Plano ${plano.nome}`,
      quantity: 1,
      value: plano.precoMensalCentavos / 100,
    }],
    subscription: {
      cycle: 'MONTHLY',
      nextDueDate: formatarDataHoraAsaas(new Date(Date.now() + 5 * 60 * 1000)),
    },
  };

  const checkout = await chamarAsaas('/v3/checkouts', { method: 'POST', body: JSON.stringify(payload) });
  if (!checkout.id) throw new Error('asaas_resposta_invalida');
  const checkoutId = String(checkout.id);
  const checkoutUrl = checkout.link || `https://asaas.com/checkoutSession/show?id=${encodeURIComponent(checkoutId)}`;

  const { error } = await supabase.from('cobrancas_assinaturas').insert({
    loja_id: lojaId,
    plano: planoCodigo,
    provedor: 'asaas',
    provider_checkout_id: checkoutId,
    provider_assinatura_id: null,
    status_provider: String(checkout.status || 'ACTIVE'),
    checkout_url: checkoutUrl,
    payer_email: null,
    external_reference: externalReference,
    atualizado_em: new Date().toISOString(),
  });
  if (error) throw error;

  return { checkout_url: checkoutUrl, provider_checkout_id: checkoutId, status: String(checkout.status || 'ACTIVE'), ambiente: ambiente() };
}

async function registrarEventoSeNovo(eventoId, tipo) {
  if (!eventoId) return true;
  const { data, error } = await supabase.from('cobranca_webhook_eventos').insert({
    provedor: 'asaas',
    evento_id: String(eventoId),
    tipo: String(tipo || 'desconhecido'),
  }).select('id').maybeSingle();
  if (!error) return Boolean(data);
  // PostgreSQL unique violation: evento já processado.
  if (String(error.code || '') === '23505') return false;
  throw error;
}

async function localizarCobranca({ checkoutId, assinaturaId, externalReference }) {
  let consulta = supabase.from('cobrancas_assinaturas').select('*').eq('provedor', 'asaas');
  if (checkoutId) consulta = consulta.eq('provider_checkout_id', String(checkoutId));
  else if (assinaturaId) consulta = consulta.eq('provider_assinatura_id', String(assinaturaId));
  else if (externalReference) consulta = consulta.eq('external_reference', String(externalReference));
  else return null;
  const { data, error } = await consulta.order('criado_em', { ascending: false }).limit(1).maybeSingle();
  if (error) throw error;
  return data || null;
}

async function atualizarCobranca(id, patch) {
  if (!id) return;
  const { error } = await supabase.from('cobrancas_assinaturas').update({ ...patch, atualizado_em: new Date().toISOString() }).eq('id', id);
  if (error) throw error;
}

function checkoutIdDoPagamento(pagamento = {}) {
  const bruto = pagamento.checkoutSession || pagamento.checkout?.id || null;
  return bruto ? String(bruto) : null;
}

async function localizarCobrancaPorAssinaturaRemota(assinaturaId) {
  if (!assinaturaId) return null;
  const resposta = await chamarAsaas(`/v3/payments?subscription=${encodeURIComponent(String(assinaturaId))}&limit=20`, { method: 'GET' });
  const pagamentos = Array.isArray(resposta?.data) ? resposta.data : [];
  for (const pagamento of pagamentos) {
    const checkoutId = checkoutIdDoPagamento(pagamento);
    const externalReference = pagamento?.externalReference ? String(pagamento.externalReference) : null;
    const cobranca = await localizarCobranca({ checkoutId, externalReference });
    if (cobranca) return cobranca;
  }
  return null;
}

async function ativarPlano({ lojaId, plano, assinaturaId = null, providerStatus }) {
  return definirAssinatura(lojaId, {
    plano,
    status: 'ativo',
    valido_ate: null,
    provedor_pagamento: 'asaas',
    provider_assinatura_id: assinaturaId,
    provider_status: providerStatus || null,
  });
}

async function aplicarEventoAsaas(payload) {
  const tipo = String(payload?.event || '');


  if (tipo.startsWith('CHECKOUT_')) {
    const checkout = payload?.checkout || {};
    const checkoutId = checkout.id ? String(checkout.id) : null;
    const ref = checkout.externalReference || null;
    let cobranca = await localizarCobranca({ checkoutId, externalReference: ref });
    const refDados = parseExternalReference(ref || cobranca?.external_reference);
    if (!cobranca && refDados.lojaId && refDados.plano) {
      cobranca = { loja_id: refDados.lojaId, plano: refDados.plano, id: null };
    }
    if (!cobranca?.loja_id || !obterPlano(cobranca.plano)) return { ignorado: true };

    if (cobranca.id) await atualizarCobranca(cobranca.id, { status_provider: tipo.replace('CHECKOUT_', '') });
    if (tipo === 'CHECKOUT_PAID') {
      const assinatura = await ativarPlano({ lojaId: cobranca.loja_id, plano: cobranca.plano, providerStatus: 'CHECKOUT_PAID' });
      return { atualizado: true, assinatura };
    }
    return { atualizado: false, status: tipo };
  }

  if (tipo.startsWith('SUBSCRIPTION_')) {
    const sub = payload?.subscription || {};
    const assinaturaId = sub.id ? String(sub.id) : null;
    const ref = sub.externalReference || null;
    let cobranca = await localizarCobranca({ assinaturaId, externalReference: ref });
    if (!cobranca && assinaturaId) cobranca = await localizarCobrancaPorAssinaturaRemota(assinaturaId);
    const refDados = parseExternalReference(ref || cobranca?.external_reference);
    if (!cobranca && refDados.lojaId && refDados.plano) cobranca = { loja_id: refDados.lojaId, plano: refDados.plano, id: null };
    if (!cobranca?.loja_id || !obterPlano(cobranca.plano)) return { ignorado: true };

    if (cobranca.id) await atualizarCobranca(cobranca.id, { provider_assinatura_id: assinaturaId, status_provider: String(sub.status || tipo) });
    const atual = await buscarAssinaturaAtual(cobranca.loja_id);
    if (tipo === 'SUBSCRIPTION_INACTIVATED' || String(sub.status || '').toUpperCase() === 'INACTIVE') {
      const assinatura = await definirAssinatura(cobranca.loja_id, { plano: cobranca.plano, status: 'inativo', valido_ate: atual?.valido_ate || null, provedor_pagamento: 'asaas', provider_assinatura_id: assinaturaId, provider_status: sub.status || tipo });
      return { atualizado: true, assinatura };
    }
    if (tipo === 'SUBSCRIPTION_DELETED' || sub.deleted === true) {
      const assinatura = await definirAssinatura(cobranca.loja_id, { plano: cobranca.plano, status: 'cancelado', valido_ate: atual?.valido_ate || null, provedor_pagamento: 'asaas', provider_assinatura_id: assinaturaId, provider_status: sub.status || tipo });
      return { atualizado: true, assinatura };
    }
    return { atualizado: Boolean(cobranca.id), status: sub.status || tipo };
  }

  if (tipo.startsWith('PAYMENT_')) {
    const pagamento = payload?.payment || {};
    const assinaturaId = pagamento.subscription ? String(pagamento.subscription) : null;
    if (!assinaturaId) return { ignorado: true };
    const checkoutId = checkoutIdDoPagamento(pagamento);
    const ref = pagamento.externalReference ? String(pagamento.externalReference) : null;
    let cobranca = await localizarCobranca({ assinaturaId });
    if (!cobranca && checkoutId) cobranca = await localizarCobranca({ checkoutId });
    if (!cobranca && ref) cobranca = await localizarCobranca({ externalReference: ref });
    if (!cobranca) cobranca = await localizarCobrancaPorAssinaturaRemota(assinaturaId);
    if (!cobranca?.loja_id || !obterPlano(cobranca.plano)) return { ignorado: true };
    if (cobranca.id) await atualizarCobranca(cobranca.id, { provider_assinatura_id: assinaturaId, status_provider: tipo });

    if (['PAYMENT_CONFIRMED', 'PAYMENT_RECEIVED'].includes(tipo)) {
      const assinatura = await ativarPlano({ lojaId: cobranca.loja_id, plano: cobranca.plano, assinaturaId, providerStatus: tipo });
      return { atualizado: true, assinatura };
    }
    if (['PAYMENT_OVERDUE', 'PAYMENT_CREDIT_CARD_CAPTURE_REFUSED', 'PAYMENT_REFUNDED', 'PAYMENT_CHARGEBACK_REQUESTED'].includes(tipo)) {
      const atual = await buscarAssinaturaAtual(cobranca.loja_id);
      if (atual?.provider_assinatura_id === assinaturaId) {
        const assinatura = await definirAssinatura(cobranca.loja_id, { plano: cobranca.plano, status: 'inativo', valido_ate: atual?.valido_ate || null, provedor_pagamento: 'asaas', provider_assinatura_id: assinaturaId, provider_status: tipo });
        return { atualizado: true, assinatura };
      }
    }
    return { atualizado: false, status: tipo };
  }

  return { ignorado: true };
}

// Serializa nesta instância; o marcador persistente representa conclusão, não tentativa.
// Reexecuções após queda repetem atribuições de estado; este caminho nunca cria cobrança.
let processamentoAnterior = Promise.resolve();
function processarEventoAsaas(payload) {
  const executar = async () => {
    if (typeof payload?.id !== 'string' || !payload.id.trim() || payload.id.length > 255 ||
        typeof payload?.event !== 'string' || !payload.event.trim()) throw new Error('evento_invalido');
    const { data, error } = await supabase.from('cobranca_webhook_eventos').select('id')
      .eq('provedor', 'asaas').eq('evento_id', payload.id).maybeSingle();
    if (error) throw error;
    if (data) return { duplicado: true };
    const resultado = await aplicarEventoAsaas(payload);
    await registrarEventoSeNovo(payload.id, payload.event);
    return resultado;
  };
  const atual = processamentoAnterior.then(executar);
  processamentoAnterior = atual.catch(() => {});
  return atual;
}

module.exports = {
  ambiente,
  apiBase,
  configurado,
  webhookConfigurado,
  webhookValido,
  formatarDataHoraAsaas,
  parseExternalReference,
  criarCheckoutAssinatura,
  processarEventoAsaas,
};

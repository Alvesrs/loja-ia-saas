/**
 * Headers de segurança básicos, sem depender de biblioteca externa
 * (equivalente a um subconjunto mínimo do que o "helmet" faria).
 */
function segurancaHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  if (req.path?.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
}

module.exports = { segurancaHeaders };

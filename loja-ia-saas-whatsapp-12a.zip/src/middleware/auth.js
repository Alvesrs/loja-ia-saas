const supabase = require('../config/supabase');

/**
 * Middleware de autenticação.
 * Espera um header: Authorization: Bearer <token>
 * O token é obtido pelo lojista ao fazer login (Supabase Auth).
 * Se válido, anexa o usuário autenticado em req.usuario.
 */
async function exigirLogin(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ erro: 'Token de autenticação ausente.' });
  }

  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data?.user) {
      return res.status(401).json({ erro: 'Token inválido ou expirado.' });
    }
    req.usuario = data.user;
    return next();
  } catch (_) {
    return res.status(503).json({ erro: 'Autenticação indisponível. Tente novamente em instantes.' });
  }
}

module.exports = { exigirLogin };

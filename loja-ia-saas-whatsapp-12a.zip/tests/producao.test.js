const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {
  OBRIGATORIAS_PRODUCAO,
  diagnosticarConfiguracao,
  validarConfiguracaoDeProducao,
  chaveMestraValida,
} = require('../src/config/producao');

const RAIZ = path.join(__dirname, '..');
const chave = crypto.randomBytes(32).toString('base64');

function envValido() {
  return {
    NODE_ENV: 'production',
    SUPABASE_URL: 'https://projeto.supabase.co',
    SUPABASE_SERVICE_ROLE_KEY: 'service-role-falsa-de-teste',
    META_APP_SECRET: 'app-secret-falso-de-teste',
    META_WHATSAPP_VERIFY_TOKEN: 'verify-token-falso-de-teste',
    WHATSAPP_CREDENTIALS_MASTER_KEY: chave,
  };
}

test('10R: produção exige todas as variáveis críticas sem exigir LLM', () => {
  const d = diagnosticarConfiguracao(envValido(), { producao: true });
  assert.equal(d.ok, true);
  assert.deepEqual([...OBRIGATORIAS_PRODUCAO].sort(), [
    'META_APP_SECRET',
    'META_WHATSAPP_VERIFY_TOKEN',
    'SUPABASE_SERVICE_ROLE_KEY',
    'SUPABASE_URL',
    'WHATSAPP_CREDENTIALS_MASTER_KEY',
  ].sort());
  assert.ok(d.avisos.some((x) => x.includes('fallback determinístico')));
});

test('10R: configuração ausente falha fechada em produção', () => {
  const d = diagnosticarConfiguracao({ NODE_ENV: 'production' }, { producao: true });
  assert.equal(d.ok, false);
  for (const nome of OBRIGATORIAS_PRODUCAO) assert.ok(d.erros.some((e) => e.includes(nome)));
  assert.throws(() => validarConfiguracaoDeProducao({ NODE_ENV: 'production' }), /Configuração de produção inválida/);
});

test('10R: chave mestra precisa ser Base64 de exatamente 32 bytes', () => {
  assert.equal(chaveMestraValida(chave), true);
  assert.equal(chaveMestraValida(crypto.randomBytes(31).toString('base64')), false);
  assert.equal(chaveMestraValida('nao-e-base64-valido***'), false);
});

test('10R: URLs externas configuradas devem usar HTTPS', () => {
  const env = envValido();
  env.SUPABASE_URL = 'http://projeto.supabase.co';
  env.LLM_PROVIDER_API_KEY = 'fake';
  env.LLM_PROVIDER_URL = 'http://llm.exemplo/v1/chat/completions';
  const d = diagnosticarConfiguracao(env, { producao: true });
  assert.equal(d.ok, false);
  assert.ok(d.erros.some((e) => e.includes('SUPABASE_URL')));
  assert.ok(d.erros.some((e) => e.includes('LLM_PROVIDER_URL')));
});

test('10R: LLM parcialmente configurado gera aviso e não imprime a chave', () => {
  const env = envValido();
  env.LLM_PROVIDER_API_KEY = 'segredo-que-nao-pode-sair';
  const d = diagnosticarConfiguracao(env, { producao: true });
  assert.equal(d.ok, true);
  assert.ok(d.avisos.some((e) => e.includes('LLM incompleto')));
  assert.equal(JSON.stringify(d).includes(env.LLM_PROVIDER_API_KEY), false);
});

test('10R: readiness e liveness são públicas e não expõem variáveis secretas', () => {
  const code = fs.readFileSync(path.join(RAIZ, 'src/routes/health.routes.js'), 'utf8');
  assert.match(code, /router\.get\('\/live'/);
  assert.match(code, /router\.get\('\/ready'/);
  assert.match(code, /res\.status\(config\.ok \? 200 : 503\)/);
  assert.equal(/config\.(erros|avisos)/.test(code), false);
  assert.equal(/SERVICE_ROLE_KEY|META_APP_SECRET|ACCESS_TOKEN|MASTER_KEY/.test(code), false);
});

test('10R: servidor valida produção antes de abrir porta e encerra worker no shutdown', () => {
  const code = fs.readFileSync(path.join(RAIZ, 'src/server.js'), 'utf8');
  assert.ok(code.indexOf('validarConfiguracaoDeProducao(process.env)') < code.indexOf('app.listen'));
  assert.match(code, /pararWorker\(\)/);
  assert.match(code, /SIGTERM/);
  assert.match(code, /SIGINT/);
});

test('10R: pacote inclui check de produção e documentação final do dono', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(RAIZ, 'package.json'), 'utf8'));
  assert.equal(pkg.version, '12.0.0');
  assert.equal(pkg.scripts['check:producao'], 'node scripts/check-producao.js');
  assert.equal(fs.existsSync(path.join(RAIZ, 'docs/ETAPA-10R.md')), true);
  assert.equal(fs.existsSync(path.join(RAIZ, 'docs/GUIA-DONO-PRODUCAO.md')), true);
});

// Gerencia a sessão do lojista no navegador.
//
// Importante: aqui só guardamos o access_token que o Supabase Auth emite
// para ESTE usuário após login (via POST /api/auth/login, já existente).
// Nunca a SERVICE_ROLE_KEY — essa fica só no backend (src/config/supabase.js)
// e nunca é enviada ao navegador.

const SESSION_KEY = 'lojaia_sessao';

function salvarSessao(usuario, token) {
  limparSessao();
  localStorage.setItem(SESSION_KEY, JSON.stringify({ usuario, token }));
}

function obterSessao() {
  try {
    const bruto = localStorage.getItem(SESSION_KEY);
    return bruto ? JSON.parse(bruto) : null;
  } catch (e) {
    return null;
  }
}

function obterToken() {
  const sessao = obterSessao();
  return sessao ? sessao.token : null;
}

function obterUsuario() {
  const sessao = obterSessao();
  return sessao ? sessao.usuario : null;
}

function limparSessao() {
  localStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem('lojaia_loja_atual');
  localStorage.removeItem('lojaia_loja_atual_id');
}

function estaAutenticado() {
  return !!obterToken();
}

function caminhoRelativo(destino) {
  // Todas as páginas do painel vivem em /painel/, então links relativos
  // simples (ex: "login.html") funcionam a partir de qualquer uma delas.
  return destino;
}

function fazerLogout() {
  limparSessao();
  window.location.href = caminhoRelativo('login.html');
}

// Mudança de conta em outra aba invalida o contexto aberto nesta aba.
window.addEventListener('storage', (event) => {
  if (event.key === SESSION_KEY) {
    sessionStorage.removeItem('lojaia_loja_atual');
    window.location.href = caminhoRelativo('login.html');
  }
});

// Controller da página Estoque. Consome os endpoints já existentes:
//   GET   /api/lojas/:lojaId/produtos                                (traz produto + estoque aninhado)
//   POST  /api/lojas/:lojaId/produtos/:produtoId/estoque              (cria/atualiza uma variação — upsert)
//   PATCH /api/lojas/:lojaId/produtos/:produtoId/estoque/:estoqueId   (atualiza a quantidade)
//
// Não existe endpoint de listagem dedicado para estoque: reaproveitamos
// GET /produtos, que já devolve `estoque: [...]` por produto (ver
// src/controllers/produtos.controller.js). Isso evita criar uma segunda
// forma de buscar os mesmos dados.
//
// O :lojaId nunca é escolhido pelo usuário: vem de obterLojaAtual(). A
// autorização de verdade (usuário → loja → produto → estoque) é sempre
// feita pelo backend — o frontend só usa os IDs que o próprio backend
// devolveu nas respostas anteriores.

const LIMITE_ESTOQUE_BAIXO = 2; // 0 = sem estoque; 1–2 = baixo; 3+ = normal

let lojaAtualId = null;
let produtosCache = [];
let termoBusca = '';
let filtroAtual = 'todos'; // 'todos' | 'com' | 'sem'
let requisicaoVariacaoEmAndamento = false;
const chipsSalvando = new Set(); // ids de estoque com PATCH em andamento

const listaEl = document.getElementById('lista-estoque');
const estadoVazioEl = document.getElementById('estado-vazio');
const estadoSemResultadosEl = document.getElementById('estado-sem-resultados');
const estadoErroEl = document.getElementById('estado-erro');
const estadoSemLojaEl = document.getElementById('estado-sem-loja');
const buscaWrapEl = document.getElementById('busca-wrap');
const campoBuscaEl = document.getElementById('campo-busca');
const mensagemErroEl = document.getElementById('mensagem-erro');
const filtroChipsEl = document.getElementById('filtro-chips');

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function iconeSalvar() {
  return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
}

// ---------- Ordenação de tamanhos ----------
// Tamanhos são texto livre no banco (não há enum rígido). Damos uma ordem
// razoável para tamanhos-padrão de roupa e caímos para ordem numérica ou
// alfabética quando o valor não é um dos conhecidos.
const ORDEM_TAMANHOS_CONHECIDOS = ['PP', 'P', 'M', 'G', 'GG', 'XG', 'XXG'];

function ordenarTamanhos(a, b) {
  const ia = ORDEM_TAMANHOS_CONHECIDOS.indexOf(a.toUpperCase());
  const ib = ORDEM_TAMANHOS_CONHECIDOS.indexOf(b.toUpperCase());
  if (ia !== -1 && ib !== -1) return ia - ib;
  if (ia !== -1) return -1;
  if (ib !== -1) return 1;
  const na = Number(a);
  const nb = Number(b);
  if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
  return a.localeCompare(b, 'pt-BR');
}

// ---------- Estados da tela ----------

function mostrarSomente(id) {
  ['lista-estoque', 'skeleton-estoque', 'estado-vazio', 'estado-sem-resultados', 'estado-erro', 'estado-sem-loja'].forEach((elId) => {
    const el = document.getElementById(elId);
    if (el) el.classList.toggle('hidden', elId !== id);
  });
}

function mostrarCarregando() {
  buscaWrapEl.classList.add('hidden');
  filtroChipsEl.classList.add('hidden');
  mostrarSomente('skeleton-estoque');
}

function mostrarErro(mensagem) {
  buscaWrapEl.classList.add('hidden');
  filtroChipsEl.classList.add('hidden');
  mensagemErroEl.textContent = mensagem;
  mostrarSomente('estado-erro');
}

function mostrarSemLoja() {
  buscaWrapEl.classList.add('hidden');
  filtroChipsEl.classList.add('hidden');
  mostrarSomente('estado-sem-loja');
}

// ---------- Carregar ----------

async function carregarEstoque() {
  mostrarCarregando();
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      mostrarSemLoja();
      return;
    }
    lojaAtualId = loja.id;
    produtosCache = await apiFetch(`/lojas/${lojaAtualId}/produtos`);
    renderizarLista();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErro(erro.message || 'Não foi possível carregar o estoque agora.');
  }
}

// ---------- Filtragem ----------

function totalEstoque(produto) {
  if (!Array.isArray(produto.estoque)) return 0;
  return produto.estoque.reduce((soma, item) => soma + (item.quantidade || 0), 0);
}

function produtosFiltrados() {
  let lista = produtosCache;

  if (filtroAtual === 'com') {
    lista = lista.filter((p) => totalEstoque(p) > 0);
  } else if (filtroAtual === 'sem') {
    lista = lista.filter((p) => totalEstoque(p) === 0);
  }

  const termo = termoBusca.trim().toLowerCase();
  if (termo) {
    lista = lista.filter((p) => p.nome.toLowerCase().includes(termo));
  }

  return lista;
}

// ---------- Render ----------

function renderizarChipVariacao(produto, item) {
  const qtd = item.quantidade;
  let classeEstado = '';
  let statusTexto = '';
  if (qtd === 0) {
    classeEstado = 'zerado';
    statusTexto = 'Sem estoque';
  } else if (qtd <= LIMITE_ESTOQUE_BAIXO) {
    classeEstado = 'baixo';
    statusTexto = 'Estoque baixo';
  }

  return `
    <div class="estoque-chip ${classeEstado}" data-estoque-id="${item.id}">
      <span class="estoque-chip-tamanho">${escaparHtml(item.tamanho)}</span>
      <input
        type="number"
        min="0"
        step="1"
        inputmode="numeric"
        value="${qtd}"
        data-quantidade-original="${qtd}"
        aria-label="Quantidade de ${escaparHtml(item.tamanho)} ${escaparHtml(item.cor)}"
      >
      <button type="button" class="estoque-chip-salvar" data-acao="salvar-quantidade" title="Salvar quantidade" disabled>
        ${iconeSalvar()}
      </button>
      <span class="estoque-chip-status">${statusTexto || `${qtd} unidade${qtd === 1 ? '' : 's'}`}</span>
    </div>`;
}

function agruparPorCor(estoque) {
  const grupos = new Map();
  for (const item of estoque) {
    const cor = item.cor;
    if (!grupos.has(cor)) grupos.set(cor, []);
    grupos.get(cor).push(item);
  }
  for (const itens of grupos.values()) {
    itens.sort((a, b) => ordenarTamanhos(a.tamanho, b.tamanho));
  }
  return grupos;
}

function renderizarCard(produto) {
  const estoque = Array.isArray(produto.estoque) ? produto.estoque : [];
  const total = totalEstoque(produto);

  let corpoHtml;
  if (estoque.length === 0) {
    corpoHtml = `<p class="estoque-sem-variacao">Nenhuma variação cadastrada para este produto.</p>`;
  } else {
    const grupos = agruparPorCor(estoque);
    corpoHtml = Array.from(grupos.entries())
      .map(
        ([cor, itens]) => `
        <div class="estoque-cor-grupo">
          <span class="estoque-cor-nome">${escaparHtml(cor)}</span>
          <div class="estoque-variacoes">
            ${itens.map((item) => renderizarChipVariacao(produto, item)).join('')}
          </div>
        </div>`
      )
      .join('');
  }

  return `
    <div class="estoque-card" data-produto-id="${produto.id}">
      <div class="estoque-card-header">
        <div>
          <h3>${escaparHtml(produto.nome)}</h3>
          <div class="estoque-card-total">${total} unidade${total === 1 ? '' : 's'} no total</div>
        </div>
        <button type="button" class="btn-secondary small" data-acao="adicionar-variacao">+ Adicionar variação</button>
      </div>
      ${corpoHtml}
    </div>`;
}

function renderizarLista() {
  buscaWrapEl.classList.remove('hidden');
  filtroChipsEl.classList.remove('hidden');

  if (produtosCache.length === 0) {
    mostrarSomente('estado-vazio');
    return;
  }

  const filtrados = produtosFiltrados();

  if (filtrados.length === 0) {
    mostrarSomente('estado-sem-resultados');
    return;
  }

  listaEl.innerHTML = `<div class="estoque-lista">${filtrados.map(renderizarCard).join('')}</div>`;
  mostrarSomente('lista-estoque');
}

// ---------- Busca e filtros ----------

campoBuscaEl.addEventListener('input', (evento) => {
  termoBusca = evento.target.value;
  if (produtosCache.length > 0) renderizarLista();
});

filtroChipsEl.addEventListener('click', (evento) => {
  const botao = evento.target.closest('button[data-filtro]');
  if (!botao) return;
  filtroAtual = botao.dataset.filtro;
  filtroChipsEl.querySelectorAll('.filtro-chip').forEach((el) => el.classList.toggle('ativo', el === botao));
  if (produtosCache.length > 0) renderizarLista();
});

// ---------- Editar quantidade (inline) ----------

listaEl.addEventListener('input', (evento) => {
  const input = evento.target;
  if (input.tagName !== 'INPUT' || input.type !== 'number') return;
  const chip = input.closest('.estoque-chip');
  const botaoSalvar = chip.querySelector('[data-acao="salvar-quantidade"]');
  const original = input.dataset.quantidadeOriginal;
  const valor = input.value;
  const mudou = valor !== '' && valor !== original;
  botaoSalvar.disabled = !mudou || chipsSalvando.has(chip.dataset.estoqueId);
  botaoSalvar.classList.toggle('pronto', mudou);
  input.classList.remove('invalido');
});

listaEl.addEventListener('click', async (evento) => {
  const botaoSalvar = evento.target.closest('[data-acao="salvar-quantidade"]');
  if (botaoSalvar) return salvarQuantidade(botaoSalvar);

  const botaoAdicionar = evento.target.closest('[data-acao="adicionar-variacao"]');
  if (botaoAdicionar) {
    const card = botaoAdicionar.closest('.estoque-card');
    const produto = produtosCache.find((p) => p.id === card.dataset.produtoId);
    if (produto) abrirModalVariacao(produto);
  }
});

async function salvarQuantidade(botaoSalvar) {
  const chip = botaoSalvar.closest('.estoque-chip');
  const card = botaoSalvar.closest('.estoque-card');
  const estoqueId = chip.dataset.estoqueId;
  const produtoId = card.dataset.produtoId;
  const input = chip.querySelector('input[type="number"]');

  if (chipsSalvando.has(estoqueId)) return; // evita envio duplicado durante carregamento

  const quantidade = interpretarQuantidade(input.value);
  if (quantidade === null) {
    input.classList.add('invalido');
    mostrarToast('Informe uma quantidade inteira maior ou igual a zero.', 'erro');
    return;
  }

  chipsSalvando.add(estoqueId);
  botaoSalvar.disabled = true;
  input.disabled = true;

  try {
    const atualizado = await apiFetch(`/lojas/${lojaAtualId}/produtos/${produtoId}/estoque/${estoqueId}`, {
      method: 'PATCH',
      body: JSON.stringify({ quantidade }),
    });

    const produto = produtosCache.find((p) => p.id === produtoId);
    if (produto) {
      const item = produto.estoque.find((e) => e.id === estoqueId);
      if (item) item.quantidade = atualizado.quantidade;
    }
    mostrarToast('Quantidade atualizada.', 'sucesso');
    renderizarLista();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    input.disabled = false;
    input.classList.add('invalido');
    botaoSalvar.disabled = false;
    mostrarToast(erro.message || 'Não foi possível atualizar a quantidade.', 'erro');
  } finally {
    chipsSalvando.delete(estoqueId);
  }
}

function interpretarQuantidade(texto) {
  if (texto === '' || texto === null || texto === undefined) return null;
  if (!/^\d+$/.test(String(texto).trim())) return null; // só inteiro não-negativo
  const numero = Number(texto);
  if (!Number.isInteger(numero) || numero < 0) return null;
  return numero;
}

// ---------- Nova variação (modal) ----------

document.getElementById('botao-nova-variacao').addEventListener('click', () => {
  if (produtosCache.length === 0) {
    mostrarToast('Cadastre um produto antes de adicionar uma variação de estoque.', 'erro');
    return;
  }
  abrirModalVariacao(null);
});

function tamanhosConhecidos() {
  const set = new Set();
  produtosCache.forEach((p) => (p.estoque || []).forEach((e) => set.add(e.tamanho)));
  return Array.from(set);
}

function coresConhecidas() {
  const set = new Set();
  produtosCache.forEach((p) => (p.estoque || []).forEach((e) => set.add(e.cor)));
  return Array.from(set);
}

function abrirModalVariacao(produtoPreSelecionado) {
  const produtosDisponiveis = produtosCache;
  const opcoesProduto = produtosDisponiveis
    .map((p) => `<option value="${p.id}" ${produtoPreSelecionado && p.id === produtoPreSelecionado.id ? 'selected' : ''}>${escaparHtml(p.nome)}</option>`)
    .join('');

  const html = `
    <h2>Nova variação</h2>
    <p>Adicione uma combinação de tamanho e cor com sua quantidade inicial.</p>
    <div id="erro-form-variacao" class="error-msg hidden" role="alert"></div>
    <form id="form-variacao" novalidate>
      <div class="field">
        <label for="campo-produto">Produto *</label>
        <select id="campo-produto" required ${produtoPreSelecionado ? 'disabled' : ''}>
          ${opcoesProduto}
        </select>
      </div>
      <div class="form-row duas-colunas">
        <div class="field">
          <label for="campo-tamanho">Tamanho *</label>
          <input type="text" id="campo-tamanho" list="lista-tamanhos" maxlength="20" placeholder="Ex: M, 40" required>
          <datalist id="lista-tamanhos">
            ${tamanhosConhecidos().map((t) => `<option value="${escaparHtml(t)}">`).join('')}
          </datalist>
          <div class="field-error hidden" id="erro-tamanho"></div>
        </div>
        <div class="field">
          <label for="campo-cor">Cor *</label>
          <input type="text" id="campo-cor" list="lista-cores" maxlength="40" placeholder="Ex: Preta" required>
          <datalist id="lista-cores">
            ${coresConhecidas().map((c) => `<option value="${escaparHtml(c)}">`).join('')}
          </datalist>
          <div class="field-error hidden" id="erro-cor"></div>
        </div>
      </div>
      <div class="field">
        <label for="campo-quantidade">Quantidade *</label>
        <input type="number" id="campo-quantidade" min="0" step="1" inputmode="numeric" value="0" required>
        <div class="field-error hidden" id="erro-quantidade"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="botao-cancelar-variacao">Cancelar</button>
        <button type="submit" class="btn-primary small" id="botao-salvar-variacao">Adicionar variação</button>
      </div>
    </form>`;

  const { fechar } = abrirModal(html);
  const form = document.getElementById('form-variacao');
  document.getElementById('botao-cancelar-variacao').addEventListener('click', fechar);

  // Se veio de um produto sem itens ainda cadastrados na página, o select
  // desabilitado precisa mesmo assim expressar o produto certo — o value
  // já foi marcado via `selected` acima. Foco no primeiro campo livre.
  (document.getElementById('campo-tamanho')).focus();

  form.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    if (requisicaoVariacaoEmAndamento) return;

    const produtoId = produtoPreSelecionado ? produtoPreSelecionado.id : document.getElementById('campo-produto').value;
    const tamanho = document.getElementById('campo-tamanho').value.trim();
    const cor = document.getElementById('campo-cor').value.trim();
    const quantidade = interpretarQuantidade(document.getElementById('campo-quantidade').value);

    const erroTamanhoEl = document.getElementById('erro-tamanho');
    const erroCorEl = document.getElementById('erro-cor');
    const erroQuantidadeEl = document.getElementById('erro-quantidade');
    [erroTamanhoEl, erroCorEl, erroQuantidadeEl].forEach((el) => el.classList.add('hidden'));
    ['campo-tamanho', 'campo-cor', 'campo-quantidade'].forEach((id) => document.getElementById(id).classList.remove('invalido'));

    const erroFormEl = document.getElementById('erro-form-variacao');
    let valido = true;
    if (!produtoId) {
      erroFormEl.textContent = 'Selecione um produto.';
      erroFormEl.classList.remove('hidden');
      valido = false;
    }
    if (!tamanho) {
      erroTamanhoEl.textContent = 'Informe o tamanho.';
      erroTamanhoEl.classList.remove('hidden');
      document.getElementById('campo-tamanho').classList.add('invalido');
      valido = false;
    }
    if (!cor) {
      erroCorEl.textContent = 'Informe a cor.';
      erroCorEl.classList.remove('hidden');
      document.getElementById('campo-cor').classList.add('invalido');
      valido = false;
    }
    if (quantidade === null) {
      erroQuantidadeEl.textContent = 'Informe uma quantidade inteira maior ou igual a zero.';
      erroQuantidadeEl.classList.remove('hidden');
      document.getElementById('campo-quantidade').classList.add('invalido');
      valido = false;
    }
    if (!valido) return;

    // Aviso amigável de possível duplicação: o backend já resolve isso
    // com upsert (produto_id, tamanho, cor) — nunca cria uma segunda
    // linha —, mas avisamos antes de enviar para que o lojista saiba que
    // vai atualizar a quantidade existente em vez de criar uma nova.
    const produto = produtosCache.find((p) => p.id === produtoId);
    const existente = produto && (produto.estoque || []).find(
      (e) => e.tamanho.trim().toLowerCase() === tamanho.toLowerCase() && e.cor.trim().toLowerCase() === cor.toLowerCase()
    );
    if (existente) {
      const ok = await confirmar({
        titulo: 'Essa variação já existe',
        mensagem: `"${produto.nome}" já tem ${tamanho} / ${cor} com ${existente.quantidade} unidade(s). Deseja atualizar a quantidade para ${quantidade}?`,
        textoConfirmar: 'Atualizar quantidade',
      });
      if (!ok) return;
    }

    const botaoSalvar = document.getElementById('botao-salvar-variacao');
    erroFormEl.classList.add('hidden');

    requisicaoVariacaoEmAndamento = true;
    botaoSalvar.disabled = true;
    botaoSalvar.textContent = 'Salvando…';

    try {
      const resultado = await apiFetch(`/lojas/${lojaAtualId}/produtos/${produtoId}/estoque`, {
        method: 'POST',
        body: JSON.stringify({ tamanho, cor, quantidade }),
      });

      if (produto) {
        const indiceExistente = (produto.estoque || []).findIndex((e) => e.id === resultado.id);
        if (indiceExistente >= 0) {
          produto.estoque[indiceExistente] = resultado;
        } else {
          produto.estoque = [...(produto.estoque || []), resultado];
        }
      }

      mostrarToast(existente ? 'Quantidade atualizada.' : 'Variação adicionada.', 'sucesso');
      renderizarLista();
      fechar();
    } catch (erro) {
      if (erro instanceof SessaoExpiradaError) return fazerLogout();
      erroFormEl.textContent = erro.message || 'Não foi possível salvar a variação.';
      erroFormEl.classList.remove('hidden');
    } finally {
      requisicaoVariacaoEmAndamento = false;
      botaoSalvar.disabled = false;
      botaoSalvar.textContent = 'Adicionar variação';
    }
  });
}

// ---------- Início ----------

montarLayout('estoque');
carregarEstoque();

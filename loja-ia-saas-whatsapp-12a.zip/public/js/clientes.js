// Controller da página Clientes. Consome os endpoints já existentes:
//   GET    /api/lojas/:lojaId/clientes
//   POST   /api/lojas/:lojaId/clientes
//   PATCH  /api/lojas/:lojaId/clientes/:clienteId
//   DELETE /api/lojas/:lojaId/clientes/:clienteId
//
// O :lojaId nunca é escolhido pelo usuário: vem de obterLojaAtual(), que
// por sua vez lista só as lojas do usuário autenticado (GET /api/lojas).
// A autorização de verdade continua sendo feita pelo backend
// (exigirDonoDaLoja) — o frontend não decide isso.
//
// A busca é feita aqui no frontend, sobre a lista já carregada (mesmo
// padrão de produtos.js) — não há endpoint de busca separado nem
// paginação nesta primeira versão, pois o volume de clientes de uma
// loja pequena não justifica essa complexidade ainda.

let lojaAtualId = null;
let clientesCache = [];
let termoBusca = '';
let requisicaoEmAndamento = false;

const listaEl = document.getElementById('lista-clientes');
const estadoVazioEl = document.getElementById('estado-vazio');
const estadoErroEl = document.getElementById('estado-erro');
const estadoSemLojaEl = document.getElementById('estado-sem-loja');
const buscaWrapEl = document.getElementById('busca-wrap');
const campoBuscaEl = document.getElementById('campo-busca');
const mensagemErroEl = document.getElementById('mensagem-erro');

function icone(nome) {
  const icones = {
    editar: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>',
    lixeira: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
    busca: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',
    pessoas: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 21v-1a7 7 0 0 1 14 0v1"/><path d="M17 11a4 4 0 1 0 0-8"/><path d="M22 21v-1a7 7 0 0 0-5-6.7"/></svg>',
    alerta: '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v5"/><path d="M12 16h.01"/></svg>',
  };
  return icones[nome] || '';
}

// ---------- Estados da tela ----------

function mostrarSomente(id) {
  ['lista-clientes', 'skeleton-clientes', 'estado-vazio', 'estado-erro', 'estado-sem-loja'].forEach((elId) => {
    const el = document.getElementById(elId);
    if (el) el.classList.toggle('hidden', elId !== id);
  });
}

function mostrarCarregando() {
  buscaWrapEl.classList.add('hidden');
  mostrarSomente('skeleton-clientes');
}

function mostrarErro(mensagem) {
  buscaWrapEl.classList.add('hidden');
  mensagemErroEl.textContent = mensagem;
  mostrarSomente('estado-erro');
}

function mostrarSemLoja() {
  buscaWrapEl.classList.add('hidden');
  mostrarSomente('estado-sem-loja');
}

// ---------- Carregar ----------

async function carregarClientes() {
  mostrarCarregando();
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      mostrarSemLoja();
      return;
    }
    lojaAtualId = loja.id;
    clientesCache = await apiFetch(`/lojas/${lojaAtualId}/clientes`);
    renderizarLista();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErro(erro.message || 'Não foi possível carregar os clientes agora.');
  }
}

function clientesFiltrados() {
  if (!termoBusca.trim()) return clientesCache;
  const termo = termoBusca.trim().toLowerCase();
  return clientesCache.filter((c) => {
    const nome = (c.nome || '').toLowerCase();
    const telefone = (c.telefone || '').toLowerCase();
    const email = (c.email || '').toLowerCase();
    return nome.includes(termo) || telefone.includes(termo) || email.includes(termo);
  });
}

function formatarData(dataIso) {
  if (!dataIso) return '—';
  const data = new Date(dataIso);
  if (Number.isNaN(data.getTime())) return '—';
  return data.toLocaleDateString('pt-BR');
}

function renderizarLinha(cliente) {
  return `
    <div class="cliente-linha" data-id="${cliente.id}">
      <div>
        <div class="cliente-nome">${escaparHtml(cliente.nome)}</div>
      </div>
      <div class="cliente-meta">
        <span>${cliente.telefone ? escaparHtml(cliente.telefone) : '—'}</span>
      </div>
      <div class="cliente-meta">
        <span>${cliente.email ? escaparHtml(cliente.email) : '—'}</span>
      </div>
      <div class="cliente-meta">
        <span>${formatarData(cliente.criado_em)}</span>
      </div>
      <div class="cliente-acoes">
        <button type="button" class="icon-btn" data-acao="editar" title="Editar cliente" aria-label="Editar ${escaparHtml(cliente.nome)}">${icone('editar')}</button>
        <button type="button" class="icon-btn perigo" data-acao="excluir" title="Excluir cliente" aria-label="Excluir ${escaparHtml(cliente.nome)}">${icone('lixeira')}</button>
      </div>
    </div>`;
}

function renderizarLista() {
  buscaWrapEl.classList.remove('hidden');
  const filtrados = clientesFiltrados();

  if (clientesCache.length === 0) {
    mostrarSomente('estado-vazio');
    return;
  }

  if (filtrados.length === 0) {
    listaEl.innerHTML = `
      <div class="cliente-lista">
        <div class="state-box">
          ${icone('busca')}
          <p class="state-title">Nenhum cliente encontrado</p>
          <p>Tente buscar por outro nome, telefone ou email.</p>
        </div>
      </div>`;
    mostrarSomente('lista-clientes');
    return;
  }

  listaEl.innerHTML = `
    <div class="cliente-lista">
      <div class="cliente-lista-head">
        <span>Cliente</span><span>Telefone</span><span>Email</span><span>Cadastro</span><span></span>
      </div>
      ${filtrados.map(renderizarLinha).join('')}
    </div>`;
  mostrarSomente('lista-clientes');
}

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ---------- Busca ----------

campoBuscaEl.addEventListener('input', (evento) => {
  termoBusca = evento.target.value;
  if (clientesCache.length > 0) renderizarLista();
});

// ---------- Ações da lista (detalhes / editar / excluir) ----------

listaEl.addEventListener('click', async (evento) => {
  const linha = evento.target.closest('.cliente-linha');
  if (!linha) return;
  const clienteId = linha.dataset.id;
  const cliente = clientesCache.find((c) => c.id === clienteId);
  if (!cliente) return;

  const botao = evento.target.closest('button[data-acao]');
  if (!botao) return abrirDetalhesCliente(cliente);

  const acao = botao.dataset.acao;
  if (acao === 'editar') return abrirModalCliente(cliente);
  if (acao === 'excluir') return excluirCliente(cliente);
});

async function excluirCliente(cliente) {
  const ok = await confirmar({
    titulo: 'Excluir cliente?',
    mensagem: `Essa ação é permanente e remove "${cliente.nome}" da sua lista de clientes. Não é possível desfazer.`,
    textoConfirmar: 'Excluir',
    perigo: true,
  });
  if (!ok) return;

  try {
    await apiFetch(`/lojas/${lojaAtualId}/clientes/${cliente.id}`, { method: 'DELETE' });
    clientesCache = clientesCache.filter((c) => c.id !== cliente.id);
    renderizarLista();
    mostrarToast('Cliente excluído.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    // Se no futuro a exclusão passar a ser bloqueada por vínculo com
    // pedidos (regra de banco), a API devolve uma mensagem genérica de
    // referência inválida (ver src/utils/erros.js) — traduzimos aqui sem
    // inventar comportamento novo no backend.
    const mensagem = /referência inválida/i.test(erro.message || '')
      ? 'Este cliente não pode ser excluído porque já tem pedidos vinculados.'
      : (erro.message || 'Não foi possível excluir o cliente.');
    mostrarToast(mensagem, 'erro');
  }
}

// ---------- Detalhes ----------

function abrirDetalhesCliente(cliente) {
  const html = `
    <h2>${escaparHtml(cliente.nome)}</h2>
    <p>Dados do cliente.</p>
    <div class="cliente-detalhes">
      <dl>
        <dt>Nome</dt><dd>${escaparHtml(cliente.nome)}</dd>
        <dt>Telefone</dt><dd>${cliente.telefone ? escaparHtml(cliente.telefone) : '—'}</dd>
        <dt>Email</dt><dd>${cliente.email ? escaparHtml(cliente.email) : '—'}</dd>
        <dt>Cadastrado em</dt><dd>${formatarData(cliente.criado_em)}</dd>
      </dl>
      <div class="aviso-em-breve">Histórico de pedidos — em breve</div>
    </div>
    <div class="modal-actions">
      <button type="button" class="btn-secondary" id="botao-fechar-detalhes">Fechar</button>
      <button type="button" class="btn-primary small" id="botao-editar-detalhes">Editar</button>
    </div>`;

  const { fechar } = abrirModal(html);
  document.getElementById('botao-fechar-detalhes').addEventListener('click', fechar);
  document.getElementById('botao-editar-detalhes').addEventListener('click', () => {
    fechar();
    abrirModalCliente(cliente);
  });
}

// ---------- Criar / editar ----------

document.getElementById('botao-novo-cliente').addEventListener('click', () => abrirModalCliente(null));
document.getElementById('botao-primeiro-cliente').addEventListener('click', () => abrirModalCliente(null));

function abrirModalCliente(clienteExistente) {
  const editando = !!clienteExistente;
  const html = `
    <h2>${editando ? 'Editar cliente' : 'Novo cliente'}</h2>
    <p>${editando ? 'Atualize os dados deste cliente.' : 'Preencha os dados do cliente para adicioná-lo à sua lista.'}</p>
    <div id="erro-form-cliente" class="error-msg hidden" role="alert"></div>
    <form id="form-cliente" novalidate>
      <div class="form-row">
        <div class="field">
          <label for="campo-nome">Nome *</label>
          <input type="text" id="campo-nome" maxlength="200" value="${editando ? escaparHtml(clienteExistente.nome) : ''}" required>
          <div class="field-error hidden" id="erro-nome"></div>
        </div>
        <div class="field">
          <label for="campo-telefone">Telefone</label>
          <input type="text" id="campo-telefone" maxlength="30" inputmode="tel" placeholder="(11) 99999-8888" value="${editando && clienteExistente.telefone ? escaparHtml(clienteExistente.telefone) : ''}">
          <div class="field-error hidden" id="erro-telefone"></div>
        </div>
        <div class="field">
          <label for="campo-email">Email</label>
          <input type="text" id="campo-email" maxlength="200" inputmode="email" placeholder="cliente@exemplo.com" value="${editando && clienteExistente.email ? escaparHtml(clienteExistente.email) : ''}">
          <div class="field-error hidden" id="erro-email"></div>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="botao-cancelar-cliente">Cancelar</button>
        <button type="submit" class="btn-primary small" id="botao-salvar-cliente">${editando ? 'Salvar alterações' : 'Adicionar cliente'}</button>
      </div>
    </form>`;

  const { fechar } = abrirModal(html);
  const form = document.getElementById('form-cliente');
  document.getElementById('botao-cancelar-cliente').addEventListener('click', fechar);
  document.getElementById('campo-nome').focus();

  form.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    if (requisicaoEmAndamento) return;

    const nome = document.getElementById('campo-nome').value.trim();
    const telefone = document.getElementById('campo-telefone').value.trim();
    const email = document.getElementById('campo-email').value.trim();

    const erroNomeEl = document.getElementById('erro-nome');
    const erroTelefoneEl = document.getElementById('erro-telefone');
    const erroEmailEl = document.getElementById('erro-email');
    const nomeInputEl = document.getElementById('campo-nome');
    const telefoneInputEl = document.getElementById('campo-telefone');
    const emailInputEl = document.getElementById('campo-email');

    [erroNomeEl, erroTelefoneEl, erroEmailEl].forEach((el) => el.classList.add('hidden'));
    [nomeInputEl, telefoneInputEl, emailInputEl].forEach((el) => el.classList.remove('invalido'));

    let valido = true;
    if (!nome) {
      erroNomeEl.textContent = 'Informe o nome do cliente.';
      erroNomeEl.classList.remove('hidden');
      nomeInputEl.classList.add('invalido');
      valido = false;
    }

    // Validação leve, só para pegar erros óbvios de digitação — a
    // validação de verdade (autoridade) é sempre feita pelo backend.
    if (telefone && !/^[0-9+()\-\s]{8,30}$/.test(telefone)) {
      erroTelefoneEl.textContent = 'Informe um telefone válido, com DDD.';
      erroTelefoneEl.classList.remove('hidden');
      telefoneInputEl.classList.add('invalido');
      valido = false;
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      erroEmailEl.textContent = 'Informe um email válido.';
      erroEmailEl.classList.remove('hidden');
      emailInputEl.classList.add('invalido');
      valido = false;
    }

    if (!valido) return;

    const corpo = {
      nome,
      telefone: telefone || null,
      email: email || null,
    };

    const botaoSalvar = document.getElementById('botao-salvar-cliente');
    const erroFormEl = document.getElementById('erro-form-cliente');
    erroFormEl.classList.add('hidden');

    requisicaoEmAndamento = true;
    botaoSalvar.disabled = true;
    botaoSalvar.textContent = editando ? 'Salvando…' : 'Adicionando…';

    try {
      if (editando) {
        const atualizado = await apiFetch(`/lojas/${lojaAtualId}/clientes/${clienteExistente.id}`, {
          method: 'PATCH',
          body: JSON.stringify(corpo),
        });
        const indice = clientesCache.findIndex((c) => c.id === clienteExistente.id);
        if (indice >= 0) clientesCache[indice] = { ...clientesCache[indice], ...atualizado };
        mostrarToast('Cliente atualizado.', 'sucesso');
      } else {
        const criado = await apiFetch(`/lojas/${lojaAtualId}/clientes`, {
          method: 'POST',
          body: JSON.stringify(corpo),
        });
        clientesCache = [criado, ...clientesCache];
        mostrarToast('Cliente adicionado.', 'sucesso');
      }
      renderizarLista();
      fechar();
    } catch (erro) {
      if (erro instanceof SessaoExpiradaError) return fazerLogout();
      erroFormEl.textContent = erro.message || 'Não foi possível salvar o cliente.';
      erroFormEl.classList.remove('hidden');
    } finally {
      requisicaoEmAndamento = false;
      botaoSalvar.disabled = false;
      botaoSalvar.textContent = editando ? 'Salvar alterações' : 'Adicionar cliente';
    }
  });
}

// ---------- Início ----------

montarLayout('clientes');
carregarClientes();

let planosAdmin = [];
let paginaAdmin = 1;
let buscaAdmin = "";
let adminCarregando = false;

function escapar(texto) { return escaparTexto(texto); }
function dataInput(valor) { if (!valor) return ''; const d=new Date(valor); return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0,10); }

async function salvarAssinatura(lojaId, elemento) {
  const plano = elemento.querySelector('[data-plano]').value;
  if (!plano) { mostrarToast('Escolha um plano comercial antes de salvar.', 'erro'); return; }
  const status = elemento.querySelector('[data-status]').value;
  const validade = elemento.querySelector('[data-validade]').value;
  const botao = elemento.querySelector('[data-salvar]');
  if (!await confirmar({ titulo: 'Alterar assinatura?', mensagem: 'Isso altera o acesso desta empresa no aplicativo. Não cancela nem altera a cobrança no Asaas.', textoConfirmar: 'Salvar alteração' })) return;
  botao.disabled = true;
  try {
    await apiFetch(`/admin/lojas/${lojaId}/assinatura`, { method:'PUT', body:JSON.stringify({ plano, status, valido_ate: validade ? `${validade}T23:59:59.999Z` : null }) });
    mostrarToast('Assinatura atualizada.');
    await carregarAdmin();
  } catch(e) { if (e instanceof SessaoExpiradaError) return fazerLogout(); mostrarToast(e.message || 'Falha ao atualizar.', 'erro'); }
  finally { botao.disabled = false; }
}

function renderEmpresa(item) {
  const a=item.situacao.assinatura; const p=item.situacao.plano;
  const planoDisponivel = planosAdmin.some((x) => x.codigo === p.codigo);
  const opcaoAtual = planoDisponivel ? '' : `<option value="" selected disabled>${escapar(p.nome)} (sem plano comercial)</option>`;
  const opPlanos=opcaoAtual + planosAdmin.map(x=>`<option value="${x.codigo}" ${x.codigo===p.codigo?'selected':''}>${x.nome}</option>`).join('');
  const status=a?.status || 'ativo';
  return `<article class="admin-company" data-loja="${item.loja.id}"><div class="admin-company-main"><div><h3>${escapar(item.loja.nome)}</h3><p>${item.situacao.usadoNoMes.toLocaleString('pt-BR')} mensagens da IA neste mês · ${p.limiteMensagensMes===null?'sem franquia fixa':`limite ${p.limiteMensagensMes.toLocaleString('pt-BR')}`}</p></div><span class="badge ${item.situacao.ativo?'badge-green':'badge-red'}">${item.situacao.statusEfetivo.replace('_',' ')}</span></div><div class="admin-form-row"><label>Plano<select data-plano>${opPlanos}</select></label><label>Status<select data-status><option value="ativo" ${status==='ativo'?'selected':''}>Ativo</option><option value="inativo" ${status==='inativo'?'selected':''}>Inativo</option><option value="cancelado" ${status==='cancelado'?'selected':''}>Cancelado</option></select></label><label>Válido até<input type="date" data-validade value="${dataInput(a?.valido_ate)}"></label><button class="btn-primary small" data-salvar>Salvar</button></div></article>`;
}

async function carregarAdmin() {
  if (adminCarregando) return;
  adminCarregando = true;
  document.getElementById('admin-lista').setAttribute('aria-busy', 'true');
  const erro=document.getElementById('admin-erro'), lista=document.getElementById('admin-lista'), resumo=document.getElementById('admin-resumo');
  erro.classList.add('hidden');
  try {
    const perfil=await apiFetch('/admin/me');
    if (!perfil.admin) { window.location.href='dashboard.html'; return; }
    const dados=await apiFetch(`/admin/empresas?pagina=${paginaAdmin}&busca=${encodeURIComponent(buscaAdmin)}`); planosAdmin=dados.planosDisponiveis || [];
    document.getElementById('admin-pagina').textContent = `Página ${dados.pagina} de ${Math.max(1, dados.totalPaginas)} · ${dados.total} empresas`;
    document.getElementById('admin-anterior').disabled = paginaAdmin <= 1;
    document.getElementById('admin-proxima').disabled = paginaAdmin >= dados.totalPaginas;
    const empresas=dados.empresas || []; const ativas=empresas.filter(e=>e.situacao.ativo).length; const bloqueadas=empresas.length-ativas;
    resumo.innerHTML=`<div class="stat-card"><div class="stat-value">${empresas.length}</div><div class="stat-label">Empresas</div></div><div class="stat-card"><div class="stat-value">${ativas}</div><div class="stat-label">Ativas</div></div><div class="stat-card"><div class="stat-value">${bloqueadas}</div><div class="stat-label">Bloqueadas</div></div>`;
    lista.innerHTML=empresas.length?empresas.map(renderEmpresa).join(''):'<div class="empty-state">Nenhuma empresa cadastrada.</div>';
    lista.querySelectorAll('[data-loja]').forEach(el=>el.querySelector('[data-salvar]').addEventListener('click',()=>salvarAssinatura(el.dataset.loja,el)));
  } catch(e) { if (e instanceof SessaoExpiradaError) return fazerLogout(); erro.textContent=e.message||'Não foi possível carregar o Admin.'; erro.classList.remove('hidden'); lista.innerHTML=''; }
  finally { adminCarregando = false; lista.setAttribute('aria-busy', 'false'); }
}
document.getElementById('admin-recarregar').addEventListener('click',carregarAdmin);
document.getElementById('admin-busca-form').addEventListener('submit', (e) => {
  e.preventDefault(); if (adminCarregando) return;
  buscaAdmin = document.getElementById('admin-busca').value.trim(); paginaAdmin = 1; carregarAdmin();
});
document.getElementById('admin-anterior').addEventListener('click', () => { if (!adminCarregando && paginaAdmin > 1) { paginaAdmin--; carregarAdmin(); } });
document.getElementById('admin-proxima').addEventListener('click', () => { if (!adminCarregando) { paginaAdmin++; carregarAdmin(); } });
async function carregarOperacao() {
  const el = document.getElementById('admin-operacao');
  try {
    const d = await apiFetch('/admin/operacao');
    el.textContent = `${d.versao} · Asaas ${d.cobranca.ambiente === 'sandbox' ? 'em teste (sandbox)' : 'produção'} · Worker ${d.worker.iniciado ? 'ativo' : 'parado'} · Fila: ${d.fila.pendente} pendentes, ${d.fila.processando} processando, ${d.fila.enviado} finalizando e ${d.fila.falhou} com falha. ${d.configuracao.erros.concat(d.configuracao.avisos).join('. ')}`;
  } catch (e) { if (e instanceof SessaoExpiradaError) return fazerLogout(); el.textContent = e.message; }
}
document.getElementById('admin-recarregar').addEventListener('click', carregarOperacao);
montarLayout('admin'); carregarAdmin(); carregarOperacao();

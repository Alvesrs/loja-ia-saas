// Controller da página Produtos. Consome os endpoints já existentes:
//   GET    /api/lojas/:lojaId/produtos
//   POST   /api/lojas/:lojaId/produtos
//   PATCH  /api/lojas/:lojaId/produtos/:produtoId
//   DELETE /api/lojas/:lojaId/produtos/:produtoId
//
// O :lojaId nunca é escolhido pelo usuário: vem de obterLojaAtual(), que
// por sua vez lista só as lojas do usuário autenticado (GET /api/lojas).
// A autorização de verdade continua sendo feita pelo backend
// (exigirDonoDaLoja / exigirProdutoDaLoja) — o frontend não decide isso.

let lojaAtualId = null;
let produtosCache = [];
let termoBusca = '';
let requisicaoEmAndamento = false;

const listaEl = document.getElementById('lista-produtos');
const estadoVazioEl = document.getElementById('estado-vazio');
const estadoErroEl = document.getElementById('estado-erro');
const estadoSemLojaEl = document.getElementById('estado-sem-loja');
const buscaWrapEl = document.getElementById('busca-wrap');
const campoBuscaEl = document.getElementById('campo-busca');
const mensagemErroEl = document.getElementById('mensagem-erro');

function icone(nome) {
  const icones = {
    editar: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>',
    lixeira: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
    energia: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/></svg>',
    busca: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',
    caixa: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 7.3 12 2 3.5 7.3 12 12l8.5-4.7Z"/><path d="M3.5 7.3v9.4L12 22l8.5-5.3V7.3"/><path d="M12 12v10"/></svg>',
    alerta: '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v5"/><path d="M12 16h.01"/></svg>',
  };
  return icones[nome] || '';
}

// ---------- Estados da tela ----------

function mostrarSomente(id) {
  ['lista-produtos', 'skeleton-produtos', 'estado-vazio', 'estado-erro', 'estado-sem-loja'].forEach((elId) => {
    const el = document.getElementById(elId);
    if (el) el.classList.toggle('hidden', elId !== id);
  });
}

function mostrarCarregando() {
  buscaWrapEl.classList.add('hidden');
  mostrarSomente('skeleton-produtos');
}

function mostrarErro(mensagem) {
  buscaWrapEl.classList.add('hidden');
  mensagemErroEl.textContent = mensagem;
  mostrarSomente('estado-erro');
}

function mostrarSemLoja() {
  buscaWrapEl.classList.add('hidden');
  mostrarSomente('estado-sem-loja');
}

// ---------- Carregar ----------

async function carregarProdutos() {
  mostrarCarregando();
  try {
    const loja = await obterLojaAtual();
    if (!loja) {
      mostrarSemLoja();
      return;
    }
    lojaAtualId = loja.id;
    produtosCache = await apiFetch(`/lojas/${lojaAtualId}/produtos`);
    renderizarLista();
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarErro(erro.message || 'Não foi possível carregar os produtos agora.');
  }
}

function produtosFiltrados() {
  if (!termoBusca.trim()) return produtosCache;
  const termo = termoBusca.trim().toLowerCase();
  return produtosCache.filter((p) => p.nome.toLowerCase().includes(termo));
}

function totalEstoque(produto) {
  if (!Array.isArray(produto.estoque)) return null;
  return produto.estoque.reduce((soma, item) => soma + (item.quantidade || 0), 0);
}

function renderizarLinha(produto) {
  const qtd = totalEstoque(produto);
  return `
    <div class="produto-linha" data-id="${produto.id}">
      <div>
        <div class="produto-nome">${escaparHtml(produto.nome)}</div>
        ${produto.descricao ? `<div class="produto-descricao">${escaparHtml(produto.descricao)}</div>` : ''}
      </div>
      <div class="produto-meta">
        <span class="produto-preco">${formatarPrecoBRL(produto.preco)}</span>
        <span class="produto-categoria">${produto.categoria ? escaparHtml(produto.categoria) : '—'}</span>
        <span class="badge ${produto.ativo ? 'badge-ativo' : 'badge-inativo'}">${produto.ativo ? 'Ativo' : 'Inativo'}</span>
        ${qtd !== null ? `<span class="produto-categoria">${qtd} em estoque</span>` : ''}
      </div>
      <div class="produto-acoes">
        <button type="button" class="icon-btn" data-acao="editar" title="Editar produto" aria-label="Editar ${escaparHtml(produto.nome)}">${icone('editar')}</button>
        <button type="button" class="icon-btn" data-acao="alternar" title="${produto.ativo ? 'Desativar' : 'Ativar'} produto" aria-label="${produto.ativo ? 'Desativar' : 'Ativar'} ${escaparHtml(produto.nome)}">${icone('energia')}</button>
        <button type="button" class="icon-btn perigo" data-acao="excluir" title="Excluir produto" aria-label="Excluir ${escaparHtml(produto.nome)}">${icone('lixeira')}</button>
      </div>
    </div>`;
}

function renderizarLista() {
  buscaWrapEl.classList.remove('hidden');
  const filtrados = produtosFiltrados();

  if (produtosCache.length === 0) {
    mostrarSomente('estado-vazio');
    return;
  }

  if (filtrados.length === 0) {
    listaEl.innerHTML = `
      <div class="produto-lista">
        <div class="state-box">
          ${icone('busca')}
          <p class="state-title">Nenhum produto encontrado</p>
          <p>Tente buscar por outro nome.</p>
        </div>
      </div>`;
    mostrarSomente('lista-produtos');
    return;
  }

  listaEl.innerHTML = `
    <div class="produto-lista">
      <div class="produto-lista-head">
        <span>Produto</span><span>Preço</span><span>Categoria</span><span>Status</span><span></span>
      </div>
      ${filtrados.map(renderizarLinha).join('')}
    </div>`;
  mostrarSomente('lista-produtos');
}

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : String(texto);
  return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ---------- Busca ----------

campoBuscaEl.addEventListener('input', (evento) => {
  termoBusca = evento.target.value;
  if (produtosCache.length > 0) renderizarLista();
});

// ---------- Ações da lista (edição / alternar / excluir) ----------

listaEl.addEventListener('click', async (evento) => {
  const botao = evento.target.closest('button[data-acao]');
  if (!botao) return;
  const linha = evento.target.closest('.produto-linha');
  if (!linha) return;
  const produtoId = linha.dataset.id;
  const produto = produtosCache.find((p) => p.id === produtoId);
  if (!produto) return;

  const acao = botao.dataset.acao;
  if (acao === 'editar') return abrirModalProduto(produto);
  if (acao === 'alternar') return alternarAtivo(produto);
  if (acao === 'excluir') return excluirProduto(produto);
});

async function alternarAtivo(produto) {
  const proximoEstado = !produto.ativo;
  const ok = await confirmar({
    titulo: proximoEstado ? 'Ativar produto?' : 'Desativar produto?',
    mensagem: proximoEstado
      ? `"${produto.nome}" voltará a aparecer como disponível.`
      : `"${produto.nome}" deixará de aparecer como disponível para o atendente de IA e nas listagens ativas.`,
    textoConfirmar: proximoEstado ? 'Ativar' : 'Desativar',
  });
  if (!ok) return;

  try {
    const atualizado = await apiFetch(`/lojas/${lojaAtualId}/produtos/${produto.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ ativo: proximoEstado }),
    });
    const indice = produtosCache.findIndex((p) => p.id === produto.id);
    if (indice >= 0) produtosCache[indice] = { ...produtosCache[indice], ...atualizado };
    renderizarLista();
    mostrarToast(proximoEstado ? 'Produto ativado.' : 'Produto desativado.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    mostrarToast(erro.message || 'Não foi possível atualizar o produto.', 'erro');
  }
}

async function excluirProduto(produto) {
  const ok = await confirmar({
    titulo: 'Excluir produto?',
    mensagem: `Essa ação é permanente e remove "${produto.nome}" e seu estoque. Não é possível desfazer.`,
    textoConfirmar: 'Excluir',
    perigo: true,
  });
  if (!ok) return;

  try {
    await apiFetch(`/lojas/${lojaAtualId}/produtos/${produto.id}`, { method: 'DELETE' });
    produtosCache = produtosCache.filter((p) => p.id !== produto.id);
    renderizarLista();
    mostrarToast('Produto excluído.', 'sucesso');
  } catch (erro) {
    if (erro instanceof SessaoExpiradaError) return fazerLogout();
    // Um produto com pedidos vinculados não pode ser excluído (FK do
    // banco). A API devolve uma mensagem genérica de referência
    // inválida (ver src/utils/erros.js) — traduzimos para algo mais
    // claro sem inventar comportamento novo no backend.
    const mensagem = /referência inválida/i.test(erro.message || '')
      ? 'Este produto não pode ser excluído porque já tem estoque ou pedidos vinculados. Desative-o em vez de excluir.'
      : (erro.message || 'Não foi possível excluir o produto.');
    mostrarToast(mensagem, 'erro');
  }
}

// ---------- Criar / editar ----------

document.getElementById('botao-novo-produto').addEventListener('click', () => abrirModalProduto(null));
document.getElementById('botao-primeiro-produto').addEventListener('click', () => abrirModalProduto(null));

function abrirModalProduto(produtoExistente) {
  const editando = !!produtoExistente;
  const html = `
    <h2>${editando ? 'Editar produto' : 'Novo produto'}</h2>
    <p>${editando ? 'Atualize os dados deste produto.' : 'Preencha os dados do produto para adicioná-lo ao catálogo.'}</p>
    <div id="erro-form-produto" class="error-msg hidden" role="alert"></div>
    <form id="form-produto" novalidate>
      <div class="form-row">
        <div class="field">
          <label for="campo-nome">Nome *</label>
          <input type="text" id="campo-nome" maxlength="200" value="${editando ? escaparHtml(produtoExistente.nome) : ''}" required>
          <div class="field-error hidden" id="erro-nome"></div>
        </div>
        <div class="field">
          <label for="campo-descricao">Descrição</label>
          <input type="text" id="campo-descricao" maxlength="500" value="${editando && produtoExistente.descricao ? escaparHtml(produtoExistente.descricao) : ''}">
        </div>
        <div class="form-row duas-colunas">
          <div class="field">
            <label for="campo-preco">Preço *</label>
            <div class="price-input-group" id="preco-grupo">
              <span>R$</span>
              <input type="text" inputmode="decimal" id="campo-preco" placeholder="0,00" value="${editando ? String(produtoExistente.preco).replace('.', ',') : ''}" required>
            </div>
            <div class="field-error hidden" id="erro-preco"></div>
          </div>
          <div class="field">
            <label for="campo-categoria">Categoria</label>
            <input type="text" id="campo-categoria" maxlength="100" value="${editando && produtoExistente.categoria ? escaparHtml(produtoExistente.categoria) : ''}">
          </div>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="botao-cancelar-produto">Cancelar</button>
        <button type="submit" class="btn-primary small" id="botao-salvar-produto">${editando ? 'Salvar alterações' : 'Adicionar produto'}</button>
      </div>
    </form>`;

  const { fechar } = abrirModal(html);
  const form = document.getElementById('form-produto');
  document.getElementById('botao-cancelar-produto').addEventListener('click', fechar);
  document.getElementById('campo-nome').focus();

  form.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    if (requisicaoEmAndamento) return;

    const nome = document.getElementById('campo-nome').value.trim();
    const descricao = document.getElementById('campo-descricao').value.trim();
    const precoTexto = document.getElementById('campo-preco').value;
    const categoria = document.getElementById('campo-categoria').value.trim();

    const erroNomeEl = document.getElementById('erro-nome');
    const erroPrecoEl = document.getElementById('erro-preco');
    const precoGrupoEl = document.getElementById('preco-grupo');
    const nomeInputEl = document.getElementById('campo-nome');

    erroNomeEl.classList.add('hidden');
    erroPrecoEl.classList.add('hidden');
    precoGrupoEl.classList.remove('invalido');
    nomeInputEl.classList.remove('invalido');

    let valido = true;
    if (!nome) {
      erroNomeEl.textContent = 'Informe o nome do produto.';
      erroNomeEl.classList.remove('hidden');
      nomeInputEl.classList.add('invalido');
      valido = false;
    }

    const preco = interpretarPrecoDigitado(precoTexto);
    if (preco === null) {
      erroPrecoEl.textContent = 'Informe um preço válido, maior ou igual a zero.';
      erroPrecoEl.classList.remove('hidden');
      precoGrupoEl.classList.add('invalido');
      valido = false;
    }

    if (!valido) return;

    const corpo = {
      nome,
      descricao: descricao || null,
      preco,
      categoria: categoria || null,
    };

    const botaoSalvar = document.getElementById('botao-salvar-produto');
    const erroFormEl = document.getElementById('erro-form-produto');
    erroFormEl.classList.add('hidden');

    requisicaoEmAndamento = true;
    botaoSalvar.disabled = true;
    botaoSalvar.innerHTML = editando ? 'Salvando…' : 'Adicionando…';

    try {
      if (editando) {
        const atualizado = await apiFetch(`/lojas/${lojaAtualId}/produtos/${produtoExistente.id}`, {
          method: 'PATCH',
          body: JSON.stringify(corpo),
        });
        const indice = produtosCache.findIndex((p) => p.id === produtoExistente.id);
        if (indice >= 0) produtosCache[indice] = { ...produtosCache[indice], ...atualizado };
        mostrarToast('Produto atualizado.', 'sucesso');
      } else {
        const criado = await apiFetch(`/lojas/${lojaAtualId}/produtos`, {
          method: 'POST',
          body: JSON.stringify(corpo),
        });
        produtosCache = [{ ...criado, estoque: [] }, ...produtosCache];
        mostrarToast('Produto adicionado.', 'sucesso');
      }
      renderizarLista();
      fechar();
    } catch (erro) {
      if (erro instanceof SessaoExpiradaError) return fazerLogout();
      erroFormEl.textContent = erro.message || 'Não foi possível salvar o produto.';
      erroFormEl.classList.remove('hidden');
    } finally {
      requisicaoEmAndamento = false;
      botaoSalvar.disabled = false;
      botaoSalvar.textContent = editando ? 'Salvar alterações' : 'Adicionar produto';
    }
  });
}

// ---------- Início ----------

montarLayout('produtos');
carregarProdutos();

# Loja IA SaaS — release 12A

Micro-SaaS de atendimento por WhatsApp, painel de empresas, catálogo/estoque, IA, planos e administração do dono. Consolidação da base 11N em um pacote único. Cobrança Asaas permanece em **sandbox**.

- **Atualização no Railway pelo celular:** [guia do dono](docs/GUIA-DONO-PRODUCAO.md).
- **Mudanças, testes e limitações:** [release 12A](docs/RELEASE-12A.md).
- **Arquitetura:** [documentação técnica](docs/ARQUITETURA.md).
- Documentos das etapas anteriores são histórico; a documentação 12A prevalece quando houver conflito.

## Executar

Requer Node.js 22 ou superior. Dependências têm versões fixas e lockfile.

```sh
npm ci
cp .env.example .env
# Preencha as credenciais no seu ambiente privado.
npm start
```

Painel: `/painel/login.html`. Healthchecks: `/api/health/live` e `/api/health/ready`. A rota `/` informa a versão da API; não é o painel.

```sh
npm test
npm run check:producao
```

O segundo comando requer as configurações reais e não imprime os valores dos segredos. A ausência delas deve reprovar o check. Testes de integração real são separados (`npm run test:integracao`); use um ambiente de teste.

## Atualização 11N → 12A

Substitua os arquivos pelo conteúdo completo deste pacote. Mantenha o projeto Supabase, as variáveis privadas e a chave mestra existentes. **Sem migration nova.** Ajuste a versão Node no Railway para 22, seguindo o guia.

A validação automatizada local não substitui a confirmação de WhatsApp, IA, banco e cobrança sandbox no ambiente hospedado. Consulte os limites operacionais documentados antes de usar cobrança real ou múltiplas réplicas.

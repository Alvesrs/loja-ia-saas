# Etapa 11M — Central de prontidão

O Dashboard passa a orientar a jornada até o atendimento real usando somente sinais existentes:
- Prompt Mestre preenchida;
- configuração Meta ativa com credencial armazenada;
- existência de conversa real processada como evidência do fluxo WhatsApp;
- próxima ação contextual para configurar IA, WhatsApp, testar ou acompanhar conversas.

A central não inventa um health-check externo da Meta e não altera backend, cobrança ou processamento.

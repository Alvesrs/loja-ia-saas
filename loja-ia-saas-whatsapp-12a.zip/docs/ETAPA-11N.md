# Etapa 11N — Teste guiado da IA

Adiciona validação guiada ao Atendente IA:
- perguntas prontas de horário, pagamento, entrega e atendimento humano;
- usa o endpoint real já existente `/ia/perguntar`;
- deixa explícito que o teste não envia WhatsApp;
- confirma visualmente quando a IA respondeu;
- lembra o lojista de revisar a resposta e ajustar a Prompt Mestre.

O estado visual de “testado” é apenas de sessão do navegador; não é usado como prova de integração WhatsApp.

# Guia do dono — atualização única para 12A

Seu fluxo é GitHub → Railway (`backend-prod`) → Supabase já existente. Não é necessário editar código manualmente. O pacote não cria um novo serviço nem um novo banco.

## 1. Atualize o repositório

1. Baixe e extraia `loja-ia-saas-whatsapp-12a.zip` no celular.
2. No repositório que já alimenta `backend-prod`, envie o conteúdo extraído, substituindo os arquivos da 11N. Envie as pastas completas, `package.json`, **package-lock.json** e `railway.json`; não envie apenas o ZIP como um arquivo do repositório.
3. Confira que `package.json` está na raiz onde já estava. Não deixe o projeto dentro de uma pasta extra.
4. Não envie `.env` real, senhas, tokens ou `node_modules`.
5. Confirme o commit. Se o autodeploy estiver ligado, o Railway começará a atualização.

## 2. Confira o Railway

Em `backend-prod`, mantenha todas as variáveis existentes. Ajuste:

| Variável | Valor |
| --- | --- |
| `NIXPACKS_NODE_VERSION` | `22` |
| `RAILPACK_NODE_VERSION` | `22` |
| `ASAAS_ENVIRONMENT` | `sandbox` |
| `NODE_ENV` | `production` |
| `PUBLIC_BASE_URL` | URL HTTPS pública do seu backend, sem `/painel` |
| `SAAS_ADMIN_EMAILS` | E-mail exato da sua conta de dono; vários separados por vírgula |

O exemplo `.env.example` não altera automaticamente as variáveis do Railway. Por isso confira o ambiente de cobrança no próprio serviço.

O `railway.json` define instalação `npm ci --omit=dev`, início `npm start` e healthcheck `/api/health/ready`. Se aparecer incompatibilidade de Node no build, confirme as variáveis acima e faça novo deploy. Mantenha **uma instância** neste lançamento; a cobrança ainda não tem fila distribuída de processamento.

Não troque `WHATSAPP_CREDENTIALS_MASTER_KEY`: os tokens já salvos dependem dela. Não remova as configurações Supabase, Meta ou IA que você já tinha definido.

## 3. Banco

Se a 11N já funciona, **não precisa rodar SQL novo**. A 12A não altera o banco.

Somente para instalação do zero: execute `src/db/schema.sql` em banco vazio. Para um banco de etapa mais antiga, confira quais migrations de `src/db/migrations` já foram aplicadas e execute apenas as faltantes, em ordem, até 011. Nunca use o schema inteiro para atualizar o banco existente sem avaliar o estado real.

## 4. Entre como dono

1. Aguarde o deploy ficar ativo.
2. Abra `https://SEU-DOMINIO/painel/login.html` e entre com o e-mail configurado em `SAAS_ADMIN_EMAILS`.
3. No celular, deslize a barra de navegação inferior até **Admin**.
4. O diagnóstico deve mostrar **12A**, o worker ativo e **Asaas em teste (sandbox)**. Se as consultas da fila falharem, o diagnóstico avisa em vez de inventar contagens.
5. Use a busca para encontrar empresas. Ao alterar um plano, o painel pede confirmação e preserva o vínculo financeiro. Essa edição muda o acesso local; não cancela pagamentos no Asaas.
6. Empresas “Legado” precisam receber um plano comercial antes de serem liberadas comercialmente.

## 5. Validação final, sem editar código

- Abra `/api/health/live` e `/api/health/ready`: ambos precisam responder sem erro. Isso é verificação de processo/configuração, não prova do atendimento completo.
- Confira login, empresa selecionada, produtos, instruções da IA e as telas Plano/Admin no celular.
- Use o teste guiado do Atendente IA. Ele não envia WhatsApp.
- De outro telefone, envie uma mensagem real ao número conectado. Confira recebimento, resposta e histórico da empresa correta.
- Com duas contas de teste de empresas distintas, confira que cada uma só enxerga seus próprios dados. Testes automatizados cobrem isolamento de rotas, mas esta é a confirmação no ambiente real.
- Faça checkout apenas no **sandbox**, com dados de teste do Asaas. Aguarde o webhook e use **Atualizar plano**. Retorno “sucesso” sozinho não ativa o plano.
- Não mude `ASAAS_ENVIRONMENT` para `production`: a liberação de pagamentos reais ainda exige sua autorização e a revisão operacional registrada na release.

Webhook Meta: `https://SEU-DOMINIO/api/webhooks/whatsapp`. Webhook Asaas: `https://SEU-DOMINIO/api/webhooks/asaas`. Preserve os tokens já configurados; nunca os compartilhe em prints.

## 6. Se algo der errado

- **Build:** confira Node 22 e presença do lockfile no GitHub.
- **Healthcheck:** veja os nomes das configurações ausentes nos logs; não publique seus valores.
- **Admin ausente:** confira o e-mail em `SAAS_ADMIN_EMAILS` e entre novamente.
- **Mensagem não chega:** confira configuração Meta/webhook e permissões. Se chega sem resposta, veja Plano e o diagnóstico da fila.
- **Checkout não ativa:** confira sandbox, token do webhook e registros de entrega no Asaas. O painel não deve ativar por URL de sucesso.
- **Falha após atualização:** use o rollback do Railway para a versão anterior. Não houve migration 12A; mantenha o banco e as credenciais. A 11N tem problemas de segurança corrigidos aqui, portanto o rollback é apenas recuperação temporária.

## Operação contínua

Mantenha cópia segura da chave mestra e backups do banco. Acompanhe fila com falhas e cobranças não reconciliadas. O histórico de mensagens não tem remoção automática nesta versão: atenda solicitações de exclusão pelo processo do responsável. A página Ajuda do painel explica os passos ao lojista.

A entrega do ZIP não publica automaticamente o aplicativo nem valida credenciais externas. A ativação só está concluída depois dos testes reais acima.

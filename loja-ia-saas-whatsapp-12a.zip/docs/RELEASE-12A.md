# Release 12A — consolidação após a 11N

Base: `loja-ia-saas-whatsapp-11n.zip`. Este pacote reúne as melhorias de experiência (11O), gestão (11P), revisão técnica (11Q) e entrega (11R). A integração externa permanece sujeita ao teste de ativação abaixo; isto não é certificado de produção comercial.

## O que mudou

- Navegação móvel com acesso a Plano, Nova empresa, Ajuda e Admin (para o dono).
- Central de ajuda com configuração, teste real do WhatsApp, plano e solução de problemas.
- Plano indica sandbox e explica que retornar do checkout não comprova pagamento. Botão para atualizar a situação; URL de checkout restrita a HTTPS no domínio Asaas.
- Admin com busca, paginação de 20 empresas, consultas em lotes limitados e confirmação de alterações. Alterar plano manualmente preserva o vínculo financeiro e não cancela a cobrança no provedor.
- Diagnóstico exclusivo do Admin: contagens da fila, estado do worker, ambiente de cobrança e configuração, sem valores de segredos nem conteúdo das conversas.
- Nomes de empresa passam a ser inseridos como texto no seletor. Confirmações e auxiliares de escape protegem texto e atributos. Login/logout limpa a seleção da conta anterior; mudança de conta em outra aba invalida seu contexto.
- Falhas de rede em autenticação retornam mensagem tratada. Respostas da API têm `Cache-Control: no-store`. Logs genéricos e de rejeição Asaas deixam de imprimir o objeto bruto do erro.
- Eventos Asaas são marcados como concluídos depois da aplicação bem-sucedida. Falhas podem ser tentadas novamente; duplicatas simultâneas são serializadas dentro da mesma instância.
- Um evento de inadimplência associado à assinatura antiga não suspende uma assinatura com outro identificador. Inserção de checkout deixa de usar `onConflict` incompatível com o índice parcial existente.
- Dependências fixadas e `package-lock.json`. Runtime mínimo Node 22; configuração Railway com instalação `npm ci`, início e healthcheck.

## Compatibilidade

Sem alteração de schema ou nova migration. Se o banco está atualizado e funcional na 11N, **não execute SQL para instalar a 12A**. Preserve todas as credenciais existentes, em especial a chave mestra do WhatsApp. Em instalação nova, use o schema completo; em banco antigo, confira as migrations faltantes (001 a 011), sem reaplicar tudo indiscriminadamente.

O banco não foi acessado nem modificado durante esta entrega. O Asaas continua com `ASAAS_ENVIRONMENT=sandbox` no exemplo; nenhuma conta externa foi alterada.

## Evidências

- 642 testes automatizados passam; 12 foram adicionados nesta release com comportamento executado para autorização, falha/repetição de webhook, concorrência local, edição financeira, paginação, texto não confiável, sessão e navegação.
- A suíte herdada mistura testes de comportamento e inspeções de código. Aprovação não equivale a 642 testes reais de integração.
- `npm audit`: zero vulnerabilidades conhecidas nas versões resolvidas na data da entrega. Isso não elimina riscos de lógica da aplicação.
- O relatório de verificação deste pacote complementa estas evidências.

## Limites encontrados na auditoria

1. **Cobrança real ainda não liberada.** Testar checkout e webhook no sandbox. Antes de ativar pagamentos reais, falta validação externa, reconciliação de eventos financeiros fora de ordem e transação/fila distribuída para múltiplas réplicas. Operar inicialmente com uma instância. Não mudar para `production` sem autorização do dono.
2. **WhatsApp não garante exatamente um envio em toda falha.** Se a Meta aceitar a mensagem e o processo cair antes de gravar `enviado`, um retry pode repetir o envio. O estado `enviado` evita repetição depois que foi persistido. Não foi realizada injeção de falha contra a Meta real.
3. **Franquia é contagem do histórico, não reserva transacional.** Trabalhos simultâneos podem ultrapassar marginalmente a franquia. A rota de teste da IA verifica o plano, mas não acrescenta mensagens ao histórico WhatsApp e não consome essa franquia; seus controles de abuso são separados.
4. **Plano legado:** empresas sem assinatura continuam liberadas por compatibilidade. O dono deve atribuir um plano antes de liberar clientes comerciais.
5. **Privacidade:** as páginas e instruções existentes não são uma auditoria jurídica. Há registros no banco e a exclusão é operacional, sem painel automatizado de pedidos de exclusão. O responsável precisa manter um canal real para atender solicitações.
6. **Serviços externos:** credenciais, permissões Meta, webhook, banco real e deploy Railway não foram validados nesta execução. O healthcheck atual valida processo/configuração; o diagnóstico Admin exercita consultas da fila, mas não comprova o caminho completo de envio.

## Critério de ativação

Execute o roteiro de `GUIA-DONO-PRODUCAO.md`. Só considere validado o atendimento quando uma mensagem de outro telefone chegar, a resposta sair e o histórico corresponder à empresa correta. Só considere validada a cobrança sandbox quando a confirmação do Asaas atualizar o plano, sem conceder acesso apenas pelo retorno do navegador.
